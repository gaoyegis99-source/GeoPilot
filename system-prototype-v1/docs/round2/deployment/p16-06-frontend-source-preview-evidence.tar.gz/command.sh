#!/bin/bash
set -euo pipefail
geo_front_source="$1"
geo_front_evidence="$2"
geo_front_cache="$3"
export npm_config_logs_max=0 TMPDIR=/dev/shm
cd "$geo_front_source"
{
  node --version
  npm --version
  uname -sr
  sha256sum package.json package-lock.json
  taskset -pc "$$"
} > "$geo_front_evidence/environment.log"
run() {
  local step="$1"
  shift
  printf '%q ' "$@" >> "$geo_front_evidence/commands.log"
  printf '\n' >> "$geo_front_evidence/commands.log"
  local result=0
  "$@" > "$geo_front_evidence/$step.log" 2>&1 || result=$?
  printf '%s\n' "$result" > "$geo_front_evidence/$step.exit"
  cat "$geo_front_evidence/$step.log"
  return "$result"
}
run install npm ci --include=dev --no-audit --no-fund --offline --cache "$geo_front_cache"
run build npm run build
run test npm test -- --run --maxWorkers=1 --reporter=default --reporter=junit --outputFile.junit="$geo_front_evidence/frontend.xml"
