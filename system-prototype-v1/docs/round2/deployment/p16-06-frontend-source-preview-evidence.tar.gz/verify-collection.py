"""Compare the selected source's backend collection with the earlier six-patch preview."""
import json
from pathlib import Path
import sys
import tarfile

root, perf = (Path(arg) for arg in sys.argv[1:])
from round2_release_manifest import _FIXED_GIS_MAPPING, fixed_gis_cases

def nodes(data):
    selected = [line for line in data.splitlines() if line.startswith("tests/") and "::" in line]
    assert len(selected) == len(set(selected))
    return set(selected)

with tarfile.open(perf / "p13-05-combined-preview-evidence.tar.gz") as archive:
    old = nodes(archive.extractfile("./collection.log").read().decode())
now = nodes((root / "backend-collection.log").read_text())
fixed = {node for group in fixed_gis_cases(Path(_FIXED_GIS_MAPPING).read_bytes()).values() for node in group}
assert len(old) == 2178 and len(now) == 2171 and len(fixed) == 82 and fixed <= now
added, excluded = sorted(now - old), sorted(old - now)
assert len(added) == 2 and all("test_status_poll_error_positions" in node for node in added)
assert len(excluded) == 9 and all(node.startswith("tests/gis/raster/test_area_stats_shared_projection.py::") for node in excluded)
print(json.dumps({"previous_nodes": len(old), "current_nodes": len(now), "matched_fixed_nodes": len(fixed),
                  "added": added, "excluded": excluded}, indent=2))
