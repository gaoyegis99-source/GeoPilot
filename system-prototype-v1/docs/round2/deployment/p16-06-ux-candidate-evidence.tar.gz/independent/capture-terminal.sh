#!/usr/bin/env bash
set -euo pipefail
audit_root=$(cd -- "$(dirname -- "$0")" && pwd)
origin=/dev/shm/geopilot-p16-ux-candidate.eNUiU7SX
exit_code=$(cat "$origin/exit-code")
[[ "$exit_code" =~ ^[0-9]+$ ]]
if test -e /proc/992168/stat; then
  proc_state=$(awk '{print $3}' /proc/992168/stat)
  if test "$proc_state" != Z; then
    printf '%s\n' 'Supervisor exit file exists while the recorded PID remains live; wait for process exit.'
    exit 2
  fi
fi
mkdir -p "$audit_root/terminal/validation/round2-validation"
cp "$origin"/{source-commit,exit-code,runner.log} "$audit_root/terminal"
if test -f "$origin/validation/round2-validation.json"; then
  cp "$origin/validation/round2-validation.json" "$audit_root/terminal/validation"
fi
for artifact in frontend.xml frontend.log frontend-install.log frontend-build.log backend-collection.log backend-dependencies.log backend.log backend.xml fixed_gis.log fixed_gis.xml; do
  if test -f "$origin/validation/round2-validation/$artifact"; then
    cp "$origin/validation/round2-validation/$artifact" "$audit_root/terminal/validation/round2-validation"
  fi
done
git --no-optional-locks -C "$origin/tree" rev-parse HEAD > "$audit_root/terminal/head"
git --no-optional-locks -C "$origin/tree" status --porcelain=v1 --untracked-files=normal > "$audit_root/terminal/porcelain"
python3 "$audit_root/audit.py" "$audit_root" terminal | tee "$audit_root/terminal.log"
(cd "$audit_root" && find . -type f ! -name SHA256SUMS ! -name capture.log -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS && sha256sum -c SHA256SUMS)
