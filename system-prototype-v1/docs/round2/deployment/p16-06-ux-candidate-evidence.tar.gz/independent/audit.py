from collections import Counter
from hashlib import sha1, sha256
import json
from pathlib import Path
import re
import shlex
import sys
from xml.etree import ElementTree as ET

root = Path(sys.argv[1])
mode = sys.argv[2]
assert mode in {"preflight", "terminal"}
source = root / "source"
preflight = root / "preflight"
suite_dir = root / "terminal/validation/round2-validation"
candidate = "6ecdbca38671b28793244d90984d116411bb4e52"
tree = "57e0348b56b996024e60d3503fbf1f05f70ef0f4"
origin = Path("/dev/shm/geopilot-p16-ux-candidate.eNUiU7SX")
project = origin / "tree/system-prototype-v1"


def oid(kind, data):
    return sha1(f"{kind} {len(data)}\0".encode() + data).hexdigest()


def commit_blob(name):
    data = (source / name).read_bytes()
    assert oid("blob", data) == (source / f"{name}.git-blob").read_text().strip()
    return data


def pytest_key(node):
    file, name = node.split("::", 1)
    function, bracket, parameters = name.partition("[")
    parts = function.split("::")
    return ".".join((file.removesuffix(".py").replace("/", "."), *parts[:-1])), parts[-1] + bracket + parameters


def log_record(path, cwd, finalized=True):
    lines = path.read_text().splitlines()
    assert lines[:2] == [f"commit {candidate}", f"cwd {cwd}"] and lines[2].startswith("command "), path
    args = shlex.split(lines[2][len("command "):])
    final = re.fullmatch(r"exit (\d+)", lines[-1])
    if finalized:
        assert final, path
    return {"args": args, "exit": int(final[1]) if final else None, "body": "\n".join(lines[3:])}


def suite_xml(path):
    document = ET.parse(path).getroot()
    assert document.tag in {"testsuite", "testsuites"}
    cases = list(document.iter("testcase"))
    names = Counter()
    totals = dict.fromkeys(("passed", "failure", "error", "skipped"), 0)
    issues = []
    for item in cases:
        key = item.attrib["classname"], item.attrib["name"]
        names[key] += 1
        state = [entry for entry in item if entry.tag in {"failure", "error", "skipped"}]
        assert len(state) <= 1 and not any(entry.tag in {"rerun", "flakyFailure", "flakyError"} for entry in item), path
        if state:
            totals[state[0].tag] += 1
            issues.append({"classname": key[0], "name": key[1], "state": state[0].tag,
                           "message": (state[0].attrib.get("message") or "")[:600]})
        else:
            totals["passed"] += 1
    for suite in (document, *[node for node in document.iter("testsuite") if node is not document]):
        if "tests" in suite.attrib:
            assert int(suite.attrib["tests"]) == len(list(suite.iter("testcase"))), path
    return document, names, {**totals, "total": len(cases), "distinct_keys": len(names), "issues": issues}


def node_list(log):
    return [line for line in log.splitlines() if re.match(r"^tests/.+?\.py::", line)]


assert all((source / name).read_text().strip() == candidate for name in ("head", "source-commit"))
assert (source / "tree").read_text().strip() == tree
assert not (source / "branch").read_bytes() and not (source / "porcelain").read_bytes()
git_commit = (source / "commit-object").read_bytes()
assert oid("commit", git_commit) == candidate and git_commit.startswith(f"tree {tree}\n".encode())
assert str(origin) in (source / "supervisor-argv").read_text() and candidate in (source / "supervisor-argv").read_text()
assert str(origin) in (source / "backend-argv").read_text()
assert all(line.endswith("25-28") for line in (source / "cpu-affinity").read_text().splitlines())
tracked = {line.removeprefix("system-prototype-v1/") for line in (source / "tracked-paths.z").read_text().split("\0") if line}
assert {"src/geopilot/artifacts/dem_area_cache.py", "src/geopilot/artifacts/step_cache.py",
        "tests/cache/test_dem_area_reuse.py", "tests/cache/test_step_cache_store.py"} <= tracked

collected = log_record(preflight / "backend-collection.log", project)
backend = node_list(collected["body"])
assert collected["exit"] == 0 and len(backend) == len(set(backend)) == 2255
assert collected["args"][-2:] == ["--collect-only", "tests"]
assert re.search(r"^2255 tests collected in ", collected["body"], re.M)
assert all(node.split("::", 1)[0] in tracked for node in backend)
preview = node_list((source / "preview-collection.log").read_text())
assert len(preview) == len(set(preview)) == 2228
added = Counter(node.split("::", 1)[0] for node in set(backend).difference(preview))
assert set(preview) <= set(backend) and sum(added.values()) == 27
assert added == {
    "tests/quality/test_summarize_user_trials.py": 13, "tests/quality/test_validate_release_readiness.py": 11,
    "tests/application/test_context_candidates.py": 3,
}

mapping = json.loads(commit_blob("p12-07-mapping.json"))
case_nodes = {case: [node["id"] for node in value["nodes"]] for case, value in mapping["fixed_cases"].items()}
assert set(case_nodes) == {f"T{i:02}" for i in range(1, 17)}
assert all(nodes and len(nodes) == len(set(nodes)) for nodes in case_nodes.values())
fixed = sorted({node for nodes in case_nodes.values() for node in nodes})
assert len(fixed) == mapping["mapped_unique_nodes"] == 82 and set(fixed) <= set(backend)

frontend_log = log_record(preflight / "frontend.log", project / "frontend")
front_xml, frontend, front_totals = suite_xml(preflight / "frontend.xml")
assert frontend_log["exit"] == 0 and front_totals == {
    "passed": 75, "failure": 0, "error": 0, "skipped": 0, "total": 75, "distinct_keys": 71, "issues": [],
}
frontend_files = Counter()
for (path, _), count in frontend.items():
    frontend_files[path] += count
assert len(frontend_files) == 16 and set(frontend_files) == {
    p.removeprefix("frontend/") for p in tracked if p.startswith("frontend/") and re.search(r"\.(?:test|spec)\.[cm]?[jt]sx?$", p)
}
assert dict(frontend_files) == {suite.attrib["name"]: int(suite.attrib["tests"]) for suite in front_xml.findall("testsuite")}
assert dict(frontend_files) == {path: int(n) for path, n in re.findall(
    r"^\s*✓\s+(src/\S+)\s+\((\d+) tests?\)", frontend_log["body"], re.M,
)}
assert "16 passed (16)" in frontend_log["body"] and "75 passed (75)" in frontend_log["body"]
parameter_tables = {name: len(lines.splitlines()) for lines, name in re.findall(
    r"it\.each\(\[\n((?:[^\n]*\n)*?)\]\)\('([^']+)'", commit_blob("MapPanel.test.tsx").decode(),
)}
repeated_titles = [(path, name, count) for (path, name), count in frontend.items() if count > 1]
assert len(repeated_titles) == 2 and all(path == "src/features/map/MapPanel.test.tsx" and
                                         count == parameter_tables[name] == 3 for path, name, count in repeated_titles)
install = log_record(preflight / "frontend-install.log", project / "frontend")
build = log_record(preflight / "frontend-build.log", project / "frontend")
deps = log_record(preflight / "backend-dependencies.log", project)
assert install["exit"] == build["exit"] == deps["exit"] == 0
assert install["args"][:2] == ["npm", "ci"] and "--offline" in install["args"]
assert build["args"] == ["npm", "run", "build"] and "tsc --noEmit && vite build" in build["body"]
packages = {p["name"]: p["version"] for p in json.loads(next(l for l in deps["body"].splitlines() if l.startswith("[")))}
assert packages["pytest"] == "8.3.4" and packages["psycopg"] == packages["psycopg-binary"] == "3.3.4"

data = {"source_commit": candidate, "source_tree": tree, "phase": mode, "frontend": front_totals,
        "frontend_files": dict(frontend_files), "frontend_repeated_parameterized_titles": repeated_titles,
        "frontend_junit_sha256": sha256((preflight / "frontend.xml").read_bytes()).hexdigest(),
        "frontend_offline_install_build_exit": [install["exit"], build["exit"]],
        "backend_collection": {"nodes": len(backend), "unique": len(set(backend)), "added": dict(sorted(added.items())), "removed": 0},
        "fixed_gis_expected": {"unique_nodes": len(fixed), "per_case": {k: len(v) for k, v in case_nodes.items()},
                               "all_in_backend_collection": True},
        "python_packages": {p: packages[p] for p in ("pytest", "psycopg", "psycopg-binary")}}
if mode == "terminal":
    outer = root / "terminal"
    supervisor_exit = int((outer / "exit-code").read_text())
    assert (outer / "head").read_text().strip() == candidate and not (outer / "porcelain").read_bytes()
    for path in preflight.iterdir():
        assert path.read_bytes() == (suite_dir / path.name).read_bytes()
    data["supervisor_exit_code"] = supervisor_exit
    actual = {}
    logs = {"frontend": frontend_log}
    for name, expected in (("backend", backend), ("fixed_gis", fixed)):
        path = suite_dir / f"{name}.xml"
        log_path = suite_dir / f"{name}.log"
        if log_path.is_file():
            logs[name] = log_record(log_path, project, finalized=False)
        if not path.is_file():
            actual[name] = {"state": "NOT_RUN" if name not in logs else "NO_FINAL_JUNIT",
                            "exit": logs.get(name, {}).get("exit")}
            continue
        _, observed, totals = suite_xml(path)
        expected_keys = Counter(map(pytest_key, expected))
        missing, extra = expected_keys - observed, observed - expected_keys
        actual[name] = {"state": "FINAL_JUNIT", "exit": logs[name]["exit"], **totals,
                        "junit_sha256": sha256(path.read_bytes()).hexdigest(), "exact_nodes": not missing and not extra,
                        "missing_keys": list(missing.items()), "unexpected_keys": list(extra.items())}
        if name == "fixed_gis":
            actual[name]["exact_command_nodes"] = [arg for arg in logs[name]["args"] if arg.startswith("tests/")] == expected
    data["observed"] = actual
    receipt = outer / "validation/round2-validation.json"
    if receipt.is_file():
        manifest = json.loads(receipt.read_bytes())
        assert manifest["source_commit"] == candidate and manifest["schema_version"] == 1
        by_suite = {record["name"]: record for record in manifest["suites"]}
        assert set(by_suite) == {"backend", "frontend", "fixed_gis"} and len(manifest["suites"]) == 3
        for name, entry in by_suite.items():
            assert entry["exit_code"] == logs[name]["exit"] == 0 and entry["command"] == logs[name]["args"]
            assert Path(entry["junit"]).name == f"{name}.xml" and Path(entry["log"]).name == f"{name}.log"
        assert by_suite["backend"]["collection"]["command"] == collected["args"]
        assert by_suite["backend"]["environment"] == by_suite["fixed_gis"]["environment"]
        assert "QGIS 3.44.15-Solothurn" in by_suite["backend"]["environment"]["qgis"]
        data["validation_receipt_sha256"] = sha256(receipt.read_bytes()).hexdigest()
        data["environment"] = {name: item["environment"] for name, item in by_suite.items()}
    clean = supervisor_exit == 0 and receipt.is_file() and all(
        (record := actual[name])["state"] == "FINAL_JUNIT"
        and record["exit"] == 0 and record["exact_nodes"]
        and record["passed"] == record["total"] == record["distinct_keys"] == expected
        and not record["failure"] and not record["error"] and not record["skipped"]
        for name, expected in (("backend", 2255), ("fixed_gis", 82))
    ) and actual["fixed_gis"]["exact_command_nodes"]
    data["independent_outcome"] = "PASS" if clean else "OBSERVED_TERMINAL_INCOMPLETE_OR_FAILED"
(root / f"{mode}.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
print(candidate, mode, "frontend 75 passed, 16 files; 2255 unique backend collected nodes; 82 exact fixed GIS targets")
if mode == "terminal":
    for name, result in data["observed"].items():
        print(name, {k: v for k, v in result.items() if k in (
            "state", "exit", "passed", "failure", "error", "skipped", "total", "distinct_keys", "exact_nodes", "exact_command_nodes")})
    print("supervisor exit", data["supervisor_exit_code"])
