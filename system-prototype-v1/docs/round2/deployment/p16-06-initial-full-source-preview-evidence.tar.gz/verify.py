"""Compare the initial full-suite JUnit with exact collection and known failures."""
from collections import Counter
import json
from pathlib import Path
import sys

from round2_release_manifest import _junit_name, _junit_report

root = Path(sys.argv[1])
initial = root / "round2-validation"
collection = (initial / "backend-collection.log").read_text()
nodes = [line for line in collection.splitlines() if line.startswith("tests/") and "::" in line]
assert len(nodes) == len(set(nodes)) == 2171
expected = Counter(_junit_name(node) for node in nodes)
document, counts = _junit_report((initial / "backend.xml").read_bytes())
observed = Counter((case.get("classname"), case.get("name")) for case in document.iter("testcase"))
assert expected == observed
failures = [case.get("name") for case in document.iter("testcase") if case.find("failure") is not None]
assert set(failures) == {
    "test_unchanged_registry_passes_without_qgis_probe",
    "test_file_rename_and_yaml_formatting_keep_the_exact_version",
    "test_additive_versions_preserve_historical_method_and_sensor_lookup",
}
assert counts["tests"] == 2171 and counts["failures"] == 3
assert counts["errors"] == counts["skipped"] == 0
assert (initial / "backend.log").read_text().endswith("\nexit 1\n")
assert (root / "exit-code").read_text().strip() == "1"
assert not (initial / "fixed_gis.xml").exists()
front, front_counts = _junit_report((initial / "frontend.xml").read_bytes())
assert front_counts["tests"] == 73
assert front_counts["failures"] == front_counts["errors"] == front_counts["skipped"] == 0
print(json.dumps({"backend": counts, "frontend": front_counts, "failed_names": sorted(failures),
                  "fixed_gis": "NOT_RUN", "validation_exit": 1}, indent=2))
