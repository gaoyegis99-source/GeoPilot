#!/bin/bash
set -euo pipefail
if [[ "${1:-}" == run ]]; then
  for arg in "$@"; do
    if [[ "$arg" == --cpuset-cpus || "$arg" == --cpuset-cpus=* ]]; then
      exec /usr/bin/docker "$@"
    fi
  done
  shift
  exec /usr/bin/docker run --cpuset-cpus 25-28 "$@"
fi
exec /usr/bin/docker "$@"
