from datetime import datetime, timezone
from pathlib import Path
import re
import sys
from time import sleep

origin = Path(sys.argv[1])
pid = int(sys.argv[2])
handle = Path(f"/proc/{pid}/stat")
exit_code = origin / "exit-code"
tests = origin / "validation/round2-validation"


def state():
    try:
        tail = handle.read_text().rsplit(") ", 1)[1].split()
    except FileNotFoundError:
        return None
    return tail[0], tail[19]


def print_status(message):
    print(datetime.now(timezone.utc).isoformat(timespec="seconds"), message, flush=True)


initial = state()
assert initial and initial[0] != "Z"
print_status(f"observing PID {pid} start_ticks={initial[1]} at 60 s intervals")
last = None
while True:
    if exit_code.is_file():
        value = exit_code.read_text().strip()
        if value.isdecimal():
            print_status(f"supervisor terminal exit={value}")
            sys.exit(0)
    current = state()
    if not current or current[0] == "Z" or current[1] != initial[1]:
        sleep(5)
        if exit_code.is_file() and exit_code.read_text().strip().isdecimal():
            continue
        print_status("exact supervisor is no longer live and no terminal exit file was published")
        sys.exit(2)
    stage = "fixed_gis" if (tests / "fixed_gis.log").exists() else "backend"
    log = tests / f"{stage}.log"
    body = log.read_text(errors="replace") if log.is_file() else ""
    percent = [int(p) for p in re.findall(r"\[\s*(\d+)%\]", body)]
    progress = percent[-1] if percent else 0
    checkpoint = (stage, progress // 10)
    if checkpoint != last:
        print_status(f"{stage} latest reported progress {progress}%")
        last = checkpoint
    sleep(60)
