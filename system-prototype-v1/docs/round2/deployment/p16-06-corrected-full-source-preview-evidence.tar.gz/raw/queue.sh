#!/bin/bash
set -euo pipefail
geo_repeat="$1"
geo_old="$2"
geo_project="$3"
geo_old_supervisor=3963908
while [[ ! -f "$geo_old/exit-code" ]]; do
  if ! kill -0 "$geo_old_supervisor" 2>/dev/null; then
    sleep 2
    if [[ ! -f "$geo_old/exit-code" ]]; then
      printf '%s\n' "Initial validation stopped without a supervisor exit record"
      exit 2
    fi
  fi
  sleep 5
done
test -s "$geo_old/validation/round2-validation/backend.xml"
printf 'Initial validation supervisor exit %s at %s\n' "$(cat "$geo_old/exit-code")" "$(date -u +%FT%TZ)"
git -C "$geo_project/.." worktree add --detach "$geo_repeat/tree" d1a9d4a68dc73ca355d13d013925d5e0fe518972
exec nice -n 19 ionice -c3 taskset -c 25-28 bash "$geo_repeat/run.sh" "$geo_repeat" "$geo_project"
