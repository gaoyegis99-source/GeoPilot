#!/bin/bash
set -o pipefail
geo_release_preview="$1"
geo_project="$2"
geo_release_source=d1a9d4a68dc73ca355d13d013925d5e0fe518972
export PATH="$geo_release_preview/bin:$PATH" TMPDIR="$geo_release_preview/tmp" npm_config_logs_max=0
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1 PROJ_NETWORK=OFF
export PYTHONDONTWRITEBYTECODE=1
cd "$geo_release_preview/tree/system-prototype-v1" || exit
"$geo_project/.venv/bin/python" -B scripts/quality/run_round2_validation.py \
  --commit "$geo_release_source" --python "$geo_project/.venv/bin/python" \
  --qgis-process "$geo_project/.environments/qgis-deb/qgis_process" \
  --python-path "$geo_project/.environments/postgis-python" --offline-npm-cache /home/mtd/.npm \
  --output "$geo_release_preview/validation" \
  --evidence system-prototype-v1/plans-round2/06_PROGRESS/ACCEPTANCE_LOG.md 2>&1 | tee "$geo_release_preview/runner.log"
geo_preview_status=${PIPESTATUS[0]}
printf '%s\n' "$geo_preview_status" > "$geo_release_preview/exit-code"
exit "$geo_preview_status"
