from collections import Counter
from hashlib import sha1, sha256
import json
from pathlib import Path
import re
import shlex
import sys
from xml.etree import ElementTree as ET

root = Path(sys.argv[1])
raw, source = root / "raw", root / "source"
report_dir = raw / "validation/round2-validation"
manifest = json.loads((raw / "validation/round2-validation.json").read_bytes())
preview = "d1a9d4a68dc73ca355d13d013925d5e0fe518972"
git_tree = "f8fc41f188e54c178c020302c9dc7edb8558aa48"


def git_oid(kind, data):
    return sha1(f"{kind} {len(data)}\0".encode() + data).hexdigest()


def pytest_key(node):
    file, name = node.split("::", 1)
    prefix, bracket, parameter = name.partition("[")
    parts = prefix.split("::")
    return ".".join((file.removesuffix(".py").replace("/", "."), *parts[:-1])), parts[-1] + bracket + parameter


def verify_log(path, cwd, command=None):
    lines = path.read_text().splitlines()
    assert lines[:2] == [f"commit {preview}", f"cwd {cwd}"] and lines[-1] == "exit 0", path
    args = shlex.split(lines[2].removeprefix("command "))
    assert lines[2].startswith("command ") and args, path
    if command is not None:
        assert args == command, path
    return lines[3:-1], args


def verify_xml(path):
    tree = ET.parse(path).getroot()
    cases = list(tree.iter("testcase"))
    assert tree.tag in ("testsuite", "testsuites") and cases, path
    assert all(not set(case_child.tag for case_child in case).intersection(
        {"skipped", "error", "failure", "rerun", "flakyFailure", "flakyError"}) for case in cases), path
    for suite in (tree, *[node for node in tree.iter("testsuite") if node is not tree]):
        if "tests" in suite.attrib:
            assert int(suite.attrib["tests"]) == len(list(suite.iter("testcase"))), path
        assert all(int(suite.attrib.get(key, 0)) == 0 for key in ("skipped", "errors", "failures", "disabled")), path
    names = Counter((case.attrib["classname"], case.attrib["name"]) for case in cases)
    if path.stem != "frontend":
        assert len(names) == len(cases), path
    return tree, names


assert manifest["schema_version"] == 1 and manifest["source_commit"] == preview
assert (raw / "source-commit").read_text().strip() == (source / "head").read_text().strip() == preview
assert (raw / "exit-code").read_text().strip() == "0"
assert (source / "tree").read_text().strip() == git_tree
assert not (source / "branch").read_text().strip() and not (source / "porcelain").read_bytes()
commit = (source / "commit-object").read_bytes()
assert git_oid("commit", commit) == preview and commit.startswith(f"tree {git_tree}\n".encode())
tracked = {item.removeprefix("system-prototype-v1/") for item in (source / "tracked-paths.z").read_text().split("\0") if item}
assert "plans-round2/04_TASKS/P13/P13-06.md" in tracked
assert (source / "p13-06-prerequisite-merge-base").read_text().strip() == "adecd011fa0d44cf0147d9db3f92c59e2763ca06"
assert (source / "p13-05-final-area-merge-base").read_text().strip() == preview
cache_paths = {"src/geopilot/artifacts/dem_area_cache.py", "src/geopilot/artifacts/step_cache.py",
               "src/geopilot/checks/cache_reuse.py", "tests/checks/test_cache_reuse.py"}
assert not (cache_paths & tracked) and not any(p.startswith("tests/cache/") for p in tracked)
preview_root = Path("/dev/shm/geopilot-validation-repeat.juIwI6Ls")
project = preview_root / "tree/system-prototype-v1"
assert f"geo_release_source={preview}" in (raw / "run.sh").read_text()
assert f"worktree add --detach \"$geo_repeat/tree\" {preview}" in (raw / "queue.sh").read_text()
assert 'taskset -c 25-28' in (raw / "queue.sh").read_text()
assert (preview_root / "validation/round2-validation.json").as_posix() == (raw / "runner.log").read_text().strip()

suites = {s["name"]: s for s in manifest["suites"]}
assert len(suites) == len(manifest["suites"]) == 3 and set(suites) == {"frontend", "backend", "fixed_gis"}
outcomes, contents, logs = {}, {}, {}
for name, suite in suites.items():
    assert suite["exit_code"] == 0
    for field, suffix in (("junit", "xml"), ("log", "log")):
        assert suite[field] == f"system-prototype-v1/artifacts/reports/final/round2-validation/{name}.{suffix}"
    cwd = project / "frontend" if name == "frontend" else project
    logs[name], _ = verify_log(report_dir / f"{name}.log", cwd, suite["command"])
    contents[name] = verify_xml(report_dir / f"{name}.xml")
    outcomes[name] = {"passed": sum(contents[name][1].values()), "skipped": 0, "errors": 0, "failures": 0}

backend_collection, _ = verify_log(report_dir / "backend-collection.log", project, suites["backend"]["collection"]["command"])
backend_nodes = [line for line in backend_collection if re.match(r"^tests/.+?\.py::", line)]
assert len(backend_nodes) == len(set(backend_nodes)) == 2171
assert any(re.fullmatch(r"2171 tests collected in .+", line) for line in backend_collection)
assert Counter(map(pytest_key, backend_nodes)) == contents["backend"][1]
assert all(node.split("::", 1)[0] in tracked for node in backend_nodes)
assert "2171 passed" in "\n".join(logs["backend"])
assert suites["backend"]["environment"] == suites["fixed_gis"]["environment"]
assert "QGIS 3.44.15-Solothurn" in suites["backend"]["environment"]["qgis"]
assert suites["backend"]["environment"]["pythonpath"].startswith(f"{project}/src:")
outcomes["backend"]["exact_collection_nodes"] = len(backend_nodes)

mapping_bytes = (source / "p12-07-mapping.json").read_bytes()
assert git_oid("blob", mapping_bytes) == (source / "mapping-blob").read_text().strip()
mapping = json.loads(mapping_bytes)
assert set(mapping["fixed_cases"]) == {f"T{i:02}" for i in range(1, 17)}
case_nodes = {case: [node["id"] for node in value["nodes"]] for case, value in mapping["fixed_cases"].items()}
assert all(nodes and len(nodes) == len(set(nodes)) for nodes in case_nodes.values())
memberships = Counter(node for nodes in case_nodes.values() for node in nodes)
fixed_nodes = sorted(memberships)
assert len(fixed_nodes) == mapping["mapped_unique_nodes"] == 82
assert [arg for arg in suites["fixed_gis"]["command"] if arg.startswith("tests/")] == fixed_nodes
assert set(fixed_nodes) <= set(backend_nodes)
assert Counter(map(pytest_key, fixed_nodes)) == contents["fixed_gis"][1]
assert "82 passed" in "\n".join(logs["fixed_gis"])
outcomes["fixed_gis"].update({"case_nodes": {case: len(nodes) for case, nodes in case_nodes.items()},
    "unique_mapping_nodes": len(fixed_nodes), "mapping_memberships": sum(memberships.values()),
    "shared_nodes": {node: n for node, n in memberships.items() if n > 1},
    "mapping_sha256": sha256(mapping_bytes).hexdigest(), "overlap_with_backend": len(fixed_nodes)})

frontend_tree, frontend_cases = contents["frontend"]
frontend_suites = {suite.attrib["name"]: int(suite.attrib["tests"]) for suite in frontend_tree.findall("testsuite")}
frontend_source = {p.removeprefix("frontend/") for p in tracked if p.startswith("frontend/")
                   and re.search(r"\.(?:test|spec)\.[cm]?[jt]sx?$", p)}
frontend_log = dict((path, int(n)) for path, n in re.findall(r"^\s*✓\s+(src/\S+)\s+\((\d+) tests?\)",
                                                            "\n".join(logs["frontend"]), re.M))
assert len(frontend_suites) == len(frontend_source) == 16 and set(frontend_suites) == frontend_source
testcase_counts = Counter()
for (classname, _), count in frontend_cases.items():
    testcase_counts[classname] += count
assert frontend_log == frontend_suites == dict(testcase_counts)
assert sum(frontend_suites.values()) == sum(frontend_cases.values()) == 73
duplicates = {(path, name): count for (path, name), count in frontend_cases.items() if count > 1}
assert len(duplicates) == 2 and len(frontend_cases) == 69
map_source = (source / "MapPanel.test.tsx").read_bytes()
assert git_oid("blob", map_source) == (source / "MapPanel.blob").read_text().strip()
parameter_tables = dict((name, len(lines.splitlines())) for lines, name in
                        re.findall(r"it\.each\(\[\n((?:[^\n]*\n)*?)\]\)\('([^']+)'", map_source.decode()))
assert all(path == "src/features/map/MapPanel.test.tsx" and count == parameter_tables[name] == 3
           for (path, name), count in duplicates.items())
assert re.search(r"Test Files\s+16 passed \(16\)", "\n".join(logs["frontend"]))
assert re.search(r"Tests\s+73 passed \(73\)", "\n".join(logs["frontend"]))
outcomes["frontend"].update({"matching_tracked_files_and_reported_counts": frontend_suites,
    "distinct_junit_title_keys": len(frontend_cases),
    "parameterized_repeated_titles": [{"file": path, "title": name, "distinct_source_parameters": count}
                                     for (path, name), count in duplicates.items()]})
install, install_args = verify_log(report_dir / "frontend-install.log", project / "frontend")
assert install_args[:2] == ["npm", "ci"] and "--offline" in install_args
build, _ = verify_log(report_dir / "frontend-build.log", project / "frontend", ["npm", "run", "build"])
assert any("tsc --noEmit && vite build" in line for line in build) and any("built in" in line for line in build)
deps, _ = verify_log(report_dir / "backend-dependencies.log", project)
packages = {pkg["name"]: pkg["version"] for pkg in json.loads(next(line for line in deps if line.startswith("[")))}
assert packages["pytest"] == "8.3.4" and packages["psycopg"] == packages["psycopg-binary"] == "3.3.4"

result = {
    "scope": "Corrected P16-06 full preview on a clean detached source; no tests rerun during this audit.",
    "source_commit": preview, "source_tree": git_tree, "supervisor_exit_code": 0,
    "source_boundary": "This preview contains P13-06 prerequisite documentation and predates the P13-06 cache implementation. It also predates f16f72d.",
    "suites": outcomes,
    "other_checks": {"npm_install_offline": True, "frontend_typecheck_and_build": True,
                     "backend_dependencies": {name: packages[name] for name in ("pytest", "psycopg", "psycopg-binary")}},
    "junit_sha256": {name: sha256((report_dir / f"{name}.xml").read_bytes()).hexdigest() for name in suites},
}
(root / "independent.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
print(f"{preview} clean detached tree {git_tree}, supervisor exit 0")
print("Frontend 73/73, 16 tracked files; backend 2171/2171 exact collected nodes; fixed GIS 82/82, T01–T16; zero skips, failures and errors")
print("Frontend offline npm install, TypeScript check and Vite build passed")
