"""Capture and independently audit the release evidence for candidate f85c3c8."""

import argparse
import ast
from collections import Counter
from hashlib import sha1, sha256
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
from xml.etree import ElementTree as ET


COMMIT = "f85c3c8b6f214840efd188d08409087c17668834"
TREE = "c4a2c22404b4872bfee797e437e1b06a21b01bf4"
PREFIX = "system-prototype-v1/"
MAPPING = "docs/round2/audit/p12-07-mapping.json"
MAP_TEST = "frontend/src/features/map/MapPanel.test.tsx"
RECHECK_TEST = "frontend/src/App.recheck.test.tsx"
INPUT_TEST = "frontend/src/App.input-recovery.test.tsx"
PROBLEM_TEST = "frontend/src/components/errors/ProblemDetails.test.tsx"
INPUT_TITLE = "opens registration after changed input and requires explicit selection to revise the saved plan"
PROBLEM_TITLE = "offers the action that matches METHOD_PRECONDITION_FAILED"
BOARD = "plans-round2/06_PROGRESS/TASK_BOARD.md"
INVENTORY = "plans-round2/06_PROGRESS/task_inventory.json"
P16_03 = "plans-round2/04_TASKS/P16/P16-03.md"
P16_07 = "plans-round2/04_TASKS/P16/P16-07.md"
SCOPE = "scripts/quality/validate_release_readiness.py"
SCOPE_TEST = "tests/quality/test_validate_release_readiness.py"
PREREQUISITES = ("P13-08", "P14-08", "P15-08", "P16-01", "P16-02", "P16-04", "P16-05", "P16-06")
WITNESS = (MAPPING, MAP_TEST, RECHECK_TEST, INPUT_TEST, PROBLEM_TEST, BOARD, INVENTORY, P16_03, P16_07, SCOPE, SCOPE_TEST)
RECHECK_TITLE = "offers one visible recovery action after cancelling a check and retains it if submission fails"
RAW_DIR = "validation/round2-validation"
PREFLIGHT = (
    "frontend-install.log", "frontend-build.log", "frontend.log", "frontend.xml",
    "backend-collection.log", "backend-dependencies.log",
)
TERMINAL = ("backend.log", "backend.xml", "fixed_gis.log", "fixed_gis.xml")
OUTCOMES = ("failures", "errors", "skipped")
ENV = {**os.environ, "GIT_OPTIONAL_LOCKS": "0"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def git(root, *args):
    return subprocess.run(["git", "-C", str(root), *args], env=ENV, check=True, capture_output=True).stdout


def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())


def witness(candidate, target):
    tree = candidate / "tree"
    require(Path(os.fsdecode(git(tree, "rev-parse", "--show-toplevel").strip())) == tree, "Unexpected candidate repository root")
    target.mkdir(parents=True, exist_ok=False)
    for filename, args in {
        "head": ("rev-parse", "HEAD"),
        "tree": ("rev-parse", "HEAD^{tree}"),
        "branch": ("branch", "--show-current"),
        "porcelain": ("status", "--porcelain=v1", "--untracked-files=normal"),
        "commit-object": ("cat-file", "commit", "HEAD"),
        "tracked-tree.z": ("ls-tree", "-rz", "HEAD"),
    }.items():
        (target / filename).write_bytes(git(tree, *args))
    copy(candidate / "source-commit", target / "source-commit")
    for rel in WITNESS:
        require((tree / PREFIX / rel).read_bytes() == git(tree, "show", f"HEAD:{PREFIX}{rel}"), f"Checked-out file differs from Git blob: {rel}")
        copy(tree / PREFIX / rel, target / rel)


def capture(candidate, root, phase):
    require(not root.is_relative_to(candidate), "Independent output must be outside candidate directory")
    stage = root / phase
    witness(candidate, stage / "source")
    (stage / "origin").write_text(str(candidate) + "\n", encoding="utf-8")
    for name in (*PREFLIGHT, *(TERMINAL if phase == "terminal" else ())):
        copy(candidate / RAW_DIR / name, stage / "reports" / name)
    if phase == "preflight":
        copy(candidate / "run.sh", stage / "run.sh")
    else:
        copy(candidate / "exit-code", stage / "exit-code")
        copy(candidate / "runner.log", stage / "runner.log")
        copy(candidate / "validation/round2-validation.json", stage / "receipt.json")


def oid(kind, payload):
    return sha1(f"{kind} {len(payload)}\0".encode("ascii") + payload).hexdigest()


def inspect_source(stage):
    source = stage / "source"
    require(all((source / name).read_text().strip() == COMMIT for name in ("head", "source-commit")), "Candidate commit mismatch")
    require((source / "tree").read_text().strip() == TREE, "Candidate tree mismatch")
    require(not (source / "branch").read_text().strip(), "Candidate is on a branch")
    require(not (source / "porcelain").read_bytes(), "Candidate worktree is dirty")
    commit = (source / "commit-object").read_bytes()
    require(oid("commit", commit) == COMMIT and commit.startswith(f"tree {TREE}\n".encode()), "Git commit object mismatch")
    entries = {}
    folders = {}
    for entry in (source / "tracked-tree.z").read_bytes().split(b"\0"):
        if entry:
            descriptor, path = entry.split(b"\t", 1)
            mode, kind, blob = descriptor.split()
            require(kind == b"blob", "Unexpected non-blob in tracked candidate tree")
            require(os.fsdecode(path) not in entries, "Duplicate Git tree path")
            entries[os.fsdecode(path)] = blob.decode("ascii")
            folder = folders
            *parents, name = path.split(b"/")
            for parent in parents:
                folder = folder.setdefault(parent, {})
            folder[name] = mode, bytes.fromhex(blob.decode("ascii"))
    require(tree_oid(folders) == TREE, "Cannot reconstruct the committed Git tree")
    for rel in WITNESS:
        require(entries[PREFIX + rel] == oid("blob", (source / rel).read_bytes()), f"Source blob mismatch: {rel}")
    return {path.removeprefix(PREFIX) for path in entries if path.startswith(PREFIX)}


def tree_oid(folder):
    payload = []
    for name, entry in sorted(folder.items(), key=lambda item: item[0] + (b"/" if isinstance(item[1], dict) else b"")):
        mode, object_id = (b"40000", bytes.fromhex(tree_oid(entry))) if isinstance(entry, dict) else entry
        payload.append(mode + b" " + name + b"\0" + object_id)
    return oid("tree", b"".join(payload))


def inspect_release_scope(source, tracked, collected):
    declarations = {
        target.id: assignment.value
        for assignment in ast.parse((source / SCOPE).read_text()).body if isinstance(assignment, ast.Assign)
        for target in assignment.targets if isinstance(target, ast.Name)
    }
    require(ast.literal_eval(declarations["TASK"]) == "P16-07", "Unexpected release task")
    require(ast.literal_eval(declarations["PREREQUISITES"]) == PREREQUISITES, "Unexpected release dependencies")
    board = {}
    for line in (source / BOARD).read_text().splitlines():
        if re.match(r"^\| P\d{2}-\d{2} \|", line):
            fields = [value.strip() for value in line.strip("|").split("|", 6)]
            require(len(fields) == 7 and fields[0] not in board, "Unexpected board row")
            board[fields[0]] = fields
    statuses = {task: board[task][-2] for task in PREREQUISITES}
    require(set(statuses.values()) == {"ACCEPTED"}, "Technical prerequisites are not all accepted on candidate board")
    require(board["P16-03"][-2] == "NOT_APPLICABLE" and board["P16-07"][-2] == "BLOCKED", "Unexpected retirement or release status")
    for task in PREREQUISITES:
        links = re.findall(r"\]\(([^)#]+)(?:#[^)]*)?\)", board[task][-1])
        require(links and all(os.path.normpath(str(Path(BOARD).parent / link)) in tracked for link in links),
                f"Untracked acceptance evidence link for {task}")
    require("NOT_APPLICABLE" in (source / P16_03).read_text() and "NOT_RUN" in (source / P16_03).read_text(),
            "Participant retirement or history missing from scope decision")
    expected_dependencies = "P13-08、P14-08、P15-08、P16-01、P16-02、P16-04 至 P16-06"
    inventory = {row["id"]: row for row in json.loads((source / INVENTORY).read_bytes())["tasks"]}
    require("NOT_APPLICABLE" in inventory["P16-03"]["acceptance"], "Inventory omits participant retirement")
    require(inventory["P16-07"]["deps"] == board["P16-07"][-3] == expected_dependencies and expected_dependencies in (source / P16_07).read_text(),
            "Inventory, board and decision document disagree on prerequisites")
    scope_nodes = [node for node in collected if node.startswith(SCOPE_TEST + "::")]
    require(len(scope_nodes) == 11 and f"{SCOPE_TEST}::test_prerequisites_met_preserves_decision_status" in scope_nodes,
            "Release-readiness regression tests missing from backend collection")
    return {
        "participant_task_status": board["P16-03"][-2], "participant_observations": "NOT_RUN",
        "decision_task": "P16-07", "decision_status_on_candidate_board": board["P16-07"][-2],
        "technical_prerequisites": statuses, "readiness_test_nodes": scope_nodes,
    }


def parse_log(path, cwd):
    lines = path.read_text(encoding="utf-8").splitlines()
    require(lines[:2] == [f"commit {COMMIT}", f"cwd {cwd}"], f"Log source or working directory mismatch: {path.name}")
    require(len(lines) >= 4 and lines[2].startswith("command "), f"Missing command: {path.name}")
    exit_match = re.fullmatch(r"exit (\d+)", lines[-1])
    require(exit_match is not None, f"Log has no terminal exit code: {path.name}")
    return shlex.split(lines[2][8:]), int(exit_match[1]), lines[3:-1]


def pytest_key(node):
    file, member = node.split("::", 1)
    definition, separator, params = member.partition("[")
    *classes, function = definition.split("::")
    module = file.removesuffix(".py").replace("/", ".")
    return ".".join((module, *classes)), function + separator + params


def junit(path):
    root = ET.parse(path).getroot()
    require(root.tag in {"testsuite", "testsuites"}, f"Unrecognized JUnit root: {path.name}")
    cases = Counter()
    counts = {"tests": 0, "passed": 0, **dict.fromkeys(OUTCOMES, 0)}
    for suite in (root, *[item for item in root.iter("testsuite") if item is not root]):
        observed = dict.fromkeys(("tests", *OUTCOMES), 0)
        for case in suite.iter("testcase"):
            observed["tests"] += 1
            states = [child.tag for child in case if child.tag in {"failure", "error", "skipped"}]
            require(len(states) <= 1 and not any(child.tag in {"rerun", "flakyFailure", "flakyError"} for child in case), f"Ambiguous testcase outcome: {path.name}")
            if states:
                state, = states
                observed[{"failure": "failures", "error": "errors", "skipped": "skipped"}[state]] += 1
            if suite is root:
                cases[case.attrib["classname"], case.attrib["name"]] += 1
        for key, count in observed.items():
            require(key not in suite.attrib or int(suite.attrib[key]) == count, f"JUnit attribute disagrees with testcase records: {path.name} {key}")
        if suite is root:
            counts.update(observed)
    counts["passed"] = counts["tests"] - sum(counts[key] for key in OUTCOMES)
    return root, cases, counts


def hash_file(path):
    return sha256(path.read_bytes()).hexdigest()


def require_green(counts, expected):
    require(counts == {"tests": expected, "passed": expected, **dict.fromkeys(OUTCOMES, 0)}, f"Unexpected JUnit results: {counts}")


def inspect(root, phase):
    start = root / "preflight"
    origin = Path((start / "origin").read_text().strip())
    project = origin / "tree/system-prototype-v1"
    tracked = inspect_source(start)
    raw = start / "reports"
    logs = {
        name: parse_log(raw / name, project / "frontend" if name.startswith("frontend") else project)
        for name in PREFLIGHT if name.endswith(".log")
    }
    require(all(exit_code == 0 for _, exit_code, _ in logs.values()), "A preflight command failed")
    install, _, _ = logs["frontend-install.log"]
    build, _, build_body = logs["frontend-build.log"]
    require(install[:2] == ["npm", "ci"] and "--offline" in install and "--cache" in install, "Expected locked offline npm install")
    require(build == ["npm", "run", "build"] and "> tsc --noEmit && vite build" in build_body, "Expected TypeScript check and production build")

    front_args, _, front_body = logs["frontend.log"]
    require(front_args == ["npm", "test", "--", "--run", "--reporter=default", "--reporter=junit",
                           f"--outputFile.junit={origin / RAW_DIR / 'frontend.xml'}"], "Unexpected frontend test command")
    front_xml, frontend, front_counts = junit(raw / "frontend.xml")
    require_green(front_counts, 78)
    front_by_file = Counter()
    for (file, _), multiplicity in frontend.items():
        front_by_file[file] += multiplicity
    listed = re.findall(r"^\s*✓\s+(src/\S+)\s+\((\d+) tests?\)", "\n".join(front_body), re.M)
    require(len(listed) == len(dict(listed)) == len(front_by_file) == 18, "Expected 18 distinct logged frontend files")
    require(front_by_file == {file: int(count) for file, count in listed}, "Vitest file counts do not match JUnit")
    require(front_by_file == {suite.attrib["name"]: int(suite.attrib["tests"]) for suite in front_xml.findall("testsuite")}, "JUnit suite file counts disagree")
    require(set(front_by_file) == {file.removeprefix("frontend/") for file in tracked
                                   if file.startswith("frontend/") and re.search(r"\.(?:test|spec)\.[cm]?[jt]sx?$", file)}, "Frontend tests differ from tracked test files")
    front_text = "\n".join(front_body)
    require(re.search(r"Test Files\s+18 passed \(18\)", front_text) and re.search(r"Tests\s+78 passed \(78\)", front_text), "Vitest summary differs from JUnit")
    recheck_file = RECHECK_TEST.removeprefix("frontend/")
    recheck_source = (start / "source" / RECHECK_TEST).read_text()
    require(f"it('{RECHECK_TITLE}'" in recheck_source and frontend[recheck_file, RECHECK_TITLE] == 1
            and any(RECHECK_TITLE in line for line in front_body), "New App.recheck test not proven in source, JUnit and console")
    input_file = INPUT_TEST.removeprefix("frontend/")
    input_source = (start / "source" / INPUT_TEST).read_text()
    require(f"it('{INPUT_TITLE}'" in input_source and frontend[input_file, INPUT_TITLE] == 1
            and any(INPUT_TITLE in line for line in front_body), "Input recovery test missing from source, JUnit or console")
    problem_file = PROBLEM_TEST.removeprefix("frontend/")
    require("'METHOD_PRECONDITION_FAILED'" in (start / "source" / PROBLEM_TEST).read_text()
            and frontend[problem_file, PROBLEM_TITLE] == 1, "Preflight problem recovery case missing")
    table_titles = {name: len(rows.splitlines()) for rows, name in re.findall(
        r"it\.each\(\[\n((?:[^\n]*\n)*?)\]\)\('([^']+)'", (start / "source" / MAP_TEST).read_text()
    )}
    repeats = [(file, name, count) for (file, name), count in frontend.items() if count != 1]
    require(len(repeats) == 2 and all(file == MAP_TEST.removeprefix("frontend/") and table_titles.get(name) == count == 3
                                    for file, name, count in repeats), "Unexplained duplicate frontend identities")

    collector, _, collection_body = logs["backend-collection.log"]
    require(collector[1:] == ["-m", "pytest", "-q", "-p", "no:cacheprovider", "--collect-only", "tests"], "Unexpected backend collection command")
    collected = [line for line in collection_body if re.match(r"^tests/.+?\.py::", line)]
    require(len(collected) == len(set(collected)) == 2255, "Expected 2255 unique backend nodes")
    require(len(set(map(pytest_key, collected))) == len(collected), "Collected nodes collide as JUnit identities")
    require(all(node.split("::", 1)[0] in tracked for node in collected), "Collection has an untracked test file")
    require(sum(bool(re.match(r"^2255 tests collected in ", line)) for line in collection_body) == 1, "Missing exact collection summary")
    release_scope = inspect_release_scope(start / "source", tracked, collected)
    mapping = json.loads((start / "source" / MAPPING).read_bytes())
    cases = mapping["fixed_cases"]
    require(set(cases) == {f"T{i:02}" for i in range(1, 17)}, "Incomplete fixed GIS case mapping")
    fixed_cases = {case: [entry["id"] for entry in info["nodes"]] for case, info in cases.items()}
    require(all(info["outcome"] == "PASS" and info["nodes"] and all(node["outcome"] == "PASS" for node in info["nodes"])
                for info in cases.values()), "Incomplete fixed GIS mapping evidence")
    require(all(len(nodes) == len(set(nodes)) for nodes in fixed_cases.values()), "Duplicate node within one fixed GIS case")
    fixed = sorted({node for nodes in fixed_cases.values() for node in nodes})
    require(len(fixed) == mapping["mapped_unique_nodes"] == 82 and set(fixed) <= set(collected), "Fixed GIS mapping differs from collected coverage")
    dependencies = {item["name"]: item["version"] for item in json.loads(next(
        line for line in logs["backend-dependencies.log"][2] if line.startswith("[")))}
    require(dependencies["pytest"] == "8.3.4" and dependencies["psycopg"] == dependencies["psycopg-binary"] == "3.3.4",
            "Expected pinned pytest and real PostGIS binding")

    result = {"phase": phase, "source_commit": COMMIT, "source_tree": TREE, "source_detached_clean": True,
              "source_blob_oids": {rel: oid("blob", (start / "source" / rel).read_bytes()) for rel in WITNESS},
              "frontend": {**front_counts, "distinct_keys": len(frontend), "files": dict(sorted(front_by_file.items())),
                           "required_nodes": [[recheck_file, RECHECK_TITLE], [input_file, INPUT_TITLE], [problem_file, PROBLEM_TITLE]],
                           "parameterized_repeats": sorted(repeats),
                           "junit_sha256": hash_file(raw / "frontend.xml")},
              "backend_collection": {"nodes": len(collected), "unique": len(set(collected)), "sha256": hash_file(raw / "backend-collection.log")},
              "release_scope": release_scope,
              "fixed_gis_mapping": {"nodes": len(fixed), "per_case": {key: len(nodes) for key, nodes in sorted(fixed_cases.items())},
                                    "all_collected": True},
              "preflight_exit_codes": {name: exit_code for name, (_, exit_code, _) in logs.items()}}
    if phase == "preflight":
        return result

    end = root / "terminal"
    require((end / "origin").read_bytes() == (start / "origin").read_bytes(), "Terminal and preflight candidate paths differ")
    require(inspect_source(end) == tracked, "Terminal tracked source differs")
    for name in PREFLIGHT:
        require((end / "reports" / name).read_bytes() == (raw / name).read_bytes(), f"Terminal changed preflight evidence: {name}")
    require((end / "exit-code").read_text().strip() == "0", "Candidate supervisor did not exit successfully")
    require((end / "runner.log").read_text().splitlines()[-1] == str(origin / "validation/round2-validation.json"), "Runner did not produce the expected terminal receipt")
    receipt = json.loads((end / "receipt.json").read_bytes())
    require(receipt["source_commit"] == COMMIT and receipt["schema_version"] == 1, "Receipt source mismatch")
    suites = {item["name"]: item for item in receipt["suites"]}
    require(len(receipt["suites"]) == 3 and set(suites) == {"frontend", "backend", "fixed_gis"}, "Incomplete final suite receipt")
    result["terminal"] = {}
    for name, expected_nodes, number in (("frontend", None, 78), ("backend", collected, 2255), ("fixed_gis", fixed, 82)):
        report = end / "reports" / f"{name}.xml"
        command, exit_code, _ = parse_log(end / "reports" / f"{name}.log", project / "frontend" if name == "frontend" else project)
        _, actual, counts = junit(report)
        require_green(counts, number)
        expected = frontend if expected_nodes is None else Counter(map(pytest_key, expected_nodes))
        require(actual == expected, f"{name} exact JUnit identities differ, missing={list((expected - actual).items())[:4]} extra={list((actual - expected).items())[:4]}")
        entry = suites[name]
        require(command == entry["command"] and exit_code == entry["exit_code"] == 0, f"{name} receipt command or exit mismatch")
        require(Path(entry["junit"]).name == report.name and Path(entry["log"]).name == f"{name}.log", f"{name} receipt evidence path mismatch")
        if name != "frontend":
            require(command[:6] == collector[:6] and command[-2].startswith("--basetemp=")
                    and command[-1] == f"--junitxml={origin / RAW_DIR / report.name}", f"Unexpected {name} execution command")
            require(command[6:-2] == (["tests"] if name == "backend" else fixed), f"{name} targets differ from expected")
        result["terminal"][name] = {**counts, "exit_code": exit_code, "exact_junit_nodes": True,
                                     "distinct_keys": len(actual), "junit_sha256": hash_file(report)}
    require(suites["backend"]["collection"]["command"] == collector
            and Path(suites["backend"]["collection"]["log"]).name == "backend-collection.log", "Terminal collection receipt mismatch")
    require(suites["backend"]["environment"] == suites["fixed_gis"]["environment"]
            and "QGIS 3.44.15-Solothurn" in suites["fixed_gis"]["environment"]["qgis"], "Fixed GIS uses unexpected environment")
    result["release_scope"]["readiness_test_nodes_passed"] = len(release_scope["readiness_test_nodes"])
    result.update({"supervisor_exit_code": 0, "receipt_sha256": hash_file(end / "receipt.json"),
                   "environment": {name: entry["environment"] for name, entry in suites.items()}})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("preflight", "terminal"))
    parser.add_argument("evidence", type=Path)
    parser.add_argument("--candidate", type=Path, help="capture live read-only input before auditing")
    args = parser.parse_args()
    root = args.evidence.resolve(strict=True)
    if args.candidate:
        capture(args.candidate.resolve(strict=True), root, args.phase)
    print(json.dumps(inspect(root, args.phase), ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
