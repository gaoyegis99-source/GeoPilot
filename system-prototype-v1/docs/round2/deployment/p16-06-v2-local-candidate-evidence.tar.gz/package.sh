#!/bin/bash
set -euo pipefail
candidate="$1"
release_dir="$2"
source_commit=$(cat "$candidate/source-commit")
test "$(cat "$candidate/exit-code")" = 0
git merge-base --is-ancestor "$source_commit" HEAD
test -z "$(git status --porcelain --untracked-files=no)"
test "$(git -C "$candidate/tree" rev-parse HEAD)" = "$source_commit"
test -z "$(git -C "$candidate/tree" status --porcelain)"
target=artifacts/reports/final
.venv/bin/python -B - "$candidate/validation" "$source_commit" "$target" <<'PY'
from pathlib import Path
import json
import sys
from xml.etree import ElementTree

evidence, source, target = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
receipt = json.loads((evidence / "round2-validation.json").read_bytes())
assert receipt["source_commit"] == source
assert {suite["name"] for suite in receipt["suites"]} == {"backend", "frontend", "fixed_gis"}
for suite in receipt["suites"]:
    nodes = ElementTree.parse(evidence / "round2-validation" / f"{suite['name']}.xml").findall(".//testcase")
    assert suite["exit_code"] == 0 and nodes
    assert not any(child.tag in {"failure", "error"} for node in nodes for child in node)
    skipped = sum(node.find("skipped") is not None for node in nodes)
    print(suite["name"], len(nodes) - skipped, "passed", skipped, "skipped")
before = {file.name for file in (target / "round2-validation").iterdir()}
after = {file.name for file in (evidence / "round2-validation").iterdir()}
assert before <= after, f"Review superseded evidence before updating: {before - after}"
PY
mkdir -p "$release_dir"
test ! -e "$release_dir/geopilot-round2.tar.gz"
cp -r "$candidate/validation/round2-validation/." "$target/round2-validation/"
cp "$candidate/validation/round2-validation.json" "$target/"
git add -- "$target/round2-validation" "$target/round2-validation.json"
git diff --cached --check -- "$target/round2-validation.json"
git commit -m "Record same-source validation for the revised P16 scope"
evidence_commit=$(git rev-parse HEAD)
printf '%s\n' "$evidence_commit" > "$candidate/evidence-commit"
.venv/bin/python -B "$target/delivery_manifest.py" --round2 \
  --source-ref "$source_commit" --evidence-ref "$evidence_commit" \
  --archive "$release_dir/geopilot-round2.tar.gz" --write
.venv/bin/python -B scripts/quality/verify_delivery_manifest.py \
  --round2-manifest "$target/round2-delivery-manifest.json" > "$candidate/verify-git.json"
cp "$target/round2-delivery-manifest.json" "$release_dir/"
offline=$(mktemp -d "$candidate/package-check.XXXXXXXX")
tar -xzf "$release_dir/geopilot-round2.tar.gz" -C "$offline"
cmp "$offline/system-prototype-v1/$target/round2-delivery-manifest.json" "$release_dir/round2-delivery-manifest.json"
.venv/bin/python -B "$offline/system-prototype-v1/scripts/quality/verify_delivery_manifest.py" \
  --round2-manifest "$offline/system-prototype-v1/$target/round2-delivery-manifest.json" \
  --offline-root "$offline" > "$candidate/verify-offline.json"
cmp "$candidate/verify-git.json" "$candidate/verify-offline.json"
( cd "$release_dir" && sha256sum geopilot-round2.tar.gz round2-delivery-manifest.json > SHA256SUMS && sha256sum -c SHA256SUMS )
cp "$candidate/verify-git.json" "$candidate/verify-offline.json" "$release_dir/"
printf '%s\n' "$offline" > "$candidate/offline-root"
