#!/bin/bash
set -uo pipefail
candidate="$1"
project="$2"
source_commit=$(cat "$candidate/source-commit")
export PATH="$candidate/bin:$PATH" TMPDIR="$candidate/tmp" npm_config_logs_max=0
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1 PROJ_NETWORK=OFF
export PYTHONDONTWRITEBYTECODE=1
cd "$candidate/tree/system-prototype-v1" || exit
"$project/.venv/bin/python" -B scripts/quality/run_round2_validation.py \
  --commit "$source_commit" --python "$project/.venv/bin/python" \
  --qgis-process "$project/.environments/qgis-deb/qgis_process" \
  --python-path "$project/.environments/postgis-python" --offline-npm-cache /home/mtd/.npm \
  --output "$candidate/validation" \
  --evidence system-prototype-v1/plans-round2/06_PROGRESS/ACCEPTANCE_LOG.md \
  --evidence system-prototype-v1/docs/round2/decisions/p13-08.md \
  --evidence system-prototype-v1/docs/round2/user-research/p16-ux-follow-up.md 2>&1 | tee "$candidate/runner.log"
result=${PIPESTATUS[0]}
printf '%s\n' "$result" > "$candidate/exit-code"
exit "$result"
