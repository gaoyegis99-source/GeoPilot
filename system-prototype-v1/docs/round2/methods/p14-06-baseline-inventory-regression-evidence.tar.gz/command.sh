#!/bin/bash
set -o pipefail
geo_versions_evidence="$1"
export GEOPILOT_QGIS_PROCESS=/nonexistent/qgis-process
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1 PROJ_NETWORK=OFF
nice -n 19 ionice -c3 taskset -c 29 .venv/bin/python -B -m pytest -q -p no:cacheprovider \
  tests/method_dev/test_version_compatibility.py tests/methods/test_selected_complex_method.py \
  --basetemp="$geo_versions_evidence/pytest" --junitxml="$geo_versions_evidence/green.xml" 2>&1 |
  tee "$geo_versions_evidence/green.log"
geo_test_status=${PIPESTATUS[0]}
printf '%s\n' "$geo_test_status" > "$geo_versions_evidence/green.exit"
exit "$geo_test_status"
