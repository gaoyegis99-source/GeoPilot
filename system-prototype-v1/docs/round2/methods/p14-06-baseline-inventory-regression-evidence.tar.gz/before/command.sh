#!/usr/bin/env bash
set -o pipefail
probe=/dev/shm/geopilot-p16-version-compat.PWgoL9ew
prototype=/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1
python_bin="$prototype/.venv/bin/python"
cd "$probe/source/system-prototype-v1" || exit 1
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm

for label in set unset; do
  if test "$label" = set; then
    environment=(env "GEOPILOT_QGIS_PROCESS=$prototype/.environments/qgis-deb/qgis_process")
  else
    environment=(env -u GEOPILOT_QGIS_PROCESS)
  fi
  "${environment[@]}" taskset -c 8 "$python_bin" -m pytest -q -p no:cacheprovider \
    "--basetemp=$probe/pytest-$label" "--junitxml=$probe/pytest-$label.xml" \
    tests/method_dev/test_version_compatibility.py 2>&1 | tee "$probe/pytest-$label.log"
  printf '%s\n' "$?" > "$probe/pytest-$label.exit-code"
  "${environment[@]}" taskset -c 8 "$python_bin" -B scripts/methods/check_versions.py \
    --baseline "$PWD" --candidate "$PWD" > "$probe/cli-$label.json" 2> "$probe/cli-$label.stderr"
  printf '%s\n' "$?" > "$probe/cli-$label.exit-code"
done

cmp "$probe/cli-set.json" "$probe/cli-unset.json" && \
  test "$(cat "$probe/pytest-set.exit-code" "$probe/pytest-unset.exit-code" | sort -u)" = 1 && \
  test "$(cat "$probe/cli-set.exit-code" "$probe/cli-unset.exit-code" | sort -u)" = 0
result=$?
printf '%s\n' "$result" > "$probe/reproduction.exit-code"
exit "$result"
