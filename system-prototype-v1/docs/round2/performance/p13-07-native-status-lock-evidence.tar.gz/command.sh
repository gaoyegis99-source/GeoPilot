#!/usr/bin/env bash
set -euo pipefail

evidence=/dev/shm/geopilot-p13-native-locks.yL6koZsg
disk=/home/mtd/liweigis/geopilot-p13-native-locks.O5kAKmFU
repository=/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1
source_tree=/dev/shm/geopilot-p13-normal-locks.O5nD9vXs/source
runtime="$repository/.environments/p13-native"
image=sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87
formal=geopilot-p1305-L-fff225f22356-SIbfWQ-t14-split_by_area-candidate-BdH0Dm
queue_retry="$repository/artifacts/test-results/p13-05-dem-m-after-t14.aMTPUR.log"
queue_capacity="$repository/artifacts/test-results/p13-05-dem-l-capacity-after-formal.8MhU5l.log"

snapshot() {
  date -u +%FT%TZ
  docker ps --format '{{.Names}} {{.Image}} {{.Status}}'
  for directory in "$repository/artifacts/test-results" "$disk" "$evidence/tmpfs-data" /mnt/datab; do
    printf '%s\n' "$directory"
    findmnt -T "$directory" -no SOURCE,FSTYPE,MAJ:MIN,TARGET
  done
  if test "$(docker ps --filter "name=$formal" --format '{{.Names}}')" = "$formal"; then
    docker inspect --format '{{range .Mounts}}{{printf "%s\t%s\t%t\n" .Source .Destination .RW}}{{end}}' "$formal" |
      while IFS=$'\t' read -r source destination writable; do
        test -n "$source" || continue
        printf '%s\t%s\t%s\t' "$source" "$destination" "$writable"
        findmnt -T "$source" -no SOURCE,FSTYPE,MAJ:MIN
      done
  fi
  tail -n 1 "$queue_retry" "$queue_capacity"
}

guard_disk() {
  local names writable scratch
  names=$(docker ps --filter name=geopilot-p1305 --format '{{.Names}}') || return 1
  test "$names" = "$formal" || return 1
  writable=$(docker inspect --format '{{range .Mounts}}{{if .RW}}{{println .Destination}}{{end}}{{end}}' "$formal") || return 1
  test "$writable" = /scratch || return 1
  scratch=$(docker inspect --format '{{range .Mounts}}{{if eq .Destination "/scratch"}}{{.Source}}{{end}}{{end}}' "$formal") || return 1
  test "$(findmnt -rn -T "$scratch" -o MAJ:MIN)" = 8:17 || return 1
  test "$(findmnt -rn -T "$disk" -o MAJ:MIN)" = 8:2 || return 1
  test "$(findmnt -rn -T "$disk" -o FSTYPE)" = ext4 || return 1
  test "$(findmnt -rn -T "$repository/artifacts/test-results" -o MAJ:MIN)" = 8:2 || return 1
  [[ $(tail -n 1 "$queue_retry") == *'waiting for T14 launcher'* ]] || return 1
  [[ $(tail -n 1 "$queue_capacity") == *'waiting for DEM M retry'* ]] || return 1
}

snapshot | tee "$evidence/guard-before-disk.log"
if ! guard_disk; then
  printf '%s\n' 'Disk guard did not pass; use completed tmpfs control.' | tee "$evidence/mode-disk"
  printf '%s\n' '2' > "$evidence/disk.exit-code"
  exit 2
fi
printf '%s\n' sda2 | tee "$evidence/mode-disk"
sha256sum "$evidence/normal_probe.py" | tee "$evidence/probe-source.sha256"
cat "$source_tree/REVISION"
docker image inspect --format '{{.Id}} {{.Architecture}} {{.Os}}' "$image"

read -r -d '' container_script <<'SH' || :
set -eu
python_bin=/runtime/venv/bin/python
"$python_bin" -c 'import sys, sqlite3, platform; print(sys.version); print("sqlite3", sqlite3.sqlite_version); print(platform.platform()); assert sys.version_info[:3] == (3,12,3) and sqlite3.sqlite_version == "3.45.1"'
"$python_bin" -c 'from pathlib import Path; print("\n".join(line for line in Path("/proc/self/mountinfo").read_text().splitlines() if line.split()[4] in {"/scratch-disk", "/scratch-tmpfs"}))'
measure() {
  "$python_bin" /harness/normal_probe.py "$1/standard" --runs 2 --readers 1 --interval 0.2
  "$python_bin" /harness/normal_probe.py "$1/concurrent" --runs 3 --readers 4 --interval 0.01 --auxiliary
}
printf '\nvolume /scratch-disk\n'
measure /scratch-disk
SH

set +e
docker run --rm --pull=never --name geopilot-p13-native-locks-yL6koZsg --network none \
  --user "$(id -u):$(id -g)" --read-only --tmpfs /tmp:rw,nosuid,nodev,mode=1777 --log-driver none \
  --cpus 1 --cpu-shares 128 --cap-drop ALL --security-opt no-new-privileges \
  --entrypoint /usr/bin/nice --workdir /probe-source/system-prototype-v1 \
  -e HOME=/tmp -e TMPDIR=/tmp -e PYTHONDONTWRITEBYTECODE=1 -e PYTHONUNBUFFERED=1 \
  -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -e GDAL_NUM_THREADS=1 -e MKL_NUM_THREADS=1 -e PROJ_NETWORK=OFF \
  -e PYTHONPATH=/probe-source/system-prototype-v1/src \
  --mount "type=bind,src=$source_tree,dst=/probe-source,readonly" \
  --mount "type=bind,src=$runtime,dst=/runtime,readonly" \
  --mount "type=bind,src=$evidence,dst=/harness,readonly" \
  --mount "type=bind,src=$disk,dst=/scratch-disk" \
  "$image" -n 12 /bin/sh -c "$container_script" 2>&1 | tee "$evidence/native-disk.log"
result=$?
set -e
printf '%s\n' "$result" > "$evidence/disk.exit-code"
snapshot | tee "$evidence/guard-after-disk.log"
exit "$result"
