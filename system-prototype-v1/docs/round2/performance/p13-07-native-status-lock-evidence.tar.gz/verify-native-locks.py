"""Recompute the isolated native status observations from the raw HTTP records."""

from collections import Counter
from hashlib import sha256
import json
from math import ceil
from pathlib import Path
import sys


def read(path):
    return json.loads(path.read_bytes())


def metric(rows):
    values = sorted(row["wall_ns"] for row in rows)
    return {f"p{p}_ms": round(values[ceil(len(values) * p / 100) - 1] / 1_000_000, 3)
            for p in (50, 95, 99, 100)}


def main(root):
    original = read(root / "comparison.json")
    observations = {}
    for storage in ("sda2", "tmpfs"):
        for mode, run_count in (("standard", 2), ("concurrent", 3)):
            label = f"{storage}_{mode}"
            folder = root / storage / mode
            raw_summary = folder / "summary.json"
            summary = read(raw_summary)
            assert summary["sqlite"] == "3.45.1"
            assert summary["pragmas"] == {
                "journal_mode": "delete", "busy_timeout": 5000, "synchronous": 2,
                "cache_spill": 483, "cache_size": -2000, "page_size": 4096,
            }
            assert summary["runs_requested"] == summary["passed_reports"] == summary["artifacts"] == run_count
            assert summary["integrity_check"] == "ok" and not summary["journal_left_after_stop"] and not summary["diagnostics"]
            assert original[label]["source_result_sha256"] == sha256(raw_summary.read_bytes()).hexdigest()
            assert original[label]["exit_code"] == 0
            rows = [json.loads(line) for line in (folder / "http.jsonl").read_bytes().splitlines()]
            assert rows and all(row["http"] == (202 if row["kind"] == "submission" else 200) for row in rows)
            groups = {}
            for kind in {row["kind"] for row in rows}:
                group = [row for row in rows if row["kind"] == kind]
                groups[kind] = {"codes": dict(Counter(str(row["http"]) for row in group)), "latency": metric(group)}
            assert groups == original[label]["requests"] == summary["requests"]
            completed = {row["run_id"] for row in rows if row.get("execution_status") == "SUCCEEDED"
                         and row["check_status"] == "PASSED"}
            assert len(completed) == run_count
            observations[label] = {"passed": run_count, "status": groups["status"], "total_http": len(rows)}
    print(json.dumps(observations, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]))
