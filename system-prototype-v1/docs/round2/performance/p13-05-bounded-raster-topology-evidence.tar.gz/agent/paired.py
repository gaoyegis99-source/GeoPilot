import json
import statistics
import subprocess
import sys

for case in ("dem-m", "remote-l"):
    groups = {"b490": [], "candidate": []}
    for repeat in range(1, 4):
        for role in (("b490", "candidate") if repeat % 2 else ("candidate", "b490")):
            cmd = [sys.executable, "-B", "probe.py", "--measure", role, case]
            data = json.loads(subprocess.check_output(cmd, text=True))
            groups[role].append(data)
            print(json.dumps({"repeat": repeat, **data}), flush=True)
    values = [row for group in groups.values() for row in group]
    assert len({(row["segments"], row["sums"]) for row in values}) == 1
    medians = {role: {key: statistics.median(row[key] for row in group) for key in ("wall_ns", "cpu_ns")}
               for role, group in groups.items()}
    for role, group in groups.items():
        medians[role]["vmhwm_bytes"] = statistics.median(row["memory_after"]["VmHWM"] for row in group)
    print(json.dumps({"case": case, "medians": medians,
                      "cpu_reduction_percent": 100 * (1 - medians["candidate"]["cpu_ns"] / medians["b490"]["cpu_ns"])}),
          flush=True)
