import hashlib
import json

from probe import TINY, WINDOWS, traced

for case in (*WINDOWS, *TINY):
    expected, observed = (traced(role, case) for role in ("b490", "candidate"))
    assert observed == expected, case
    print(json.dumps({
        "case": case, "selected_cells": expected["selected"], "ordered_calls": len(expected["calls"]),
        "transformed_points": sum(expected["points"]), "max_segments": expected["segments"],
        "error": expected["error"], "bitwise_coordinates_and_areas": True,
        "trace_sha256": hashlib.sha256(json.dumps(expected).encode()).hexdigest(),
    }), flush=True)
