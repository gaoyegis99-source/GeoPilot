from collections import Counter
from time import process_time_ns
import json
import numpy as np

from probe import load, load_case


def profile(variant, case):
    mod = load(variant)
    data, selected, tile, affine, transformer, size = load_case(case)
    rr, cc = np.nonzero(selected)
    layouts = []
    for start in range(0, len(rr), size):
        rows, cols = rr[start:start + size], cc[start:start + size]
        layouts.append(((rows-rows.min()).tobytes(), (cols-cols.min()).tobytes()))
    frequency = Counter(layouts)
    same = sum(a == b for a,b in zip(layouts,layouts[1:]))
    seen, two_hits = [], 0
    for layout in layouts:
        if layout in seen:
            two_hits += 1
            seen.remove(layout)
        seen.append(layout)
        del seen[:-2]
    spent = Counter()
    calls = Counter()
    def patch(obj,name):
        real = getattr(obj,name)
        def wrapped(*args, **kwargs):
            start = process_time_ns()
            try:
                return real(*args, **kwargs)
            finally:
                spent[name] += process_time_ns()-start
                calls[name] += 1
        setattr(obj,name,wrapped)
        return real
    patches = [(mod,"_project_points"),(mod,"_cell_areas"),(mod._BatchLayout,"level"),
               (mod._BatchLayout,"matches"),(mod._BatchProjection,"areas")]
    if hasattr(mod._BatchLayout,"shared_level"):
        patches.append((mod._BatchLayout,"shared_level"))
    originals = [(o,n,patch(o,n)) for o,n in patches]
    try:
        sums=np.zeros(256)
        start=process_time_ns()
        mod._sum_projected_tile(data,selected,tile,affine,transformer,sums)
        total=process_time_ns()-start
    finally:
        for obj,name,method in originals:
            setattr(obj,name,method)
    print(json.dumps({"variant":variant,"case":case,"core_cpu_ms":total/1e6,
      "scoped_cpu_ms":{k:round(v/1e6,3) for k,v in spent.items()},"calls":calls,
      "batches":len(layouts),"distinct_layouts":len(frequency),"frequent_layout_counts":list(frequency.values())[:20],
      "consecutive_hits":same,"two_layout_hits":two_hits}))


for variant in ("a2","b490"):
    for case in ("dem-m","remote-l"):
        profile(variant,case)
