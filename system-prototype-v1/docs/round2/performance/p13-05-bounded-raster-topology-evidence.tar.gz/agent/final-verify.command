cd /dev/shm/geopilot-p13-05-area-hotspots.hzjXGw
env PYTHONPATH=/dev/shm/geopilot-p13-05-area-hotspots.hzjXGw/source/system-prototype-v1/src PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1 PROJ_NETWORK=OFF ionice -c3 nice -n 19 taskset -c 31 /home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/.venv/bin/python -B verify.py 
