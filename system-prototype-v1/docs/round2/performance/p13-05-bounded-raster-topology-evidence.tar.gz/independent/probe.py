"""Only three sealed 256x256 windows and tiny synthetic projection guards."""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import statistics
import subprocess
import sys
import tempfile
import time

import numpy as np
import rasterio
from pyproj import Transformer
from pyproj.exceptions import ProjError
from rasterio.transform import Affine
from rasterio.windows import Window


HERE = Path(__file__).resolve().parent
SEALED = Path(os.environ["GEOPILOT_TOPOLOGY_FIXTURES"])
WINDOWS = {"dem-m": (0, 0), "dem-l": (1024, 1024), "remote-l": (0, 0)}
TINY = ("shear-and-gaps", "column-shift", "refines-after-shared", "collapsed-second", "invalid-eighth", "proj-error-eighth")
SEAMS = ((179.85, "EPSG:6933"), (89.85, "EPSG:8858"), (-30.15, "EPSG:8859"))


def load(name):
    module_name = f"isolated_{name}"
    spec = importlib.util.spec_from_file_location(module_name, HERE / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def digest(array):
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


class SyntheticProjection:
    def __init__(self, scenario):
        self.scenario = scenario

    def transform(self, x, y, *, errcheck):
        assert errcheck
        if self.scenario == "refines-after-shared":
            return x, y + 0.003 * np.maximum(y - 1, 0) * np.sin(x * 1.1)
        if self.scenario == "collapsed-second":
            return x, np.minimum(y, 1)
        broken = (y > 1) & (np.remainder(x, 0.25) == 0.125)
        if self.scenario == "proj-error-eighth" and broken.any():
            raise ProjError("Test transform rejects a new second-row vertex")
        return np.where(broken, np.nan, x), y


def proj(crs):
    return Transformer.from_crs(crs, 6933, always_xy=True, allow_ballpark=False, only_best=True)


def load_case(case):
    if case in WINDOWS:
        col, row = WINDOWS[case]
        tile = Window(col, row, 256, 256)
        with rasterio.open(SEALED / f"{case}.tif") as src:
            data = src.read(1, window=tile, masked=True)
            selected = ~np.ma.getmaskarray(data) & (data.data > 0) & (data.data < 255)
            return data.data, selected, tile, src.transform, proj(src.crs), 256
    if case == "shear-and-gaps":
        data = np.array([[7, 1, 7, 7], [7, 1, 7, 7], [7, 1, 7, 7], [0, 2, 2, 0], [0, 2, 2, 0]], dtype=np.uint8)
        affine = Affine(10, 2, 500000, 1, -10, 4500000)
        return data, data > 0, Window(40, 48, 4, 5), affine, proj(32650), 4
    if case == "column-shift":
        data = np.array([[7, 7, 7, 0, 0], [0, 7, 7, 7, 0], [0, 0, 7, 7, 7]], dtype=np.uint8)
        affine = Affine(10, 2, 500000, 1, -10, 4500000)
        return data, data > 0, Window(40, 48, 5, 3), affine, proj(32650), 3
    data = np.full((3, 3), 7, dtype=np.uint8)
    return data, data > 0, Window(0, 0, 3, 3), Affine.identity(), SyntheticProjection(case), 3


def traced(name, case):
    mod = load(name)
    data, selected, tile, affine, transformer, size = load_case(case)
    mod._CELL_BATCH_SIZE = size
    calls = []
    points = []
    areas = mod._BatchProjection.areas
    project = mod._project_points

    def wrapped_project(row, col, *args):
        points.append(row.size)
        return project(row, col, *args)

    def wrapped_areas(self, segments, *args):
        entry = [self._row_origin, self._col_origin, segments]
        try:
            result = areas(self, segments, *args)
        except ValueError as error:
            calls.append(entry + [str(error)])
            raise
        calls.append(entry + [result.size, digest(result), digest(self._x), digest(self._y)])
        return result

    mod._BatchProjection.areas = wrapped_areas
    mod._project_points = wrapped_project
    sums = np.zeros(256)
    try:
        segments = mod._sum_projected_tile(data, selected, tile, affine, transformer, sums)
        error = None
    except ValueError as exc:
        segments, error = None, [type(exc).__name__, str(exc)]
    return {"calls": calls, "points": points, "error": error, "segments": segments, "sums": digest(sums),
            "selected": int(selected.sum()), "classes": np.flatnonzero(sums).tolist()}


def compare_exact():
    for case in (*WINDOWS, *TINY):
        a, b = (traced(name, case) for name in ("frozen", "candidate"))
        assert a["calls"] == b["calls"], (case, "batch/order/coordinate or area bits changed",
                                          next(((x, y) for x, y in zip(a["calls"], b["calls"]) if x != y), None))
        assert {k: v for k, v in a.items() if k != "points"} == {k: v for k, v in b.items() if k != "points"}
        assert len(a["points"]) == len(b["points"])
        if case == "column-shift":
            assert a["points"] == b["points"]
        if case == "refines-after-shared":
            assert a["segments"] > 8 and any(x != y for x, y in zip(a["points"], b["points"]))
            assert a["points"][-1] == b["points"][-1]
        if case in ("collapsed-second", "invalid-eighth", "proj-error-eighth"):
            assert a["error"] and a["calls"][-1][:2] == [1, 0] and len(a["calls"]) >= 4
        print(json.dumps({
            "case": case, "selected": a["selected"], "level_calls": len(a["calls"]),
            "converged_or_attempted_levels": dict(Counter(row[2] for row in a["calls"])),
            "frozen_transform_points": sum(a["points"]), "candidate_transform_points": sum(b["points"]),
            "point_saving_pct": round((1 - sum(b["points"]) / sum(a["points"])) * 100, 3),
            "batch_level_calls_with_savings": sum(x != y for x, y in zip(a["points"], b["points"])),
            "max_segments": a["segments"], "exact_order_xy_areas_sums": True,
            "error": a["error"], "trace_sha256": hashlib.sha256(json.dumps(a["calls"]).encode()).hexdigest(),
        }), flush=True)
    with tempfile.TemporaryDirectory(dir=HERE) as tmp:
        for west, target in SEAMS:
            path = Path(tmp) / "cut.tif"
            with rasterio.open(path, "w", driver="GTiff", width=3, height=1, count=1, dtype="uint8",
                               crs="EPSG:4326", transform=Affine(0.1, 0, west, 0, -0.05, 0.03), nodata=255) as ds:
                ds.write(np.full((1, 3), 7, dtype=np.uint8), 1)
            errors = []
            for name in ("frozen", "candidate"):
                try:
                    load(name).summarize_threshold_area(path, area_crs=target)
                except ValueError as exc:
                    errors.append([type(exc).__name__, str(exc)])
            assert len(errors) == 2 and errors[0] == errors[1] and "single longitude interval" in errors[0][1]
            print(json.dumps({"case": "policy-projection-cut", "target": target, "west": west, "error": errors[0]}))


def memory():
    fields = {}
    for line in Path("/proc/self/status").read_text().splitlines():
        name, value = line.split(":", 1)
        if name in ("VmRSS", "VmHWM"):
            fields[name] = int(value.split()[0]) * 1024
    fields["ru_maxrss"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    return fields


def measure_once(name, case):
    mod = load(name)
    data, selected, tile, affine, transformer, size = load_case(case)
    mod._CELL_BATCH_SIZE = size
    sums = np.zeros(256)
    before = memory()
    wall, cpu = time.monotonic_ns(), time.process_time_ns()
    segments = mod._sum_projected_tile(data, selected, tile, affine, transformer, sums)
    cpu, wall = time.process_time_ns() - cpu, time.monotonic_ns() - wall
    after = memory()
    print(json.dumps({"variant": name, "case": case, "wall_ns": wall, "cpu_ns": cpu,
                      "memory_before": before, "memory_after": after, "segments": segments, "sums": digest(sums)}))


def repeat():
    for case in WINDOWS:
        rows = []
        for i in range(5):
            for name in (("frozen", "candidate") if i % 2 == 0 else ("candidate", "frozen")):
                cmd = [sys.executable, "-B", __file__, "--measure", name, case]
                row = json.loads(subprocess.check_output(cmd, text=True))
                row["repeat"] = i + 1
                rows.append(row)
                print(json.dumps(row), flush=True)
        assert len({(row["segments"], row["sums"]) for row in rows}) == 1
        stats = {}
        for name in ("frozen", "candidate"):
            group = [row for row in rows if row["variant"] == name]
            stats[name] = {key: statistics.median(row[key] for row in group) for key in ("wall_ns", "cpu_ns")}
            stats[name].update({key: statistics.median(row["memory_after"][key] for row in group)
                                for key in ("VmRSS", "VmHWM", "ru_maxrss")})
        print(json.dumps({"case": case, "medians": stats,
                          "candidate_cpu_saving_pct": round((1 - stats["candidate"]["cpu_ns"] / stats["frozen"]["cpu_ns"]) * 100, 3)}),
              flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--trace", action="store_true")
    parser.add_argument("--repeat", action="store_true")
    parser.add_argument("--measure", nargs=2)
    args = parser.parse_args()
    if args.trace:
        compare_exact()
    if args.repeat:
        repeat()
    if args.measure:
        measure_once(*args.measure)
