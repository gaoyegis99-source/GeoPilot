"""Compare both implementations on fixed compact and sparse integer layouts."""

import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np


FIELDS = ("keys", "inverse", "reused", "missing", "new_rows", "new_cols")


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def layouts(seed, compact):
    rng = np.random.default_rng(seed)
    for index in range(24):
        width, height = (int(value) for value in rng.integers(2, 15, size=2))
        selected = rng.choice(width * height, size=min(width * height, 13 + index * 2), replace=False)
        rows, cols = np.divmod(selected, width)
        stride = 1 if compact else 31
        yield (rows - rows.min()) * stride, (cols - cols.min()) * stride


def main(root):
    reference = load("reference_area_stats", root / "b490.py")
    candidate = load("candidate_area_stats", root / "candidate.py")
    results = []
    for compact in (True, False):
        digest = hashlib.sha256()
        nlevels = 0
        for rows, cols in layouts(20261113, compact):
            original = reference._BatchLayout(rows, cols)
            improved = candidate._BatchLayout(rows, cols)
            keys = np.empty(0, dtype=np.int64)
            for segments in (2, 4, 8, 16):
                before = original.level(segments, keys)
                after = improved.level(segments, keys)
                for field in FIELDS:
                    a, b = getattr(before, field), getattr(after, field)
                    assert a.shape == b.shape and a.dtype == b.dtype
                    assert a.tobytes() == b.tobytes(), (compact, nlevels, segments, field)
                    digest.update(b.tobytes())
                keys = before.keys
                nlevels += 1
        results.append({"layout": "compact" if compact else "sparse", "checked_levels": nlevels, "sha256": digest.hexdigest()})
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]))
