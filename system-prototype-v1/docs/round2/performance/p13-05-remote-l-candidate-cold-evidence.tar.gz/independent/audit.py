"""Read only the committed JSONL prefix for the remote sensing L frozen candidate cold group."""
from collections import Counter
from hashlib import sha256
from io import BytesIO
from itertools import islice
import json
import math
import re
from pathlib import Path
import shlex
from statistics import median
import subprocess
import tarfile
import sys

REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
DOCS = REPO / "docs/round2/performance"
ROOT = REPO / "artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l"
ATTEMPT = ROOT / "remote-l/candidate/attempt.tnx5f7_f"
TRIALS = ATTEMPT / "evidence/trials.jsonl"
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
MANIFEST = "7ca5d30de46b40955845aadb312ff02b6653a11fc708d8aeaaf8d404fb769e04"
FINAL_STEP = "calculate_change"
POLL_ERROR = {"http_status": 500, "body": {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}}}
RESOURCES = ("cpu_ns", "peak_rss_bytes", "disk_read_bytes", "disk_write_bytes")
METRICS = ("wall_ns", "queue_wall_ns", "execute_steps_wall_ns", "finalize_wall_ns", *RESOURCES, "peak_temp_bytes")
PROOFS = {
    "first_s": ("/tmp/geopilot-p13-05-raster-s-audit.rJKuNw/independent.json",
                "f6c4e2d81e0d269b154a5640c7aa71a4636472174bb841e86290c59c630c437b"),
    "remote_s_rerun": ("/tmp/geopilot-p13-05-remote-s-after-vector-l-audit.Gbk18m/independent.json",
                       "cbb29456d9657978bdd4a59d60f0debdedc7bcb91a38efc5b6a0f08f85c2892b"),
    "dem_m": ("/tmp/geopilot-p13-05-dem-m-pair-attempt-audit.vYP1vW/independent.json",
              "685e02b33b3977545e0c515aff591b7ee1202551f9f82d755506028009f66e42"),
}
DEM_L_PROOF = Path("/tmp/geopilot-p13-05-dem-l-final-pair-audit.EppAOX/independent.json")
DEM_L_PROOF_SHA = "8f0c3286971b1c44239eddaf2afd24fa71b9a9128d4961530ab3c438c0b61995"
CLASSIFICATION_SOURCE = DOCS / "p13-04-remote-l-classification-source.json"


def classification_reference(historical):
    frozen = read(CLASSIFICATION_SOURCE)
    source, = [row for row in historical if row["run_id"] == frozen["source_run_id"]]
    assert source["run_state"] == frozen["source_run_terminal_state"]
    assert frozen["fixture_manifest_sha256"] == MANIFEST
    assert frozen["source_step"] == FINAL_STEP and frozen["source_tool"] == source["telemetry"]["steps"][-1]["tool"]
    assert (frozen["shape"], frozen["valid_class_counts"], frozen["masked_pixels"]) == (
        [3072, 3072], {"1": 1572864, "2": 1572864, "3": 1572864}, 4718592,
    )
    return frozen


def digest(raw):
    return sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    with path.open("rb") as stream:
        return [json.loads(line) for line in stream]


def proof(label):
    name, expected = PROOFS[label]
    raw = Path(name).read_bytes()
    assert digest(raw) == expected
    return json.loads(raw)


def observe(value):
    return {"status": "recorded" if value is not None else "unavailable", "value": value}


def distribution(items):
    values = [item["value"] for item in items if item.get("value") is not None]
    return {
        "n": len(values), "coverage": dict(Counter(item["status"] for item in items)), "values": values,
        "median": median(values) if len(values) >= 3 else None,
        "p95": sorted(values)[math.ceil(.95 * len(values)) - 1] if len(values) >= 3 else None,
    }


def check_timeout(row, expected_steps, expected_params):
    run = row["run_state"]
    assert (row["status"], run["execution_status"], run["check_status"], run["current_step"]) == (
        "FAIL", "FAILED", "NOT_CHECKED", FINAL_STEP,
    )
    assert run["run_id"] == row["run_id"] and run["current_report_id"] is None and not run["cancel_requested"]
    error = run["error"]
    assert (error["code"], error["phase"], error["step_key"], error["message"]) == (
        "PROCESS_TIMEOUT", "execute", FINAL_STEP, "Process exceeded 60 seconds",
    )
    assert row["exit_code"] == -15 and row["error"]["type"] == "ValueError"
    assert "did not pass execution/checks" in row["error"]["message"]
    assert all(key not in row for key in ("correctness", "v1_completed_checks", "output_bytes"))
    doc = row["telemetry"]
    assert (doc["schema_version"], doc["run_id"], doc["execution_status"], doc["check_status"], doc["exit_code"]) == (
        1, row["run_id"], "FAILED", "NOT_CHECKED", -15,
    )
    steps = row["executed_steps"]
    assert len(steps) == len(doc["steps"]) == len(expected_steps) == 8
    for i, (request, event) in enumerate(zip(steps, doc["steps"], strict=True)):
        key, tool, version = expected_steps[i]
        assert request["step_key"] == event["step_key"] == key
        assert request["tool"] == {"id": tool, "version": version} == {k: event["tool"][k] for k in ("id", "version")}
        assert request["parameters"] == expected_params[i]
        failed = i == 7
        expected_status, expected_exit = ("FAILED", -15) if failed else ("SUCCEEDED", 0)
        assert request["status"] == event["status"] == expected_status
        assert request["exit_code"] == event["exit_code"] == expected_exit
        process, = [item for item in event["processes"] if item["phase"] == "execute"]
        assert process["exit_code"] == expected_exit and process["timed_out"] == failed and not process["cancelled"]
        if failed:
            assert process["wall_ns"] >= 60_000_000_000


def metrics(row):
    doc = row["telemetry"]
    return {
        "wall_ns": observe(row["wall_ns"]), "queue_wall_ns": doc["queue_wall_ns"],
        "execute_steps_wall_ns": observe(doc["execute_steps_wall_ns"]), "finalize_wall_ns": observe(doc["finalize_wall_ns"]),
        **doc["resources"], "peak_temp_bytes": row["workspace_size"]["peak_temp_bytes"],
    }


def official_history():
    files = [DOCS / f"p13-04-{kind}-method-{size}-trials.jsonl"
             for kind, size in (("raster", "s"), ("raster", "m"), ("raster", "l"), ("remote", "sm"), ("remote", "l"))]
    rows = [row for f in files for row in jsonl(f)]
    assert len(rows) == len({row["run_id"] for row in rows}) == 84
    same = [row for row in rows if row["family"] == "remote_sensing" and row["tier"] == "L"]
    assert len(same) == 14 and {row["manifest_sha256"] for row in same} == {MANIFEST}
    for row in same:
        state = row["run_state"]
        assert (row["status"], state["execution_status"], state["check_status"], state["current_step"]) == (
            "FAIL", "FAILED", "NOT_CHECKED", FINAL_STEP,
        )
        assert state["error"]["code"] == "PROCESS_TIMEOUT"
        assert [step["exit_code"] for step in row["telemetry"]["steps"]] == [0] * 7 + [-15]
    return rows, same


def prior_ids(historical, current):
    first = [rid for case in proof("first_s").values() for side in ("base", "candidate") for rid in case[side]["run_ids"]]
    later = [row["run_id"] for side in ("base", "candidate") for row in proof("remote_s_rerun")[side]["observations"]]
    medium = [row["run_id"] for side in ("baseline", "candidate") for row in proof("dem_m")[side]["observations"]]
    assert digest(DEM_L_PROOF.read_bytes()) == DEM_L_PROOF_SHA
    dem_l = [row["run_id"] for side in ("base", "candidate") for row in read(DEM_L_PROOF)[side]["samples"]]
    previous = first + later + medium + dem_l + [row["run_id"] for row in historical]
    assert (len(first), len(later), len(medium), len(dem_l), len(previous)) == (47, 28, 25, 28, 212)
    assert len(previous + current) == len(set(previous + current))
    return {"P13-04": 84, "first_s": 47, "remote_s_rerun": 28, "dem_m": 25, "dem_l": 28,
            "current_cold": len(current), "combined_unique": len(previous + current)}


CANDIDATE = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
BASE_PROOF = Path("/tmp/geopilot-p13-05-remote-l-base-final-audit.PVQ1vW/independent.json")
BASE_PROOF_SHA = "fd5976b36d90817967dadd75073775dac05957ff54332fee69b3a0749a143656"
FIRST_ARCHIVE = "system-prototype-v1/docs/round2/performance/p13-05-remote-l-candidate-first-evidence.tar.gz"
FIXTURE = "system-prototype-v1/benchmarks/raster/area-fixtures/manifest.json"
WORKSPACE_ROOT = Path("/scratch/evidence/samples/L/method/process_cold")
CHECKS = ["product_configuration_matches", "common_valid_pixels_aligned", "change_direction_is_second_minus_first",
          "ndvi_values_in_range"]


def git(commit, path):
    return subprocess.check_output(["git", "-C", str(REPO), "show", f"{commit}:{path}"])


def frozen_refs(commit):
    fixture_manifest = json.loads(git(commit, FIXTURE))
    fixture, = [item for item in fixture_manifest["fixtures"] if item["id"] == "remote-l"]
    raw = git(commit, FIRST_ARCHIVE)
    with tarfile.open(fileobj=BytesIO(raw), mode="r:gz") as archive:
        item, = [member for member in archive.getmembers() if member.name.endswith("/verified.json")]
        with archive.extractfile(item) as source:
            first = json.load(source)
    assert fixture["source"]["fixture_manifest_sha256"] == MANIFEST
    assert fixture["grid"]["shape"] == [3072, 3072]
    assert fixture_manifest["area_reference"] == {
        "crs": "EPSG:6933", "relative_tolerance": 2e-7, "absolute_tolerance_m2": .02,
    }
    return fixture, first, digest(raw)


def independently_expected_masks(reference):
    first = reference["grids"]["landsat"]
    second = reference["grids"]["sentinel"]
    scl = reference["grids"]["native_scl"]
    first_width = first["shape"][1]
    second_width = second["shape"][1]
    first_pixel, second_pixel, scl_pixel = (grid["transform"][0] for grid in (first, second, scl))
    offset = first["transform"][2] - second["transform"][2]
    assert (first_width, second_width, first_pixel, second_pixel, scl_pixel, offset) == (3072, 9218, 30, 10, 20, 7)
    second_rows = second_clear_columns = 0
    for i in range(second_width):
        pos = (i + .5) * second_pixel
        coarse = math.floor((pos - offset) / first_pixel)
        if not 0 <= coarse < first_width:
            continue
        second_rows += 1
        center = (math.floor(pos / scl_pixel) + .5) * scl_pixel
        phase = math.floor((center - offset) / first_pixel) % 6
        second_clear_columns += phase != 4
    return reference["expected_pixels_per_phase"] * 4, second_rows * second_clear_columns


def correctness(row, fixture, reference):
    result = row["correctness"]
    assert set(result) == {
        "first_quality_mask", "first_ndvi", "second_quality_mask", "second_ndvi", "aligned_ndvi",
        "change_raster", "change_classes", "calibration_report", "area_statistics",
    }
    first_clear, second_clear = independently_expected_masks(reference)
    assert (first_clear, second_clear) == (6291456, 66060288)
    first_size, second_size = (reference["landsat_pixels"], reference["sentinel_pixels"])
    common = reference["common_valid_pixels"]
    assert common == sum(fixture["valid_class_counts"].values()) == 4718592
    assert reference["nodata_pixels"] == fixture["masked_pixels"] == first_size - common
    expected = {
        "first_quality_mask": ("landsat", [first_size], [0], first_clear, 0),
        "first_ndvi": ("landsat", [first_clear], [first_size - first_clear], None, 1e-6),
        "second_quality_mask": ("sentinel", [second_size], [0], second_clear, 0),
        "second_ndvi": ("sentinel", [second_clear], [second_size - second_clear], None, 1e-6),
        "aligned_ndvi": ("landsat", [common] * 2, [first_size - common] * 2, None, 1e-6),
        "change_raster": ("landsat", [common], [first_size - common], None, 1e-6),
        "change_classes": ("landsat", [common], [first_size - common], None, 0),
    }
    for name, (grid, valid, masked, ones, tolerance) in expected.items():
        item = result[name]
        expected_grid = reference["grids"][grid]
        assert (item["height"], item["width"]) == tuple(expected_grid["shape"])
        assert item["transform"] == expected_grid["transform"] and item["crs"] == reference["crs"]
        assert (item["valid_pixels_by_band"], item["masked_pixels_by_band"]) == (valid, masked)
        assert item.get("value_one_pixels_by_band") == ([ones] if ones is not None else None)
        assert item["maximum_absolute_error"] == 0 and item["absolute_tolerance"] == tolerance

    for role, source in (("first_product", "landsat"), ("second_product", "sentinel")):
        expected_product = reference["products"][source]
        actual = result["calibration_report"][role]
        assert actual["configuration"] == expected_product["configuration"]
        assert actual["product_id"] == expected_product["id"] and actual["product_key"] == expected_product["product_key"]
        for band in ("red", "nir"):
            value, expected_band = actual["bands"][band], expected_product["bands"][band]
            assert (value["source_code"], value["source_index"]) == (expected_band["code"], expected_band["index"])
            if source == "landsat":
                assert (value["scale"], value["offset"]) == (2.75e-5, -.2)
            else:
                assert (value["quantification"], value["dn_offset"]) == (10000, -1000)

    area = result["area_statistics"]
    actual = area["observed"]
    assert (area["relative_tolerance"], area["absolute_tolerance_m2"]) == (2e-7, .02)
    assert (actual["source_crs"], actual["area_crs"], actual["area_method"], actual["area_unit"],
            actual["cell_area_method"], actual["resampling"]) == (
        "EPSG:32632", "EPSG:6933", "equal_area", "square_meter", "projected_cell_boundary", "none",
    )
    assert actual["threshold"] == reference["change_threshold"] and actual["direction"] == reference["change_direction"]
    assert (actual["valid_pixel_count"], actual["selected_pixel_count"], actual["unselected_pixel_count"],
            actual["nodata_pixel_count"]) == (common, common, 0, fixture["masked_pixels"])
    assert actual["boundary_convergence"] == {"absolute_tolerance_m2": 1e-6, "relative_tolerance": 1e-8, "max_segments_per_edge_used": 8}
    assert {str(item["class_id"]): item["pixel_count"] for item in actual["classes"]} == fixture["valid_class_counts"]
    assert [item["class_name"] for item in actual["classes"]] == ["decrease", "stable", "increase"]
    observed = {str(item["class_id"]): item["area_m2"] for item in actual["classes"]}
    frozen = fixture["expected_area_m2"]
    errors = {}
    for key, value in observed.items():
        assert math.isclose(area["expected_area_by_class_m2"][key], frozen[key], abs_tol=2e-6, rel_tol=0)
        assert math.isclose(value, frozen[key], abs_tol=.02, rel_tol=2e-7)
        errors[key] = abs(value - frozen[key])
    assert math.isclose(actual["total_area_m2"], math.fsum(observed.values()), abs_tol=1e-6, rel_tol=0)
    total_ref = math.fsum(frozen.values())
    assert math.isclose(actual["total_area_m2"], total_ref, abs_tol=.02, rel_tol=2e-7)
    return {"pixels_by_class": fixture["valid_class_counts"], "nodata": fixture["masked_pixels"],
            "observed_area_m2": observed, "independent_area_m2": frozen, "absolute_error_m2": errors,
            "observed_total_m2": actual["total_area_m2"], "independent_total_m2": total_ref,
            "total_absolute_error_m2": abs(actual["total_area_m2"] - total_ref), "max_raster_absolute_error": 0.0}


def verify_terminal(row, expected_steps, params):
    state = row["run_state"]
    assert state["run_id"] == row["run_id"] and (state["execution_status"], state["check_status"]) == ("SUCCEEDED", "PASSED")
    assert state["current_report_id"] and not state["cancel_requested"] and not state["error"]
    doc = row["telemetry"]
    assert (doc["schema_version"], doc["run_id"], doc["execution_status"], doc["check_status"], doc["exit_code"]) == (
        1, row["run_id"], "SUCCEEDED", "PASSED", 0,
    )
    assert row["exit_code"] == 0
    for (key, tool, version), request, event, options in zip(expected_steps, row["executed_steps"], doc["steps"], params, strict=True):
        assert request["step_key"] == event["step_key"] == key
        assert request["tool"] == {"id": tool, "version": version} == {k: event["tool"][k] for k in ("id", "version")}
        assert request["parameters"] == options
        assert request["status"] == event["status"] == "SUCCEEDED" and request["exit_code"] == event["exit_code"] == 0
        process, = [item for item in event["processes"] if item["phase"] == "execute"]
        assert process["exit_code"] == 0 and not process["timed_out"] and not process["cancelled"]
    assert row["v1_completed_checks"] == CHECKS


def artifact_evidence(row, first, base_changes, fixture):
    remote = Path(row["workspace"])
    remote.relative_to(WORKSPACE_ROOT)
    work = ATTEMPT / remote.relative_to("/scratch")
    assert work.resolve().is_relative_to(ATTEMPT.resolve())
    manifest = work / "outputs/manifest.json"
    check_report = work / "checks/report.json"
    assert manifest.stat().st_size < 16384 and check_report.stat().st_size < 512 * 1024
    metadata = read(manifest)
    checks = read(check_report)
    assert (checks["run_id"], checks["report_id"], checks["status"], checks["completed_rules"]) == (
        row["run_id"], row["run_state"]["current_report_id"], "PASSED", CHECKS,
    )
    assert all(checks["rules"][name]["passed"] for name in CHECKS)
    expected = first["verified_file_groups"]
    assert set(metadata["artifacts"]) == set(expected) and len(expected) == 10
    total = 0
    fingerprints = {}
    for role, item in metadata["artifacts"].items():
        assert re.fullmatch(r"[0-9a-f]{64}", item["fingerprint"])
        path = work / item["path"]
        assert path.resolve().is_relative_to(work.resolve()) and path.is_file()
        assert metadata["tool_files"][item["path"]] == item["fingerprint"]
        size = path.stat().st_size
        assert size == expected[role]["bytes"] and item["fingerprint"] == expected[role]["file_group_sha256"]
        total += size
        fingerprints[role] = {"registered_file_group_sha256": item["fingerprint"], "bytes": size}
        if role in ("change_classes", "change_raster"):
            observed = digest(path.read_bytes())
            assert observed == (fixture["sha256"] if role == "change_classes" else base_changes)
            fingerprints[role]["actual_raw_sha256"] = observed
        elif role == "area_statistics":
            assert read(path) == row["correctness"]["area_statistics"]["observed"]
        elif role == "alignment_report":
            data = read(path)
            assert (data["common_valid_pixels"], data["resampling"]) == (fixture["masked_pixels"], "nearest")
    assert total == row["output_bytes"] == 5054589
    return {"registered_roles": fingerprints, "official_output_bytes": total,
            "output_manifest_sha256": digest(manifest.read_bytes()), "check_report_sha256": digest(check_report.read_bytes())}


def main(commit, output, allow_prefix=False):
    plan = read(ROOT / "plan.json")
    assert plan["commits"]["candidate"] == CANDIDATE and plan["input_manifest_sha256"]["remote-l"] == MANIFEST
    store, docker = (ATTEMPT / "command.log").read_text().splitlines()
    args = shlex.split(docker)
    assert store.startswith("storage=/dev/sda2 ext4") and plan["image"] in args
    assert args[args.index("--source-commit") + 1] == CANDIDATE and args[args.index("--tiers") + 1] == "L"
    fixture, first, first_archive_sha = frozen_refs(commit)
    historical, same = official_history()
    historic = same[0]
    reference = read(DOCS / "p13-04-remote-method-l-report.json")["inputs"]["L"]["reference"]
    expected_steps = [(step["step_key"], step["tool"]["id"], step["tool"]["version"]) for step in historic["telemetry"]["steps"]]
    sensors = {key: historic["confirmed_parameters"][key] for key in ("first_configuration", "second_configuration")}
    params = ({}, sensors, {}, {}, {}, {}, {"resampling": "nearest"}, {"change_threshold": .1, "area_crs": "EPSG:6933"})
    assert digest(BASE_PROOF.read_bytes()) == BASE_PROOF_SHA
    baseline = read(BASE_PROOF)
    assert baseline["input_manifest_sha256"] == MANIFEST
    base_changes = {item["sha256"] for item in baseline["staged_change_rasters"]}
    assert len(base_changes) == 1
    base_changes = base_changes.pop()

    with TRIALS.open("rb") as stream:
        raw = [line for line in islice(stream, 7) if line.endswith(b"\n")]
    rows = [json.loads(line) for line in raw]
    assert rows and (allow_prefix or len(rows) == 7)
    assert all(len({row[key] for row in rows}) == len(rows) for key in ("worker_pid", "run_id", "task_id", "plan_id", "workspace"))
    samples = []
    for i, row in enumerate(rows, 1):
        assert (row["cache"], row["index"], row["kind"], row["sample_id"]) == (
            "process_cold", i, "warmup" if i <= 2 else "measurement", f"remote_sensing/L/method/process_cold/{i:02d}",
        )
        assert (row["family"], row["tier"], row["workload"], row["manifest_sha256"], row["worker_exit_code"]) == (
            "remote_sensing", "L", "method", MANIFEST, 0,
        )
        for key in ("method", "critical_options", "confirmed_parameters", "parameters_sha256", "source_input_bytes", "logical_source_input_bytes"):
            assert row[key] == historic[key]
        errors = row.get("status_poll_errors", [])
        assert all(error == POLL_ERROR for error in errors)
        if row["run_state"]["execution_status"] == "SUCCEEDED":
            verify_terminal(row, expected_steps, params)
            checked = correctness(row, fixture, reference)
            artifact = artifact_evidence(row, first, base_changes, fixture)
            assert row["status"] == ("FAIL" if errors else "PASS")
            if errors:
                assert row["error"]["type"] == "StatusObservationFailure"
            else:
                assert not row.get("error")
        else:
            check_timeout(row, expected_steps, params)
            checked, artifact = None, None
        samples.append({
            "run_id": row["run_id"], "sample_id": row["sample_id"], "kind": row["kind"], "status": row["status"],
            "state": row["run_state"], "status_poll_errors": errors, "raw_error_type": (row.get("error") or {}).get("type"),
            "correctness": checked, "artifact_evidence": artifact, "steps": row["executed_steps"], "readings": metrics(row),
        })
    assert samples[0]["run_id"] == first["run_id"]
    base_ids = [row["run_id"] for row in baseline["samples"]]
    identity = prior_ids(historical, base_ids + [row["run_id"] for row in rows])
    assert identity.pop("current_cold") == len(rows) + 14
    identity["remote_l_base"] = 14
    identity["remote_l_candidate_cold"] = len(rows)
    measured = [row for row in rows if row["kind"] == "measurement"]
    distributions = {}
    for status in ("PASS", "FAIL"):
        subset = [row for row in measured if row["status"] == status]
        columns = [metrics(row) for row in subset]
        outcome = {field: distribution([item[field] for item in columns]) for field in METRICS}
        steps = {}
        for i, (key, _, _) in enumerate(expected_steps):
            events = [row["telemetry"]["steps"][i] for row in subset]
            steps[key] = {
                "wall_ns": distribution([observe(event["wall_ns"]) for event in events]),
                **{field: distribution([event["resources"][field] for event in events]) for field in RESOURCES},
            }
        outcome["steps"] = steps
        distributions[status] = outcome
    result = {
        "scope": "frozen candidate cold only", "attempt": str(ATTEMPT),
        "input_manifest_sha256": MANIFEST, "candidate_source": CANDIDATE, "cold_prefix_sha256": digest(b"".join(raw)),
        "first_candidate_archive_sha256": first_archive_sha, "first_candidate_archive_commit": commit,
        "warmup_status_counts": dict(Counter(row["status"] for row in rows if row["kind"] == "warmup")),
        "measurement_status_counts": dict(Counter(row["status"] for row in measured)), "distributions": distributions,
        "status_poll_errors": sum(len(row["status_poll_errors"]) for row in samples),
        "samples": samples, "run_identity": identity, "single_side_formal_receipt_at_snapshot": None,
    }
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("cold rows", len(rows), "warmups", result["warmup_status_counts"], "measurement", result["measurement_status_counts"])
    for row in samples:
        print(row["sample_id"], row["run_id"], row["status"], row["state"]["execution_status"], row["state"]["check_status"],
              "poll errors", len(row["status_poll_errors"]), "artifact check", bool(row["correctness"]))
    for status, d in distributions.items():
        print(status, "wall", d["wall_ns"], "RSS", d["peak_rss_bytes"], "temp", d["peak_temp_bytes"])
        print(status, "change step", d["steps"][FINAL_STEP]["wall_ns"], d["steps"][FINAL_STEP]["peak_rss_bytes"])
    print("independent classification/area", samples[0]["correctness"], "identities", identity)
    print("cold only; no formal side receipt or strict pair verified")


if __name__ == "__main__":
    main(sys.argv[1], Path(sys.argv[2]), allow_prefix="--allow-prefix" in sys.argv[3:])
