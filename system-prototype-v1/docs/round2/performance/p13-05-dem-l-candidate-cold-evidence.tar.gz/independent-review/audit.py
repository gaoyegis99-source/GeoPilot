"""Read only the committed JSONL prefix for the DEM L frozen candidate cold group."""
from collections import Counter
from hashlib import sha256
from itertools import islice
import json
import math
from pathlib import Path
import shlex
from statistics import median
import sys

REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
DOCS = REPO / "docs/round2/performance"
ROOT = REPO / "artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l"
BASE_ATTEMPT = ROOT / "dem-l/base/attempt.7zlasqgn"
ATTEMPT = ROOT / "dem-l/candidate/attempt.53h1my_a"
TRIALS = ATTEMPT / "evidence/trials.jsonl"
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
MANIFEST = "a9c670131aa9d4feab76b63e9ad38c75a1822ac0bd8a8bb1808fadc7fa5771ff"
AREA_STEP = "calculate_area_with_equal_area_projection"
POLL_ERROR = {"http_status": 500, "body": {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}}}
RESOURCES = ("cpu_ns", "peak_rss_bytes", "disk_read_bytes", "disk_write_bytes")
METRICS = ("wall_ns", "queue_wall_ns", "execute_steps_wall_ns", "finalize_wall_ns", *RESOURCES, "peak_temp_bytes")
PROOFS = {
    "first_s": ("/tmp/geopilot-p13-05-raster-s-audit.rJKuNw/independent.json",
                "f6c4e2d81e0d269b154a5640c7aa71a4636472174bb841e86290c59c630c437b"),
    "remote_s_rerun": ("/tmp/geopilot-p13-05-remote-s-after-vector-l-audit.Gbk18m/independent.json",
                       "cbb29456d9657978bdd4a59d60f0debdedc7bcb91a38efc5b6a0f08f85c2892b"),
    "dem_m": ("/tmp/geopilot-p13-05-dem-m-pair-attempt-audit.vYP1vW/independent.json",
              "685e02b33b3977545e0c515aff591b7ee1202551f9f82d755506028009f66e42"),
}
THRESHOLD = {"intervals": [{"class_id": 7, "lower": 45, "upper": 45, "include_lower": True, "include_upper": True}]}
STEP_PARAMS = (
    {"radius_pixels": 1}, {}, {"band": 1, "vertical_unit": "metadata", "z_factor": 1.0},
    {"band": 1, "z_factor": 1.0, "terrain_output": "slope", "slope_unit": "degree"}, {},
    {"threshold": THRESHOLD}, {"area_crs": "EPSG:6933"},
)


def digest(raw):
    return sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    with path.open("rb") as stream:
        return [json.loads(line) for line in stream]


def proof(label):
    name, expected = PROOFS[label]
    raw = Path(name).read_bytes()
    assert digest(raw) == expected
    return json.loads(raw)


def observe(value):
    return {"status": "recorded" if value is not None else "unavailable", "value": value}


def distribution(items):
    values = [item["value"] for item in items if item.get("value") is not None]
    return {
        "n": len(values), "coverage": dict(Counter(item["status"] for item in items)), "values": values,
        "median": median(values) if len(values) >= 3 else None,
        "p95": sorted(values)[math.ceil(.95 * len(values)) - 1] if len(values) >= 3 else None,
    }


def check_timeout(row, expected_steps):
    run = row["run_state"]
    assert (row["status"], run["execution_status"], run["check_status"], run["current_step"]) == (
        "FAIL", "FAILED", "NOT_CHECKED", AREA_STEP,
    )
    assert run["run_id"] == row["run_id"] and run["current_report_id"] is None and not run["cancel_requested"]
    error = run["error"]
    assert (error["code"], error["phase"], error["step_key"], error["message"]) == (
        "PROCESS_TIMEOUT", "execute", AREA_STEP, "Process exceeded 60 seconds",
    )
    assert row["exit_code"] == -15 and row["error"]["type"] == "ValueError"
    assert "did not pass execution/checks" in row["error"]["message"]
    assert all(key not in row for key in ("correctness", "v1_completed_checks", "output_bytes"))
    doc = row["telemetry"]
    assert (doc["schema_version"], doc["run_id"], doc["execution_status"], doc["check_status"], doc["exit_code"]) == (
        1, row["run_id"], "FAILED", "NOT_CHECKED", -15,
    )
    steps = row["executed_steps"]
    assert len(steps) == len(doc["steps"]) == len(expected_steps) == 7
    for i, (request, event) in enumerate(zip(steps, doc["steps"], strict=True)):
        key, tool, version = expected_steps[i]
        assert request["step_key"] == event["step_key"] == key
        assert request["tool"] == {"id": tool, "version": version} == {k: event["tool"][k] for k in ("id", "version")}
        assert request["parameters"] == STEP_PARAMS[i]
        failed = i == 6
        expected_status, expected_exit = ("FAILED", -15) if failed else ("SUCCEEDED", 0)
        assert request["status"] == event["status"] == expected_status
        assert request["exit_code"] == event["exit_code"] == expected_exit
        process, = [item for item in event["processes"] if item["phase"] == "execute"]
        assert process["exit_code"] == expected_exit and process["timed_out"] == failed and not process["cancelled"]
        if failed:
            assert process["wall_ns"] >= 60_000_000_000


def metrics(row):
    doc = row["telemetry"]
    return {
        "wall_ns": observe(row["wall_ns"]), "queue_wall_ns": doc["queue_wall_ns"],
        "execute_steps_wall_ns": observe(doc["execute_steps_wall_ns"]), "finalize_wall_ns": observe(doc["finalize_wall_ns"]),
        **doc["resources"], "peak_temp_bytes": row["workspace_size"]["peak_temp_bytes"],
    }


def official_history():
    files = [DOCS / f"p13-04-{kind}-method-{size}-trials.jsonl"
             for kind, size in (("raster", "s"), ("raster", "m"), ("raster", "l"), ("remote", "sm"), ("remote", "l"))]
    rows = [row for f in files for row in jsonl(f)]
    assert len(rows) == len({row["run_id"] for row in rows}) == 84
    same = [row for row in rows if row["family"] == "raster" and row["tier"] == "L"]
    assert len(same) == 14 and {row["manifest_sha256"] for row in same} == {MANIFEST}
    for row in same:
        state = row["run_state"]
        assert (row["status"], state["execution_status"], state["check_status"], state["current_step"]) == (
            "FAIL", "FAILED", "NOT_CHECKED", AREA_STEP,
        )
        assert state["error"]["code"] == "PROCESS_TIMEOUT"
        assert [step["exit_code"] for step in row["telemetry"]["steps"]] == [0] * 6 + [-15]
    return rows, same


def prior_ids(historical, current):
    first = [rid for case in proof("first_s").values() for side in ("base", "candidate") for rid in case[side]["run_ids"]]
    later = [row["run_id"] for side in ("base", "candidate") for row in proof("remote_s_rerun")[side]["observations"]]
    medium = [row["run_id"] for side in ("baseline", "candidate") for row in proof("dem_m")[side]["observations"]]
    previous = first + later + medium + [row["run_id"] for row in historical]
    assert (len(first), len(later), len(medium), len(previous)) == (47, 28, 25, 184)
    assert len(previous + current) == len(set(previous + current))
    return {"P13-04": 84, "first_s": 47, "remote_s_rerun": 28, "dem_m": 25,
            "current_cold": len(current), "combined_unique": len(previous + current)}


CANDIDATE = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
BASE_PROOF = Path("/tmp/geopilot-p13-05-dem-l-base-final-audit.nlTqBt/independent.json")
BASE_PROOF_SHA = "121d8afd6a208700e83c5b19bb274c2ae830bcba9521f0df30bf6de207b009b6"
COLD_ROOT = Path("/scratch/evidence/samples/L/method/process_cold")


def readonly_command(attempt, source, plan):
    disk, command = (attempt / "command.log").read_text().splitlines()
    args = shlex.split(command)
    assert disk.startswith("storage=/dev/sda2 ext4") and plan["image"] in args
    assert args[args.index("--source-commit") + 1] == source and args[args.index("--tiers") + 1] == "L"
    assert args[args.index("--cache") + 1:args.index("--cache") + 3] == ["process_cold", "warm"]
    mount, = [args[i + 1] for i, item in enumerate(args) if item == "--mount" and ",dst=/inputs," in args[i + 1]]
    assert mount.endswith(",dst=/inputs,readonly")
    return mount


def cold_prefix(attempt):
    path = attempt / "evidence/trials.jsonl"
    with path.open("rb") as stream:
        raw = list(islice(stream, 7))
    assert len(raw) == 7 and all(line.endswith(b"\n") for line in raw)
    rows = [json.loads(line) for line in raw]
    assert [(row["cache"], row["index"]) for row in rows] == [("process_cold", i) for i in range(1, 8)]
    return rows, digest(b"".join(raw))


def threshold_file(attempt, row):
    workspace = Path(row["workspace"])
    workspace.relative_to(COLD_ROOT)
    path = attempt / workspace.relative_to("/scratch") / "intermediate/extract_by_threshold/threshold_regions.tif"
    assert path.resolve().is_relative_to(attempt.resolve())
    assert path.is_file() and 0 < path.stat().st_size <= 256 * 1024
    payload = path.read_bytes()
    return {"path": str(path), "bytes": len(payload), "sha256": digest(payload)}


def main(output):
    plan = read(ROOT / "plan.json")
    assert plan["commits"] == {"base": BASE, "candidate": CANDIDATE}
    assert plan["input_manifest_sha256"]["dem-l"] == MANIFEST and plan["disk"][:2] == ["/dev/sda2", "ext4"]
    mount = readonly_command(ATTEMPT, CANDIDATE, plan)
    assert mount == readonly_command(BASE_ATTEMPT, BASE, plan)

    historical, historical_l = official_history()
    historic = historical_l[0]
    expected_steps = [(step["step_key"], step["tool"]["id"], step["tool"]["version"])
                      for step in historic["telemetry"]["steps"]]
    assert expected_steps[-1][0] == AREA_STEP
    frozen = read(DOCS / "p13-04-raster-method-l-report.json")["inputs"]["L"]
    assert frozen["manifest_sha256"] == MANIFEST and frozen["first_fingerprints"] == frozen["last_fingerprints"]

    assert digest(BASE_PROOF.read_bytes()) == BASE_PROOF_SHA
    baseline = read(BASE_PROOF)
    assert baseline["input_manifest_sha256"] == MANIFEST
    base_rows, base_sha = cold_prefix(BASE_ATTEMPT)
    rows, candidate_sha = cold_prefix(ATTEMPT)
    assert base_sha == baseline["cold_prefix_sha256"]
    assert [row["run_id"] for row in base_rows] == [row["run_id"] for row in baseline["samples"][:7]]
    for field in ("task_id", "plan_id", "worker_pid", "run_id", "workspace"):
        assert len({row[field] for row in rows}) == len(rows)
    observations, fingerprints = [], []
    for row, before in zip(rows, base_rows, strict=True):
        index = row["index"]
        assert (row["kind"], row["sample_id"]) == ("warmup" if index <= 2 else "measurement", f"raster/L/method/process_cold/{index:02d}")
        assert (row["family"], row["tier"], row["workload"], row["manifest_sha256"], row["worker_exit_code"]) == (
            "raster", "L", "method", MANIFEST, 0,
        )
        assert row["source_input_bytes"] == historic["source_input_bytes"] == before["source_input_bytes"]
        assert row["logical_source_input_bytes"] == frozen["reference"]["raw_input_bytes"] == before["logical_source_input_bytes"]
        for key in ("method", "critical_options", "confirmed_parameters", "parameters_sha256"):
            assert row[key] == before[key] == historic[key]
        params = json.dumps(row["confirmed_parameters"], sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
        assert digest(params) == row["parameters_sha256"]
        assert row["executed_steps"] == before["executed_steps"]
        errors = row.get("status_poll_errors", [])
        assert all(error == POLL_ERROR for error in errors)
        check_timeout(row, expected_steps)
        a, b = threshold_file(BASE_ATTEMPT, before), threshold_file(ATTEMPT, row)
        assert (a["bytes"], a["sha256"]) == (b["bytes"], b["sha256"])
        fingerprints.append({"index": index, "base": a, "candidate": b})
        observations.append({
            "sample_id": row["sample_id"], "run_id": row["run_id"], "task_id": row["task_id"], "plan_id": row["plan_id"],
            "kind": row["kind"], "status_poll_errors": errors, "state": row["run_state"], "steps": row["executed_steps"],
            "readings": metrics(row),
        })
    assert len({item["candidate"]["sha256"] for item in fingerprints}) == 1
    base_ids = [row["run_id"] for row in baseline["samples"]]
    new_ids = [row["run_id"] for row in observations]
    assert len(base_ids) == len(set(base_ids)) == 14 and len(new_ids) == len(set(new_ids)) == 7
    identity = prior_ids(historical, base_ids + new_ids)
    assert identity.pop("current_cold") == 21
    identity.update({"baseline_dem_l": 14, "candidate_dem_l_cold": 7})
    assert identity["combined_unique"] == 205

    measured = [row for row in rows if row["kind"] == "measurement"]
    assert len(measured) == 5
    result = {
        "scope": "frozen candidate cold rows only", "candidate": str(ATTEMPT),
        "candidate_source": CANDIDATE, "candidate_cold_raw_sha256": candidate_sha,
        "baseline_cold_raw_sha256": base_sha, "input_manifest_sha256": MANIFEST, "readonly_input_mount": mount,
        "input_fingerprints_from_p13_04": frozen["first_fingerprints"],
        "measured_counts": {"PASS": 0, "FAIL": 5}, "samples": observations, "run_identity": identity,
        "status_poll_errors": sum(len(row["status_poll_errors"]) for row in observations),
        "candidate_failed_distributions": {key: distribution([metrics(row)[key] for row in measured]) for key in METRICS},
        "candidate_success_distributions": {key: distribution([]) for key in METRICS},
        "baseline_failed_distributions": baseline["groups"]["process_cold"]["failed_distributions"],
        "baseline_failed_step_distributions": baseline["groups"]["process_cold"]["failed_step_distributions"],
        "candidate_failed_step_distributions": {},
        "cold_intermediate_file_fingerprints": fingerprints,
        "full_correctness_verified": False,
    }
    for i, (key, _, _) in enumerate(expected_steps):
        events = [row["telemetry"]["steps"][i] for row in measured]
        result["candidate_failed_step_distributions"][key] = {
            "wall_ns": distribution([observe(event["wall_ns"]) for event in events]),
            **{field: distribution([event["resources"][field] for event in events]) for field in RESOURCES},
        }
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("frozen candidate cold 2 warmups + 5 measurements, all six prior steps succeeded; area 60s timeout, -15")
    print("status poll errors", result["status_poll_errors"], "IDs", identity)
    print("same readonly inputs and step requests; 14 cold intermediate threshold files, same bytes and SHA",
          fingerprints[0]["candidate"]["bytes"], fingerprints[0]["candidate"]["sha256"])
    for label in ("baseline", "candidate"):
        d = result[f"{label}_failed_distributions"]
        print(label, "failed wall", d["wall_ns"], "RSS", d["peak_rss_bytes"], "temp", d["peak_temp_bytes"])
        area = result[f"{label}_failed_step_distributions"][AREA_STEP]
        print(label, "failed area step", area["wall_ns"], "area RSS", area["peak_rss_bytes"])
    print("formal artifact correctness not reached; no successful percentiles")


if __name__ == "__main__":
    main(Path(sys.argv[1]))
