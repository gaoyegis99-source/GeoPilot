"""Audit the completed DEM L cold prefix and its unpublished classification."""

from hashlib import sha256
import json
import math
from pathlib import Path
from statistics import median
import sys


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def distribution(observations):
    values = sorted(item["value"] for item in observations)
    return {
        "samples": len(values),
        "partial": sum(item["status"] == "partial" for item in observations),
        "median": median(values),
        "p95_nearest_rank": values[math.ceil(0.95 * len(values)) - 1],
    }


def main(attempt, fixtures, output):
    manifest = json.loads((fixtures / "manifest.json").read_bytes())
    reference = next(item for item in manifest["fixtures"] if item["id"] == "dem-l")
    assert digest(fixtures / reference["path"]) == reference["sha256"]
    input_sha = reference["source"]["fixture_manifest_sha256"]
    prefix = [line for line in (attempt / "evidence/trials.jsonl").read_bytes().splitlines(keepends=True)
              if line.endswith(b"\n")][:7]
    rows = [json.loads(line) for line in prefix]
    assert [(row["cache"], row["index"], row["kind"]) for row in rows] == [
        ("process_cold", n, "warmup" if n <= 2 else "measurement") for n in range(1, 8)
    ]
    assert len({row["run_id"] for row in rows}) == 7
    records = []
    area_key = "calculate_area_with_equal_area_projection"
    relative = Path(reference["source"]["run_relative_path"])
    for row in rows:
        assert (row["status"], row["family"], row["tier"], row["manifest_sha256"]) == ("FAIL", "raster", "L", input_sha)
        state = row["run_state"]
        assert (state["execution_status"], state["check_status"]) == ("FAILED", "NOT_CHECKED")
        assert (state["error"]["code"], state["error"]["step_key"], state["error"]["message"]) == (
            "PROCESS_TIMEOUT", area_key, "Process exceeded 60 seconds",
        )
        steps = row["executed_steps"]
        assert len(steps) == 7 and all((step["status"], step["exit_code"]) == ("SUCCEEDED", 0) for step in steps[:-1])
        assert (steps[-2]["step_key"], steps[-1]["step_key"], steps[-1]["status"], steps[-1]["exit_code"]) == (
            "extract_by_threshold", area_key, "FAILED", -15,
        )
        assert "correctness" not in row and not row.get("v1_completed_checks")
        workspace = attempt / Path(row["workspace"]).relative_to("/scratch")
        assert workspace.resolve(strict=True) == workspace and workspace.name == row["run_id"]
        assert workspace.is_relative_to(attempt) and not (workspace / "outputs/manifest.json").exists()
        request = json.loads((workspace / "steps/extract_by_threshold/request.json").read_bytes())
        assert request["run_id"] == row["run_id"]
        assert request["output_targets"]["threshold_regions"]["path"] == relative.as_posix()
        classification = workspace / relative
        assert classification.is_file() and not classification.is_symlink()
        assert classification.stat().st_size == reference["bytes"] and digest(classification) == reference["sha256"]
        records.append({
            "sample_id": row["sample_id"], "run_id": row["run_id"],
            "wall_ns": row["wall_ns"],
            "status_poll_errors": len(row.get("status_poll_errors") or []),
            "classification_sha256": digest(classification),
            "steps": [{"key": step["step_key"], "status": step["status"], "exit_code": step["exit_code"]} for step in steps],
        })
    measured = rows[2:]
    result = {
        "state": "VERIFIED_COLD_PREFIX",
        "source": str(attempt),
        "samples_sha256": sha256(b"".join(prefix)).hexdigest(),
        "input_manifest_sha256": input_sha,
        "source_input_bytes": sorted({row["source_input_bytes"] for row in rows}),
        "classification": {key: reference[key] for key in ("bytes", "sha256", "grid", "valid_class_counts", "masked_pixels")},
        "records": records,
        "measured_failures": len(measured),
        "failed_wall_ns": distribution([{"value": row["wall_ns"], "status": "recorded"} for row in measured]),
        "peak_rss_bytes": distribution([row["telemetry"]["resources"]["peak_rss_bytes"] for row in measured]),
        "peak_temp_bytes": distribution([row["workspace_size"]["peak_temp_bytes"] for row in measured]),
        "area_step_wall_ns": distribution([
            {"value": row["telemetry"]["steps"][-1]["wall_ns"], "status": "recorded"} for row in measured
        ]),
    }
    (output / "samples-prefix.jsonl").write_bytes(b"".join(prefix))
    (output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print("Seven cold records and their unpublished classification outputs verified.")
    print("Input manifest", input_sha, "classification", reference["sha256"])
    print("Measurement counts and metrics", {key: result[key] for key in (
        "measured_failures", "failed_wall_ns", "peak_rss_bytes", "peak_temp_bytes", "area_step_wall_ns",
    )})


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve(strict=True), Path(sys.argv[2]).resolve(strict=True), Path(sys.argv[3]))
