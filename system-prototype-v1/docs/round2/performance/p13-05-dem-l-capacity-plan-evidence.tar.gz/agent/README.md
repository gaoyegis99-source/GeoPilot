# DEM L 整幅等积面积容量探针

在现有正式栅格和 T14 队列全部退出并由主控交接后，执行 `proof/deferred-run.command`。三个版本各用一个新容器及其中的独立 Python 子进程，顺序为 `977ab41`、`a2d2e68`、`b490254`。入口直接调用生产 `summarize_threshold_area`，范围是封存分类的完整面积计算。该实验与正式方法配对分别归档，正式方法仍使用生产 60 秒步骤时限。

```bash
python3 -B /dev/shm/geopilot-p13-05-dem-l-capacity.tQo1Yb/launch.py \
  --run \
  --output /home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/artifacts/test-results/p13-05-dem-l-capacity.tQo1Yb \
  --total-seconds 5700 --variant-seconds 1800
```

总墙钟上限 5,700 秒从取得共用测量锁开始，单个 native worker 上限 1,800 秒。外层还限制容器墙钟，预留原生绑定核验及终止清理时间。预算不足的余下版本记录 `NOT_RUN_TOTAL_BUDGET`。内层超时会终止子进程并记录采样和回收资源，容器退出 124。外层超时会强制移除本次容器并核对是否仍运行，真实容器退出未知时记录空值。全三侧完成且校验通过时计划退出 0，存在失败或缺测时退出 1，锁、身份或收据核对失败时退出 2。

## 身份和观察

- 三份独立源码从精确 Git 树导出，无额外覆盖。对应源码文件清单、生产面积模块 SHA、完整提交 ID 已固化在 `snapshots/source-manifest.json`。正式开始前复核整树，容器只读挂载。
- 原始 `benchmarks/raster/area-fixtures/dem-l.tif` 为 128,239 B，SHA-256 `7a62aed10a269d83989d10d9f35b12527ef4be1be523e51bd0300649549213e8`。三侧读取同一个只读文件。正式核对格网 8190×8190、EPSG:32650、类别 7 的 67,039,236 个有效像元、36,864 个 NoData。独立 EPSG:6933 参考为 6,708,920,388.833747 m²，相对/绝对容差为 2e-7 / 0.02 m²。输出保存完整生产报告以及逐类参考差。
- 固定镜像 `c618d0d9…`，只读 P16-06 原生 Python 和 QGIS 绑定，CPU31、nice 19、ionice idle、单线程。每侧核对实际 Python 绑定树和版本、CPU 及所记录环境变量。宿主核对镜像 ID 和 CLI 摘要。运行不调用 QGIS 工具。
- 生产调用自身墙钟和 CPU 单独记录。原生监督进程另记录完整 worker 墙钟、用户/系统 CPU、内核峰值 RSS 和 200 ms RSS 样本。超时保留环境和可用统计，生产返回的原始报告在独立验算前固化，便于诊断。收据绑定实际生成的报告、环境和结果。
- 共用锁是 `/mnt/datab/geopilot-p13-05-vector-m.8IVSI6/.orchestrator.lock`。现有或非独立输出根、锁忙、输入及源码失配均拒绝执行。计划输出根独立于正式结果、源快照和输入。

## 已执行验证

`bash check-plan.sh` 使用禁止 Docker 调用的替身。三份精确源码准备、三个命令的预演和六项小夹具均退出 0。夹具覆盖忙锁、旧目录、输入与源码失配、合成进程预算、参考及收据。Docker 调用计数为零，指定正式结果根不存在。当前未对 DEM L 解码或运行面积计算。

`proof/` 保留实际命令、原始输出及退出码。环境与参考契约见 `snapshots/contract.json`。临时快照位于 tmpfs，重启后可用 `launch.py --prepare` 从固定 Git 对象重建。
