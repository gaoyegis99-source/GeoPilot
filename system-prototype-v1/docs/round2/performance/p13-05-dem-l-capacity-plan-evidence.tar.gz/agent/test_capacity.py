"""No GIS: frozen command metadata, temporary seals and miniature process/receipt fixtures."""
import argparse
import fcntl
import json
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import launch
from probe import check_area, digest, supervise, write_json


class CapacityTests(unittest.TestCase):
    def setUp(self):
        workspace = tempfile.TemporaryDirectory(dir=launch.HERE)
        self.addCleanup(workspace.cleanup)
        self.path = Path(workspace.name)

    def test_preview_has_three_frozen_readonly_commands(self):
        lines = (launch.HERE / "proof/dry-run.log").read_text().splitlines()
        record, commands = json.loads(lines[0]), [shlex.split(line) for line in lines[1:]]
        self.assertEqual(record["total_seconds"], 5700)
        self.assertEqual(record["each_worker_seconds"], 1800)
        self.assertEqual(record["fixture"]["sha256"], launch.INPUT_SHA)
        self.assertEqual(record["shared_lease"], str(launch.LOCK))
        self.assertEqual(len(commands), 3)
        for (role, (commit, module_sha)), cmd in zip(launch.SOURCES.items(), commands, strict=True):
            self.assertEqual(cmd[:2], ["docker", "run"])
            self.assertIn(launch.IMAGE, cmd)
            self.assertIn("PYTHONPATH=/project/src", cmd)
            self.assertIn("PROJ_NETWORK=OFF", cmd)
            self.assertIn(f"type=bind,src={launch.INPUT},dst=/fixture/dem-l.tif,readonly", cmd)
            self.assertIn(f"type=bind,src={launch.RUNTIME},dst=/runtime,readonly", cmd)
            self.assertIn(f"type=bind,src={launch.HERE}/snapshots/{role},dst=/project,readonly", cmd)
            self.assertEqual(cmd[cmd.index("--commit") + 1], commit)
            self.assertEqual(cmd[cmd.index("--source-sha") + 1], module_sha)
            self.assertEqual(cmd[-2:], ["--budget-seconds", "1800"])

    def test_busy_and_existing_root_rejected_before_any_native_call(self):
        lock = self.path / "lock"
        lock.touch()
        output = self.path / "result"
        with lock.open("rb") as file, patch.object(launch, "LOCK", lock):
            fcntl.flock(file, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with self.assertRaisesRegex(ValueError, "measurement lock is busy"):
                launch.run(argparse.Namespace(output=output, total_seconds=5700, variant_seconds=1800),
                           self.path / "missing-source", {})
        self.assertFalse(output.exists())
        output.mkdir()
        with self.assertRaisesRegex(ValueError, "Output already exists"):
            launch.fresh(output)

    def test_input_mismatch_rejected_before_worker(self):
        invalid = self.path / "dem-l.tif"
        invalid.write_bytes(b"synthetic altered input")
        with patch.object(launch, "INPUT", invalid):
            with self.assertRaisesRegex(ValueError, "Sealed file differs"):
                launch.contract()

    def test_source_manifest_catches_changed_module_and_added_file(self):
        snapshots = self.path
        write_json(snapshots / "contract.json", {})
        identities = {}
        for role, (commit, area_sha) in launch.SOURCES.items():
            source = snapshots / role / launch.MODULE
            source.parent.mkdir(parents=True)
            source.write_bytes((launch.HERE / "snapshots" / role / launch.MODULE).read_bytes())
            manifest = snapshots / f"{role}.sha256"
            manifest.write_bytes(launch.manifest_bytes(snapshots / role))
            identities[role] = {"commit": commit, "area_module_sha256": area_sha,
                                "source_manifest_sha256": digest(manifest), "source_files": 1}
        write_json(snapshots / "source-manifest.json", identities)
        launch.check_sources(snapshots, {}, full=True)
        new_file = snapshots / "baseline" / "extra.py"
        new_file.write_text("# added file")
        with self.assertRaisesRegex(ValueError, "source tree changed"):
            launch.check_sources(snapshots, {}, full=True)
        new_file.unlink()
        (snapshots / "baseline" / launch.MODULE).write_text("# changed module")
        with self.assertRaisesRegex(ValueError, "Sealed file differs"):
            launch.check_sources(snapshots, {}, full=False)

    def test_worker_supervisor_samples_success_and_budget_stop(self):
        okay = supervise([sys.executable, "-B", "-c", "sum(range(100_000))"], 1)
        self.assertEqual(okay["worker_exit_code"], 0)
        self.assertFalse(okay["timed_out"])
        self.assertGreater(okay["peak_rss_bytes"], 0)
        self.assertGreater(okay["cpu_user_s"] + okay["cpu_system_s"], 0)
        stopped = supervise([sys.executable, "-B", "-c", "import time; time.sleep(5)"], 0.05)
        self.assertTrue(stopped["timed_out"])
        self.assertLess(stopped["worker_exit_code"], 0)
        self.assertGreater(stopped["rss_samples"], 0)

    def test_verified_receipt_and_independent_reference_tamper(self):
        fixture = {"grid": {"shape": [2, 2], "crs": "EPSG:32650"},
                   "valid_class_counts": {"7": 3}, "expected_area_m2": {"7": 300.0}, "masked_pixels": 1}
        reference = {"crs": "EPSG:6933", "relative_tolerance": 2e-7, "absolute_tolerance_m2": 0.02}
        report = {"source_crs": "EPSG:32650", "area_crs": "EPSG:6933", "area_unit": "square_meter",
                  "cell_area_method": "projected_cell_boundary", "resampling": "none",
                  "selected_pixel_count": 3, "valid_pixel_count": 3, "unselected_pixel_count": 0,
                  "nodata_pixel_count": 1, "classes": [{"class_id": 7, "pixel_count": 3, "area_m2": 300.0}],
                  "total_area_m2": 300.0}
        sealed = {"fixture": fixture, "area_reference": reference, "runtime_tree": {"fixture": True}}
        commit, source_sha = launch.SOURCES["frozen"]
        result = self.path / "result.json"
        environment = self.path / "environment.json"
        production = self.path / "production-report.json"
        write_json(environment, {"fixture": True})
        write_json(production, report)
        write_json(result, {"status": "PASS", "commit": commit, "area_module_sha256": source_sha,
                            "input_sha256_before": launch.INPUT_SHA, "input_sha256_after": launch.INPUT_SHA,
                            "core_wall_ns": 1, "core_cpu_ns": 1, "report": report, "environment": {"fixture": True},
                            "reference_checks": check_area(report, fixture, reference)})
        receipt = self.path / "receipt.json"
        base = {"scope": "direct_area_capacity_probe", "commit": commit, "container_exit_code": 0,
                "worker_wall_budget_s": 1800, "runtime_tree": sealed["runtime_tree"], "peak_rss_bytes": 8192,
                "wall_ns": 1, "cpu_user_s": 0, "cpu_system_s": 0, "worker_exit_code": 0, "timed_out": False}
        write_json(receipt, {**base, "files_sha256": {p.name: digest(p) for p in (environment, production, result)}})
        self.assertEqual(launch.verify_receipt(self.path, 0, "frozen", 1800, sealed)["report"], report)
        with self.assertRaisesRegex(ValueError, "differs from the independent reference"):
            check_area({**report, "classes": [{"class_id": 7, "pixel_count": 3, "area_m2": 301.0}]},
                       fixture, reference)
        result.write_text("{}")
        with self.assertRaisesRegex(ValueError, "Sealed file differs"):
            launch.verify_receipt(self.path, 0, "frozen", 1800, sealed)
        result.unlink()
        production.unlink()
        receipt.unlink()
        write_json(receipt, {**base, "container_exit_code": 124, "timed_out": True,
                             "worker_exit_code": -15, "files_sha256": {environment.name: digest(environment)}})
        self.assertIsNone(launch.verify_receipt(self.path, 124, "frozen", 1800, sealed))


if __name__ == "__main__":
    unittest.main()
