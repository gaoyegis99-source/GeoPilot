#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
output=/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/artifacts/test-results/p13-05-dem-l-capacity.tQo1Yb
record() {
  local label="$1" code=0
  shift
  local -a cmd=(env "PATH=$PWD/proof/forbid-docker:$PATH" PYTHONDONTWRITEBYTECODE=1 ionice -c3 nice -n 19 taskset -c 31 "$@")
  printf '%q ' "${cmd[@]}" > "proof/$label.command"
  printf '\n' >> "proof/$label.command"
  "${cmd[@]}" > "proof/$label.log" 2>&1 || code=$?
  printf '%s\n' "$code" > "proof/$label.exit-code"
  return "$code"
}
if [[ ! -e snapshots ]]; then
  record prepare python3 -B launch.py --prepare
fi
record dry-run python3 -B launch.py --dry-run --output "$output" --total-seconds 5700 --variant-seconds 1800
record fixtures python3 -B -m unittest -v test_capacity
test ! -e "$output" && test ! -e proof/forbid-docker/docker.calls
