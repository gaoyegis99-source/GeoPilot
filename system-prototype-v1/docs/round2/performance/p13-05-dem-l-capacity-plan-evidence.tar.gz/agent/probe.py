"""Native supervisor and one direct production area call. Never used by host dry-run."""
import argparse
from hashlib import file_digest, sha256
import json
import math
import os
from pathlib import Path
import resource
import stat
import subprocess
import sys
import time
import traceback


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def check_area(report, fixture, reference):
    expected_counts = {int(k): v for k, v in fixture["valid_class_counts"].items()}
    expected_areas = {int(k): v for k, v in fixture["expected_area_m2"].items()}
    classes = {row["class_id"]: row for row in report["classes"]}
    height, width = fixture["grid"]["shape"]
    selected = sum(expected_counts.values())
    masked = fixture["masked_pixels"]
    require(
        len(classes) == len(report["classes"]) and set(classes) == expected_counts.keys() == expected_areas.keys()
        and report["source_crs"] == fixture["grid"]["crs"] and report["area_crs"] == reference["crs"]
        and report["area_unit"] == "square_meter" and report["cell_area_method"] == "projected_cell_boundary"
        and report["resampling"] == "none"
        and report["valid_pixel_count"] == report["selected_pixel_count"] == selected
        and report["unselected_pixel_count"] == 0 and report["nodata_pixel_count"] == masked
        and selected + masked == height * width,
        "Full classification, CRS, units or measurement method differ from the sealed fixture",
    )
    differences = {}
    for cls, row in classes.items():
        observed = row["area_m2"]
        require(
            row["pixel_count"] == expected_counts[cls] and observed > 0
            and math.isclose(observed, expected_areas[cls],
                             rel_tol=reference["relative_tolerance"], abs_tol=reference["absolute_tolerance_m2"]),
            f"Class {cls} differs from the independent reference",
        )
        differences[cls] = {"expected_m2": expected_areas[cls], "observed_m2": observed,
                            "difference_m2": observed - expected_areas[cls], "pixel_count": row["pixel_count"]}
    require(
        report["total_area_m2"] == math.fsum(row["area_m2"] for row in classes.values())
        and math.isclose(report["total_area_m2"], math.fsum(expected_areas.values()),
                         rel_tol=reference["relative_tolerance"], abs_tol=reference["absolute_tolerance_m2"]),
        "Area totals differ from the complete class report or independent reference",
    )
    return differences


def runtime_inventory(root):
    # Same path, entry format and digest as the P16-06 native binding seal.
    entries = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            entry = {"link": os.readlink(path), "resolved": str(path.resolve(strict=True))}
        elif path.is_file():
            entry = {"sha256": digest(path), "mode": stat.S_IMODE(path.stat().st_mode)}
        else:
            require(path.is_dir(), f"Unexpected runtime entry: {path}")
            continue
        entries[path.relative_to(root).as_posix()] = entry
    canonical = json.dumps(entries, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return {"count": len(entries), "sha256": sha256(canonical.encode()).hexdigest()}


def area_worker(args):
    import numpy
    import pyproj
    import rasterio
    from geopilot.gis.raster import area_stats

    request = json.loads(args.contract.read_bytes())
    source = Path("/project/src/geopilot/gis/raster/area_stats.py")
    require(Path(area_stats.__file__).resolve() == source and digest(source) == args.source_sha,
            "Loaded production area module differs from the selected commit")
    before = digest(args.input)
    fixture, reference = request["fixture"], request["area_reference"]
    require(before == fixture["sha256"], "Input differs from the sealed classification")
    with rasterio.open(args.input) as dataset:
        grid = fixture["grid"]
        require(
            dataset.crs.to_string() == grid["crs"] and list(dataset.shape) == grid["shape"]
            and list(dataset.transform)[:6] == grid["transform"] and list(dataset.dtypes) == grid["dtypes"]
            and list(dataset.nodatavals) == grid["nodata"] and [list(s) for s in dataset.block_shapes] == grid["block_shapes"],
            "Input grid metadata differs from the sealed classification",
        )
    env = {"python": sys.version, "numpy": numpy.__version__, "rasterio": rasterio.__version__,
           "gdal": rasterio.__gdal_version__, "pyproj": pyproj.__version__, "proj": pyproj.proj_version_str,
           "affinity": sorted(os.sched_getaffinity(0)), "nice": os.nice(0),
           "variables": {key: os.environ.get(key) for key in request["runtime_variables"]}}
    require(env["python"] == request["python_version"] and env["affinity"] == [31] and env["nice"] == 19
            and env["variables"] == request["runtime_variables"], "Worker runtime environment differs")
    write_json(args.output / "environment.json", env)
    wall, cpu = time.monotonic_ns(), time.process_time_ns()
    report = area_stats.summarize_threshold_area(args.input, area_crs=reference["crs"])
    cpu, wall = time.process_time_ns() - cpu, time.monotonic_ns() - wall
    write_json(args.output / "production-report.json", report)
    after = digest(args.input)
    verification = check_area(report, fixture, reference)
    require(after == before, "Classification changed during the probe")
    write_json(args.output / "result.json", {
        "status": "PASS", "commit": args.commit, "area_module_sha256": args.source_sha,
        "input_sha256_before": before, "input_sha256_after": after,
        "core_wall_ns": wall, "core_cpu_ns": cpu, "environment": env, "report": report,
        "area_reference": reference, "reference_checks": verification,
    })


def rss_bytes(pid):
    try:
        for line in Path(f"/proc/{pid}/status").read_text().splitlines():
            if line.startswith("VmRSS:"):
                return int(line.split()[1]) * 1024
    except ProcessLookupError:
        pass
    except FileNotFoundError:
        pass
    return None


def supervise(command, budget):
    """Sample live RSS and preserve reaped CPU/RSS even if the worker is stopped."""
    usage_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    start = time.monotonic_ns()
    timed_out, samples, sampled_peak = False, 0, None
    with subprocess.Popen(command) as process:
        deadline = time.monotonic() + budget
        while process.poll() is None:
            reading = rss_bytes(process.pid)
            if reading is not None:
                samples += 1
                sampled_peak = max(sampled_peak or 0, reading)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                timed_out = True
                process.terminate()
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                break
            time.sleep(min(0.2, remaining))
        exit_code = process.returncode
    usage_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    return {"wall_ns": time.monotonic_ns() - start,
            "cpu_user_s": usage_after.ru_utime - usage_before.ru_utime,
            "cpu_system_s": usage_after.ru_stime - usage_before.ru_stime,
            "peak_rss_bytes": usage_after.ru_maxrss * 1024, "sampled_rss_peak_bytes": sampled_peak,
            "rss_samples": samples, "worker_exit_code": exit_code, "timed_out": timed_out,
            "worker_wall_budget_s": budget}


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-sha", required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--budget-seconds", type=int, required=True)
    args = parser.parse_args()
    if args.worker:
        area_worker(args)
        return
    contract = json.loads(args.contract.read_bytes())
    inventory = runtime_inventory(Path("/runtime"))
    require(inventory == contract["runtime_tree"], "Native Python binding inventory differs from the seal")
    stats = supervise([sys.executable, "-B", __file__, "--worker", *sys.argv[1:]], args.budget_seconds)
    if stats["timed_out"]:
        exit_code = 124
    elif stats["worker_exit_code"] != 0:
        exit_code = stats["worker_exit_code"] if stats["worker_exit_code"] > 0 else 128 - stats["worker_exit_code"]
    else:
        exit_code = 0
    files = {}
    for name in ("environment.json", "production-report.json", "result.json"):
        path = args.output / name
        if path.is_file():
            files[name] = digest(path)
    if exit_code == 0 and len(files) != 3:
        exit_code = 2
    write_json(args.output / "receipt.json", {
        "scope": "direct_area_capacity_probe", "commit": args.commit, "runtime_tree": inventory,
        "container_exit_code": exit_code, "files_sha256": files,
        **stats,
    })
    raise SystemExit(exit_code)


if __name__ == "__main__":
    try:
        main()
    except (KeyError, OSError, TypeError, ValueError):
        traceback.print_exc()
        sys.exit(2)
