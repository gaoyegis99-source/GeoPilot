#!/usr/bin/env python3
"""Prepare, preview, or run an isolated full DEM L area capacity probe."""
import argparse
from contextlib import contextmanager
from datetime import UTC, datetime
import fcntl
import json
import os
from pathlib import Path
import secrets
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from probe import check_area, digest, require, write_json


HERE = Path(__file__).resolve().parent
REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
FIXTURE_DIR = REPO / "benchmarks/raster/area-fixtures"
INPUT = FIXTURE_DIR / "dem-l.tif"
INPUT_SHA = "7a62aed10a269d83989d10d9f35b12527ef4be1be523e51bd0300649549213e8"
MANIFEST_SHA = "1e9d8ac426fad203ca3286f747c44c756332197faf6693c8baaabce451eab95b"
NATIVE_SEAL = REPO / "docs/round2/deployment/p16-06-native-bindings-verification.json"
NATIVE_SEAL_SHA = "a57303f3da1d0d6a0dcb4718a3127dc4d11967f95f4c81a1b17ab66dfd689db0"
IMAGE = "sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87"
RUNTIME = REPO / ".environments/p13-native"
QGIS = REPO / ".environments/qgis-deb/usr/bin"
LOCK = Path("/mnt/datab/geopilot-p13-05-vector-m.8IVSI6/.orchestrator.lock")
MODULE = "src/geopilot/gis/raster/area_stats.py"
SOURCES = {
    "baseline": ("977ab412d9f6e7558d22a5c431fac0ada90b07be", "f64f55ed7e601922d63fc0467084ea6fca9764c65e8d0c4b9310e264eeda4afb"),
    "frozen": ("a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc", "7e812cc2b359cdb77f8876f971769c9aa58667860179c37bdc7a0df441221b4f"),
    "cross-batch": ("b49025453794331f0a42cb9390a7ed0708c0e7d7", "ef67e293dd1a46923876394c563508168ba989ce9018a456f13f534f944091fd"),
}
CLEANUP_MARGIN = 15
INVENTORY_MARGIN = 90


def read(path):
    return json.loads(path.read_bytes())


def check_digest(path, expected):
    require(not path.is_symlink() and path.is_file() and digest(path) == expected, f"Sealed file differs: {path}")


def contract():
    manifest = FIXTURE_DIR / "manifest.json"
    check_digest(manifest, MANIFEST_SHA)
    check_digest(INPUT, INPUT_SHA)
    check_digest(NATIVE_SEAL, NATIVE_SEAL_SHA)
    sealed = read(manifest)
    fixture, = (record for record in sealed["fixtures"] if record["id"] == "dem-l")
    require(fixture["path"] == INPUT.name and fixture["sha256"] == INPUT_SHA
            and INPUT.stat().st_size == fixture["bytes"], "Classification manifest identity differs")
    native = read(NATIVE_SEAL)
    require(native["image_required"] == IMAGE, "Offline native image identity differs")
    return {"fixture": fixture, "area_reference": sealed["area_reference"],
            "fixture_manifest_sha256": MANIFEST_SHA, "native_seal_sha256": NATIVE_SEAL_SHA,
            "runtime_tree": native["runtime_tree"], "runtime_variables": native["runtime_variables"],
            "python_version": native["python"]["version"], "cli_sha256": native["cli_sha256"]}


def manifest_bytes(root):
    entries = []
    for path in sorted(root.rglob("*")):
        require(not path.is_symlink(), f"Unexpected source symlink: {path}")
        if path.is_file():
            entries.append(f"{digest(path)}  ./{path.relative_to(root).as_posix()}\n")
        else:
            require(path.is_dir(), f"Unexpected source entry: {path}")
    require(entries, f"Empty source tree: {root}")
    return "".join(entries).encode()


def prepare(snapshots, sealed):
    require(not os.path.lexists(snapshots), f"Prepared path already exists: {snapshots}")
    with tempfile.TemporaryDirectory(prefix=".snapshot-", dir=snapshots.parent) as tmp:
        stage = Path(tmp)
        identities = {}
        for role, (commit, area_sha) in SOURCES.items():
            source = stage / role
            source.mkdir()
            subprocess.run(
                ["bash", "-c", 'set -euo pipefail; git -C "$1" archive "$2" | tar -x -C "$3"',
                 "archive", REPO.parent, f"{commit}:system-prototype-v1", source],
                check=True,
            )
            check_digest(source / MODULE, area_sha)
            data = manifest_bytes(source)
            manifest = stage / f"{role}.sha256"
            manifest.write_bytes(data)
            identities[role] = {"commit": commit, "area_module_sha256": area_sha,
                                "source_manifest_sha256": digest(manifest), "source_files": data.count(b"\n")}
        write_json(stage / "source-manifest.json", identities)
        write_json(stage / "contract.json", sealed)
        stage.rename(snapshots)
    print(json.dumps(identities, indent=2))


def check_sources(snapshots, sealed, *, full):
    require(snapshots.resolve(strict=True) == snapshots, "Prepared source path must be canonical")
    require(read(snapshots / "contract.json") == sealed, "Prepared contract differs from sealed inputs")
    identities = read(snapshots / "source-manifest.json")
    require(identities.keys() == SOURCES.keys(), "Prepared source set differs")
    for role, (commit, area_sha) in SOURCES.items():
        actual = identities[role]
        source = snapshots / role
        manifest = snapshots / f"{role}.sha256"
        check_digest(manifest, actual["source_manifest_sha256"])
        require(actual["commit"] == commit and actual["area_module_sha256"] == area_sha
                and actual["source_files"] == len(manifest.read_bytes().splitlines()), f"Source identity differs: {role}")
        check_digest(source / MODULE, area_sha)
        if full:
            require(manifest_bytes(source) == manifest.read_bytes(), f"Prepared source tree changed: {role}")
    return identities


def fresh(path):
    require(path.is_absolute() and path.resolve() == path and path.parent.is_dir() and "," not in str(path),
            "Output must be an absolute canonical path with an existing parent")
    require(not os.path.lexists(path), f"Output already exists: {path}")


@contextmanager
def lease(path):
    require(path.is_file() and not path.is_symlink(), f"Missing shared measurement lock: {path}")
    with path.open("rb") as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError(f"Shared measurement lock is busy: {path}") from error
        yield


def command(snapshots, role, output, name, budget, sealed):
    commit, area_sha = SOURCES[role]
    cmd = ["docker", "run", "--rm", "--pull=never", "--name", name, "--network", "none", "--cpuset-cpus", "31",
           "--user", f"{os.getuid()}:{os.getgid()}", "--entrypoint", "/usr/bin/nice", "--workdir", "/project",
           "-e", "PYTHONPATH=/project/src", "-e", "PYTHONDONTWRITEBYTECODE=1", "-e", "GDAL_CACHEMAX=64"]
    for key, value in sealed["runtime_variables"].items():
        if value is not None:
            cmd.extend(("-e", f"{key}={value}"))
    for host, guest in ((snapshots / role, "/project"), (RUNTIME, "/runtime"),
                        (QGIS / "qgis_process", "/usr/bin/qgis_process"),
                        (QGIS / "qgis_process.bin", "/usr/bin/qgis_process.bin"),
                        (HERE / "probe.py", "/probe/probe.py"), (snapshots / "contract.json", "/probe/contract.json"),
                        (INPUT, "/fixture/dem-l.tif")):
        cmd.extend(("--mount", f"type=bind,src={host},dst={guest},readonly"))
    cmd.extend(("--mount", f"type=bind,src={output},dst=/scratch", IMAGE,
                "-n", "19", "/usr/bin/ionice", "-c", "3", "/runtime/venv/bin/python", "-B", "/probe/probe.py",
                "--input", "/fixture/dem-l.tif", "--contract", "/probe/contract.json", "--output", "/scratch",
                "--source-sha", area_sha, "--commit", commit, "--budget-seconds", str(budget)))
    return cmd


def verify_receipt(directory, code, role, budget, sealed):
    receipt = read(directory / "receipt.json")
    require(receipt["scope"] == "direct_area_capacity_probe" and receipt["commit"] == SOURCES[role][0]
            and receipt["container_exit_code"] == code and receipt["worker_wall_budget_s"] == budget
            and receipt["runtime_tree"] == sealed["runtime_tree"] and receipt["peak_rss_bytes"] > 0
            and receipt["wall_ns"] > 0 and receipt["cpu_user_s"] >= 0 and receipt["cpu_system_s"] >= 0,
            f"Native receipt disagrees with the run: {directory}")
    files = receipt["files_sha256"]
    names = ("environment.json", "production-report.json", "result.json")
    require(files.keys() == {name for name in names if (directory / name).is_file()},
            f"Receipt file list differs: {directory}")
    for name, expected in files.items():
        check_digest(directory / name, expected)
    if code != 0:
        require(not receipt["timed_out"] or code == 124, "Timed-out worker has inconsistent status")
        return None
    require(files.keys() == set(names), f"Completed worker lacks complete output evidence: {directory}")
    result = read(directory / "result.json")
    require(result["environment"] == read(directory / "environment.json")
            and result["report"] == read(directory / "production-report.json"),
            "Validated result differs from the raw production evidence")
    commit, module_sha = SOURCES[role]
    require(receipt["worker_exit_code"] == 0 and not receipt["timed_out"]
            and result["status"] == "PASS" and result["commit"] == commit and result["area_module_sha256"] == module_sha
            and result["input_sha256_before"] == result["input_sha256_after"] == INPUT_SHA
            and result["core_wall_ns"] > 0 and result["core_cpu_ns"] > 0, f"Worker result identity differs: {directory}")
    verify = check_area(result["report"], sealed["fixture"], sealed["area_reference"])
    require({str(k): v for k, v in verify.items()} == result["reference_checks"], "Reference verification differs")
    return result


def measure(snapshots, role, output, sealed, budget, deadline):
    name = f"geopilot-dem-l-capacity-{role}-{secrets.token_hex(6)}"
    cmd = command(snapshots, role, output, name, budget, sealed)
    (output / "command.log").write_text(shlex.join(cmd) + "\n")
    (output / "container-name").write_text(name + "\n")
    remaining = deadline - time.monotonic() - CLEANUP_MARGIN
    host_timeout = min(remaining, budget + INVENTORY_MARGIN)
    require(host_timeout > budget, "Global budget cannot cover this complete worker allowance")
    write_json(output / "budget.json", {"worker_wall_budget_s": budget, "outer_container_wall_budget_s": host_timeout,
                                        "remaining_total_budget_s": remaining + CLEANUP_MARGIN,
                                        "started_utc": datetime.now(UTC).isoformat()})
    try:
        with (output / "container.log").open("xb") as log:
            code = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=False, timeout=host_timeout).returncode
    except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
        with (output / "cleanup.log").open("xb") as log:
            subprocess.run(["docker", "container", "rm", "-f", name], stdout=log, stderr=subprocess.STDOUT,
                           check=False, timeout=8)
        still_active = subprocess.check_output(
            ["docker", "ps", "--filter", f"name=^/{name}$", "--format", "{{.Names}}"], text=True, timeout=5,
        ).splitlines()
        write_json(output / "outer-stop.json", {"host_timeout_s": host_timeout, "still_active": still_active,
                                                "reason": type(error).__name__})
        require(name not in still_active, "Stopped capacity container is still running")
        if isinstance(error, KeyboardInterrupt):
            raise
        return {"state": "OUTER_TIMEOUT", "container_exit_code": None}, None
    (output / "exit-code").write_text(f"{code}\n")
    if not (output / "receipt.json").is_file():
        return {"state": "NO_RECEIPT", "container_exit_code": code}, None
    result = verify_receipt(output, code, role, budget, sealed)
    return {"state": "PASS" if result else "NONZERO_WORKER", "container_exit_code": code}, result


def run(args, snapshots, sealed):
    with lease(LOCK):
        deadline = time.monotonic() + args.total_seconds
        started = datetime.now(UTC).isoformat()
        fresh(args.output)
        identities = check_sources(snapshots, sealed, full=True)
        for guest, expected in sealed["cli_sha256"].items():
            check_digest(QGIS / Path(guest).name, expected)
        actual_image = subprocess.check_output(
            ["docker", "image", "inspect", IMAGE, "--format", "{{.Id}}"], timeout=10, text=True).strip()
        require(actual_image == IMAGE, "Native image ID differs")
        args.output.mkdir(mode=0o700)
        proof = args.output / "proof"
        proof.mkdir()
        for name in ("source-manifest.json", "contract.json", *(f"{role}.sha256" for role in SOURCES)):
            shutil.copyfile(snapshots / name, proof / name)
        for source in (FIXTURE_DIR / "manifest.json", NATIVE_SEAL, HERE / "probe.py", HERE / "launch.py"):
            shutil.copyfile(source, proof / source.name)
        write_json(args.output / "plan.json", {
            "scope": "direct_area_capacity_probe", "image": IMAGE, "shared_lease": str(LOCK), "started_utc": started,
            "input": str(INPUT), "input_sha256": INPUT_SHA, "sources": identities,
            "total_wall_budget_s": args.total_seconds, "each_worker_wall_budget_s": args.variant_seconds,
        })
        states, results, environments = {}, {}, {}
        for role in SOURCES:
            if deadline - time.monotonic() <= args.variant_seconds + CLEANUP_MARGIN:
                states[role] = {"state": "NOT_RUN_TOTAL_BUDGET", "container_exit_code": None}
                continue
            directory = args.output / role
            directory.mkdir()
            state, result = measure(snapshots, role, directory, sealed, args.variant_seconds, deadline)
            states[role] = state
            if result is not None:
                results[role] = result
            if (directory / "environment.json").is_file():
                environments[role] = read(directory / "environment.json")
            print(f"{role}: {state}", flush=True)
        check_digest(INPUT, INPUT_SHA)
        comparable = (len(environments) == len(SOURCES)
                      and len({json.dumps(environment, sort_keys=True) for environment in environments.values()}) == 1)
        exact = (results["frozen"]["report"] == results["cross-batch"]["report"]
                 if {"frozen", "cross-batch"} <= results.keys() else None)
        write_json(args.output / "summary.json", {
            "scope": "direct_area_capacity_probe", "variants": states, "same_observed_environment": comparable,
            "frozen_cross_batch_report_exact": exact,
            "elapsed_s": args.total_seconds - (deadline - time.monotonic()), "finished_utc": datetime.now(UTC).isoformat(),
        })
        return 0 if len(results) == len(SOURCES) and comparable and exact else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--prepare", action="store_true")
    modes.add_argument("--dry-run", action="store_true")
    modes.add_argument("--run", action="store_true")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--total-seconds", type=int)
    parser.add_argument("--variant-seconds", type=int)
    args = parser.parse_args()
    snapshots = HERE / "snapshots"
    sealed = contract()
    if args.prepare:
        require(args.output is args.total_seconds is args.variant_seconds is None, "--prepare takes no run options")
        prepare(snapshots, sealed)
        return 0
    require(args.output is not None and args.variant_seconds is not None and args.variant_seconds > 0
            and args.total_seconds is not None
            and args.total_seconds >= len(SOURCES) * (args.variant_seconds + CLEANUP_MARGIN),
            "Set a new output root and explicit total and per-variant wall budgets")
    fresh(args.output)
    require(not args.output.is_relative_to(snapshots) and not args.output.is_relative_to(FIXTURE_DIR),
            "Output must be independent of source snapshots and sealed inputs")
    if args.run:
        return run(args, snapshots, sealed)
    identities = check_sources(snapshots, sealed, full=False)
    print(json.dumps({"mode": "dry-run", "scope": "direct_area_capacity_probe", "image": IMAGE,
                      "shared_lease": str(LOCK), "total_seconds": args.total_seconds,
                      "each_worker_seconds": args.variant_seconds, "sources": identities, **sealed}, sort_keys=True))
    for role in SOURCES:
        print(shlex.join(command(snapshots, role, args.output / role, f"geopilot-dem-l-capacity-{role}-NEW",
                                 args.variant_seconds, sealed)))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (KeyError, OSError, TypeError, ValueError, subprocess.SubprocessError) as error:
        print(f"DEM L capacity: {error}", file=sys.stderr)
        raise SystemExit(2) from error
