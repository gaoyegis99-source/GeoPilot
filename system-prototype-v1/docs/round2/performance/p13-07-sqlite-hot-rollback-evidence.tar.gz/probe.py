import hashlib
import json
import logging
import os
import select
import signal
import sqlite3
import subprocess
import sys
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from time import monotonic_ns

from fastapi.testclient import TestClient

from geopilot.api.app import create_app
from geopilot.persistence.run_repository import insert_run
from geopilot.persistence.schema import initialize_database, open_database
from geopilot.runs.models import Run


ROOT = Path(__file__).resolve().parent
DATABASE = ROOT / "project.sqlite"
JOURNAL = DATABASE.with_name(f"{DATABASE.name}-journal")
RUN_ID = "rollback-probe"
JOURNAL_MAGIC = bytes.fromhex("d9d505f920a163d7")


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def file_state(database):
    files = (database, database.with_name(f"{database.name}-journal"))
    return {path.name: {"size": path.stat().st_size, "sha256": digest(path)} for path in files if path.exists()}


def initialize():
    initialize_database(DATABASE)
    now = datetime.now(UTC)
    with open_database(DATABASE) as connection, connection:
        assert connection.execute("PRAGMA journal_mode=DELETE").fetchone()[0] == "delete"
        assert connection.execute("PRAGMA busy_timeout").fetchone()[0] == 5000
        connection.execute("INSERT INTO task VALUES ('task', '{}', NULL, ?)", (now.isoformat(),))
        connection.execute("INSERT INTO analysis_plan VALUES ('plan', 1, 'task', 'confirmed', '{}', ?)", (now.isoformat(),))
        insert_run(connection, Run(id=RUN_ID, plan_id="plan", plan_version=1, workdir=str(ROOT), created_at=now))
        connection.execute("CREATE TABLE probe_payload (id INTEGER PRIMARY KEY, payload BLOB NOT NULL)")
        connection.executemany("INSERT INTO probe_payload VALUES (?, zeroblob(3072))", [(i,) for i in range(256)])
    assert not JOURNAL.exists()


def writer(mode):
    with open_database(DATABASE) as connection:
        assert connection.execute("PRAGMA journal_mode").fetchone()[0] == "delete"
        connection.execute("PRAGMA synchronous=FULL")
        connection.execute("PRAGMA cache_size=12")
        connection.execute("PRAGMA cache_spill=ON")
        connection.execute("BEGIN IMMEDIATE")
        if mode == "spill":
            connection.execute("UPDATE probe_payload SET payload = randomblob(length(payload))")
            assert JOURNAL.open("rb").read(8) == JOURNAL_MAGIC
        print("writer-ready", flush=True)
        if sys.stdin.buffer.read(1) == b"r":
            connection.rollback()


@contextmanager
def active_writer(mode):
    with (ROOT / f"writer-{mode}.stderr").open("wb") as stderr:
        process = subprocess.Popen([sys.executable, __file__, mode], stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE, stderr=stderr)
        try:
            assert select.select([process.stdout], [], [], 5)[0]
            assert process.stdout.readline() == b"writer-ready\n"
            assert process.poll() is None
            yield process
        finally:
            if process.poll() is None:
                process.kill()
            process.communicate(timeout=5)


def locks(database, pid):
    stat = database.stat()
    identity = f"{os.major(stat.st_dev):02x}:{os.minor(stat.st_dev):02x}:{stat.st_ino}"
    return [line for line in Path("/proc/locks").read_text().splitlines()
            if f" {pid} {identity} " in line]


class DiagnosticCapture(logging.Handler):
    def __init__(self):
        super().__init__(logging.WARNING)
        self.events = []

    def emit(self, record):
        assert record.exc_info is None
        event = json.loads(record.getMessage())
        assert event["event"] == "run_status_read_failed"
        self.events.append(event)
        print(f"production-warning {record.getMessage()}", flush=True)


def observe(label, database, expected_status, code=None):
    logger = logging.getLogger("geopilot.api.app")
    capture = DiagnosticCapture()
    logger.addHandler(capture)
    try:
        with TestClient(create_app(database)) as client:
            start = monotonic_ns()
            response = client.get(f"/api/runs/{RUN_ID}")
            elapsed_ms = (monotonic_ns() - start) / 1_000_000
    finally:
        logger.removeHandler(capture)
    assert response.status_code == expected_status
    if code is None:
        assert capture.events == []
    else:
        event, = capture.events
        assert event["error_kind"] == "sqlite"
        assert event["sqlite_extended_code"] == code and event["sqlite_primary_code"] == code & 0xFF
        assert response.json() == {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}}
    observation = {"http_status": response.status_code, "http_ms": round(elapsed_ms, 3),
                   "json": response.json(), "events": capture.events}
    print(label, json.dumps(observation), flush=True)
    return observation


def run():
    initialize()
    observations = {"sqlite_version": sqlite3.sqlite_version, "journal_mode": "delete", "configured_busy_timeout_ms": 5000}
    observations["initial_files"] = file_state(DATABASE)
    observations["initial_status"] = observe("initial_status", DATABASE, 200)

    with active_writer("reserved") as process:
        observations["reserved_locks"] = locks(DATABASE, process.pid)
        assert any(line.endswith("1073741825 1073741825") and "WRITE" in line for line in observations["reserved_locks"])
        observations["reserved_status"] = observe("reserved_status", DATABASE, 200)
        assert not JOURNAL.exists()
        process.stdin.write(b"r")
        process.stdin.flush()
        assert process.wait(timeout=5) == 0

    with active_writer("spill") as process:
        observations["spill_locks"] = locks(DATABASE, process.pid)
        assert any(line.endswith("1073741824 1073742335") and "WRITE" in line for line in observations["spill_locks"])
        observations["active_files"] = file_state(DATABASE)
        assert observations["active_files"][DATABASE.name] != observations["initial_files"][DATABASE.name]
        observations["locked_status"] = observe("locked_status", DATABASE, 500, sqlite3.SQLITE_BUSY)
        assert observations["locked_status"]["events"][0]["elapsed_ms"] >= 4_000
        process.kill()
        observations["writer_exit"] = process.wait(timeout=5)
        assert observations["writer_exit"] == -signal.SIGKILL and locks(DATABASE, process.pid) == []

    observations["orphaned_files"] = file_state(DATABASE)
    assert observations["orphaned_files"] == observations["active_files"]
    with JOURNAL.open("rb") as stream:
        observations["journal_magic"] = stream.read(8).hex()
    assert observations["journal_magic"] == JOURNAL_MAGIC.hex()
    observations["hot_status"] = observe("hot_status", DATABASE, 500, sqlite3.SQLITE_READONLY_ROLLBACK)
    assert observations["hot_status"]["events"][0]["elapsed_ms"] < 4_000
    assert file_state(DATABASE) == observations["orphaned_files"]

    started = monotonic_ns()
    with open_database(DATABASE) as connection:
        assert connection.execute("SELECT count(*) FROM probe_payload WHERE payload = zeroblob(3072)").fetchone()[0] == 256
        assert connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    observations["read_write_recovery_ms"] = round((monotonic_ns() - started) / 1_000_000, 3)
    observations["recovered_files"] = file_state(DATABASE)
    assert observations["recovered_files"] == observations["initial_files"]
    observations["recovered_status"] = observe("recovered_status", DATABASE, 200)
    assert observations["recovered_status"]["json"] == observations["initial_status"]["json"]

    missing = ROOT / "missing.sqlite"
    observations["missing_status"] = observe("missing_status", missing, 500, sqlite3.SQLITE_CANTOPEN)
    assert not missing.exists()
    broken = ROOT / "not-a-database.sqlite"
    broken.write_bytes(b"this file does not contain a SQLite database\n" * 128)
    broken_before = file_state(broken)
    observations["broken_status"] = observe("broken_status", broken, 500, sqlite3.SQLITE_NOTADB)
    assert file_state(broken) == broken_before
    (ROOT / "probe.json").write_text(json.dumps(observations, indent=2) + "\n")
    print(f"Recovered original database bytes in {observations['read_write_recovery_ms']} ms", flush=True)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        writer(sys.argv[1])
    else:
        run()
