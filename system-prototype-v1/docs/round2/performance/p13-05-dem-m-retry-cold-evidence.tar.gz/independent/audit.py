"""Read only the seven finalized cold JSONL records and stable classification TIFFs."""
from collections import Counter
from hashlib import sha256
from io import BytesIO
from itertools import islice
import json
import math
from pathlib import Path
import shlex
from statistics import median
import subprocess
import sys
import tarfile

REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
DOC = "system-prototype-v1/docs/round2/performance"
ROOT = REPO / "artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l/dem-m"
ATTEMPTS = {"retry": ROOT / "base/attempt.spcasn8d", "old": ROOT / "base/attempt.5kzfg0pd",
            "candidate": ROOT / "candidate/attempt.f0puyhqd"}
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
CANDIDATE = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
MANIFEST = "24e15649d2777503ff2c3ca7544de9b6ca038d4ffaf04f6fa16b01ba271169f7"
AREA_STEP = "calculate_area_with_equal_area_projection"
PROOF = Path("/tmp/geopilot-p13-05-dem-m-pair-attempt-audit.vYP1vW/independent.json")
PROOF_SHA = "685e02b33b3977545e0c515aff591b7ee1202551f9f82d755506028009f66e42"
POLL_ERROR = {"http_status": 500, "body": {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}}}


def digest(raw):
    return sha256(raw).hexdigest()


def git(commit, name):
    return subprocess.check_output(["git", "-C", str(REPO), "show", f"{commit}:{DOC}/{name}"])


def sealed_jsonl(commit, name, key):
    raw = git(commit, name)
    with tarfile.open(fileobj=BytesIO(raw), mode="r:gz") as archive:
        checksums = dict((path, sha) for sha, path in
                         (line.split(maxsplit=1) for line in archive.extractfile("./SHA256SUMS").read().decode().splitlines()))
        payload = archive.extractfile(key).read()
        assert digest(payload) == checksums[key]
    return payload, digest(raw)


def cold_prefix(attempt):
    with (attempt / "evidence/trials.jsonl").open("rb") as file:
        raw = list(islice(file, 7))
    assert len(raw) == 7 and all(line.endswith(b"\n") for line in raw)
    rows = [json.loads(line) for line in raw]
    assert [(row["cache"], row["index"]) for row in rows] == [("process_cold", i) for i in range(1, 8)]
    return rows, b"".join(raw)


def classification(attempt, row):
    workspace = Path(row["workspace"])
    workspace.relative_to("/scratch/evidence/samples/M/method/process_cold")
    target = attempt / workspace.relative_to("/scratch") / "intermediate/extract_by_threshold/threshold_regions.tif"
    assert target.resolve().is_relative_to(attempt.resolve())
    assert target.is_file() and target.stat().st_size == 11527
    raw = target.read_bytes()
    assert raw[:4] in (b"II*\0", b"MM\0*")
    return {"path": str(target), "bytes": len(raw), "sha256": digest(raw)}


def distribution(records):
    values = sorted(item["value"] for item in records if item["value"] is not None)
    return {"n": len(values), "coverage": dict(Counter(item["status"] for item in records)), "values": values,
            "median": median(values) if len(values) >= 3 else None,
            "p95": values[math.ceil(.95 * len(values)) - 1] if len(values) >= 3 else None}


def reading(value):
    return {"status": "recorded", "value": value}


def normalized_steps(steps):
    return [{name: step[name] for name in ("step_key", "tool", "parameters")} for step in steps]


def recorded_timeout(row, candidate_settings):
    state = row["run_state"]
    assert row["status"] == "FAIL" and row["exit_code"] == -15
    assert (state["execution_status"], state["check_status"], state["current_step"]) == ("FAILED", "NOT_CHECKED", AREA_STEP)
    assert state["current_report_id"] is None and not state["cancel_requested"]
    failure = state["error"]
    assert (failure["code"], failure["phase"], failure["step_key"], failure["message"]) == (
        "PROCESS_TIMEOUT", "execute", AREA_STEP, "Process exceeded 60 seconds",
    )
    assert row["error"]["type"] == "ValueError" and "did not pass execution/checks" in row["error"]["message"]
    assert "correctness" not in row and "v1_completed_checks" not in row
    sidecar = row["telemetry"]
    assert (sidecar["run_id"], sidecar["execution_status"], sidecar["check_status"], sidecar["exit_code"]) == (
        row["run_id"], "FAILED", "NOT_CHECKED", -15,
    )
    assert normalized_steps(row["executed_steps"]) == normalized_steps(candidate_settings["executed_steps"])
    assert len(sidecar["steps"]) == len(row["executed_steps"]) == 7
    for index, (request, event) in enumerate(zip(row["executed_steps"], sidecar["steps"], strict=True)):
        expected_status, expected_exit = ("FAILED", -15) if index == 6 else ("SUCCEEDED", 0)
        assert request["step_key"] == event["step_key"]
        assert request["tool"] == {key: event["tool"][key] for key in ("id", "version")}
        assert request["status"] == event["status"] == expected_status
        assert request["exit_code"] == event["exit_code"] == expected_exit
        process, = [proc for proc in event["processes"] if proc["phase"] == "execute"]
        assert process["exit_code"] == expected_exit and not process["cancelled"]
        assert process["timed_out"] == (index == 6)
        if index == 6:
            assert process["wall_ns"] >= 60_000_000_000



def main(commit, output):
    proof_bytes = PROOF.read_bytes()
    assert digest(proof_bytes) == PROOF_SHA
    proof = json.loads(proof_bytes)
    settings = proof["candidate"]["settings"]
    reference = json.loads(git(commit, "p13-04-dem-m-classification-source.json"))
    assert reference["fixture_manifest_sha256"] == MANIFEST
    assert (reference["valid_class_counts"], reference["masked_pixels"]) == ({"7": 4183812}, 2304)
    frozen_mounts = {}
    shards = {}
    for key, attempt in ATTEMPTS.items():
        store, command = (attempt / "command.log").read_text().splitlines()
        args = shlex.split(command)
        assert store.startswith("storage=/dev/sda2 ext4")
        assert args[args.index("--source-commit") + 1] == (CANDIDATE if key == "candidate" else BASE)
        mount, = [args[i + 1] for i, item in enumerate(args) if item == "--mount" and ",dst=/inputs," in args[i + 1]]
        assert mount.endswith(",dst=/inputs,readonly")
        frozen_mounts[key] = mount
        shards[key] = cold_prefix(attempt)
    assert len(set(frozen_mounts.values())) == 1
    histories = {}
    for key, arc in (("old", "p13-05-dem-m-incomplete-evidence.tar.gz"), ("candidate", "p13-05-dem-m-candidate-evidence.tar.gz")):
        member = "./" + str(ATTEMPTS[key].relative_to(ROOT.parent)) + "/evidence/trials.jsonl"
        raw, arch_sha = sealed_jsonl(commit, arc, member)
        assert shards[key][1] == b"".join(raw.splitlines(keepends=True)[:7])
        histories[key] = {"archive_sha256": arch_sha, "sealed_jsonl_sha256": digest(raw)}
    previous_ids = [row["run_id"] for side in ("baseline", "candidate") for row in proof[side]["observations"]]
    assert len(previous_ids) == len(set(previous_ids)) == 25
    checked = {}
    for key, (rows, raw) in shards.items():
        seen = []
        for i, row in enumerate(rows, 1):
            assert (row["sample_id"], row["kind"]) == (
                f"raster/M/method/process_cold/{i:02d}", "warmup" if i <= 2 else "measurement",
            )
            assert (row["family"], row["tier"], row["workload"], row["worker_exit_code"], row["manifest_sha256"]) == (
                "raster", "M", "method", 0, MANIFEST,
            )
            for field in ("method", "critical_options", "confirmed_parameters"):
                assert row[field] == settings[field]
            raw_params = json.dumps(row["confirmed_parameters"], sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
            assert row["parameters_sha256"] == digest(raw_params)
            assert all(item == POLL_ERROR for item in row.get("status_poll_errors", []))
            if key == "candidate":
                assert row["status"] == "PASS" and row["exit_code"] == 0 and row["executed_steps"] == settings["executed_steps"]
                assert (row["run_state"]["execution_status"], row["run_state"]["check_status"]) == ("SUCCEEDED", "PASSED")
                assert row["correctness"]["area_statistics"]["observed"]["total_area_m2"] == proof["candidate"]["area"]["observed_area_m2"]
            else:
                recorded_timeout(row, settings)
            classes = classification(ATTEMPTS[key], row)
            assert (classes["bytes"], classes["sha256"]) == (reference["bytes"], reference["sha256"])
            seen.append({"run_id": row["run_id"], "sample_id": row["sample_id"], "kind": row["kind"], "status": row["status"],
                         "run_state": row["run_state"], "status_poll_errors": row.get("status_poll_errors", []),
                         "steps": row["executed_steps"], "classification": classes})
        assert len({row["run_id"] for row in seen}) == 7
        measured = [row for row in rows if row["kind"] == "measurement"]
        status = "PASS" if key == "candidate" else "FAIL"
        assert len(measured) == 5 and all(row["status"] == status for row in measured)
        checked[key] = {
            "cold_prefix_sha256": digest(raw), "observations": seen, "formal_status": status,
            "get_500_by_trial": [len(row["status_poll_errors"]) for row in seen],
            "formal_wall_ns": distribution([reading(row["wall_ns"]) for row in measured]),
            "formal_rss_bytes": distribution([row["telemetry"]["resources"]["peak_rss_bytes"] for row in measured]),
            "formal_temp_bytes": distribution([row["workspace_size"]["peak_temp_bytes"] for row in measured]),
            "formal_area_step_wall_ns": distribution([reading(row["telemetry"]["steps"][-1]["wall_ns"]) for row in measured]),
            "formal_area_step_rss_bytes": distribution([row["telemetry"]["steps"][-1]["resources"]["peak_rss_bytes"] for row in measured]),
        }
    assert len({row["run_id"] for row in checked["retry"]["observations"]} | set(previous_ids)) == 32
    assert checked["retry"]["get_500_by_trial"] == [0] * 7
    assert checked["old"]["get_500_by_trial"] == [0, 1, 0, 0, 0, 0, 0]
    payload = {
        "scope": "DEM M original retry cold prefix only",
        "git_commit": commit, "input_manifest_sha256": MANIFEST, "readonly_inputs": frozen_mounts["retry"],
        "archive_proofs": histories, "historical_reference": reference,
        "shards": checked, "pair_formal_receipt_verified": False,
        "correctness_scope": "all 21 terminal cold classification TIFFs match reference bytes; retry stops before complete artifact verification",
        "id_counts": {"previous_dem_m": 25, "new_retry_cold": 7, "combined_unique": 32},
    }
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    for key, data in checked.items():
        print(key, "formal", data["formal_status"], "E2E", data["formal_wall_ns"], "area", data["formal_area_step_wall_ns"])
        print(key, "RSS", data["formal_rss_bytes"], "temporary", data["formal_temp_bytes"], "per-trial GET500", data["get_500_by_trial"])
    print("21 terminal cold classifications match archived reference", reference["sha256"])
    print("7 retry cold failures are actual area timeouts, all first six steps success; no complete artifact verification")
    print("7 retry run IDs disjoint from previously sealed 25 DEM M IDs; cold prefix only")


if __name__ == "__main__":
    main(sys.argv[1], Path(sys.argv[2]))
