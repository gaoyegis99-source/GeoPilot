"""Replay the published DEM M retry cold prefix against the sealed classification reference."""

from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import sys

import numpy as np
import rasterio

bundle, evidence = (Path(arg) for arg in sys.argv[1:])
reference = json.loads((evidence / "p13-04-dem-m-classification-source.json").read_bytes())
raw = (bundle / "cold-trials.jsonl").read_bytes()
rows = [json.loads(line) for line in raw.splitlines()]
assert len(rows) == len({row["run_id"] for row in rows}) == 7
files = {}
for index, row in enumerate(rows, 1):
    assert (row["cache"], row["index"], row["kind"]) == ("process_cold", index, "warmup" if index <= 2 else "measurement")
    assert row["status"] == "FAIL" and row["manifest_sha256"] == reference["fixture_manifest_sha256"]
    assert not row.get("status_poll_errors") and not row.get("correctness")
    state = row["run_state"]
    assert (state["execution_status"], state["check_status"]) == ("FAILED", "NOT_CHECKED")
    assert state["error"]["code"] == "PROCESS_TIMEOUT"
    steps = row["executed_steps"]
    assert [step["exit_code"] for step in steps] == [0] * 6 + [-15]
    assert steps[-1]["step_key"] == "calculate_area_with_equal_area_projection"
    filename = bundle / "classification" / f"{index:02d}.tif"
    digest = sha256(filename.read_bytes()).hexdigest()
    assert digest == reference["sha256"]
    with rasterio.open(filename) as dataset:
        assert dataset.crs.to_string() == reference["crs"]
        assert list(dataset.shape) == reference["shape"]
        assert list(dataset.transform)[:6] == reference["transform"]
        assert dataset.nodata == reference["nodata"]
        band = dataset.read(1, masked=True)
        valid_values, counts = np.unique(band.compressed(), return_counts=True)
        assert {str(value): int(count) for value, count in zip(valid_values, counts, strict=True)} == reference["valid_class_counts"]
        assert int(np.ma.count_masked(band)) == reference["masked_pixels"]
    files[filename.name] = digest
measured = rows[2:]
walls = [row["wall_ns"] for row in measured]
print(json.dumps({
    "cold_rows_sha256": sha256(raw).hexdigest(), "status_errors": 0, "timed_out": 7,
    "run_ids": [row["run_id"] for row in rows], "classification_sha256": files,
    "measurement_wall_ns": {"median": median(walls), "p95": max(walls)},
}, indent=2))
