#!/usr/bin/env bash
set -euo pipefail

portable=$1
source=$2
python_bin=$3
attempt=$(cat "$source/candidate/COMPLETED")
test "$attempt" = attempt.tnx5f7_f
target="$portable/remote-l/candidate/$attempt"
mkdir -p "$target/evidence"
cp "$source/candidate/COMPLETED" "$portable/remote-l/candidate/"
cp "$source/candidate/$attempt"/{command.log,container-name,container.log,exit-code,self-comparison.command,self-comparison.exit-code,self-comparison.json,self-comparison.stderr} "$target/"
cp "$source/candidate/$attempt/evidence"/{report.json,runtime-configuration.json,trials.jsonl} "$target/evidence/"

shopt -s nullglob
comparisons=("$source"/pair.*/before-after.json)
test "${#comparisons[@]}" = 1
comp_dir=${comparisons[0]%/before-after.json}
pair_target="$portable/remote-l/${comp_dir##*/}"
mkdir "$pair_target"
cp "$comp_dir"/{before-after.command,before-after.exit-code,before-after.json,before-after.stderr} "$pair_target/"

env PYTHONPATH="$portable/proof" "$python_bin" -B "$portable/proof/verify-remote-pair.py" \
  "$portable" "$source/candidate/$attempt" > "$portable/proof/verified.json"
