"""Replay a completed raster pair from its portable sealed evidence."""

from hashlib import sha256
import json
from pathlib import Path
import re
import runpy
import subprocess
import sys


def read_json(path):
    return json.loads(path.read_bytes())


def checked_attempt(portable, side, verifier, contract):
    folder = portable / side
    attempt_name = (folder / "COMPLETED").read_text().strip()
    assert re.fullmatch(r"attempt\.[a-z0-9_]+", attempt_name)
    attempt = folder / attempt_name
    evidence = verifier["verify_attempt"](attempt, side, contract)
    return attempt, evidence


def compare(comparator, before, after):
    return subprocess.check_output([
        sys.executable, "-B", comparator, "--kind", "raster",
        "--require-runtime-configuration", "--before", before, "--after", after,
    ])


def replay(directory, case):
    proof = directory / "proof"
    verifier = runpy.run_path(str(proof / "run-raster-pairs.py"))
    profile, tier, _, expected_hash = verifier["CASES"][case]
    family = profile.replace("-", "_")
    manifest_path = proof / "input-manifest.json"
    assert sha256(manifest_path.read_bytes()).hexdigest() == expected_hash
    manifest = read_json(manifest_path)
    assert (manifest["family"], manifest["tier"]) == (family, tier)
    files = {
        record["role"]: {key: record[key] for key in ("path", "bytes", "sha256")}
        for record in manifest["files"]
    }
    assert len(files) == len(manifest["files"])
    contract = (None, family, tier, expected_hash, files)
    comparator = proof / "run_memory_profile.py"
    assert sha256(comparator.read_bytes()).hexdigest() == verifier["COMPARATOR"]
    sources = {}
    seen = set()
    for side in ("base", "candidate"):
        attempt, evidence = checked_attempt(directory / case, side, verifier, contract)
        ids = {json.loads(line)["run_id"] for line in (evidence / "trials.jsonl").read_text().splitlines()}
        assert len(ids) == 14 and not ids.intersection(seen)
        seen.update(ids)
        assert (attempt / "self-comparison.exit-code").read_text().strip() == "0"
        assert not (attempt / "self-comparison.stderr").read_bytes()
        assert compare(comparator, evidence, evidence) == (attempt / "self-comparison.json").read_bytes()
        sources[side] = evidence
        print(side, attempt.name, "trials", len(ids), "container", (attempt / "exit-code").read_text().strip())
    pair, = (folder for folder in (directory / case).glob("pair.*") if (folder / "before-after.json").is_file())
    assert (pair / "before-after.exit-code").read_text().strip() == "0"
    assert not (pair / "before-after.stderr").read_bytes()
    comparison = compare(comparator, sources["base"], sources["candidate"])
    assert comparison == (pair / "before-after.json").read_bytes()
    assert read_json(pair / "before-after.json")["status"] == "MATCHED_EVIDENCE"
    print("Pair and both self comparisons reproduce byte-for-byte.", len(seen), "unique run IDs.")


if __name__ == "__main__":
    replay(Path(sys.argv[1]), sys.argv[2])
