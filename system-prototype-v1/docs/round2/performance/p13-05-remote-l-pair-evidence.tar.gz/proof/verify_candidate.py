"""Capture or replay completed cold samples from the frozen remote L candidate."""

import argparse
from collections import Counter
from hashlib import sha256
import json
from math import isclose
from pathlib import Path
import shutil
from statistics import median

from geopilot.data.fingerprint import copy_file_group, fingerprint_file


SAMPLE_PREFIX = "remote_sensing/L/method/process_cold/"
DIFFERENCE_SHA = "d215839bf661e72c290c0237ef1a52f98fcb4605c64f5b5a460f2346f6dd020d"
STEP = "calculate_change"


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def capture(root, attempt, count):
    root.mkdir(parents=True, exist_ok=True)
    raw = (attempt / "evidence/trials.jsonl").read_bytes().splitlines(keepends=True)[:count]
    assert len(raw) == count and all(line.endswith(b"\n") for line in raw)
    (root / "trials.jsonl").write_bytes(b"".join(raw))
    for line in raw:
        row = json.loads(line)
        assert row["sample_id"].startswith(SAMPLE_PREFIX)
        capture_sample(root, attempt, row)


def capture_sample(root, attempt, row):
    run = row["run_id"]
    work = attempt / Path(row["workspace"]).relative_to("/scratch")
    assert work.name == run
    directory = root / "runs" / run
    for relative in ("outputs/manifest.json", "checks/report.json", f"steps/{STEP}/request.json",
                     f"steps/{STEP}/result.json", f"steps/{STEP}/process.log"):
        target = directory / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(work / relative, target)
    stage = work / "intermediate" / STEP
    children = sorted(path.name for path in stage.iterdir())
    (directory / "staging-inventory.json").write_text(json.dumps(children) + "\n")
    for artifact in read(work / "outputs/manifest.json")["artifacts"].values():
        relative = artifact["path"]
        target = directory / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        copy_file_group(work / relative, target, expected_digest=artifact["fingerprint"])


def verify_artifacts(directory, row, reference):
    artifacts = read(directory / "outputs/manifest.json")["artifacts"]
    assert len(artifacts) == 10
    observed = {}
    for role, record in artifacts.items():
        path = directory / record["path"]
        result = fingerprint_file(path)
        assert result.digest == record["fingerprint"]
        observed[role] = {"sha256": result.digest, "bytes": result.size_bytes}
    assert sum(item["bytes"] for item in observed.values()) == row["output_bytes"]
    assert digest(directory / artifacts["change_classes"]["path"]) == reference["sha256"]
    assert digest(directory / artifacts["change_raster"]["path"]) == DIFFERENCE_SHA
    area = read(directory / artifacts["area_statistics"]["path"])
    assert area == row["correctness"]["area_statistics"]["observed"]
    assert (area["source_crs"], area["area_crs"], area["area_method"], area["direction"]) == (
        "EPSG:32632", "EPSG:6933", "equal_area", "second_minus_first",
    )
    assert area["nodata_pixel_count"] == reference["masked_pixels"]
    assert area["valid_pixel_count"] == area["selected_pixel_count"] == 4_718_592
    assert len(area["classes"]) == 3
    differences = {}
    for item in area["classes"]:
        key = str(item["class_id"])
        expected = reference["expected_area_m2"][key]
        assert item["pixel_count"] == reference["valid_class_counts"][key]
        assert isclose(item["area_m2"], expected, rel_tol=2e-7, abs_tol=.02)
        differences[key] = item["area_m2"] - expected
    return observed, area["total_area_m2"], differences


def verify_sample(root, row, index, reference):
    kind = "warmup" if index < 3 else "measurement"
    sample_id = f"remote_sensing/L/method/{row['cache']}/{index:02d}"
    assert (row["sample_id"], row["kind"], row["index"]) == (sample_id, kind, index)
    state = row["run_state"]
    assert (state["run_id"], state["execution_status"], state["check_status"]) == (row["run_id"], "SUCCEEDED", "PASSED")
    assert not state["error"] and row.get("correctness")
    polls = row.get("status_poll_errors", [])
    assert all(error["http_status"] == 500 and error["body"]["detail"]["code"] == "STORAGE_FAILED" for error in polls)
    if polls:
        assert row["status"] == "FAIL" and row["error"]["type"] == "StatusObservationFailure"
    else:
        assert row["status"] == "PASS" and "error" not in row
    steps = row["executed_steps"]
    assert len(steps) == 8 and all((step["status"], step["exit_code"]) == ("SUCCEEDED", 0) for step in steps)
    terminal = row["telemetry"]["steps"][-1]
    assert terminal["step_key"] == STEP and terminal["wall_ns"] < 60_000_000_000
    directory = root / "runs" / row["run_id"]
    report = read(directory / "checks/report.json")
    assert (report["report_id"], report["run_id"], report["status"]) == (state["current_report_id"], row["run_id"], "PASSED")
    assert report["completed_rules"] == row["v1_completed_checks"]
    result = read(directory / f"steps/{STEP}/result.json")
    request = read(directory / f"steps/{STEP}/request.json")
    assert result["run_id"] == request["run_id"] == row["run_id"] and result["exit_code"] == 0
    assert request["parameters"] == {"change_threshold": 0.1, "area_crs": "EPSG:6933"}
    assert read(directory / "staging-inventory.json") == ["area_statistics.json", "change_classes.tif", "change_raster.tif"]
    artifacts, area, differences = verify_artifacts(directory, row, reference)
    return {
        "run_id": row["run_id"], "kind": kind, "status": row["status"], "status_get_500": len(polls),
        "wall_ns": row["wall_ns"], "step_wall_ns": terminal["wall_ns"],
        "run_peak_rss_bytes": row["telemetry"]["resources"]["peak_rss_bytes"],
        "step_peak_rss_bytes": terminal["resources"]["peak_rss_bytes"],
        "step_cpu_ns": terminal["resources"]["cpu_ns"],
        "temp_peak_bytes": row["workspace_size"]["peak_temp_bytes"],
        "area_m2": area, "area_deviations_m2": differences, "artifacts": artifacts,
    }


def distribution(values):
    return {"samples": len(values), "median": median(values) if len(values) >= 3 else None,
            "p95_nearest_rank": max(values) if len(values) >= 3 else None}


def verify(root, count):
    raw = root / "trials.jsonl"
    rows = [json.loads(line) for line in raw.read_bytes().splitlines()]
    assert len(rows) == count and len({row["run_id"] for row in rows}) == count
    assert {row["manifest_sha256"] for row in rows} == {digest(root / "input-manifest.json")}
    assert len({row["parameters_sha256"] for row in rows}) == 1
    reference = next(item for item in read(root / "fixture-manifest.json")["fixtures"] if item["id"] == "remote-l")
    samples = [verify_sample(root, row, index, reference) for index, row in enumerate(rows, 1)]
    assert all(sample["artifacts"] == samples[0]["artifacts"] for sample in samples)
    measured = [row for row in samples if row["kind"] == "measurement"]
    output = {
        "samples_sha256": digest(raw), "observed_runs": count, "gis_passed": count,
        "get_500": sum(row["status_get_500"] for row in samples), "distinct_artifact_roles": len(samples[0]["artifacts"]),
        "measurements": dict(Counter(row["status"] for row in measured)), "samples": samples,
        "verified_change_step": distribution([row["step_wall_ns"] for row in measured]),
    }
    for status in ("PASS", "FAIL"):
        output[f"{status.lower()}_wall_ns"] = distribution([row["wall_ns"] for row in measured if row["status"] == status])
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--attempt", type=Path)
    parser.add_argument("--count", type=int, choices=range(1, 8), default=7)
    args = parser.parse_args()
    if args.attempt:
        capture(args.root, args.attempt, args.count)
    verify(args.root, args.count)
