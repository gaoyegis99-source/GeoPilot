"""Reproduce the strict comparison and staged TIFF audit for the remote L original."""

from hashlib import sha256
import json
from pathlib import Path
import runpy
from statistics import median
import sys

from replay import checked_attempt, compare, read_json


STEP = "calculate_change"


def inspect(attempt, raw, row, index):
    kind = "warmup" if index < 3 else "measurement"
    assert (row["sample_id"], row["kind"], row["index"]) == (f"remote_sensing/L/method/{row['cache']}/{index:02d}", kind, index)
    state = row["run_state"]
    assert (row["status"], state["execution_status"], state["check_status"]) == ("FAIL", "FAILED", "NOT_CHECKED")
    assert state["error"]["code"] == "PROCESS_TIMEOUT" and state["error"]["step_key"] == STEP
    assert not state["current_report_id"] and "correctness" not in row
    steps = row["executed_steps"]
    assert len(steps) == 8 and all((step["status"], step["exit_code"]) == ("SUCCEEDED", 0) for step in steps[:-1])
    assert (steps[-1]["step_key"], steps[-1]["status"], steps[-1]["exit_code"]) == (STEP, "FAILED", -15)
    workspace = attempt / Path(row["workspace"]).relative_to("/scratch")
    assert workspace.name == state["run_id"] == row["run_id"]
    sample = attempt / "evidence/samples/L/method" / row["cache"] / f"{index:02d}-{kind}" / "trial.json"
    assert read_json(sample) == {key: value for key, value in row.items() if key not in {"worker_exit_code", "worker_log"}}
    request = read_json(workspace / "steps" / STEP / "request.json")
    result = read_json(workspace / "steps" / STEP / "result.json")
    assert request["run_id"] == result["run_id"] == row["run_id"]
    assert request["parameters"] == steps[-1]["parameters"] == {"change_threshold": 0.1, "area_crs": "EPSG:6933"}
    assert result["outputs"] == {} and result["error"] == state["error"] and result["exit_code"] == -15
    log = (workspace / "steps" / STEP / "process.log").read_text()
    assert "exit_code: -15" in log and "PROCESS_TIMEOUT: Process exceeded 60 seconds" in log
    assert not (workspace / "outputs/manifest.json").exists()
    assert all(not (workspace / item["path"]).exists() for item in request["output_targets"].values())
    files = {}
    for path in sorted((workspace / "intermediate" / STEP).rglob("*.tif")):
        assert path.name not in files
        files[path.name] = {"bytes": path.stat().st_size, "sha256": sha256(path.read_bytes()).hexdigest()}
    assert files == {
        "classes.tif": {"bytes": 44420, "sha256": raw["reference_sha256"]},
        "change_raster.tif": {"bytes": 311039, "sha256": "d215839bf661e72c290c0237ef1a52f98fcb4605c64f5b5a460f2346f6dd020d"},
    }
    errors = row.get("status_poll_errors", [])
    assert all(item["http_status"] == 500 and item["body"]["detail"]["code"] == "STORAGE_FAILED" for item in errors)
    telemetry = row["telemetry"]
    terminal_step = telemetry["steps"][-1]
    assert terminal_step["step_key"] == STEP and terminal_step["processes"][0]["timed_out"]
    return {
        "run_id": row["run_id"], "kind": kind, "wall_ns": row["wall_ns"], "status_get_500": len(errors),
        "step_wall_ns": terminal_step["wall_ns"], "step_peak_rss_bytes": terminal_step["resources"]["peak_rss_bytes"],
        "run_peak_rss_bytes": telemetry["resources"]["peak_rss_bytes"],
        "temp_peak_bytes": row["workspace_size"]["peak_temp_bytes"], "staged_tiffs": files,
    }


def main(root):
    proof = root / "proof"
    verifier = runpy.run_path(str(proof / "run-raster-pairs.py"))
    profile, tier, _, expected = verifier["CASES"]["remote-l"]
    input_path = proof / "input-manifest.json"
    assert sha256(input_path.read_bytes()).hexdigest() == expected
    manifest = read_json(input_path)
    family = profile.replace("-", "_")
    assert (manifest["family"], manifest["tier"]) == (family, tier)
    files = {record["role"]: {key: record[key] for key in ("path", "bytes", "sha256")} for record in manifest["files"]}
    attempt, evidence = checked_attempt(root / "remote-l", "base", verifier, (None, family, tier, expected, files))
    assert (attempt / "exit-code").read_text().strip() == "1"
    assert (attempt / "self-comparison.exit-code").read_text().strip() == "0"
    assert (attempt / "self-comparison.stderr").stat().st_size == 0
    comparator = proof / "run_memory_profile.py"
    assert sha256(comparator.read_bytes()).hexdigest() == verifier["COMPARATOR"]
    assert compare(comparator, evidence, evidence) == (attempt / "self-comparison.json").read_bytes()
    paired = read_json(attempt / "self-comparison.json")
    assert paired["status"] == "MATCHED_EVIDENCE" and not paired["candidate_all_measurements_pass"]
    assert all(group["before"]["counts"] == {"PASS": 0, "FAIL": 5, "NOT_RUN": 0}
               and group["successful_sample_deltas"] == {} for group in paired["groups"])

    lines = (evidence / "trials.jsonl").read_bytes().splitlines(keepends=True)
    cold = read_json(proof / "cold-summary.json")
    assert len(lines) == 14 and sha256(b"".join(lines[:7])).hexdigest() == cold["trials_sha256"]
    rows = [json.loads(line) for line in lines]
    assert len({row["run_id"] for row in rows}) == 14
    stats = {"attempt": attempt.name, "configuration_sha256": paired["runtime_configuration"]["sha256"], "groups": {}}
    for cache, group in zip(("process_cold", "warm"), (rows[:7], rows[7:]), strict=True):
        assert all(row["cache"] == cache for row in group)
        observed = [inspect(attempt, cold, row, index) for index, row in enumerate(group, 1)]
        measures = [row for row in observed if row["kind"] == "measurement"]
        assert len(measures) == 5
        stats["groups"][cache] = {
            "rows": observed,
            "status_get_500": sum(row["status_get_500"] for row in observed),
            **{field: {"median": median(row[field] for row in measures), "p95_nearest_rank": max(row[field] for row in measures)}
               for field in ("wall_ns", "step_wall_ns")},
        }
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve(strict=True))
