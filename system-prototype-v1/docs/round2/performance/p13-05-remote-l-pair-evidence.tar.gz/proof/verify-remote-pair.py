"""Replay the frozen remote L pair and revalidate its published candidate artifacts."""

from collections import Counter
from contextlib import redirect_stdout
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

from replay import read_json, replay
from verify_candidate import capture_sample, distribution, verify_sample


def completed(root, side):
    path = root / "remote-l" / side
    return path / (path / "COMPLETED").read_text().strip()


def candidate_groups(root, rows):
    fixture = read_json(root / "proof/fixture-manifest.json")
    reference = next(item for item in fixture["fixtures"] if item["id"] == "remote-l")
    records = {}
    for cache in ("process_cold", "warm"):
        group = [row for row in rows if row["cache"] == cache]
        assert len(group) == 7
        samples = [verify_sample(root / "proof/candidate-files", row, index, reference)
                   for index, row in enumerate(group, 1)]
        assert all(sample["artifacts"] == samples[0]["artifacts"] for sample in samples)
        measured = [sample for sample in samples if sample["kind"] == "measurement"]
        assert len(measured) == 5
        metrics = {}
        for field in ("run_peak_rss_bytes", "step_peak_rss_bytes", "step_cpu_ns", "temp_peak_bytes"):
            values = [sample[field] for sample in measured]
            metrics[field] = {
                "coverage": dict(sorted(Counter(item["status"] for item in values).items())),
                **distribution([item["value"] for item in values if item["value"] is not None]),
            }
        records[cache] = {
            "samples": samples,
            "observed_gis_pass": len(samples),
            "status_get_500": sum(sample["status_get_500"] for sample in samples),
            "measurement_counts": dict(Counter(sample["status"] for sample in measured)),
            "measurement_verified_change_step_ns": distribution([sample["step_wall_ns"] for sample in measured]),
            "measurement_verified_change_step_ns_range": [
                min(sample["step_wall_ns"] for sample in measured), max(sample["step_wall_ns"] for sample in measured),
            ],
            "metrics": metrics,
            **{f"{status.lower()}_wall_ns": distribution([sample["wall_ns"] for sample in measured if sample["status"] == status])
               for status in ("PASS", "FAIL")},
        }
    assert records["process_cold"]["samples"][0]["artifacts"] == records["warm"]["samples"][0]["artifacts"]
    return records


def main(root, *, capture=None):
    proof = root / "proof"
    attempt = completed(root, "candidate")
    source = (attempt / "evidence/trials.jsonl").read_bytes()
    lines = source.splitlines(keepends=True)
    assert len(lines) == 14 and all(line.endswith(b"\n") for line in lines)
    cold = read_json(proof / "candidate-cold-summary.json")
    assert sha256(b"".join(lines[:7])).hexdigest() == cold["samples_sha256"]
    rows = [json.loads(line) for line in lines]
    if capture is not None:
        assert source == (capture / "evidence/trials.jsonl").read_bytes()
        for row in rows:
            capture_sample(proof / "candidate-files", capture, row)

    with redirect_stdout(sys.stderr):
        replay(root, "remote-l")
    base = subprocess.check_output([sys.executable, "-B", proof / "verify-remote-original.py", root])
    assert base == (proof / "base-replayed.json").read_bytes()
    pair, = (folder for folder in (root / "remote-l").glob("pair.*") if (folder / "before-after.json").is_file())
    matched = read_json(pair / "before-after.json")
    assert matched["status"] == "MATCHED_EVIDENCE"
    groups = candidate_groups(root, rows)
    for group in matched["groups"]:
        cache = group["group"][2]
        assert group["before"]["counts"] == {"PASS": 0, "FAIL": 5, "NOT_RUN": 0}
        assert group["successful_sample_deltas"] == {}
        actual = groups[cache]["measurement_counts"]
        assert all(actual.get(status, 0) == count for status, count in group["after"]["counts"].items())
    assert {row["manifest_sha256"] for row in rows} == {sha256((proof / "input-manifest.json").read_bytes()).hexdigest()}
    print(json.dumps({
        "candidate_attempt": attempt.name, "original_attempt": completed(root, "base").name,
        "strict_pair_sha256": sha256((pair / "before-after.json").read_bytes()).hexdigest(),
        "runtime_configuration_sha256": matched["runtime_configuration"]["sha256"],
        "candidate_trials_sha256": sha256(source).hexdigest(), "candidate_verified_runs": len(rows),
        "candidate_groups": groups,
    }, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve(strict=True), capture=Path(sys.argv[2]) if len(sys.argv) > 2 else None)
