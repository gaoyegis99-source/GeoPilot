"""Read only the committed JSONL prefix for the completed remote sensing L frozen pair."""
from collections import Counter
from hashlib import sha256
from io import BytesIO
import json
import math
import re
from pathlib import Path
import shlex
from statistics import median
import subprocess
import tarfile
import sys

REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
DOCS = REPO / "docs/round2/performance"
ROOT = REPO / "artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l"
ATTEMPT = ROOT / "remote-l/candidate/attempt.tnx5f7_f"
TRIALS = ATTEMPT / "evidence/trials.jsonl"
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
MANIFEST = "7ca5d30de46b40955845aadb312ff02b6653a11fc708d8aeaaf8d404fb769e04"
FINAL_STEP = "calculate_change"
POLL_ERROR = {"http_status": 500, "body": {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}}}
RESOURCES = ("cpu_ns", "peak_rss_bytes", "disk_read_bytes", "disk_write_bytes")
METRICS = ("wall_ns", "queue_wall_ns", "execute_steps_wall_ns", "finalize_wall_ns", *RESOURCES, "peak_temp_bytes")
PROOFS = {
    "first_s": ("/tmp/geopilot-p13-05-raster-s-audit.rJKuNw/independent.json",
                "f6c4e2d81e0d269b154a5640c7aa71a4636472174bb841e86290c59c630c437b"),
    "remote_s_rerun": ("/tmp/geopilot-p13-05-remote-s-after-vector-l-audit.Gbk18m/independent.json",
                       "cbb29456d9657978bdd4a59d60f0debdedc7bcb91a38efc5b6a0f08f85c2892b"),
    "dem_m": ("/tmp/geopilot-p13-05-dem-m-pair-attempt-audit.vYP1vW/independent.json",
              "685e02b33b3977545e0c515aff591b7ee1202551f9f82d755506028009f66e42"),
}
DEM_L_PROOF = Path("/tmp/geopilot-p13-05-dem-l-final-pair-audit.EppAOX/independent.json")
DEM_L_PROOF_SHA = "8f0c3286971b1c44239eddaf2afd24fa71b9a9128d4961530ab3c438c0b61995"
CLASSIFICATION_SOURCE = DOCS / "p13-04-remote-l-classification-source.json"


def classification_reference(historical):
    frozen = read(CLASSIFICATION_SOURCE)
    source, = [row for row in historical if row["run_id"] == frozen["source_run_id"]]
    assert source["run_state"] == frozen["source_run_terminal_state"]
    assert frozen["fixture_manifest_sha256"] == MANIFEST
    assert frozen["source_step"] == FINAL_STEP and frozen["source_tool"] == source["telemetry"]["steps"][-1]["tool"]
    assert (frozen["shape"], frozen["valid_class_counts"], frozen["masked_pixels"]) == (
        [3072, 3072], {"1": 1572864, "2": 1572864, "3": 1572864}, 4718592,
    )
    return frozen


def digest(raw):
    return sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    with path.open("rb") as stream:
        return [json.loads(line) for line in stream]


def proof(label):
    name, expected = PROOFS[label]
    raw = Path(name).read_bytes()
    assert digest(raw) == expected
    return json.loads(raw)


def observe(value):
    return {"status": "recorded" if value is not None else "unavailable", "value": value}


def distribution(items):
    values = [item["value"] for item in items if item.get("value") is not None]
    return {
        "n": len(values), "coverage": dict(Counter(item["status"] for item in items)), "values": values,
        "median": median(values) if len(values) >= 3 else None,
        "p95": sorted(values)[math.ceil(.95 * len(values)) - 1] if len(values) >= 3 else None,
    }


def check_timeout(row, expected_steps, expected_params):
    run = row["run_state"]
    assert (row["status"], run["execution_status"], run["check_status"], run["current_step"]) == (
        "FAIL", "FAILED", "NOT_CHECKED", FINAL_STEP,
    )
    assert run["run_id"] == row["run_id"] and run["current_report_id"] is None and not run["cancel_requested"]
    error = run["error"]
    assert (error["code"], error["phase"], error["step_key"], error["message"]) == (
        "PROCESS_TIMEOUT", "execute", FINAL_STEP, "Process exceeded 60 seconds",
    )
    assert row["exit_code"] == -15 and row["error"]["type"] == "ValueError"
    assert "did not pass execution/checks" in row["error"]["message"]
    assert all(key not in row for key in ("correctness", "v1_completed_checks", "output_bytes"))
    doc = row["telemetry"]
    assert (doc["schema_version"], doc["run_id"], doc["execution_status"], doc["check_status"], doc["exit_code"]) == (
        1, row["run_id"], "FAILED", "NOT_CHECKED", -15,
    )
    steps = row["executed_steps"]
    assert len(steps) == len(doc["steps"]) == len(expected_steps) == 8
    for i, (request, event) in enumerate(zip(steps, doc["steps"], strict=True)):
        key, tool, version = expected_steps[i]
        assert request["step_key"] == event["step_key"] == key
        assert request["tool"] == {"id": tool, "version": version} == {k: event["tool"][k] for k in ("id", "version")}
        assert request["parameters"] == expected_params[i]
        failed = i == 7
        expected_status, expected_exit = ("FAILED", -15) if failed else ("SUCCEEDED", 0)
        assert request["status"] == event["status"] == expected_status
        assert request["exit_code"] == event["exit_code"] == expected_exit
        process, = [item for item in event["processes"] if item["phase"] == "execute"]
        assert process["exit_code"] == expected_exit and process["timed_out"] == failed and not process["cancelled"]
        if failed:
            assert process["wall_ns"] >= 60_000_000_000


def metrics(row):
    doc = row["telemetry"]
    return {
        "wall_ns": observe(row["wall_ns"]), "queue_wall_ns": doc["queue_wall_ns"],
        "execute_steps_wall_ns": observe(doc["execute_steps_wall_ns"]), "finalize_wall_ns": observe(doc["finalize_wall_ns"]),
        **doc["resources"], "peak_temp_bytes": row["workspace_size"]["peak_temp_bytes"],
    }


def official_history():
    files = [DOCS / f"p13-04-{kind}-method-{size}-trials.jsonl"
             for kind, size in (("raster", "s"), ("raster", "m"), ("raster", "l"), ("remote", "sm"), ("remote", "l"))]
    rows = [row for f in files for row in jsonl(f)]
    assert len(rows) == len({row["run_id"] for row in rows}) == 84
    same = [row for row in rows if row["family"] == "remote_sensing" and row["tier"] == "L"]
    assert len(same) == 14 and {row["manifest_sha256"] for row in same} == {MANIFEST}
    for row in same:
        state = row["run_state"]
        assert (row["status"], state["execution_status"], state["check_status"], state["current_step"]) == (
            "FAIL", "FAILED", "NOT_CHECKED", FINAL_STEP,
        )
        assert state["error"]["code"] == "PROCESS_TIMEOUT"
        assert [step["exit_code"] for step in row["telemetry"]["steps"]] == [0] * 7 + [-15]
    return rows, same


def prior_ids(historical, current):
    first = [rid for case in proof("first_s").values() for side in ("base", "candidate") for rid in case[side]["run_ids"]]
    later = [row["run_id"] for side in ("base", "candidate") for row in proof("remote_s_rerun")[side]["observations"]]
    medium = [row["run_id"] for side in ("baseline", "candidate") for row in proof("dem_m")[side]["observations"]]
    assert digest(DEM_L_PROOF.read_bytes()) == DEM_L_PROOF_SHA
    dem_l = [row["run_id"] for side in ("base", "candidate") for row in read(DEM_L_PROOF)[side]["samples"]]
    previous = first + later + medium + dem_l + [row["run_id"] for row in historical]
    assert (len(first), len(later), len(medium), len(dem_l), len(previous)) == (47, 28, 25, 28, 212)
    assert len(previous + current) == len(set(previous + current))
    return {"P13-04": 84, "first_s": 47, "remote_s_rerun": 28, "dem_m": 25, "dem_l": 28,
            "current_cold": len(current), "combined_unique": len(previous + current)}


CANDIDATE = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
BASE_PROOF = Path("/tmp/geopilot-p13-05-remote-l-base-final-audit.PVQ1vW/independent.json")
BASE_PROOF_SHA = "fd5976b36d90817967dadd75073775dac05957ff54332fee69b3a0749a143656"
FIRST_ARCHIVE = "system-prototype-v1/docs/round2/performance/p13-05-remote-l-candidate-first-evidence.tar.gz"
FIXTURE = "system-prototype-v1/benchmarks/raster/area-fixtures/manifest.json"
WORKSPACE_ROOT = Path("/scratch/evidence/samples/L/method")
CHECKS = ["product_configuration_matches", "common_valid_pixels_aligned", "change_direction_is_second_minus_first",
          "ndvi_values_in_range"]


def git(commit, path):
    return subprocess.check_output(["git", "-C", str(REPO), "show", f"{commit}:{path}"])


def frozen_refs(commit):
    fixture_manifest = json.loads(git(commit, FIXTURE))
    fixture, = [item for item in fixture_manifest["fixtures"] if item["id"] == "remote-l"]
    raw = git(commit, FIRST_ARCHIVE)
    with tarfile.open(fileobj=BytesIO(raw), mode="r:gz") as archive:
        item, = [member for member in archive.getmembers() if member.name.endswith("/verified.json")]
        with archive.extractfile(item) as source:
            first = json.load(source)
    assert fixture["source"]["fixture_manifest_sha256"] == MANIFEST
    assert fixture["grid"]["shape"] == [3072, 3072]
    assert fixture_manifest["area_reference"] == {
        "crs": "EPSG:6933", "relative_tolerance": 2e-7, "absolute_tolerance_m2": .02,
    }
    return fixture, first, digest(raw)


def independently_expected_masks(reference):
    first = reference["grids"]["landsat"]
    second = reference["grids"]["sentinel"]
    scl = reference["grids"]["native_scl"]
    first_width = first["shape"][1]
    second_width = second["shape"][1]
    first_pixel, second_pixel, scl_pixel = (grid["transform"][0] for grid in (first, second, scl))
    offset = first["transform"][2] - second["transform"][2]
    assert (first_width, second_width, first_pixel, second_pixel, scl_pixel, offset) == (3072, 9218, 30, 10, 20, 7)
    second_rows = second_clear_columns = 0
    for i in range(second_width):
        pos = (i + .5) * second_pixel
        coarse = math.floor((pos - offset) / first_pixel)
        if not 0 <= coarse < first_width:
            continue
        second_rows += 1
        center = (math.floor(pos / scl_pixel) + .5) * scl_pixel
        phase = math.floor((center - offset) / first_pixel) % 6
        second_clear_columns += phase != 4
    return reference["expected_pixels_per_phase"] * 4, second_rows * second_clear_columns


def correctness(row, fixture, reference):
    result = row["correctness"]
    assert set(result) == {
        "first_quality_mask", "first_ndvi", "second_quality_mask", "second_ndvi", "aligned_ndvi",
        "change_raster", "change_classes", "calibration_report", "area_statistics",
    }
    first_clear, second_clear = independently_expected_masks(reference)
    assert (first_clear, second_clear) == (6291456, 66060288)
    first_size, second_size = (reference["landsat_pixels"], reference["sentinel_pixels"])
    common = reference["common_valid_pixels"]
    assert common == sum(fixture["valid_class_counts"].values()) == 4718592
    assert reference["nodata_pixels"] == fixture["masked_pixels"] == first_size - common
    expected = {
        "first_quality_mask": ("landsat", [first_size], [0], first_clear, 0),
        "first_ndvi": ("landsat", [first_clear], [first_size - first_clear], None, 1e-6),
        "second_quality_mask": ("sentinel", [second_size], [0], second_clear, 0),
        "second_ndvi": ("sentinel", [second_clear], [second_size - second_clear], None, 1e-6),
        "aligned_ndvi": ("landsat", [common] * 2, [first_size - common] * 2, None, 1e-6),
        "change_raster": ("landsat", [common], [first_size - common], None, 1e-6),
        "change_classes": ("landsat", [common], [first_size - common], None, 0),
    }
    for name, (grid, valid, masked, ones, tolerance) in expected.items():
        item = result[name]
        expected_grid = reference["grids"][grid]
        assert (item["height"], item["width"]) == tuple(expected_grid["shape"])
        assert item["transform"] == expected_grid["transform"] and item["crs"] == reference["crs"]
        assert (item["valid_pixels_by_band"], item["masked_pixels_by_band"]) == (valid, masked)
        assert item.get("value_one_pixels_by_band") == ([ones] if ones is not None else None)
        assert item["maximum_absolute_error"] == 0 and item["absolute_tolerance"] == tolerance

    for role, source in (("first_product", "landsat"), ("second_product", "sentinel")):
        expected_product = reference["products"][source]
        actual = result["calibration_report"][role]
        assert actual["configuration"] == expected_product["configuration"]
        assert actual["product_id"] == expected_product["id"] and actual["product_key"] == expected_product["product_key"]
        for band in ("red", "nir"):
            value, expected_band = actual["bands"][band], expected_product["bands"][band]
            assert (value["source_code"], value["source_index"]) == (expected_band["code"], expected_band["index"])
            if source == "landsat":
                assert (value["scale"], value["offset"]) == (2.75e-5, -.2)
            else:
                assert (value["quantification"], value["dn_offset"]) == (10000, -1000)

    area = result["area_statistics"]
    actual = area["observed"]
    assert (area["relative_tolerance"], area["absolute_tolerance_m2"]) == (2e-7, .02)
    assert (actual["source_crs"], actual["area_crs"], actual["area_method"], actual["area_unit"],
            actual["cell_area_method"], actual["resampling"]) == (
        "EPSG:32632", "EPSG:6933", "equal_area", "square_meter", "projected_cell_boundary", "none",
    )
    assert actual["threshold"] == reference["change_threshold"] and actual["direction"] == reference["change_direction"]
    assert (actual["valid_pixel_count"], actual["selected_pixel_count"], actual["unselected_pixel_count"],
            actual["nodata_pixel_count"]) == (common, common, 0, fixture["masked_pixels"])
    assert actual["boundary_convergence"] == {"absolute_tolerance_m2": 1e-6, "relative_tolerance": 1e-8, "max_segments_per_edge_used": 8}
    assert {str(item["class_id"]): item["pixel_count"] for item in actual["classes"]} == fixture["valid_class_counts"]
    assert [item["class_name"] for item in actual["classes"]] == ["decrease", "stable", "increase"]
    observed = {str(item["class_id"]): item["area_m2"] for item in actual["classes"]}
    frozen = fixture["expected_area_m2"]
    errors = {}
    for key, value in observed.items():
        assert math.isclose(area["expected_area_by_class_m2"][key], frozen[key], abs_tol=2e-6, rel_tol=0)
        assert math.isclose(value, frozen[key], abs_tol=.02, rel_tol=2e-7)
        errors[key] = abs(value - frozen[key])
    assert math.isclose(actual["total_area_m2"], math.fsum(observed.values()), abs_tol=1e-6, rel_tol=0)
    total_ref = math.fsum(frozen.values())
    assert math.isclose(actual["total_area_m2"], total_ref, abs_tol=.02, rel_tol=2e-7)
    return {"pixels_by_class": fixture["valid_class_counts"], "nodata": fixture["masked_pixels"],
            "observed_area_m2": observed, "independent_area_m2": frozen, "absolute_error_m2": errors,
            "observed_total_m2": actual["total_area_m2"], "independent_total_m2": total_ref,
            "total_absolute_error_m2": abs(actual["total_area_m2"] - total_ref), "max_raster_absolute_error": 0.0}


def verify_terminal(row, expected_steps, params):
    state = row["run_state"]
    assert state["run_id"] == row["run_id"] and (state["execution_status"], state["check_status"]) == ("SUCCEEDED", "PASSED")
    assert state["current_report_id"] and not state["cancel_requested"] and not state["error"]
    doc = row["telemetry"]
    assert (doc["schema_version"], doc["run_id"], doc["execution_status"], doc["check_status"], doc["exit_code"]) == (
        1, row["run_id"], "SUCCEEDED", "PASSED", 0,
    )
    assert row["exit_code"] == 0
    for (key, tool, version), request, event, options in zip(expected_steps, row["executed_steps"], doc["steps"], params, strict=True):
        assert request["step_key"] == event["step_key"] == key
        assert request["tool"] == {"id": tool, "version": version} == {k: event["tool"][k] for k in ("id", "version")}
        assert request["parameters"] == options
        assert request["status"] == event["status"] == "SUCCEEDED" and request["exit_code"] == event["exit_code"] == 0
        process, = [item for item in event["processes"] if item["phase"] == "execute"]
        assert process["exit_code"] == 0 and not process["timed_out"] and not process["cancelled"]
    assert row["v1_completed_checks"] == CHECKS


def artifact_evidence(row, first, base_changes, fixture):
    remote = Path(row["workspace"])
    remote.relative_to(WORKSPACE_ROOT / row["cache"])
    work = ATTEMPT / remote.relative_to("/scratch")
    assert work.resolve().is_relative_to(ATTEMPT.resolve())
    manifest = work / "outputs/manifest.json"
    check_report = work / "checks/report.json"
    assert manifest.stat().st_size < 16384 and check_report.stat().st_size < 512 * 1024
    metadata = read(manifest)
    checks = read(check_report)
    assert (checks["run_id"], checks["report_id"], checks["status"], checks["completed_rules"]) == (
        row["run_id"], row["run_state"]["current_report_id"], "PASSED", CHECKS,
    )
    assert all(checks["rules"][name]["passed"] for name in CHECKS)
    expected = first["verified_file_groups"]
    assert set(metadata["artifacts"]) == set(expected) and len(expected) == 10
    total = 0
    fingerprints = {}
    for role, item in metadata["artifacts"].items():
        assert re.fullmatch(r"[0-9a-f]{64}", item["fingerprint"])
        path = work / item["path"]
        assert path.resolve().is_relative_to(work.resolve()) and path.is_file()
        assert metadata["tool_files"][item["path"]] == item["fingerprint"]
        size = path.stat().st_size
        assert size == expected[role]["bytes"] and item["fingerprint"] == expected[role]["file_group_sha256"]
        total += size
        fingerprints[role] = {"registered_file_group_sha256": item["fingerprint"], "bytes": size}
        if role in ("change_classes", "change_raster"):
            observed = digest(path.read_bytes())
            assert observed == (fixture["sha256"] if role == "change_classes" else base_changes)
            fingerprints[role]["actual_raw_sha256"] = observed
        elif role == "area_statistics":
            assert read(path) == row["correctness"]["area_statistics"]["observed"]
        elif role == "alignment_report":
            data = read(path)
            assert (data["common_valid_pixels"], data["resampling"]) == (fixture["masked_pixels"], "nearest")
    assert total == row["output_bytes"] == 5054589
    return {"registered_roles": fingerprints, "official_output_bytes": total,
            "output_manifest_sha256": digest(manifest.read_bytes()), "check_report_sha256": digest(check_report.read_bytes())}


BASE_ATTEMPT = ROOT / "remote-l/base/attempt.pr0gnzp2"
COLD_PROOF = Path("/tmp/geopilot-p13-05-remote-l-candidate-cold-audit.gk2ymt/independent.json")
COLD_PROOF_SHA = "e42d4b0b5be716e97301f9f325651210851d0c20534bdb57b26524bb19eef3a2"
CACHES = ("process_cold", "warm")
STATUSES = ("PASS", "FAIL", "NOT_RUN")
RECEIPT = "f290b7d264577770445efb0ad192777294df5e9f230050edff595c05ce2455b3"
COMPARISON_METRICS = ("wall_ns", "peak_rss_bytes", "peak_temp_bytes")
RUNNER = {
    "run_raster.py": "9a4a9bc061d770c1fce631895bff25f819751e5a98291440f231e5ed267a3729",
    "_raster_metrics.py": "d23eb107cd1ec19eb040ca391831d8028c4523ff783f09314fdc22e05057722e",
    "_raster_reference.py": "eb54e29bbee34e05952e699e4c9b4bc99f3f342ece30773280836eec02cb19a3",
    "_raster_workloads.py": "fa6bc12a43c93487c8159feb7fdf3529ac21b0bc0acaf436fe7a73591b54dd8d",
}


def verify_report(attempt, source, plan, historical_input):
    assert (attempt.parent / "COMPLETED").read_text().strip() == attempt.name
    disk, command = (attempt / "command.log").read_text().splitlines()
    args = shlex.split(command)
    assert disk.startswith("storage=/dev/sda2 ext4") and plan["image"] in args
    assert args[args.index("--source-commit") + 1] == source and args[args.index("--tiers") + 1] == "L"
    assert args[args.index("--cache") + 1:args.index("--cache") + 3] == list(CACHES)
    mount, = [args[i + 1] for i, item in enumerate(args) if item == "--mount" and ",dst=/inputs," in args[i + 1]]
    assert mount.endswith(",dst=/inputs,readonly")

    report_file = attempt / "evidence/report.json"
    receipt_file = attempt / "evidence/runtime-configuration.json"
    report, receipt = read(report_file), read(receipt_file)
    assert (report["mode"], report["environment"]["commit"], report["family"]) == ("formal", source, "remote_sensing")
    assert not report.get("error") and report["implementation_sha256"] == RUNNER
    assert re.sub(r"\[.*\]", "", report["environment"]["storage"]["mount_source_and_filesystem"]) == "/dev/sda2 ext4"
    assert set(report["inputs"]) == {"L"}
    inputs = report["inputs"]["L"]
    assert inputs["directory"] == "/inputs/L" and inputs["generation_ns"] is None
    assert inputs["manifest_sha256"] == MANIFEST and inputs["reference"] == historical_input["reference"]
    assert inputs["first_fingerprints"] == inputs["last_fingerprints"] == historical_input["first_fingerprints"] == historical_input["last_fingerprints"]
    assert receipt["schema_version"] == 1 and receipt["report_files"] == {"report.json": digest(report_file.read_bytes())}
    assert receipt["before"] == receipt["after"] and receipt["before"]["sha256"] == RECEIPT
    canonical = json.dumps({key: value for key, value in receipt["before"].items() if key != "sha256"},
                           ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False)
    assert digest(canonical.encode("ascii")) == RECEIPT
    return report, mount, {
        "report.json": digest(report_file.read_bytes()), "runtime-configuration.json": digest(receipt_file.read_bytes()),
    }


def measured_distributions(measured, expected_steps):
    columns = [metrics(row) for row in measured]
    result = {field: distribution([item[field] for item in columns]) for field in METRICS}
    steps = {}
    for index, (key, _, _) in enumerate(expected_steps):
        events = [row["telemetry"]["steps"][index] for row in measured]
        steps[key] = {
            "wall_ns": distribution([observe(event["wall_ns"]) for event in events]),
            **{field: distribution([event["resources"][field] for event in events]) for field in RESOURCES},
        }
    result["steps"] = steps
    return result


def group_counts(rows):
    count = Counter(row["status"] for row in rows)
    return {status: count[status] for status in STATUSES}


def groups_from_rows(report, rows, expected_steps):
    assert report["expected_groups"] == [{"tier": "L", "workload": "method", "cache": cache} for cache in CACHES]
    assert len(report["groups"]) == 2
    groups = {}
    for group, cache in zip(report["groups"], CACHES, strict=True):
        shard = [row for row in rows if row["cache"] == cache]
        warmups = [row for row in shard if row["kind"] == "warmup"]
        measured = [row for row in shard if row["kind"] == "measurement"]
        assert len(shard) == 7 and len(warmups) == 2 and len(measured) == 5
        assert len({row["worker_pid"] for row in shard}) == (7 if cache == "process_cold" else 1)
        assert (group["cache"], group["tier"], group["workload"], group["expected_trials"], group["observed_trials"],
                group["trial_failures"], group["interrupted"], group["warm_worker_exit"]) == (
            cache, "L", "method", 7, 7, group_counts(shard)["FAIL"], False, None if cache == "process_cold" else 0,
        )
        assert group["input_fingerprints_before"] == group["input_fingerprints_after"] == report["inputs"]["L"]["first_fingerprints"]
        counts = group_counts(measured)
        actual = group["operations"]["method"]
        assert (actual["passed"], actual["failed"], actual["missing"]) == (counts["PASS"], counts["FAIL"], 0)
        subset = {status: [row for row in measured if row["status"] == status] for status in ("PASS", "FAIL")}
        dist = {status: measured_distributions(selected, expected_steps) for status, selected in subset.items()}
        passing = dist["PASS"]
        if counts["PASS"] >= 3:
            wall = passing["wall_ns"]
            assert actual["wall_ns"] == {"median": wall["median"], "p95_nearest_rank": wall["p95"]}
            pixels = distribution([observe(row["pixels_per_second"]) for row in subset["PASS"]])
            assert actual["pixels_per_second"] == {"median": pixels["median"], "p95_nearest_rank": pixels["p95"]}
            sampled = [row["telemetry"]["resources"]["peak_rss_bytes"] for row in subset["PASS"]
                       if row["telemetry"]["resources"]["peak_rss_bytes"]["status"] == "sampled"]
            assert actual["sampled_peak_rss_count"] == len(sampled)
            summary = distribution(sampled)
            assert actual.get("peak_rss_bytes") == (
                {"median": summary["median"], "p95_nearest_rank": summary["p95"]} if len(sampled) >= 3 else None
            )
        else:
            assert set(actual) == {"passed", "failed", "missing"}
        codes = Counter()
        for row in subset["FAIL"]:
            err = row["run_state"].get("error") or row.get("error")
            codes[(err.get("code") if isinstance(err, dict) else None) or "unspecified"] += 1
        groups[cache] = {
            "warmup_counts": group_counts(warmups), "measurement_counts": counts, "failure_codes": dict(codes),
            "distributions": dist,
            "all_durable_success_measurements": measured_distributions(
                [row for row in measured if row["run_state"]["execution_status"] == "SUCCEEDED"], expected_steps,
            ),
        }
    return groups


def verify_side(attempt, source, plan, historical_input, historic, expected_steps, params, fixture, first, base_change):
    report, mount, file_hashes = verify_report(attempt, source, plan, historical_input)
    raw = (attempt / "evidence/trials.jsonl").read_bytes().splitlines(keepends=True)
    assert len(raw) == 14 and all(line.endswith(b"\n") for line in raw)
    file_hashes["trials.jsonl"] = digest(b"".join(raw))
    rows = [json.loads(line) for line in raw]
    assert [(row["cache"], row["index"]) for row in rows] == [(cache, i) for cache in CACHES for i in range(1, 8)]
    assert all(len({row[field] for row in rows}) == 14 for field in ("task_id", "plan_id", "run_id", "workspace"))
    failed = any(row["status"] == "FAIL" for row in rows)
    exit_code = int((attempt / "exit-code").read_text())
    assert exit_code == int(failed) and report["status"] == ("FAIL" if failed else "PASS")
    samples = []
    for row in rows:
        i, cache = row["index"], row["cache"]
        assert (row["kind"], row["sample_id"]) == (
            "warmup" if i <= 2 else "measurement", f"remote_sensing/L/method/{cache}/{i:02d}",
        )
        assert (row["family"], row["tier"], row["workload"], row["manifest_sha256"], row.get("worker_exit_code")) == (
            "remote_sensing", "L", "method", MANIFEST, 0 if cache == "process_cold" else None,
        )
        for key in ("method", "critical_options", "confirmed_parameters", "parameters_sha256", "source_input_bytes", "logical_source_input_bytes"):
            assert row[key] == historic[key]
        options = json.dumps(row["confirmed_parameters"], sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
        assert digest(options) == row["parameters_sha256"]
        errors = row.get("status_poll_errors", [])
        assert all(error == POLL_ERROR for error in errors)
        if row["run_state"]["execution_status"] == "SUCCEEDED":
            assert source == CANDIDATE
            verify_terminal(row, expected_steps, params)
            checked = correctness(row, fixture, historical_input["reference"])
            artifact = artifact_evidence(row, first, base_change, fixture)
            assert row["status"] == ("FAIL" if errors else "PASS")
            if errors:
                assert row["error"]["type"] == "StatusObservationFailure"
            else:
                assert not row.get("error")
        else:
            check_timeout(row, expected_steps, params)
            checked, artifact = None, None
        samples.append({
            "run_id": row["run_id"], "sample_id": row["sample_id"], "kind": row["kind"], "status": row["status"],
            "state": row["run_state"], "status_poll_errors": errors, "raw_error_type": (row.get("error") or {}).get("type"),
            "correctness": checked, "artifact_evidence": artifact, "steps": row["executed_steps"], "readings": metrics(row),
        })
    return {
        "attempt": str(attempt), "source": source, "container_exit": exit_code, "readonly_inputs": mount,
        "files": file_hashes, "cold_prefix_sha256": digest(b"".join(raw[:7])), "groups": groups_from_rows(report, rows, expected_steps),
        "status_poll_errors": sum(len(sample["status_poll_errors"]) for sample in samples), "samples": samples,
    }


def comparator_distribution(raw):
    return {"samples": raw["n"], "partial": raw["coverage"].get("partial", 0),
            "median": raw["median"], "p95_nearest_rank": raw["p95"]}


def check_comparison(path, before, after):
    prefix = path.stem
    assert path.with_name(prefix + ".exit-code").read_text().strip() == "0"
    assert path.with_name(prefix + ".stderr").read_bytes() == b""
    args = shlex.split(path.with_name(prefix + ".command").read_text())
    assert "--require-runtime-configuration" in args
    for label, side in (("before", before), ("after", after)):
        assert Path(args[args.index(f"--{label}") + 1]) == Path(side["attempt"]) / "evidence"
    compare = read(path)
    assert (compare["status"], compare["before_source"], compare["after_source"], compare["same_source"]) == (
        "MATCHED_EVIDENCE", before["source"], after["source"], before["source"] == after["source"],
    )
    assert compare["candidate_all_measurements_pass"] == all(
        after["groups"][cache]["measurement_counts"]["PASS"] == 5 for cache in CACHES
    )
    assert compare["runtime_configuration"] == {
        "level": "application_config_and_python_proj", "schema_version": 1, "sha256": RECEIPT,
    }
    assert len(compare["groups"]) == 2 and {g["group"][2] for g in compare["groups"]} == set(CACHES)
    for group in compare["groups"]:
        cache = group["group"][2]
        assert group["group"] == ["L", "method", cache, "p13-01", "method"]
        assert group["step_parameter_evidence"] == "normalized_step_requests"
        for label, side in (("before", before), ("after", after)):
            recorded = side["groups"][cache]
            assert group[label]["counts"] == recorded["measurement_counts"]
            assert group[label]["failure_codes"] == recorded["failure_codes"]
            for field in COMPARISON_METRICS:
                for status in ("PASS", "FAIL"):
                    assert group[label][field][status] == comparator_distribution(recorded["distributions"][status][field])
        deltas = {}
        for field in COMPARISON_METRICS:
            left, right = (group[label][field]["PASS"] for label in ("before", "after"))
            if left["samples"] == right["samples"] == group["before"]["counts"]["PASS"] == group["after"]["counts"]["PASS"] >= 3 and not (left["partial"] or right["partial"]):
                deltas[field] = {key: right[key] - left[key] for key in ("median", "p95_nearest_rank")}
        assert group["successful_sample_deltas"] == deltas
    return {"path": str(path), "sha256": digest(path.read_bytes()), "status": compare["status"],
            "successful_sample_deltas": {g["group"][2]: g["successful_sample_deltas"] for g in compare["groups"]}}


def main(commit, output):
    plan = read(ROOT / "plan.json")
    assert plan["commits"] == {"base": BASE, "candidate": CANDIDATE}
    assert plan["input_manifest_sha256"]["remote-l"] == MANIFEST and plan["disk"][:2] == ["/dev/sda2", "ext4"]
    fixture, first, first_archive_sha = frozen_refs(commit)
    historical, same = official_history()
    historic = same[0]
    historical_input = read(DOCS / "p13-04-remote-method-l-report.json")["inputs"]["L"]
    assert historical_input["manifest_sha256"] == MANIFEST
    expected_steps = [(step["step_key"], step["tool"]["id"], step["tool"]["version"]) for step in historic["telemetry"]["steps"]]
    sensors = {key: historic["confirmed_parameters"][key] for key in ("first_configuration", "second_configuration")}
    params = ({}, sensors, {}, {}, {}, {}, {"resampling": "nearest"}, {"change_threshold": .1, "area_crs": "EPSG:6933"})

    assert digest(BASE_PROOF.read_bytes()) == BASE_PROOF_SHA
    baseline = read(BASE_PROOF)
    base_changes = {item["sha256"] for item in baseline["staged_change_rasters"]}
    assert len(base_changes) == 1 and baseline["input_manifest_sha256"] == MANIFEST
    base_change = base_changes.pop()
    base, candidate = (
        verify_side(attempt, source, plan, historical_input, historic, expected_steps, params, fixture, first, base_change)
        for attempt, source in ((BASE_ATTEMPT, BASE), (ATTEMPT, CANDIDATE))
    )
    assert base["readonly_inputs"] == candidate["readonly_inputs"]
    for name, sha in base["files"].items():
        assert sha == baseline["files"][str(BASE_ATTEMPT / "evidence" / name)]
    assert base["cold_prefix_sha256"] == baseline["cold_prefix_sha256"]
    assert [row["run_id"] for row in base["samples"]] == [row["run_id"] for row in baseline["samples"]]
    for cache in CACHES:
        for field in METRICS:
            assert base["groups"][cache]["distributions"]["FAIL"][field] == baseline["groups"][cache]["failed_distributions"][field]

    assert digest(COLD_PROOF.read_bytes()) == COLD_PROOF_SHA
    previous = read(COLD_PROOF)
    assert candidate["cold_prefix_sha256"] == previous["cold_prefix_sha256"]
    assert candidate["samples"][:7] == previous["samples"]
    assert candidate["groups"]["process_cold"]["distributions"] == previous["distributions"]
    for left, right in zip(base["samples"], candidate["samples"], strict=True):
        assert [{k: s[k] for k in ("step_key", "tool", "parameters")} for s in left["steps"]] == [
            {k: s[k] for k in ("step_key", "tool", "parameters")} for s in right["steps"]
        ]
    ids = [row["run_id"] for side in (base, candidate) for row in side["samples"]]
    identity = prior_ids(historical, ids)
    assert identity.pop("current_cold") == 28 and identity["combined_unique"] == 240
    identity["remote_l_pair"] = 28

    for side in (base, candidate):
        side["self_comparison"] = check_comparison(Path(side["attempt"]) / "self-comparison.json", side, side)
    pair_path, = (ROOT / "remote-l").glob("pair.*/before-after.json")
    pair = check_comparison(pair_path, base, candidate)
    assert pair["successful_sample_deltas"] == {cache: {} for cache in CACHES}
    result = {
        "scope": "completed remote L frozen pair only", "input_manifest_sha256": MANIFEST,
        "runtime_configuration_sha256": RECEIPT, "first_candidate_archive_sha256": first_archive_sha,
        "cold_prefixes_verified": True, "identity": identity, "pair": pair, "base": base, "candidate": candidate,
    }
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    for label, side in (("base", base), ("candidate", candidate)):
        print(label, "exit", side["container_exit"], "status read errors", side["status_poll_errors"],
              "durable outcomes", dict(Counter(f"{row['state']['execution_status']}/{row['state']['check_status']}" for row in side["samples"])))
        for cache, group in side["groups"].items():
            print(label, cache, "warmups", group["warmup_counts"], "formal", group["measurement_counts"], group["failure_codes"])
            for status, data in group["distributions"].items():
                print(status, "wall", data["wall_ns"], "RSS", data["peak_rss_bytes"], "temp", data["peak_temp_bytes"])
                print(status, "change step", data["steps"][FINAL_STEP]["wall_ns"], "step RSS", data["steps"][FINAL_STEP]["peak_rss_bytes"])
    print("candidate first verified area", candidate["samples"][0]["correctness"])
    print("strict pair", pair, "unique IDs", identity)


if __name__ == "__main__":
    main(sys.argv[1], Path(sys.argv[2]))
