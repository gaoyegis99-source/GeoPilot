"""Verify the complete frozen DEM L original evidence without a running database."""

from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys

from replay import checked_attempt, compare, read_json


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def main(root):
    proof = root / "proof"
    verifier = runpy.run_path(str(proof / "run-raster-pairs.py"))
    profile, tier, _, expected_hash = verifier["CASES"]["dem-l"]
    family = profile.replace("-", "_")
    manifest_path = proof / "input-manifest.json"
    assert digest(manifest_path) == expected_hash
    manifest = read_json(manifest_path)
    assert (manifest["family"], manifest["tier"]) == (family, tier)
    files = {
        record["role"]: {key: record[key] for key in ("path", "bytes", "sha256")}
        for record in manifest["files"]
    }
    assert len(files) == len(manifest["files"])
    attempt, evidence = checked_attempt(root / "dem-l", "base", verifier, (None, family, tier, expected_hash, files))
    assert (attempt / "exit-code").read_text().strip() == "1"
    assert (attempt / "self-comparison.exit-code").read_text().strip() == "0"
    assert not (attempt / "self-comparison.stderr").read_bytes()
    comparator = proof / "run_memory_profile.py"
    assert digest(comparator) == verifier["COMPARATOR"]
    replay = compare(comparator, evidence, evidence)
    assert replay == (attempt / "self-comparison.json").read_bytes()
    report = json.loads(replay)
    assert report["status"] == "MATCHED_EVIDENCE" and not report["candidate_all_measurements_pass"]

    fixtures = root / "fixtures"
    reference = next(item for item in read_json(fixtures / "manifest.json")["fixtures"] if item["id"] == "dem-l")
    assert reference["source"]["fixture_manifest_sha256"] == expected_hash
    assert digest(fixtures / reference["path"]) == reference["sha256"]
    cold = read_json(proof / "cold-summary.json")
    raw = (evidence / "trials.jsonl").read_bytes().splitlines(keepends=True)
    assert sha256(b"".join(raw[:7])).hexdigest() == cold["samples_sha256"]
    for line in raw:
        row = json.loads(line)
        error = row["run_state"]["error"]
        assert (row["status"], error["code"], error["step_key"], error["message"]) == (
            "FAIL", "PROCESS_TIMEOUT", "calculate_area_with_equal_area_projection", "Process exceeded 60 seconds",
        )
        assert (row["run_state"]["execution_status"], row["run_state"]["check_status"]) == ("FAILED", "NOT_CHECKED")
        assert len(row["executed_steps"]) == 7
        assert all((step["status"], step["exit_code"]) == ("SUCCEEDED", 0) for step in row["executed_steps"][:-1])
        assert row["executed_steps"][-1]["exit_code"] == -15
        assert "correctness" not in row and not row.get("v1_completed_checks")
        run = attempt / Path(row["workspace"]).relative_to("/scratch")
        assert run.resolve(strict=True) == run and run.is_relative_to(attempt) and run.name == row["run_id"]
        request = read_json(run / "steps/extract_by_threshold/request.json")
        relative = reference["source"]["run_relative_path"]
        assert request["run_id"] == row["run_id"]
        assert request["output_targets"]["threshold_regions"]["path"] == relative
        assert (run / relative).stat().st_size == reference["bytes"] and digest(run / relative) == reference["sha256"]
    print("Fourteen complete original rows, preserved cold prefix, and unpublished threshold rasters verified.")
    print("Frozen strict self-comparison reproduces byte-for-byte, 0 successful measurements.")


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve(strict=True))
