import ast
import hashlib
import json
import runpy
import shlex
import shutil
import subprocess
import sys
import tarfile
from collections import Counter
from pathlib import Path
from types import SimpleNamespace


REPOSITORY = Path(sys.argv[1]).resolve()
OUTPUT = Path(sys.argv[2]).resolve()
PERFORMANCE = REPOSITORY / "docs/round2/performance"
BUNDLE = Path(__file__).resolve().parent
FROZEN = BUNDLE / "frozen"
SOURCE_FILES = ["scripts/bench/run_with_runtime_configuration.py", "scripts/bench/run_raster.py",
                "scripts/bench/_raster_workloads.py", "scripts/bench/_raster_metrics.py",
                "src/geopilot/api/app.py", "src/geopilot/runs/query_service.py", "src/geopilot/persistence/schema.py"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def member(archive, name):
    data = archive.extractfile(name)
    with data:
        return data.read()


def archive_records(file, prefix):
    with tarfile.open(file) as tar:
        files = [name for name in tar.getnames() if name.startswith(prefix) and name.endswith("/evidence/trials.jsonl")]
        for path in files:
            directory = path.rsplit("/", 1)[0]
            rows = [json.loads(raw) for raw in member(tar, path).splitlines()]
            report = json.loads(member(tar, f"{directory}/report.json"))
            receipt_path = f"{directory}/runtime-configuration.json"
            receipt = json.loads(member(tar, receipt_path)) if receipt_path in tar.getnames() else None
            groups = Counter()
            errors = []
            for row in rows:
                state = row.get("run_state") or {}
                service_code = (state.get("error") or {}).get("code")
                response_errors = row.get("status_poll_errors", [])
                error_kind = (row.get("error") or {}).get("type")
                if service_code:
                    category = service_code
                elif row["status"] == "PASS":
                    category = "PASS"
                elif (state.get("execution_status"), state.get("check_status")) == ("SUCCEEDED", "PASSED") and row.get("correctness") and error_kind == "StatusObservationFailure":
                    category = "verified_GIS_success_with_observation_failure"
                elif row.get("stop_group") and "Three consecutive run status GET requests failed" in (row.get("error") or {}).get("message", ""):
                    category = "observation_abort_without_terminal_in_trial"
                else:
                    category = "other_or_unresolved"
                groups[category] += 1
                if response_errors:
                    errors.append({"sample_id": row["sample_id"], "category": category, "failures": len(response_errors),
                                   "http": [item["http_status"] for item in response_errors],
                                   "entries_with_elapsed": sum("elapsed_ns" in item for item in response_errors),
                                   "cancel_status": (row.get("cancellation") or {}).get("http_status"),
                                   "worker_exit_code": row.get("worker_exit_code"), "last_run_state": state})
            yield {"archive": file.name, "member": path, "archive_sha256": sha(file.read_bytes()),
                   "report_status": report["status"], "report_groups": [
                       {key: group[key] for key in ("cache", "observed_trials", "expected_trials", "interrupted")}
                       for group in report["groups"]], "receipt_bound_files": sorted(receipt["report_files"]) if receipt else None,
                   "rows": len(rows), "categories": dict(groups), "status_errors": errors}


def function(path, name, namespace):
    src = ast.parse(path.read_text(), filename=str(path))
    selected = next(node for node in src.body if isinstance(node, ast.FunctionDef) and node.name == name)
    exec(compile(ast.Module(body=[selected], type_ignores=[]), str(path), "exec"), namespace)
    return namespace[name]


def show_chronology_is_lost():
    clock = SimpleNamespace(monotonic=lambda: 0, sleep=lambda duration: None)
    poll = function(FROZEN / "scripts/bench/_raster_workloads.py", "_terminal_state", {"time": clock})
    busy = {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}}
    running = {"run_id": "fixture", "execution_status": "RUNNING", "check_status": "NOT_CHECKED"}
    success = {"run_id": "fixture", "execution_status": "SUCCEEDED", "check_status": "PASSED"}

    def run(sequence):
        responses = iter(sequence)

        def get(_):
            data = next(responses)
            return SimpleNamespace(status_code=500 if data is busy else 200, json=lambda: data, text=json.dumps(data))

        trial = {}
        assert poll(SimpleNamespace(get=get), "/api/runs/fixture", trial, 1) == success
        assert next(responses, None) is None
        return trial

    separate = [busy, running, busy, running, busy, success]
    clustered = [busy, busy, running, busy, running, success]
    trial = run(separate)
    assert trial == run(clustered) and len(trial["status_poll_errors"]) == 3
    return {"first_http_sequence": [500, 200, 500, 200, 500, 200],
            "second_http_sequence": [500, 500, 200, 500, 200, 200], "identical_trial": trial}


def verify_receipt_boundary():
    archive_path = PERFORMANCE / "p13-05-remote-l-base-evidence.tar.gz"
    digest_before = sha(archive_path.read_bytes())
    isolated = OUTPUT / "closed-remote-l"
    isolated.mkdir()
    with tarfile.open(archive_path) as archive:
        archive.extractall(isolated, filter="data")
    verifier = runpy.run_path(str(isolated / "proof/run-raster-pairs.py"))
    proof = isolated / "proof"
    manifest_bytes = (proof / "input-manifest.json").read_bytes()
    profile, tier, _, expected_hash = verifier["CASES"]["remote-l"]
    assert sha(manifest_bytes) == expected_hash
    manifest = json.loads(manifest_bytes)
    files = {record["role"]: {key: record[key] for key in ("path", "bytes", "sha256")} for record in manifest["files"]}
    contract = (None, profile.replace("-", "_"), tier, expected_hash, files)
    side = isolated / "remote-l/base"
    attempt = side / (side / "COMPLETED").read_text().strip()
    original = verifier["verify_attempt"](attempt, "base", contract)
    modified_attempt = OUTPUT / "mutated-copy" / attempt.name
    shutil.copytree(attempt, modified_attempt)
    raw = modified_attempt / "evidence/trials.jsonl"
    old_bytes = raw.read_bytes()
    records = [json.loads(line) for line in old_bytes.splitlines()]
    changed = next(row for row in records if (row["run_state"]["error"] or {}).get("code") == "PROCESS_TIMEOUT" and row.get("status_poll_errors"))
    removed = changed.pop("status_poll_errors")
    raw.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in records))
    edited = verifier["verify_attempt"](modified_attempt, "base", contract)

    comparator = proof / "run_memory_profile.py"
    assert sha(comparator.read_bytes()) == verifier["COMPARATOR"]

    def compare(left, right):
        command = [sys.executable, "-B", str(comparator), "--kind", "raster", "--require-runtime-configuration",
                   "--before", str(left), "--after", str(right)]
        process = subprocess.run(command, capture_output=True, check=True)
        assert not process.stderr
        return process.stdout, shlex.join(command)

    original_comparison, baseline_command = compare(original, original)
    edited_comparison, edited_command = compare(original, edited)
    assert original_comparison == (attempt / "self-comparison.json").read_bytes() == edited_comparison
    receipt = json.loads((original / "runtime-configuration.json").read_bytes())
    assert receipt["report_files"] == {"report.json": sha((original / "report.json").read_bytes())}
    assert (original / "runtime-configuration.json").read_bytes() == (edited / "runtime-configuration.json").read_bytes()
    assert sha(archive_path.read_bytes()) == digest_before
    (OUTPUT / "strict-original.json").write_bytes(original_comparison)
    (OUTPUT / "strict-edited-copy.json").write_bytes(edited_comparison)
    return {"source_archive": archive_path.name, "source_archive_sha256": digest_before, "changed_sample": changed["sample_id"],
            "kept_run_error": changed["run_state"]["error"]["code"], "removed_status_errors": removed,
            "original_raw_sha256": sha(old_bytes), "edited_raw_sha256": sha(raw.read_bytes()),
            "receipt_bound_files": sorted(receipt["report_files"]), "both_verified": True,
            "comparison_byte_equal": True, "comparison_sha256": sha(edited_comparison),
            "strict_commands": [baseline_command, edited_command], "strict_exit_codes": [0, 0]}


source_command = (BUNDLE / "active-launch-command.snapshot").read_bytes()
(OUTPUT / "active-launch-command.snapshot").write_bytes(source_command)
tokens = shlex.split(source_command.decode().splitlines()[1])
assert tokens[0:2] == ["docker", "run"] and tokens[tokens.index("--name") + 1] == "geopilot-p1305-dem-m-base-spcasn8d"
assert tokens[tokens.index("--source-commit") + 1] == "977ab412d9f6e7558d22a5c431fac0ada90b07be"
assert any(token.endswith("/base,dst=/project,readonly") for token in tokens)
assert "run_status_read_failed" not in (FROZEN / "src/geopilot/api/app.py").read_text()
assert "elapsed_ns" not in (FROZEN / "scripts/bench/_raster_workloads.py").read_text()
assert "elapsed_ns" in (REPOSITORY / "scripts/bench/_raster_workloads.py").read_text()
assert '"GEOPILOT_TELEMETRY": "1"' in (FROZEN / "scripts/bench/_raster_metrics.py").read_text()

archives = []
for suffix, prefix in [("dem-m-incomplete", "./dem-m/"), ("remote-s-rerun", "./remote-s/"), ("remote-l-pair", "./remote-l/")]:
    archives.extend(archive_records(PERFORMANCE / f"p13-05-{suffix}-evidence.tar.gz", prefix))
assert len(archives) == 6 and all(error["entries_with_elapsed"] == 0 for archive in archives for error in archive["status_errors"])
chronology = show_chronology_is_lost()
receipt = verify_receipt_boundary()
report = {"active_launch_command_sha256": sha(source_command),
          "frozen_source_sha256": {path: sha((FROZEN / path).read_bytes()) for path in SOURCE_FILES},
          "archives": archives, "same_raw_for_distinct_request_chronology": chronology, "raw_receipt_boundary": receipt}
(OUTPUT / "review.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
for row in archives:
    print(row["member"], row["rows"], row["categories"], "status_http_errors",
          sum(error["failures"] for error in row["status_errors"]), "receipt_bound", row["receipt_bound_files"])
print("Distinct poll sequences produce identical frozen trial fields", chronology["first_http_sequence"], chronology["second_http_sequence"])
print("Frozen verifier and strict comparison are unchanged after removal of", len(receipt["removed_status_errors"]),
      "status failure(s) in", receipt["changed_sample"], "on an isolated copy")
