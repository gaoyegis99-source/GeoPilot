#!/bin/bash
set -o pipefail
geo_poll_evidence="$1"
phase="$2"
expression="$3"
env PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 TMPDIR=/dev/shm \
  nice -n 19 ionice -c3 taskset -c 31 .venv/bin/python -B -m pytest -q -p no:cacheprovider \
  tests/benchmarks/test_run_raster.py -k "$expression" \
  --junitxml="$geo_poll_evidence/$phase.xml" 2>&1 | tee "$geo_poll_evidence/$phase.log"
status=${PIPESTATUS[0]}
printf '%s\n' "$status" > "$geo_poll_evidence/$phase.exit"
exit "$status"
