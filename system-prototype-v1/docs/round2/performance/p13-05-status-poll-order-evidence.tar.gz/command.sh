#!/usr/bin/env bash
set -o pipefail
repository=/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1
proof=/dev/shm/geopilot-p13-dem-retry-observation.tici5HpP
"$repository/.venv/bin/python" -B "$proof/offline.py" "$repository" "$proof" 2>&1 | tee "$proof/offline.log"
result=$?
printf '%s\n' "$result" > "$proof/exit-code"
exit "$result"
