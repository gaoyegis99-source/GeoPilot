from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
import sys


def load(path):
    return json.loads(path.read_bytes())


def attempt(case, side):
    root = case / side
    return root / (root / "COMPLETED").read_text().strip()


def readings(rows, status, field):
    values = [row[field] for row in rows if row["status"] == status]
    return {"median": median(values), "p95": max(values)}


def main(bundle, sealed_cold, reference_path):
    case = bundle / "dem-m"
    base, candidate = (attempt(case, side) for side in ("base", "candidate"))
    baseline_raw, candidate_raw = ((path / "evidence/trials.jsonl").read_bytes() for path in (base, candidate))
    assert b"".join(baseline_raw.splitlines(keepends=True)[:7]) == (sealed_cold / "cold-trials.jsonl").read_bytes()
    reference = load(reference_path)
    original = [json.loads(line) for line in baseline_raw.splitlines()]
    revised = [json.loads(line) for line in candidate_raw.splitlines()]
    assert len(original) == len(revised) == 14
    for row in original:
        state = row["run_state"]
        assert (row["status"], state["execution_status"], state["check_status"]) == ("FAIL", "FAILED", "NOT_CHECKED")
        assert state["error"]["code"] == "PROCESS_TIMEOUT" and not row.get("status_poll_errors")
        steps = row["executed_steps"]
        assert [item["exit_code"] for item in steps] == [0] * 6 + [-15]
        assert steps[-1]["step_key"] == "calculate_area_with_equal_area_projection"
        file = base / Path(row["workspace"]).relative_to("/scratch") / "intermediate/extract_by_threshold/threshold_regions.tif"
        assert sha256(file.read_bytes()).hexdigest() == reference["sha256"]
    for row in revised:
        state = row["run_state"]
        assert (state["execution_status"], state["check_status"]) == ("SUCCEEDED", "PASSED")
        assert row["correctness"] and all(item["exit_code"] == 0 for item in row["executed_steps"])
        if row["status"] == "FAIL":
            assert row["error"]["type"] == "StatusObservationFailure" and row["status_poll_errors"]
    output = {}
    for cache in ("process_cold", "warm"):
        measured_base, measured_candidate = ([row for row in group if row["cache"] == cache and row["kind"] == "measurement"]
                                              for group in (original, revised))
        assert len(measured_base) == len(measured_candidate) == 5
        output[cache] = {
            "base_failure_wall_ns": readings(measured_base, "FAIL", "wall_ns"),
            "candidate_success_wall_ns": readings(measured_candidate, "PASS", "wall_ns"),
            "candidate_benchmark_counts": dict(Counter(row["status"] for row in measured_candidate)),
            "base_rss_coverage": dict(Counter(row["telemetry"]["resources"]["peak_rss_bytes"]["status"] for row in measured_base)),
        }
    print(json.dumps({
        "base_sha256": sha256(baseline_raw).hexdigest(),
        "candidate_sha256": sha256(candidate_raw).hexdigest(),
        "base_timeout": len(original),
        "base_classification_matches": len(original),
        "base_status_errors": 0,
        "candidate_passed_checks": len(revised),
        "candidate_status_observation_trials": sum(row["status"] == "FAIL" for row in revised),
        "groups": output,
    }, indent=2))


if __name__ == "__main__":
    main(*(Path(argument) for argument in sys.argv[1:]))
