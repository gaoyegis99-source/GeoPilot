"""Check the sealed DEM M candidate before the original side finishes."""

from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys

from replay import checked_attempt, compare, read_json


def main(directory):
    proof = directory / "proof"
    verifier = runpy.run_path(str(proof / "run-raster-pairs.py"))
    profile, tier, _, expected_hash = verifier["CASES"]["dem-m"]
    family = profile.replace("-", "_")
    manifest_path = proof / "input-manifest.json"
    assert sha256(manifest_path.read_bytes()).hexdigest() == expected_hash
    manifest = read_json(manifest_path)
    assert (manifest["family"], manifest["tier"]) == (family, tier)
    files = {
        record["role"]: {key: record[key] for key in ("path", "bytes", "sha256")}
        for record in manifest["files"]
    }
    assert len(files) == len(manifest["files"])
    contract = (None, family, tier, expected_hash, files)
    attempt, evidence = checked_attempt(directory / "dem-m", "candidate", verifier, contract)
    assert (attempt / "self-comparison.exit-code").read_text().strip() == "0"
    assert not (attempt / "self-comparison.stderr").read_bytes()
    comparator = proof / "run_memory_profile.py"
    assert sha256(comparator.read_bytes()).hexdigest() == verifier["COMPARATOR"]
    observed = compare(comparator, evidence, evidence)
    assert observed == (attempt / "self-comparison.json").read_bytes()
    document = json.loads(observed)
    assert document["status"] == "MATCHED_EVIDENCE" and not document["candidate_all_measurements_pass"]
    cold = read_json(proof / "cold-prefix.json")
    first_seven = b"".join((evidence / "trials.jsonl").read_bytes().splitlines(keepends=True)[:7])
    assert cold["prefix_sha256"] == sha256(first_seven).hexdigest()
    print("Fourteen DEM M candidate trials and the cold prefix match the sealed reports.")
    print("Strict self-comparison reproduces byte-for-byte.")


if __name__ == "__main__":
    main(Path(sys.argv[1]))
