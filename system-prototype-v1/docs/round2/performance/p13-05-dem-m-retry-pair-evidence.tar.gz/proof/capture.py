from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import sys

live, bundle = (Path(arg).resolve() for arg in sys.argv[1:])
case = bundle / "dem-m"
base_name = (live / "base/COMPLETED").read_text().strip()
assert base_name == "attempt.spcasn8d"
source = live / "base" / base_name
target = case / "base" / base_name
name = (live / "candidate/COMPLETED").read_text().strip()
assert name == (case / "candidate/COMPLETED").read_text().strip() == "attempt.f0puyhqd"
for filename in ("report.json", "trials.jsonl", "runtime-configuration.json"):
    member = Path("candidate") / name / "evidence" / filename
    assert (live / member).read_bytes() == (case / member).read_bytes()

def capture(origin, files):
    for filename in files:
        output = case / origin.relative_to(live) / filename
        output.parent.mkdir(parents=True, exist_ok=True)
        copyfile(origin / filename, output)

capture(live / "base", ("COMPLETED",))
capture(source, (
    "command.log", "container-name", "container.log", "exit-code",
    "self-comparison.command", "self-comparison.exit-code", "self-comparison.json", "self-comparison.stderr",
    "evidence/report.json", "evidence/runtime-configuration.json", "evidence/trials.jsonl",
))
pair, = [path for path in live.glob("pair.*") if (path / "before-after.json").is_file()]
capture(pair, ("before-after.command", "before-after.exit-code", "before-after.json", "before-after.stderr"))
rows = [json.loads(line) for line in (target / "evidence/trials.jsonl").read_bytes().splitlines()]
assert len(rows) == 14
for row in rows:
    workspace = Path(row["workspace"]).relative_to("/scratch")
    members = [workspace / "intermediate/extract_by_threshold/threshold_regions.tif",
               workspace / "steps/extract_by_threshold/request.json"]
    for name in members:
        assert (source / name).resolve().is_relative_to(source)
    capture(source, members)
for path in sorted(source.glob("evidence/samples/M/method/**/worker.log")):
    capture(source, (path.relative_to(source),))
print(pair.name, "raw rows sha256", sha256((target / "evidence/trials.jsonl").read_bytes()).hexdigest())
