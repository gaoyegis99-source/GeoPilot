"""Check production-server warning output using only a disposable SQLite project."""

from datetime import UTC, datetime
from hashlib import sha256
import json
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import tempfile
import time
from urllib.error import HTTPError
from urllib.request import urlopen

from geopilot.domain.step_io import ExecutionStatus
from geopilot.persistence.run_repository import insert_run
from geopilot.persistence.schema import initialize_database, open_database
from geopilot.runs.models import Run


def get(url):
    try:
        response = urlopen(url, timeout=12)
    except HTTPError as error:
        response = error
    with response:
        return response.status, json.load(response)


def wait_for_socket(server, log):
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline and server.poll() is None:
        match = re.search(r"Uvicorn running on (http://127\.0\.0\.1:\d+)", log.read_text())
        if match:
            return match[1]
        time.sleep(0.05)
    raise RuntimeError("Loopback GeoPilot server did not start")


def seed_database(path, workspace):
    initialize_database(path)
    with open_database(path) as connection, connection:
        connection.execute("INSERT INTO task VALUES ('task', '{}', NULL, '2026-11-12')")
        connection.execute("INSERT INTO analysis_plan VALUES ('plan', 1, 'task', 'confirmed', '{}', '2026-11-12')")
        insert_run(connection, Run(
            id="terminal-probe", plan_id="plan", plan_version=1,
            workdir=str(workspace / "terminal-probe"), created_at=datetime(2026, 11, 12, tzinfo=UTC),
            execution_status=ExecutionStatus.SUCCEEDED,
        ))


def main(output):
    log = output / "server.log"
    expected_failure = 500, {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}}
    with tempfile.TemporaryDirectory(prefix="geopilot-status-socket-", dir="/dev/shm") as directory:
        root = Path(directory)
        database = root / "project.sqlite"
        workspace = root / "workspace"
        seed_database(database, workspace)
        with log.open("wb") as stream:
            server = subprocess.Popen([
                sys.executable, "-B", "-m", "geopilot.api.server", "--database", str(database),
                "--workspace", str(workspace), "--port", "0",
            ], stdout=stream, stderr=subprocess.STDOUT)
            try:
                endpoint = wait_for_socket(server, log) + "/api/runs/"
                initial = get(endpoint + "terminal-probe")
                assert initial[0] == 200 and initial[1]["execution_status"] == "SUCCEEDED"
                with open_database(database) as writer, writer:
                    assert writer.execute("PRAGMA journal_mode").fetchone()[0] == "delete"
                    writer.execute("BEGIN EXCLUSIVE")
                    assert get(endpoint + "terminal-probe") == expected_failure
                assert get(endpoint + "terminal-probe") == initial
                assert get(endpoint + "absent")[0] == 404
                with open_database(database) as writer, writer:
                    writer.execute("UPDATE run SET error_json = ?", (json.dumps({"message": "private-fixture-sentinel"}),))
                assert get(endpoint + "terminal-probe") == expected_failure
            finally:
                server.terminate()
                try:
                    server.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    server.kill()
                    server.wait(timeout=5)
                    raise
        raw = log.read_text()
        assert "Application shutdown complete." in raw
        assert "private-fixture-sentinel" not in raw
        events = [json.loads(line) for line in raw.splitlines() if line.startswith('{"event": "run_status_read_failed"')]
        sqlite_event, validation_event = events
        assert sqlite_event.pop("elapsed_ms") >= 4_000
        assert validation_event.pop("elapsed_ms") >= 0
        assert sqlite_event == {
            "event": "run_status_read_failed", "error_kind": "sqlite",
            "sqlite_primary_code": sqlite3.SQLITE_BUSY, "sqlite_extended_code": sqlite3.SQLITE_BUSY,
        }
        assert validation_event == {"event": "run_status_read_failed", "error_kind": "state_validation"}
        print(json.dumps({
            "http_status_sequence": [200, 500, 200, 404, 500],
            "sqlite_version": sqlite3.sqlite_version, "server_exit": server.returncode,
            "server_log_sha256": sha256(log.read_bytes()).hexdigest(),
            "diagnostic_events": [json.loads(line) for line in raw.splitlines() if line.startswith('{"event": "run_status_read_failed"')],
        }, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]))
