"""Read-only independent S raster method comparison audit."""

from hashlib import sha256
import json
import math
import re
from pathlib import Path
import shlex
from statistics import median
import sys


REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
ROOT = REPO / "artifacts/test-results/p13-05-raster-pairs.a2d2e68.TONYtP"
ARCHIVE = REPO / "docs/round2/performance"
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
CANDIDATE = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
CASES = {
    "dem-s": ("raster", "raster-method-s", {"7": 259956}, 144, 7),
    "remote-s": ("remote_sensing", "remote-method-sm", {"1": 6144, "2": 6144, "3": 6144}, 18432, 8),
}
CACHES = ("process_cold", "warm")
METRICS = ("wall_ns", "peak_rss_bytes", "peak_temp_bytes")
PASS = {"PASS": 5, "FAIL": 0, "NOT_RUN": 0}
RUNNER = {
    "run_raster.py": "9a4a9bc061d770c1fce631895bff25f819751e5a98291440f231e5ed267a3729",
    "_raster_metrics.py": "d23eb107cd1ec19eb040ca391831d8028c4523ff783f09314fdc22e05057722e",
    "_raster_reference.py": "eb54e29bbee34e05952e699e4c9b4bc99f3f342ece30773280836eec02cb19a3",
    "_raster_workloads.py": "fa6bc12a43c93487c8159feb7fdf3529ac21b0bc0acaf436fe7a73591b54dd8d",
}
IMAGE = "sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87"


def read(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream]


def digest(raw):
    return sha256(raw).hexdigest()


def stats(values):
    ordered = sorted(values)
    return {"median": median(ordered), "p95_nearest_rank": ordered[math.ceil(.95 * len(ordered)) - 1]} if len(ordered) >= 3 else None


def dist(items):
    values = [i["value"] for i in items if i.get("value") is not None]
    return {
        "samples": len(values), "partial": sum(i.get("status") == "partial" and i.get("value") is not None for i in items),
        **(stats(values) or {"median": None, "p95_nearest_rank": None}),
    }


def area_check(observed, reference, class_counts, nodata, remote):
    assert set(observed) == set(reference)
    area = observed["area_statistics"]
    independent = reference["area_statistics"]
    expected = independent["expected_area_by_class_m2"]
    assert area["expected_area_by_class_m2"] == expected
    assert area["relative_tolerance"] == independent["relative_tolerance"] == 2e-7
    assert area["absolute_tolerance_m2"] == independent["absolute_tolerance_m2"] == .02
    value = area["observed"]
    classes = {str(row["class_id"]): row for row in value["classes"]}
    assert len(classes) == len(value["classes"]) == len(class_counts)
    assert {code: row["pixel_count"] for code, row in classes.items()} == class_counts
    assert value["valid_pixel_count"] == value["selected_pixel_count"] == sum(class_counts.values())
    assert value["unselected_pixel_count"] == 0 and value["nodata_pixel_count"] == nodata
    assert (value["area_crs"], value["area_method"], value["area_unit"], value["cell_area_method"], value["resampling"]) == (
        "EPSG:6933", "equal_area", "square_meter", "projected_cell_boundary", "none",
    )
    assert value["source_crs"] == independent["observed"]["source_crs"]
    if remote:
        assert value["threshold"] == .1 and value["direction"] == "second_minus_first"
        assert [classes[str(i)]["class_name"] for i in (1, 2, 3)] == ["decrease", "stable", "increase"]
    errors = {}
    for code, item in classes.items():
        error = abs(item["area_m2"] - expected[code])
        assert math.isclose(item["area_m2"], expected[code], rel_tol=2e-7, abs_tol=.02)
        errors[code] = error
    assert math.isclose(value["total_area_m2"], math.fsum(expected.values()), rel_tol=2e-7, abs_tol=.02)
    assert math.isclose(value["total_area_m2"], math.fsum(item["area_m2"] for item in classes.values()),
                        rel_tol=1e-14, abs_tol=1e-7)
    for key in observed.keys() - {"area_statistics"}:
        actual, earlier = observed[key], reference[key]
        if "maximum_absolute_error" not in actual:
            assert actual == earlier, key
            continue
        assert actual["absolute_tolerance"] == earlier["absolute_tolerance"]
        assert actual["maximum_absolute_error"] <= actual["absolute_tolerance"]
        for name in actual.keys() - {"maximum_absolute_error", "file_bytes"}:
            assert actual[name] == earlier[name], (key, name)
    return {
        "class_counts": class_counts, "nodata": nodata, "total_area_m2": value["total_area_m2"],
        "area_by_class_m2": {code: item["area_m2"] for code, item in classes.items()},
        "independent_area_m2": expected, "abs_error_by_class_m2": errors,
        "total_abs_error_m2": abs(value["total_area_m2"] - math.fsum(expected.values())),
        "boundary_convergence": value["boundary_convergence"],
        "raster_max_abs_error": max(item.get("maximum_absolute_error", 0) for item in observed.values()),
    }


def historic_evidence(case):
    _, historic_name, _, _, _ = CASES[case]
    archive_report = read(ARCHIVE / f"p13-04-{historic_name}-report.json")
    archive_trials = ARCHIVE / f"p13-04-{historic_name}-trials.jsonl"
    return archive_report, next(row for row in jsonl(archive_trials) if row["tier"] == "S")


def trial_identity(row, case, manifest, historic):
    family = CASES[case][0]
    index = row["index"]
    assert row["sample_id"] == f"{family}/S/method/{row['cache']}/{index:02d}"
    assert (row["family"], row["tier"], row["workload"], row["kind"], row["manifest_sha256"]) == (
        family, "S", "method", "warmup" if index <= 2 else "measurement", manifest,
    )
    assert row["method"] == historic["method"] and row["critical_options"] == historic["critical_options"]
    assert row["parameters_sha256"] == digest(json.dumps(
        row["confirmed_parameters"], sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode())
    assert row["run_state"]["run_id"] == row["run_id"]


def completed_output(row, historic, case):
    family, _, class_counts, nodata, nsteps = CASES[case]
    state, sidecar = row["run_state"], row["telemetry"]
    assert row["exit_code"] == 0
    assert (state["execution_status"], state["check_status"]) == ("SUCCEEDED", "PASSED")
    assert state["current_report_id"] and not state["error"] and not state["cancel_requested"]
    assert (sidecar["run_id"], sidecar["execution_status"], sidecar["check_status"], sidecar["exit_code"]) == (
        row["run_id"], "SUCCEEDED", "PASSED", 0,
    )
    steps = row["executed_steps"]
    assert len(steps) == len(sidecar["steps"]) == nsteps and len({s["step_key"] for s in steps}) == nsteps
    for raw, event in zip(steps, sidecar["steps"]):
        assert raw["status"] == event["status"] == "SUCCEEDED" and raw["exit_code"] == event["exit_code"] == 0
        assert raw["step_key"] == event["step_key"]
        assert raw["tool"] == {key: event["tool"][key] for key in ("id", "version")}
        assert isinstance(raw["parameters"], dict)
    assert [s["step_key"] for s in steps] == [s["step_key"] for s in historic["telemetry"]["steps"]]
    assert row["v1_completed_checks"] == historic["v1_completed_checks"]
    settings = {key: row[key] for key in ("method", "critical_options", "confirmed_parameters", "executed_steps")}
    area = area_check(row["correctness"], historic["correctness"], class_counts, nodata, family == "remote_sensing")
    return settings, area


def environment_check(path, report):
    assert report["implementation_sha256"] == RUNNER
    storage = report["environment"]["storage"]["mount_source_and_filesystem"]
    assert re.sub(r"\[.*\]", "", storage) == "/dev/sda2 ext4"
    command = path.parent / "command.log"
    assert IMAGE in shlex.split(command.read_text().splitlines()[1])


def validate_side(path, commit, case):
    family = CASES[case][0]
    archive_report, historic = historic_evidence(case)
    report_file = path / "report.json"
    report = read(report_file)
    environment_check(path, report)
    receipt = read(path / "runtime-configuration.json")
    assert report["mode"] == "formal" and report["status"] == "PASS" and not report.get("error"), path
    assert report["environment"]["commit"] == commit and report["family"] == family, path
    assert (path.parent / "exit-code").read_text().strip() == (path.parent / "self-comparison.exit-code").read_text().strip() == "0"
    assert (path.parent.parent / "COMPLETED").read_text().strip() == path.parent.name
    assert receipt["schema_version"] == 1 and receipt["report_files"] == {"report.json": digest(report_file.read_bytes())}
    snapshot = receipt["before"]
    assert snapshot == receipt["after"]
    assert snapshot["sha256"] == digest(json.dumps(
        {k: v for k, v in snapshot.items() if k != "sha256"},
        ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode("ascii"))
    current, old = report["inputs"]["S"], archive_report["inputs"]["S"]
    assert set(report["inputs"]) == {"S"} and current["directory"] == "/inputs/S" and current["generation_ns"] is None
    assert current["manifest_sha256"] == old["manifest_sha256"]
    assert current["first_fingerprints"] == current["last_fingerprints"] == old["first_fingerprints"] == old["last_fingerprints"]
    trials_file = path / "trials.jsonl"
    rows = jsonl(trials_file)
    assert len(rows) == len({row["run_id"] for row in rows}) == 14
    assert {(row["cache"], row["index"]) for row in rows} == {(cache, i) for cache in CACHES for i in range(1, 8)}
    areas, settings = [], []
    for row in rows:
        trial_identity(row, case, current["manifest_sha256"], historic)
        assert row["status"] == "PASS" and not row.get("status_poll_errors")
        assert row.get("worker_exit_code") == (0 if row["cache"] == "process_cold" else None)
        options, area = completed_output(row, historic, case)
        settings.append(options)
        areas.append(area)
    assert all(item == settings[0] for item in settings), path
    assert all(item == areas[0] for item in areas), path

    groups, per_step = {}, {}
    planned = [{"tier": "S", "workload": "method", "cache": cache} for cache in CACHES]
    assert report["expected_groups"] == planned and len(report["groups"]) == 2
    for cache in CACHES:
        raw = [r for r in rows if r["cache"] == cache]
        assert len({r["worker_pid"] for r in raw}) == (7 if cache == "process_cold" else 1)
        assert len({r["plan_id"] for r in raw}) == len({r["task_id"] for r in raw}) == 7
        measured = [r for r in raw if r["kind"] == "measurement"]
        assert len(measured) == 5 and sum(r["kind"] == "warmup" for r in raw) == 2
        group = next(g for g in report["groups"] if g["cache"] == cache)
        assert (group["tier"], group["workload"], group["expected_trials"], group["observed_trials"], group["trial_failures"]) == (
            "S", "method", 7, 7, 0,
        )
        assert not group["interrupted"] and group["warm_worker_exit"] == (0 if cache == "warm" else None)
        assert group["input_fingerprints_before"] == group["input_fingerprints_after"] == current["first_fingerprints"]
        aggregate = group["operations"]["method"]
        assert (aggregate["passed"], aggregate["failed"], aggregate["missing"]) == (5, 0, 0)
        assert aggregate["wall_ns"] == stats([r["wall_ns"] for r in measured])
        assert aggregate["pixels_per_second"] == stats([r["pixels_per_second"] for r in measured])
        rss = [r["telemetry"]["resources"]["peak_rss_bytes"] for r in measured]
        sampled = [i["value"] for i in rss if i["status"] == "sampled" and i["value"] is not None]
        assert aggregate["sampled_peak_rss_count"] == len(sampled)
        assert aggregate.get("peak_rss_bytes") == stats(sampled)
        groups[cache] = {
            "wall_ns": dist([{"status": "recorded", "value": r["wall_ns"]} for r in measured]),
            "peak_rss_bytes": dist(rss),
            "peak_temp_bytes": dist([r["workspace_size"]["peak_temp_bytes"] for r in measured]),
        }
        per_step[cache] = {}
        for step in settings[0]["executed_steps"]:
            key = step["step_key"]
            events = [next(t for t in r["telemetry"]["steps"] if t["step_key"] == key) for r in measured]
            per_step[cache][key] = {
                "wall_ns": stats([item["wall_ns"] for item in events]),
                "peak_rss_bytes": dist([item["resources"]["peak_rss_bytes"] for item in events]),
            }
    return {"evidence": str(path), "run_ids": [r["run_id"] for r in rows], "receipt": snapshot["sha256"],
            "input_manifest_sha256": current["manifest_sha256"], "settings": settings[0], "area": areas[0],
            "files": {item.name: digest(item.read_bytes()) for item in (report_file, trials_file, path / "runtime-configuration.json")},
            "groups": groups, "steps": per_step, "status_poll_errors": sum(len(r.get("status_poll_errors", [])) for r in rows)}


def audit_pair(case, path):
    assert path.with_name("before-after.exit-code").read_text().strip() == "0"
    command = shlex.split(path.with_name("before-after.command").read_text())
    before, after = (Path(command[command.index(flag) + 1]) for flag in ("--before", "--after"))
    d = read(path)
    assert (d["status"], d["before_source"], d["after_source"], d["candidate_all_measurements_pass"]) == (
        "MATCHED_EVIDENCE", BASE, CANDIDATE, True,
    )
    a, b = validate_side(before, BASE, case), validate_side(after, CANDIDATE, case)
    assert len(set(a["run_ids"] + b["run_ids"])) == 28
    assert a["receipt"] == b["receipt"] == d["runtime_configuration"]["sha256"]
    assert a["input_manifest_sha256"] == b["input_manifest_sha256"] and a["settings"] == b["settings"]
    for cache in CACHES:
        group = next(g for g in d["groups"] if g["group"] == ["S", "method", cache, "p13-01", "method"])
        assert group["step_parameter_evidence"] == "normalized_step_requests"
        delta = {}
        for side, observed in (("before", a), ("after", b)):
            assert group[side]["counts"] == PASS and group[side]["failure_codes"] == {}
            for metric in METRICS:
                assert group[side][metric]["PASS"] == observed["groups"][cache][metric], (case, cache, side, metric)
                assert group[side][metric]["FAIL"] == dist([])
        for metric in METRICS:
            x, y = a["groups"][cache][metric], b["groups"][cache][metric]
            if x["samples"] == y["samples"] == 5 and not (x["partial"] or y["partial"]):
                delta[metric] = {key: y[key] - x[key] for key in ("median", "p95_nearest_rank")}
        assert group["successful_sample_deltas"] == delta, (case, cache, delta)
    return {"result": str(path), "result_sha256": digest(path.read_bytes()), "base": a, "candidate": b}


def audit_interrupted_remote(case, path, candidate):
    assert case == "remote-s"
    archive_report, historic = historic_evidence(case)
    report_file, trials_file = path / "report.json", path / "trials.jsonl"
    report = read(report_file)
    environment_check(path, report)
    attempt = path.parent
    assert (attempt / "exit-code").read_text().strip() == "1"
    assert "no receipt: The benchmark has no complete formal report" in (attempt / "container.log").read_text()
    assert not (path / "runtime-configuration.json").exists()
    assert not (attempt / "self-comparison.exit-code").exists()
    assert not (attempt.parent / "COMPLETED").exists()
    assert not list(attempt.parent.parent.glob("pair.*/before-after.*"))
    assert (report["environment"]["commit"], report["family"], report["mode"], report["status"]) == (
        BASE, "remote_sensing", "formal", "FAIL",
    )
    assert report["error"]["message"] == "Benchmark worker stopped without a reliable terminal observation"
    current, old = report["inputs"]["S"], archive_report["inputs"]["S"]
    assert current["manifest_sha256"] == old["manifest_sha256"] == candidate["input_manifest_sha256"]
    assert current["first_fingerprints"] == current["last_fingerprints"] == old["first_fingerprints"] == old["last_fingerprints"]
    assert report["expected_groups"] == [{"tier": "S", "workload": "method", "cache": cache} for cache in CACHES]
    group, = report["groups"]
    assert (group["cache"], group["tier"], group["workload"], group["expected_trials"], group["observed_trials"],
            group["interrupted"], group["trial_failures"]) == ("process_cold", "S", "method", 7, 5, True, 3)
    assert group["input_fingerprints_before"] == group["input_fingerprints_after"] == current["first_fingerprints"]
    assert group["operations"]["method"] == {"passed": 1, "failed": 2, "missing": 2}
    rows = jsonl(trials_file)
    assert len(rows) == len({row["run_id"] for row in rows}) == len({row["worker_pid"] for row in rows}) == 5
    assert [(row["cache"], row["index"], row["status"]) for row in rows] == [
        ("process_cold", i, status) for i, status in enumerate(("PASS", "FAIL", "FAIL", "PASS", "FAIL"), 1)
    ]
    observations = []
    for row in rows:
        trial_identity(row, case, current["manifest_sha256"], historic)
        assert row["worker_exit_code"] == 0
        count = len(row.get("status_poll_errors", []))
        assert count == {2: 2, 3: 2, 5: 5}.get(row["index"], 0)
        assert all(item == {"http_status": 500, "body": {"detail": {
            "code": "STORAGE_FAILED", "message": "Could not read the run record."
        }}} for item in row.get("status_poll_errors", []))
        state = row["run_state"]
        observation = {
            "sample_id": row["sample_id"], "kind": row["kind"], "run_id": row["run_id"], "status": row["status"],
            "wall_ns": row["wall_ns"], "worker_exit_code": row["worker_exit_code"], "poll_errors": row.get("status_poll_errors", []),
            "observed_execution_status": state["execution_status"], "observed_check_status": state["check_status"],
            "error_type": (row.get("error") or {}).get("type"), "cancel": row.get("cancellation"),
            "executed_step_count": len(row.get("executed_steps", [])),
        }
        if row["index"] < 5:
            assert observation["error_type"] == ("StatusObservationFailure" if count else None)
            settings, area = completed_output(row, historic, case)
            assert settings == candidate["settings"] and area == candidate["area"]
            observation["area"] = area
        else:
            assert observation["error_type"] == "RuntimeError"
            assert row["error"]["message"] == "Three consecutive run status GET requests failed with STORAGE_FAILED"
            assert (state["execution_status"], state["check_status"]) == ("RUNNING", "NOT_CHECKED")
            assert row["stop_group"] and row["exit_code"] is None
            assert all(key not in row for key in ("executed_steps", "correctness", "telemetry"))
            cancellation = row["cancellation"]
            assert cancellation["http_status"] == 202
            ack = json.loads(cancellation["body"])
            assert (ack["run_id"], ack["execution_status"], ack["check_status"], ack["cancel_requested"]) == (
                row["run_id"], "RUNNING", "NOT_CHECKED", True,
            )
        observations.append(observation)
    print("remote-s baseline incomplete", path)
    print("remote-s baseline 5 attempted / 14 planned, 4 observed SUCCEEDED/PASSED, 1 terminal unknown,",
          sum(len(obs["poll_errors"]) for obs in observations), "HTTP 500 status reads")
    print("remote-s baseline formal cold PASS/FAIL/missing = 1/2/2, warm = 0/0/5; strict comparison not produced")
    for obs in observations:
        print("remote-s baseline", obs["sample_id"], obs["run_id"], obs["status"], obs["error_type"],
              obs["observed_execution_status"], obs["observed_check_status"], "polls", len(obs["poll_errors"]),
              "steps", obs["executed_step_count"])
    return {
        "evidence": str(path), "run_ids": [r["run_id"] for r in rows], "observations": observations,
        "files": {item.name: digest(item.read_bytes()) for item in (report_file, trials_file, attempt / "container.log")},
        "cold_counts": group["operations"]["method"], "warm_counts": {"passed": 0, "failed": 0, "missing": 5},
        "runtime_configuration": None, "strict_pair_result": None, "successful_sample_deltas": None,
    }


plan = read(ROOT / "plan.json")
assert plan["commits"] == {"base": BASE, "candidate": CANDIDATE}
assert plan["image"] == IMAGE and plan["disk"][:2] == ["/dev/sda2", "ext4"]
output = {}
for case in CASES:
    paths = [p for p in sorted((ROOT / case).glob("pair.*/before-after.json")) if p.with_name("before-after.exit-code").is_file()]
    if not paths:
        sides = {}
        for side, source in (("base", BASE), ("candidate", CANDIDATE)):
            marker = ROOT / case / side / "COMPLETED"
            if marker.is_file():
                result = validate_side(marker.parent / marker.read_text().strip() / "evidence", source, case)
                print(case, side, "single side verified PASS", result["evidence"])
                sides[side] = result
        if case == "remote-s" and "candidate" in sides and "base" not in sides:
            failed = list((ROOT / case / "base").glob("attempt.*/exit-code"))
            if failed:
                assert len(failed) == 1
                sides["base"] = audit_interrupted_remote(case, failed[0].parent / "evidence", sides["candidate"])
                output[case] = {"result": None, "comparison_status": "not_produced", **sides}
                print("remote-s candidate area", sides["candidate"]["area"])
                for cache in CACHES:
                    print("remote-s candidate", cache, sides["candidate"]["groups"][cache])
        continue
    assert len(paths) == 1, paths
    result = audit_pair(case, paths[0])
    output[case] = result
    print(case, "28 PASS, paired report and raw statistics agree", result["result"])
    for cache in CACHES:
        left, right = (result[side]["groups"][cache] for side in ("base", "candidate"))
        fmt = lambda key, scale: " → ".join(f"{item[key]['median']/scale:.3f}/{item[key]['p95_nearest_rank']/scale:.3f}" for item in (left, right))
        print(cache, "wall s median/P95", fmt("wall_ns", 1e9), "RSS MiB median/P95", fmt("peak_rss_bytes", 2**20),
              "RSS partial", left["peak_rss_bytes"]["partial"], right["peak_rss_bytes"]["partial"],
              "temp MiB median/P95", fmt("peak_temp_bytes", 2**20),
              "temp partial", left["peak_temp_bytes"]["partial"], right["peak_temp_bytes"]["partial"])
    print("area base/candidate", [result[side]["area"] for side in ("base", "candidate")])
all_ids = [rid for case in output.values() for side in ("base", "candidate") for rid in case[side]["run_ids"]]
assert len(all_ids) == len(set(all_ids)) == 47
assert all(data["candidate"]["input_manifest_sha256"] == plan["input_manifest_sha256"][case] for case, data in output.items())
Path(sys.argv[1]).write_text(json.dumps(output, indent=2) + "\n")
print("verified observed unique run IDs", len(all_ids))
