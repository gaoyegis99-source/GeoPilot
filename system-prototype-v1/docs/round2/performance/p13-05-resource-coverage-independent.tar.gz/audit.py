"""Recompute ten completed pairs solely from a specified Git tree."""
from collections import Counter
from hashlib import sha256
from io import BytesIO
import json
import math
from pathlib import Path, PurePosixPath
import re
from statistics import median
import subprocess
import sys
import tarfile

DOC = "system-prototype-v1/docs/round2/performance"
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
CANDIDATE = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
CONFIG = "f290b7d264577770445efb0ad192777294df5e9f230050edff595c05ce2455b3"
CACHES = ("process_cold", "warm")
STATUSES = ("PASS", "FAIL", "NOT_RUN")
METRICS = ("wall_ns", "peak_rss_bytes", "peak_temp_bytes")
POLLS = {"http_status": 500, "body": {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}}}
CASES = [
    ("M", "t13-points-intersects", "vector-m-revised", "vector-m-revised", "vector"),
    ("M", "t13-lines-within", "vector-m-revised", "vector-m-revised", "vector"),
    ("M", "t14-split_by_area", "vector-m-revised", "vector-m-revised", "vector"),
    ("M", "road", "vector-m-revised", "vector-m-revised", "vector"),
    ("L", "t13-points-intersects", "vector-l-point", "vector-l-point", "vector"),
    ("L", "t13-lines-intersects", "vector-l-line", "vector-l-line", "vector"),
    ("L", "t14-split_by_area", "vector-l-area", "vector-l-area", "vector"),
    ("S", "dem-s", "raster-s", "raster-s", "raster"),
    ("S", "remote-s", "remote-s-rerun", "remote-s-rerun", "raster"),
    ("L", "dem-l", "dem-l", "dem-l-pair", "raster"),
]


def digest(raw):
    return sha256(raw).hexdigest()


def git(commit, name):
    return subprocess.check_output(["git", "show", f"{commit}:{DOC}/{name}"])


class Evidence:
    def __init__(self, raw):
        self.archive_sha256 = digest(raw)
        self.archive = tarfile.open(fileobj=BytesIO(raw), mode="r:gz")
        self.entries = {}
        for member in self.archive.getmembers():
            if not member.isfile():
                continue
            path = str(PurePosixPath(member.name))
            assert not path.startswith("/") and ".." not in PurePosixPath(path).parts
            assert path not in self.entries
            self.entries[path] = member
        self.seals = {}
        if "SHA256SUMS" in self.entries:
            for row in self.bytes("SHA256SUMS").decode().splitlines():
                expected, path = row.split(maxsplit=1)
                self.seals[str(PurePosixPath(path))] = expected

    def bytes(self, path):
        member = self.entries[path]
        with self.archive.extractfile(member) as stream:
            return stream.read()

    def sealed(self, path):
        raw = self.bytes(path)
        if self.seals:
            assert digest(raw) == self.seals[path], path
        return raw

    def json(self, path):
        return json.loads(self.sealed(path))

    def under(self, root, suffix):
        return sorted(path for path in self.entries if path.startswith(root + "/") and path.endswith(suffix))


def counter(rows):
    counts = Counter(row["status"] for row in rows)
    return {s: counts[s] for s in STATUSES}


def failure(row, kind):
    state = row["run_status" if kind == "vector" else "run_state"]
    error = state.get("error") or row.get("error")
    return (error.get("code") if isinstance(error, dict) else row.get("reason")) or "unspecified"


def metric(row, kind, key):
    if key == "wall_ns":
        return {"status": "recorded", "value": row["wall_ns"]}
    if key == "peak_rss_bytes":
        tele = row["telemetry"]["document"] if kind == "vector" else row["telemetry"]
        return tele["resources"][key]
    return (row if kind == "vector" else row["workspace_size"])[key]


def distribution(readings):
    values = sorted(item["value"] for item in readings if item["value"] is not None)
    return {
        "samples": len(values),
        "partial": sum(item["status"] == "partial" and item["value"] is not None for item in readings),
        "median": median(values) if len(values) >= 3 else None,
        "p95_nearest_rank": values[math.ceil(.95 * len(values)) - 1] if len(values) >= 3 else None,
    }


def group_summary(rows, kind):
    measured = [row for row in rows if row["phase" if kind == "vector" else "kind"] == "measurement"]
    assert len(rows) == 7 and len(measured) == 5
    result = {
        "counts": counter(measured),
        "failure_codes": dict(Counter(failure(row, kind) for row in measured if row["status"] == "FAIL")),
    }
    for key in METRICS:
        result[key] = {s: distribution([metric(row, kind, key) for row in measured if row["status"] == s])
                       for s in ("PASS", "FAIL")}
    return result


def comparison_deltas(before, after):
    deltas = {}
    for key in METRICS:
        a, b = before[key]["PASS"], after[key]["PASS"]
        n = before["counts"]["PASS"]
        if n >= 3 and a["samples"] == b["samples"] == n == after["counts"]["PASS"] and not (a["partial"] or b["partial"]):
            deltas[key] = {q: b[q] - a[q] for q in ("median", "p95_nearest_rank")}
    return deltas


def check_receipt(archive, root, kind):
    receipt = archive.json(root + "/runtime-configuration.json")
    names = ("summary.json", "environment.json") if kind == "vector" else ("report.json",)
    assert receipt["schema_version"] == 1
    assert receipt["report_files"] == {name: digest(archive.sealed(root + "/" + name)) for name in names}
    snap = receipt["before"]
    assert snap == receipt["after"] and snap["sha256"] == CONFIG
    content = {key: value for key, value in snap.items() if key != "sha256"}
    canonical = json.dumps(content, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("ascii")
    assert digest(canonical) == CONFIG


def archived_side(archive, workload, tier, side, kind):
    parent = f"{workload}/{side}"
    attempt = archive.sealed(parent + "/COMPLETED").decode().strip()
    assert re.fullmatch(r"attempt\.[a-z0-9A-Z_]+", attempt)
    root = f"{parent}/{attempt}/evidence"
    source = BASE if side == "base" else CANDIDATE
    check_receipt(archive, root, kind)
    raw = archive.sealed(root + ("/samples.jsonl" if kind == "vector" else "/trials.jsonl"))
    rows = [json.loads(line) for line in raw.splitlines()]
    assert len(rows) == len({row["run_id"] for row in rows}) == 14
    assert all(row["tier"] == tier and row["status"] in {"PASS", "FAIL"} for row in rows)
    if kind == "vector":
        assert [(row["cache"], row["phase"], row["repeat"]) for row in rows] == [
            (cache, phase, i) for cache in CACHES for phase, n in (("warmup", 2), ("measurement", 5))
            for i in range(1, n + 1)
        ]
        inputs = archive.json(root + "/inputs.json")[tier]
        assert archive.json(root + "/environment.json")["source_commit"] == source
        report = archive.json(root + "/summary.json")
        assert not report["probe"] and report["sample_counts"] == counter(rows)
        assert report["status"] == ("INCOMPLETE" if any(row["status"] == "FAIL" for row in rows) else "PASS")
        assert inputs["files_before"] == inputs["files_after"]
        manifest = inputs["input_manifest_sha256"]
        assert all(row["workload"] == workload and row["input_manifest_sha256"] == manifest for row in rows)
        fingerprints = inputs["files_before"]
        exit_file = f"{parent}/{attempt}/container-exit"
    else:
        assert [(row["cache"], row["kind"], row["index"]) for row in rows] == [
            (cache, "warmup" if i <= 2 else "measurement", i) for cache in CACHES for i in range(1, 8)
        ]
        report = archive.json(root + "/report.json")
        assert report["environment"]["commit"] == source and report["mode"] == "formal" and not report.get("error")
        assert report["status"] == ("FAIL" if any(row["status"] == "FAIL" for row in rows) else "PASS")
        inputs = report["inputs"][tier]
        assert inputs["first_fingerprints"] == inputs["last_fingerprints"]
        manifest = inputs["manifest_sha256"]
        assert all(row["manifest_sha256"] == manifest for row in rows)
        fingerprints = inputs["first_fingerprints"]
        exit_file = f"{parent}/{attempt}/exit-code"
    assert int(archive.sealed(exit_file)) == int(any(row["status"] == "FAIL" for row in rows))
    assert len(report["groups"]) == 2
    for group, cache in zip(report["groups"], CACHES, strict=True):
        assert group["cache"] == cache
        group_rows = [row for row in rows if row["cache"] == cache]
        c = group_summary(group_rows, kind)["counts"]
        if kind == "vector":
            assert {s: group[f"measured_{s.lower()}"] for s in STATUSES} == c
        else:
            assert (group["expected_trials"], group["observed_trials"], group["interrupted"]) == (7, 7, False)
            assert group["trial_failures"] == sum(row["status"] == "FAIL" for row in group_rows)
            assert group["operations"]["method"]["passed"] == c["PASS"]
            assert group["operations"]["method"]["failed"] == c["FAIL"]
            assert group["operations"]["method"]["missing"] == 0
    return rows, manifest, fingerprints, digest(raw), root


def step_keys(row, kind):
    steps = row["steps" if kind == "vector" else "executed_steps"]
    return [(s.get("key") or s.get("step_key"), s["status"], s["exit_code"]) for s in steps]


def check_terminal(row, kind):
    state = row["run_status" if kind == "vector" else "run_state"]
    assert state["run_id"] == row["run_id"] and not state["cancel_requested"]
    steps = step_keys(row, kind)
    if (state["execution_status"], state["check_status"]) == ("SUCCEEDED", "PASSED"):
        assert all(code == 0 and status == "SUCCEEDED" for _, status, code in steps)
        assert row.get("correctness")
        if row["status"] == "FAIL":
            assert kind == "raster" and row["error"]["type"] == "StatusObservationFailure"
            assert row["status_poll_errors"] and all(item == POLLS for item in row["status_poll_errors"])
        return "artifact_correctness_verified"
    assert (state["execution_status"], state["check_status"]) == ("FAILED", "NOT_CHECKED")
    assert row["status"] == "FAIL" and not row.get("correctness")
    error = state["error"]
    assert (error["code"], error["phase"], error["message"]) == ("PROCESS_TIMEOUT", "execute", "Process exceeded 60 seconds")
    failed, = [i for i, (key, status, code) in enumerate(steps) if (status, code) == ("FAILED", -15) and key == error["step_key"]]
    assert all((status, code) == ("SUCCEEDED", 0) for _, status, code in steps[:failed])
    assert all((status, code) == ("NOT_STARTED", None) for _, status, code in steps[failed + 1:])
    return "timeout:" + error["step_key"]


def vector_reference(row, workload, reference):
    expected = reference["reference"]
    value = row["correctness"]
    assert row["checks"]["rules"] and all(row["checks"]["rules"].values())
    tiles = expected["side_tiles"]**2
    if workload.startswith("t13"):
        _, layer, predicate = workload.split("-")
        item = expected["t13"]["relations"][predicate][layer]
        assert value == {
            "selected": item["count"], "clipped": item["count"], "retained_line_length_m": item["retained_line_length_m"],
            "retained_area_m2": item["retained_area_m2"],
        }
        assert set(row["artifacts"]) == {"clipped_targets", "original_targets"}
    elif workload == "t14-split_by_area":
        item = expected["t14"]
        method = item["methods"]["split_by_area"]
        assert value == {
            "selected": item["selected_rows"], "clipped": sum(item["clipped_rows_per_id_per_tile"].values()) * tiles,
            "counts": method["counts"], "areas_m2": method["areas_m2"],
            "allocation_rows": len(method["details_per_tile"]) * tiles, "zones": expected["layer_counts"]["t14.gpkg"]["zones"],
        }
        assert set(row["artifacts"]) == {"clipped_targets", "original_targets", "allocation_details", "zone_statistics"}
    else:
        road = expected["road"]
        match = road["relations"]["intersects"]
        assert {key: value[key] for key in ("road_candidates", "targets_before_clip", "targets_after_clip", "counts")} == {
            "road_candidates": len(road["candidate_road_ids"]) * tiles,
            "targets_before_clip": len(match["before_clip_target_ids"]) * tiles,
            "targets_after_clip": len(match["clipped_target_ids"]) * tiles, "counts": match["total_counts"],
        }
        tolerances = road["main_road_buffer"]["absolute_tolerances"]
        buffer = value["buffer"]
        for actual, limit in (("max_bounds_error_m", "bounds_m"), ("max_area_error_m2", "area_m2"),
                              ("max_boundary_hausdorff_m", "boundary_hausdorff_m")):
            assert 0 <= buffer[actual] <= tolerances[limit]
        assert set(row["artifacts"]) == {"buffer_extent", "selected_targets", "zone_statistics"}


def raster_reference(row, reference):
    assert row["v1_completed_checks"]
    result, old = row["correctness"], reference["correctness"]
    assert set(result) == set(old)
    for key, actual in result.items():
        expected = old[key]
        if key == "area_statistics":
            observed = actual["observed"]
            frozen = expected["expected_area_by_class_m2"]
            rel, absolute = actual["relative_tolerance"], actual["absolute_tolerance_m2"]
            assert actual["expected_area_by_class_m2"] == frozen and (rel, absolute) == (2e-7, .02)
            rows = observed["classes"]
            assert [(r["class_id"], r["pixel_count"]) for r in rows] == [
                (r["class_id"], r["pixel_count"]) for r in expected["observed"]["classes"]
            ]
            assert all(math.isclose(r["area_m2"], frozen[str(r["class_id"])], rel_tol=rel, abs_tol=absolute) for r in rows)
            assert math.isclose(observed["total_area_m2"], sum(frozen.values()), rel_tol=rel, abs_tol=absolute)
            for field in ("source_crs", "area_crs", "valid_pixel_count", "selected_pixel_count", "nodata_pixel_count"):
                assert observed[field] == expected["observed"][field]
        elif "maximum_absolute_error" in actual:
            assert actual["maximum_absolute_error"] <= actual["absolute_tolerance"] == expected["absolute_tolerance"]
            for field in ("width", "height", "transform", "crs", "valid_pixels_by_band", "masked_pixels_by_band"):
                assert actual[field] == expected[field]
        else:
            assert actual == expected


def comparison_object(archive, workload, wrapper, comparison_name, kind):
    pair_file, = archive.under(workload, "/result.json" if kind == "vector" else "/before-after.json")
    root = pair_file.rsplit("/", 1)[0]
    if kind == "vector":
        if root + "/stderr.log" in archive.entries:
            assert archive.sealed(root + "/stderr.log") == b""
    else:
        assert archive.sealed(root + "/before-after.stderr") == b""
        assert archive.sealed(root + "/before-after.exit-code").strip() == b"0"
    pair = archive.json(pair_file)
    if comparison_name == "vector-m-revised":
        item, = [item for item in wrapper["workloads"] if item["workload"] == workload]
        assert item["comparison"] == pair_file and item["groups"] == pair["groups"]
        return pair, item
    if comparison_name == "raster-s":
        item = wrapper["cases"][workload]
        assert item["comparison"] == pair
        return pair, item
    assert pair == wrapper
    return pair, {}


def executed(row, kind):
    entries = row["steps" if kind == "vector" else "executed_steps"]
    return {item.get("key") or item.get("step_key"): (item["tool"], item["parameters"])
            for item in entries if item["status"] != "NOT_STARTED"}


def check_options(sides, kind):
    canonical = sides["before"][0]
    for row in sides["before"] + sides["after"]:
        assert row["method"] == canonical["method"] and row["critical_options"] == canonical["critical_options"]
        if kind == "raster":
            assert row["confirmed_parameters"] == canonical["confirmed_parameters"]
            payload = json.dumps(row["confirmed_parameters"], sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
            assert row["parameters_sha256"] == digest(payload)
    for before, after in zip(sides["before"], sides["after"], strict=True):
        left, right = executed(before, kind), executed(after, kind)
        assert left and right and all(left[key] == right[key] for key in left.keys() & right.keys())


def check_group(before, after, comparison, tier, workload, cache, kind):
    expected_key = [tier, workload, cache, "p13-01"] if kind == "vector" else [tier, "method", cache, "p13-01", "method"]
    assert comparison["group"] == expected_key
    if kind == "raster":
        assert comparison["step_parameter_evidence"] == "normalized_step_requests"
    assert comparison["before"] == before and comparison["after"] == after
    changes = comparison_deltas(before, after)
    assert comparison["successful_sample_deltas"] == changes
    return {"before": before, "after": after, "successful_sample_deltas": changes,
            "rss_successful_change_applicable": "peak_rss_bytes" in changes}


def main(commit, output):
    archives = {}
    comparators = {}
    references = {}
    audits = []
    identities = []
    for tier, workload, comp, archive, kind in CASES:
        if archive not in archives:
            archives[archive] = Evidence(git(commit, f"p13-05-{archive}-evidence.tar.gz"))
        evidence = archives[archive]
        if comp not in comparators:
            comparators[comp] = json.loads(git(commit, f"p13-05-{comp}-comparison.json"))
        pair, wrapper = comparison_object(evidence, workload, comparators[comp], comp, kind)
        assert (pair["status"], pair["before_source"], pair["after_source"], pair["same_source"]) == ("MATCHED_EVIDENCE", BASE, CANDIDATE, False)
        assert pair["runtime_configuration"]["sha256"] == CONFIG
        sides = {}
        outputs = {}
        for name, side in (("before", "base"), ("after", "candidate")):
            rows, manifest, fingerprints, raw_sha, root = archived_side(evidence, workload, tier, side, kind)
            identities.extend(row["run_id"] for row in rows)
            sides[name] = rows
            outcomes = Counter()
            for row in rows:
                status = check_terminal(row, kind)
                outcomes[status] += 1
                if status != "artifact_correctness_verified":
                    continue
                if kind == "vector":
                    key = f"p13-03-{tier}-input-manifest.json"
                    if key not in references:
                        raw = git(commit, key)
                        references[key] = (json.loads(raw), digest(raw))
                    ref, ref_hash = references[key]
                    assert manifest == ref_hash
                    vector_reference(row, workload, ref)
                else:
                    key = "p13-04-raster-method-s-trials.jsonl" if workload == "dem-s" else "p13-04-remote-method-sm-trials.jsonl"
                    if key not in references:
                        historic = [json.loads(line) for line in git(commit, key).splitlines()]
                        references[key] = next(r for r in historic if r["tier"] == tier and r["status"] == "PASS")
                    raster_reference(row, references[key])
            outputs[name] = {
                "terminal_and_correctness": dict(outcomes), "manifest": manifest, "input_fingerprints": fingerprints,
                "raw_sha256": raw_sha, "evidence": root,
                "example_correctness_record": next((row["correctness"] for row in rows if row.get("correctness")), None),
            }
            if comp == "vector-m-revised":
                assert wrapper["input_manifest_sha256"] == manifest
                assert wrapper[f"{side}_sample_sha256"] == raw_sha
            if comp == "raster-s":
                assert wrapper[f"{name}_trials_sha256"] == raw_sha

        assert outputs["before"]["manifest"] == outputs["after"]["manifest"]
        assert outputs["before"]["input_fingerprints"] == outputs["after"]["input_fingerprints"]
        check_options(sides, kind)
        groups = {}
        assert len(pair["groups"]) == 2 and {g["group"][2] for g in pair["groups"]} == set(CACHES)
        for cache in CACHES:
            previous, current = (
                group_summary([row for row in sides[side] if row["cache"] == cache], kind)
                for side in ("before", "after")
            )
            comparison, = [group for group in pair["groups"] if group["group"][2] == cache]
            groups[cache] = check_group(previous, current, comparison, tier, workload, cache, kind)
            field = "phase" if kind == "vector" else "kind"
            groups[cache]["warmups"] = {
                label: counter([row for row in rows if row["cache"] == cache and row[field] == "warmup"])
                for label, rows in sides.items()
            }
        assert pair["candidate_all_measurements_pass"] == all(g["after"]["counts"]["PASS"] == 5 for g in groups.values())
        observations = []
        if workload == "remote-s":
            for side, rows in sides.items():
                for row in rows:
                    errors = row.get("status_poll_errors", [])
                    if errors:
                        assert row["status"] == "FAIL" and row["kind"] == "measurement"
                        assert row["error"]["type"] == "StatusObservationFailure" and all(item == POLLS for item in errors)
                        assert check_terminal(row, kind) == "artifact_correctness_verified"
                        observations.append({"side": side, "cache": row["cache"], "sample": row["sample_id"],
                                             "run_id": row["run_id"], "get_500": len(errors), "durable_outcome": "SUCCEEDED/PASSED",
                                             "wall_ns": row["wall_ns"], "comparator_failure_code": failure(row, kind)})
            assert [(x["side"], x["cache"], x["get_500"]) for x in observations] == [
                ("before", "process_cold", 4), ("before", "process_cold", 1), ("before", "warm", 1),
            ]
        if workload == "dem-l":
            files = [path for path in evidence.entries if path.startswith("dem-l/") and path.endswith("/threshold_regions.tif")]
            assert len(files) == 28
            hashes = {digest(evidence.sealed(path)) for path in files}
            assert hashes == {"7a62aed10a269d83989d10d9f35b12527ef4be1be523e51bd0300649549213e8"}
            assert all(any(row["run_id"] in path for path in files) for row in sides["before"] + sides["after"])
        step_rss = None
        if tier == "M" and workload == "t14-split_by_area":
            step_rss = {}
            for label, rows in sides.items():
                measured = [row for row in rows if row["cache"] == "process_cold" and row["phase"] == "measurement"]
                readings = [
                    next(step["resources"]["peak_rss_bytes"] for step in row["telemetry"]["document"]["steps"]
                         if step["step_key"] == "aggregate_by_zone") for row in measured
                ]
                assert len(readings) == 5 and all(item["status"] == "sampled" for item in readings)
                step_rss[label] = distribution(readings)
        audits.append({"tier": tier, "workload": workload, "comparison": comp, "archive": archive,
                       "archive_sha256": evidence.archive_sha256, "groups": groups, "cold_aggregate_rss_if_fully_sampled": step_rss,
                       "sides": outputs, "observation_failures": observations})

    assert len(audits) == 10 and len(identities) == len(set(identities)) == 280
    assert comparators["vector-m-revised"]["records"] == 112
    all_groups = [group for pair in audits for group in pair["groups"].values()]
    assert len(all_groups) == 20
    assert not any(group["rss_successful_change_applicable"] for group in all_groups)
    wall_deltas = sum("wall_ns" in group["successful_sample_deltas"] for group in all_groups)
    temp_deltas = sum("peak_temp_bytes" in group["successful_sample_deltas"] for group in all_groups)
    outcomes = Counter()
    for case in audits:
        for side in case["sides"].values():
            outcomes.update(side["terminal_and_correctness"])
    assert wall_deltas == 10 and temp_deltas == 6
    assert outcomes["artifact_correctness_verified"] == 196
    assert sum(count for name, count in outcomes.items() if name.startswith("timeout:")) == 84
    output.write_text(json.dumps({
        "commit": commit, "pair_count": 10, "cache_group_count": 20, "unique_run_ids": len(identities),
        "eligible_success_deltas": {"wall_ns": wall_deltas, "peak_rss_bytes": 0, "peak_temp_bytes": temp_deltas},
        "terminal_and_correctness_counts": dict(outcomes),
        "correctness_scope": "archived recorded artifact checks and reference comparison, plus DEM L staged TIFF bytes",
        "pairs": audits,
    }, indent=2) + "\n", encoding="utf-8")

    def seconds(dist):
        return "-" if dist["median"] is None else f"{dist['median']/1e9:.3f}/{dist['p95_nearest_rank']/1e9:.3f}"

    print("commit", commit, "10 pairs, 20 cache groups, 280 unique run IDs")
    for case in audits:
        print(case["tier"], case["workload"], "correctness",
              *(str(side["terminal_and_correctness"]) for side in case["sides"].values()))
        for cache, group in case["groups"].items():
            b, c = group["before"], group["after"]
            print(" ", cache, "PASS/FAIL", f"{b['counts']['PASS']}/{b['counts']['FAIL']}", "->",
                  f"{c['counts']['PASS']}/{c['counts']['FAIL']}", "success s", seconds(b["wall_ns"]["PASS"]),
                  "->", seconds(c["wall_ns"]["PASS"]), "failure s", seconds(b["wall_ns"]["FAIL"]),
                  "->", seconds(c["wall_ns"]["FAIL"]), "RSS partial/pass", b["peak_rss_bytes"]["PASS"]["partial"],
                  "->", c["peak_rss_bytes"]["PASS"]["partial"], "RSS partial/fail", b["peak_rss_bytes"]["FAIL"]["partial"],
                  "->", c["peak_rss_bytes"]["FAIL"]["partial"], "deltas", ",".join(group["successful_sample_deltas"]) or "-")
        if case["cold_aggregate_rss_if_fully_sampled"]:
            print(" ", "cold aggregate_by_zone RSS bytes", case["cold_aggregate_rss_if_fully_sampled"])
        for observation in case["observation_failures"]:
            print(" ", "status-observation failure", observation["sample"], "500 count", observation["get_500"],
                  "durable", observation["durable_outcome"], "code", observation["comparator_failure_code"])


if __name__ == "__main__":
    main(sys.argv[1], Path(sys.argv[2]))
