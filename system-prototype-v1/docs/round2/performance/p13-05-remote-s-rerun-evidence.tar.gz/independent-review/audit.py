"""Read-only independent completed remote S method comparison audit."""

from collections import Counter
from hashlib import sha256
import json
import math
import re
from pathlib import Path
import shlex
from statistics import median
import sys


REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
ROOT = REPO / "artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l"
ARCHIVE = REPO / "docs/round2/performance"
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
CANDIDATE = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
CASES = {
    "dem-s": ("raster", "raster-method-s", {"7": 259956}, 144, 7),
    "remote-s": ("remote_sensing", "remote-method-sm", {"1": 6144, "2": 6144, "3": 6144}, 18432, 8),
}
CACHES = ("process_cold", "warm")
METRICS = ("wall_ns", "peak_rss_bytes", "peak_temp_bytes")
PASS = {"PASS": 5, "FAIL": 0, "NOT_RUN": 0}
RUNNER = {
    "run_raster.py": "9a4a9bc061d770c1fce631895bff25f819751e5a98291440f231e5ed267a3729",
    "_raster_metrics.py": "d23eb107cd1ec19eb040ca391831d8028c4523ff783f09314fdc22e05057722e",
    "_raster_reference.py": "eb54e29bbee34e05952e699e4c9b4bc99f3f342ece30773280836eec02cb19a3",
    "_raster_workloads.py": "fa6bc12a43c93487c8159feb7fdf3529ac21b0bc0acaf436fe7a73591b54dd8d",
}
IMAGE = "sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87"


def read(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream]


def digest(raw):
    return sha256(raw).hexdigest()


def stats(values):
    ordered = sorted(values)
    return {"median": median(ordered), "p95_nearest_rank": ordered[math.ceil(.95 * len(ordered)) - 1]} if len(ordered) >= 3 else None


def dist(items):
    values = [i["value"] for i in items if i.get("value") is not None]
    return {
        "samples": len(values), "partial": sum(i.get("status") == "partial" and i.get("value") is not None for i in items),
        **(stats(values) or {"median": None, "p95_nearest_rank": None}),
    }


def area_check(observed, reference, class_counts, nodata, remote):
    assert set(observed) == set(reference)
    area = observed["area_statistics"]
    independent = reference["area_statistics"]
    expected = independent["expected_area_by_class_m2"]
    assert area["expected_area_by_class_m2"] == expected
    assert area["relative_tolerance"] == independent["relative_tolerance"] == 2e-7
    assert area["absolute_tolerance_m2"] == independent["absolute_tolerance_m2"] == .02
    value = area["observed"]
    classes = {str(row["class_id"]): row for row in value["classes"]}
    assert len(classes) == len(value["classes"]) == len(class_counts)
    assert {code: row["pixel_count"] for code, row in classes.items()} == class_counts
    assert value["valid_pixel_count"] == value["selected_pixel_count"] == sum(class_counts.values())
    assert value["unselected_pixel_count"] == 0 and value["nodata_pixel_count"] == nodata
    assert (value["area_crs"], value["area_method"], value["area_unit"], value["cell_area_method"], value["resampling"]) == (
        "EPSG:6933", "equal_area", "square_meter", "projected_cell_boundary", "none",
    )
    assert value["source_crs"] == independent["observed"]["source_crs"]
    if remote:
        assert value["threshold"] == .1 and value["direction"] == "second_minus_first"
        assert [classes[str(i)]["class_name"] for i in (1, 2, 3)] == ["decrease", "stable", "increase"]
    errors = {}
    for code, item in classes.items():
        error = abs(item["area_m2"] - expected[code])
        assert math.isclose(item["area_m2"], expected[code], rel_tol=2e-7, abs_tol=.02)
        errors[code] = error
    assert math.isclose(value["total_area_m2"], math.fsum(expected.values()), rel_tol=2e-7, abs_tol=.02)
    assert math.isclose(value["total_area_m2"], math.fsum(item["area_m2"] for item in classes.values()),
                        rel_tol=1e-14, abs_tol=1e-7)
    for key in observed.keys() - {"area_statistics"}:
        actual, earlier = observed[key], reference[key]
        if "maximum_absolute_error" not in actual:
            assert actual == earlier, key
            continue
        assert actual["absolute_tolerance"] == earlier["absolute_tolerance"]
        assert actual["maximum_absolute_error"] <= actual["absolute_tolerance"]
        for name in actual.keys() - {"maximum_absolute_error", "file_bytes"}:
            assert actual[name] == earlier[name], (key, name)
    return {
        "class_counts": class_counts, "nodata": nodata, "total_area_m2": value["total_area_m2"],
        "area_by_class_m2": {code: item["area_m2"] for code, item in classes.items()},
        "independent_area_m2": expected, "abs_error_by_class_m2": errors,
        "total_abs_error_m2": abs(value["total_area_m2"] - math.fsum(expected.values())),
        "boundary_convergence": value["boundary_convergence"],
        "raster_max_abs_error": max(item.get("maximum_absolute_error", 0) for item in observed.values()),
    }


def historic_evidence(case):
    _, historic_name, _, _, _ = CASES[case]
    archive_report = read(ARCHIVE / f"p13-04-{historic_name}-report.json")
    archive_trials = ARCHIVE / f"p13-04-{historic_name}-trials.jsonl"
    return archive_report, next(row for row in jsonl(archive_trials) if row["tier"] == "S")


def trial_identity(row, case, manifest, historic):
    family = CASES[case][0]
    index = row["index"]
    assert row["sample_id"] == f"{family}/S/method/{row['cache']}/{index:02d}"
    assert (row["family"], row["tier"], row["workload"], row["kind"], row["manifest_sha256"]) == (
        family, "S", "method", "warmup" if index <= 2 else "measurement", manifest,
    )
    assert row["method"] == historic["method"] and row["critical_options"] == historic["critical_options"]
    assert row["parameters_sha256"] == digest(json.dumps(
        row["confirmed_parameters"], sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode())
    assert row["run_state"]["run_id"] == row["run_id"]


def completed_output(row, historic, case):
    family, _, class_counts, nodata, nsteps = CASES[case]
    state, sidecar = row["run_state"], row["telemetry"]
    assert row["exit_code"] == 0
    assert (state["execution_status"], state["check_status"]) == ("SUCCEEDED", "PASSED")
    assert state["current_report_id"] and not state["error"] and not state["cancel_requested"]
    assert (sidecar["run_id"], sidecar["execution_status"], sidecar["check_status"], sidecar["exit_code"]) == (
        row["run_id"], "SUCCEEDED", "PASSED", 0,
    )
    steps = row["executed_steps"]
    assert len(steps) == len(sidecar["steps"]) == nsteps and len({s["step_key"] for s in steps}) == nsteps
    for raw, event in zip(steps, sidecar["steps"]):
        assert raw["status"] == event["status"] == "SUCCEEDED" and raw["exit_code"] == event["exit_code"] == 0
        assert raw["step_key"] == event["step_key"]
        assert raw["tool"] == {key: event["tool"][key] for key in ("id", "version")}
        assert isinstance(raw["parameters"], dict)
    assert [s["step_key"] for s in steps] == [s["step_key"] for s in historic["telemetry"]["steps"]]
    assert row["v1_completed_checks"] == historic["v1_completed_checks"]
    settings = {key: row[key] for key in ("method", "critical_options", "confirmed_parameters", "executed_steps")}
    area = area_check(row["correctness"], historic["correctness"], class_counts, nodata, family == "remote_sensing")
    return settings, area


def environment_check(path, report):
    assert report["implementation_sha256"] == RUNNER
    storage = report["environment"]["storage"]["mount_source_and_filesystem"]
    assert re.sub(r"\[.*\]", "", storage) == "/dev/sda2 ext4"
    command = path.parent / "command.log"
    assert IMAGE in shlex.split(command.read_text().splitlines()[1])


CASE = "remote-s"
PAIR = ROOT / CASE / "pair.9g_9y1ij/before-after.json"
PRIOR = Path("/tmp/geopilot-p13-05-raster-s-audit.rJKuNw/independent.json")
PRIOR_SHA = "f6c4e2d81e0d269b154a5640c7aa71a4636472174bb841e86290c59c630c437b"
RESOURCES = ("cpu_ns", "peak_rss_bytes", "disk_read_bytes", "disk_write_bytes")
STATUS_READ_ERROR = {
    "http_status": 500, "body": {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}},
}


def observation(value):
    return {"status": "recorded" if value is not None else "unavailable", "value": value}


def summary(items):
    return {
        **dist(items), "coverage": dict(Counter(item["status"] for item in items)),
        "observed_values": [item["value"] for item in items],
    }


def columns(row):
    sidecar = row["telemetry"]
    return {
        "wall_ns": observation(row["wall_ns"]), "queue_wall_ns": sidecar["queue_wall_ns"],
        "execute_steps_wall_ns": observation(sidecar["execute_steps_wall_ns"]),
        "finalize_wall_ns": observation(sidecar["finalize_wall_ns"]),
        **sidecar["resources"], "peak_temp_bytes": row["workspace_size"]["peak_temp_bytes"],
    }


def validate_side(path, commit):
    archive_report, historic = historic_evidence(CASE)
    report_file = path / "report.json"
    report = read(report_file)
    environment_check(path, report)
    receipt = read(path / "runtime-configuration.json")
    assert report["mode"] == "formal" and not report.get("error")
    assert report["environment"]["commit"] == commit and report["family"] == "remote_sensing"
    assert (path.parent / "self-comparison.exit-code").read_text().strip() == "0"
    assert (path.parent.parent / "COMPLETED").read_text().strip() == path.parent.name
    container_exit = int((path.parent / "exit-code").read_text())
    assert receipt["schema_version"] == 1 and receipt["report_files"] == {"report.json": digest(report_file.read_bytes())}
    snapshot = receipt["before"]
    assert snapshot == receipt["after"]
    assert snapshot["sha256"] == digest(json.dumps(
        {key: value for key, value in snapshot.items() if key != "sha256"}, ensure_ascii=True,
        sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode("ascii"))
    current, old = report["inputs"]["S"], archive_report["inputs"]["S"]
    assert set(report["inputs"]) == {"S"} and current["directory"] == "/inputs/S" and current["generation_ns"] is None
    assert current["manifest_sha256"] == old["manifest_sha256"]
    assert current["first_fingerprints"] == current["last_fingerprints"] == old["first_fingerprints"] == old["last_fingerprints"]

    trials_file = path / "trials.jsonl"
    rows = jsonl(trials_file)
    assert len(rows) == len({row["run_id"] for row in rows}) == 14
    assert [(row["cache"], row["index"]) for row in rows] == [(cache, i) for cache in CACHES for i in range(1, 8)]
    for key in ("task_id", "plan_id", "workspace"):
        assert len({row[key] for row in rows}) == 14
    assert container_exit == int(any(row["status"] == "FAIL" for row in rows))
    assert report["status"] == ("FAIL" if container_exit else "PASS")
    areas, settings, evidence = [], [], []
    for row in rows:
        trial_identity(row, CASE, current["manifest_sha256"], historic)
        assert row.get("worker_exit_code") == (0 if row["cache"] == "process_cold" else None)
        errors = row.get("status_poll_errors", [])
        assert all(error == STATUS_READ_ERROR for error in errors)
        assert row["status"] == ("FAIL" if errors else "PASS")
        if errors:
            assert row["error"] == {
                "type": "StatusObservationFailure",
                "message": "Execution reached terminal state after an HTTP status-read error",
            }
        else:
            assert not row.get("error")
        options, area = completed_output(row, historic, CASE)
        settings.append(options)
        areas.append(area)
        assert row["pixels"] == 36864
        assert math.isclose(row["pixels_per_second"], row["pixels"] * 1e9 / row["wall_ns"], rel_tol=1e-14)
        evidence.append({
            "sample_id": row["sample_id"], "cache": row["cache"], "kind": row["kind"], "run_id": row["run_id"],
            "task_id": row["task_id"], "plan_id": row["plan_id"], "status": row["status"],
            "status_poll_errors": errors, "worker_pid": row["worker_pid"],
            "run_status": row["run_state"], "step_exit_codes": [step["exit_code"] for step in row["executed_steps"]],
            "parameters_sha256": row["parameters_sha256"], "correctness": area, "readings": columns(row),
        })
    assert all(item == settings[0] for item in settings)
    assert all(item == areas[0] for item in areas)

    groups = {}
    planned = [{"tier": "S", "workload": "method", "cache": cache} for cache in CACHES]
    assert report["expected_groups"] == planned and len(report["groups"]) == 2
    for cache in CACHES:
        raw = [row for row in rows if row["cache"] == cache]
        assert len({row["worker_pid"] for row in raw}) == (7 if cache == "process_cold" else 1)
        measured = [row for row in raw if row["kind"] == "measurement"]
        warmups = [row for row in raw if row["kind"] == "warmup"]
        assert len(measured) == 5 and len(warmups) == 2
        group = next(group for group in report["groups"] if group["cache"] == cache)
        assert (group["tier"], group["workload"], group["expected_trials"], group["observed_trials"]) == ("S", "method", 7, 7)
        assert group["trial_failures"] == sum(row["status"] == "FAIL" for row in raw)
        assert not group["interrupted"] and group["warm_worker_exit"] == (0 if cache == "warm" else None)
        assert group["input_fingerprints_before"] == group["input_fingerprints_after"] == current["first_fingerprints"]
        counts = Counter(row["status"] for row in measured)
        failures = Counter(row["error"]["type"] for row in measured if row["status"] == "FAIL")
        aggregate = group["operations"]["method"]
        assert (aggregate["passed"], aggregate["failed"], aggregate["missing"]) == (counts["PASS"], counts["FAIL"], 0)
        passing = [row for row in measured if row["status"] == "PASS"]
        assert aggregate.get("wall_ns") == stats([row["wall_ns"] for row in passing])
        assert aggregate.get("pixels_per_second") == stats([row["pixels_per_second"] for row in passing])
        sampled = [row["telemetry"]["resources"]["peak_rss_bytes"]["value"] for row in passing
                   if row["telemetry"]["resources"]["peak_rss_bytes"]["status"] == "sampled"]
        assert aggregate.get("sampled_peak_rss_count") == len(sampled)
        assert aggregate.get("peak_rss_bytes") == stats(sampled)

        by_status = {}
        for status in ("PASS", "FAIL"):
            subset = [row for row in measured if row["status"] == status]
            records = [columns(row) for row in subset]
            metrics = ("wall_ns", "queue_wall_ns", "execute_steps_wall_ns", "finalize_wall_ns", *RESOURCES, "peak_temp_bytes")
            result = {field: summary([record[field] for record in records]) for field in metrics}
            result["steps"] = {}
            for i, step in enumerate(settings[0]["executed_steps"]):
                events = [row["telemetry"]["steps"][i] for row in subset]
                result["steps"][step["step_key"]] = {
                    "wall_ns": summary([observation(event["wall_ns"]) for event in events]),
                    "peak_rss_bytes": summary([event["resources"]["peak_rss_bytes"] for event in events]),
                }
            by_status[status] = result
        groups[cache] = {
            "warmup_counts": dict(Counter(row["status"] for row in warmups)),
            "measurement_counts": {status: counts[status] for status in ("PASS", "FAIL", "NOT_RUN")},
            "measurement_failure_types": dict(failures), "distribution": by_status,
        }
    return {
        "evidence": str(path), "container_exit": container_exit, "report_status": report["status"], "receipt": snapshot["sha256"],
        "input_manifest_sha256": current["manifest_sha256"], "settings": settings[0], "area": areas[0],
        "files": {item.name: digest(item.read_bytes()) for item in (report_file, trials_file, path / "runtime-configuration.json")},
        "groups": groups, "observations": evidence, "status_poll_errors": sum(len(item["status_poll_errors"]) for item in evidence),
    }


def check_pair(report, sides):
    assert (report["status"], report["before_source"], report["after_source"], report["candidate_all_measurements_pass"]) == (
        "MATCHED_EVIDENCE", BASE, CANDIDATE, True,
    )
    assert not report["same_source"]
    assert len(report["groups"]) == 2 and {group["group"][2] for group in report["groups"]} == set(CACHES)
    assert report["runtime_configuration"]["sha256"] == sides["before"]["receipt"] == sides["after"]["receipt"]
    assert sides["before"]["settings"] == sides["after"]["settings"]
    assert sides["before"]["area"] == sides["after"]["area"]
    fields = ("samples", "partial", "median", "p95_nearest_rank")
    for group in report["groups"]:
        cache = group["group"][2]
        assert group["group"] == ["S", "method", cache, "p13-01", "method"]
        assert group["step_parameter_evidence"] == "normalized_step_requests"
        for label, side in sides.items():
            recorded = group[label]
            expected = side["groups"][cache]
            assert recorded["counts"] == expected["measurement_counts"]
            expected_codes = {"unspecified": expected["measurement_counts"]["FAIL"]} if expected["measurement_counts"]["FAIL"] else {}
            assert recorded["failure_codes"] == expected_codes
            for metric in METRICS:
                for status in ("PASS", "FAIL"):
                    assert recorded[metric][status] == {f: expected["distribution"][status][metric][f] for f in fields}
        assert group["before"]["counts"]["PASS"] != group["after"]["counts"]["PASS"]
        assert group["successful_sample_deltas"] == {}


def main(output):
    assert PAIR.with_name("before-after.exit-code").read_text().strip() == "0"
    assert PAIR.with_name("before-after.stderr").read_bytes() == b""
    command = shlex.split(PAIR.with_name("before-after.command").read_text())
    assert "--require-runtime-configuration" in command
    paths = {label: Path(command[command.index(f"--{label}") + 1]) for label in ("before", "after")}
    assert paths["before"].parent.name == "attempt.86mfi320"
    assert paths["after"].parent.name == "attempt._d7itl7q"
    sides = {"before": validate_side(paths["before"], BASE), "after": validate_side(paths["after"], CANDIDATE)}
    check_pair(read(PAIR), sides)
    assert sides["before"]["container_exit"] == 1 and sides["after"]["container_exit"] == 0
    assert sides["before"]["status_poll_errors"] == 6 and sides["after"]["status_poll_errors"] == 0

    assert digest(PRIOR.read_bytes()) == PRIOR_SHA
    prior = [rid for case in read(PRIOR).values() for side in ("base", "candidate") for rid in case[side]["run_ids"]]
    rows = [row for side in sides.values() for row in side["observations"]]
    current = [row["run_id"] for row in rows]
    assert len(prior) == len(set(prior)) == 47
    assert len(current) == len(set(current)) == 28
    assert len(set(prior + current)) == 75
    assert len({row["task_id"] for row in rows}) == len({row["plan_id"] for row in rows}) == 28
    plan = read(ROOT / "plan.json")
    assert plan["commits"] == {"base": BASE, "candidate": CANDIDATE}
    assert plan["image"] == IMAGE and plan["disk"][:2] == ["/dev/sda2", "ext4"]
    assert all(side["input_manifest_sha256"] == plan["input_manifest_sha256"][CASE] for side in sides.values())
    result = {
        "pair": str(PAIR), "pair_sha256": digest(PAIR.read_bytes()), "previous_run_ids_checked": len(prior),
        "new_run_ids_checked": len(current), "correctness_verified_for_all_28": True,
        "base": sides["before"], "candidate": sides["after"],
    }
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    for label, side in sides.items():
        print(label, "container exit", side["container_exit"], "receipt", side["receipt"],
              "poll errors", side["status_poll_errors"])
        for row in side["observations"]:
            if row["status_poll_errors"]:
                print("observation failure", row["sample_id"], row["run_id"], len(row["status_poll_errors"]),
                      row["run_status"]["execution_status"], row["run_status"]["check_status"], row["step_exit_codes"])
        for cache, group in side["groups"].items():
            print(label, cache, group["measurement_counts"])
            for status in ("PASS", "FAIL"):
                d = group["distribution"][status]
                print(status, "wall ns", d["wall_ns"], "RSS bytes", d["peak_rss_bytes"], "temp bytes", d["peak_temp_bytes"])
    print("independent area", sides["after"]["area"])
    print("28 unique current IDs, 47 prior IDs disjoint; strict pair delta empty", PAIR)


if __name__ == "__main__":
    main(Path(sys.argv[1]))
