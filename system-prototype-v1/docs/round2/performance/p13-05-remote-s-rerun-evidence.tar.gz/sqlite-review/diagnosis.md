# 遥感 S 原版重测 86mfi320 状态读诊断

原版运行提交为 `977ab412d9f6e7558d22a5c431fac0ada90b07be`。此次仅在 tmpfs 中复制 8 个无 SQLite journal/WAL/SHM 伴随文件的终态数据库，以 `mode=ro&immutable=1` 核对。未启动 GIS 或服务。复算校验 114 个源文件的前后 SHA-256，验证实际冻结基准脚本的 4 个散列与 report 相同。

## 样本结论

| 正式计量 | 记录的 GET 失败 | 原始计量状态 | SQLite 终态 | 执行步骤 | 正式成果 |
| --- | ---: | --- | --- | --- | ---: |
| 冷态 04 | 4 | FAIL | SUCCEEDED / PASSED | 8 × SUCCEEDED / 0 | 10 |
| 冷态 07 | 1 | FAIL | SUCCEEDED / PASSED | 8 × SUCCEEDED / 0 | 10 |
| 暖态 07 | 1 | FAIL | SUCCEEDED / PASSED | 8 × SUCCEEDED / 0 | 10 |

上述六次 GET 均为 HTTP 500 `STORAGE_FAILED`，消息为 `Could not read the run record.`。三条 trial 均记录 `StatusObservationFailure`。失败样本的 24 份步骤结果和过程日志均为 exit 0，四项 V1 检查通过，正式成果清单与 SQLite 登记逐项一致。保存的独立验算显示三个分类各 6,144 个像元、NoData 18,432 个像元，七项栅格最大误差为 0，每次面积合计与参考相差约 0.000087565 m²。复算只使用现有保存值，没有重新计算栅格。

所有 14 个 SQLite 运行逐一对上原始 trial 的 run、plan、task、workspace，均 `SUCCEEDED / PASSED`、无运行错误、未请求取消。112 步全部为 `SUCCEEDED` 和 exit 0。原始正式报告仍为 FAIL、容器退出 1。预热 4/4 通过，冷态计量 3/5、暖态计量 4/5 通过。自比较器退出 0，语义为 `MATCHED_EVIDENCE`，其 `candidate_all_measurements_pass=false`。保留六次失败响应及全部原始试验标签。由于失败 GET 无分次耗时，无法从墙钟中拆出其等待成本。

## 原因与修改边界

冻结原版的 `scripts/bench/_raster_workloads.py:205–229` 每次调用 GET，记录任何错误响应，针对 500 `STORAGE_FAILED` 最多容忍连续两次。任一成功 GET 重置计数。三个样本均最终读到成功终态，累计四次的样本也未达到连续三次的停止条件。`scripts/bench/run_raster.py:134,164–177` 初始化样本为 FAIL，并在此前有状态读错误时保存 `StatusObservationFailure`，因此样本仍被排除。

冻结原版、Git 原版 `977ab41` 和取消修复提交 `71ae95d` 的 `api/app.py`、`runs/query_service.py`、`persistence/schema.py` 字节一致。GET 路由把 `sqlite3.Error` 或 Pydantic `ValidationError` 映射到同一 500 响应。此批 worker 日志为空，六次响应未记下底层异常、锁持有者及各次等待时间。先前留档的独占写锁探针已实证 GET 可因 `SQLITE_BUSY` 在 5.008 秒后返回相同 500，且释放后 GET 恢复 200。该探针支持锁争用假设，具体到这六次请求的底层原因仍未确认。

`71ae95d` 在子进程取消观察的只读连接上单独将 `busy_timeout` 设为 0，限定 `SQLITE_BUSY/LOCKED` 由下一轮再次观察，保持已提交取消及其他错误的语义。本批使用冻结原版。现有修复的作用域仍不包括 GET、执行结果写入或全局 SQLite 配置。

值得独立修复 GET 状态边界。先在现有短期独占锁夹具验证只读连接的局部等待预算、总截止时间和锁释放后恢复，并记录可区分的 SQLite 主错误码和等待耗时。候选策略是有界重试状态 GET，耗尽后只把 BUSY/LOCKED 映射为带重试提示的临时状态不可用，继续明确区分 404、真实存储故障及无效状态。若采用新 HTTP 状态或错误码，须同步核对前端和基准观察器，旧冻结基准只容忍 `500/STORAGE_FAILED`。保留每次错误计数和完整正式通过条件，修改另行复测，已有三个失败样本不重新分类。

## 复算入口

在 `/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1` 运行：

```bash
set -o pipefail
evidence=/dev/shm/geopilot-p13-remote-s-86mfi320.bTPfYiNy
python -B "$evidence/audit.py" \
  artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l/remote-s/base/attempt.86mfi320 \
  artifacts/test-results/p13-05-revised-pair-source.a2d2e68/base \
  | cmp "$evidence/audit.json" -
```

复算及逐字节比较均退出 0。审计 JSON 的 SHA-256 为 `39bb2221c01c85d5213da0332903fa7b21dd86f9598be61de77f5bfa6454e43b`。 [原始复算 JSON](/dev/shm/geopilot-p13-remote-s-86mfi320.bTPfYiNy/audit.json) · [复算脚本](/dev/shm/geopilot-p13-remote-s-86mfi320.bTPfYiNy/audit.py) · [既有受控 GET 探针](/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/docs/round2/performance/p13-05-raster-s-status-probe.json)
