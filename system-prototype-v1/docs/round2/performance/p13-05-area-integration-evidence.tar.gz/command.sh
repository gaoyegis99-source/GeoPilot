#!/bin/bash
set -o pipefail
geo_area_evidence="$1"
export PATH="$geo_area_evidence/bin:$PATH" TMPDIR="$geo_area_evidence/tmp"
export PYTHONPATH="$PWD/src:$PWD/.environments/postgis-python"
export GEOPILOT_QGIS_PROCESS="$PWD/.environments/qgis-deb/qgis_process"
export PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PROJ_NETWORK=OFF QT_QPA_PLATFORM=offscreen
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1
{
  .venv/bin/python -B --version
  .venv/bin/python -B -m pytest --version
  .venv/bin/python -B -c 'import psycopg, rasterio, pyproj, sqlite3; print(psycopg.__version__, rasterio.__gdal_version__, pyproj.proj_version_str, sqlite3.sqlite_version)'
  "$GEOPILOT_QGIS_PROCESS" --version
} > "$geo_area_evidence/bundle/environment.log" 2>&1
.venv/bin/python -B -m pytest -q -p no:cacheprovider -W error::pytest.PytestUnhandledThreadExceptionWarning \
  tests/data_adapters tests/gis --basetemp="$geo_area_evidence/tmp/pytest" \
  --junitxml="$geo_area_evidence/bundle/regression.xml" 2>&1 | tee "$geo_area_evidence/bundle/regression.log"
geo_area_status=${PIPESTATUS[0]}
printf '%s\n' "$geo_area_status" > "$geo_area_evidence/bundle/exit-code"
exit "$geo_area_status"
