"""Compare the nested execution timing spans in sealed DEM L samples."""

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
import sys


def distribution(values):
    return {"median": median(values), "range": [min(values), max(values)]}


def audit_side(path, caches):
    raw = path.read_bytes()
    complete_lines = [line for line in raw.splitlines(keepends=True) if line.endswith(b"\n")]
    rows = [json.loads(line) for line in complete_lines]
    groups = {}
    for cache in caches:
        selected = [row for row in rows if row["cache"] == cache]
        assert [(row["index"], row["kind"]) for row in selected] == [
            (i, "warmup" if i <= 2 else "measurement") for i in range(1, 8)
        ]
        timing, identities = [], set()
        for row in selected:
            assert (row["family"], row["tier"], row["status"]) == ("raster", "L", "FAIL")
            error = row["run_state"]["error"]
            assert (error["code"], error["step_key"]) == (
                "PROCESS_TIMEOUT", "calculate_area_with_equal_area_projection",
            )
            assert row["run_state"]["execution_status"] == "FAILED"
            telemetry = row["telemetry"]
            assert telemetry["run_id"] == row["run_id"] and telemetry["wall_scope"] == "execution_through_finalization"
            steps = telemetry["steps"]
            assert len(steps) == 7 and all(step["exit_code"] == 0 for step in steps[:-1])
            area = steps[-1]
            assert area["exit_code"] == -15 and area["step_key"] == error["step_key"]
            identities.add(tuple((step["step_key"], json.dumps(step["tool"], sort_keys=True)) for step in row["executed_steps"]))
            if row["kind"] == "warmup":
                continue
            step_times = {step["step_key"]: step["wall_ns"] for step in steps}
            execute = telemetry["execute_steps_wall_ns"]
            assert execute + telemetry["finalize_wall_ns"] == telemetry["wall_ns"]
            residual = execute - sum(step_times.values())
            assert residual >= 0
            area_cpu = area["resources"]["cpu_ns"]
            assert area_cpu["status"] == "partial" and 0 < area_cpu["value"] <= area["wall_ns"]
            timing.append({
                "sample": row["sample_id"], "run_id": row["run_id"], "observed_wall_ns": row["wall_ns"],
                "execute_steps_wall_ns": execute, "step_wall_ns": step_times,
                "outside_recorded_steps_ns": residual, "area_cpu_lower_bound_ns": area_cpu["value"],
                "status_poll_errors": len(row.get("status_poll_errors") or []),
            })
        assert len(identities) == 1 and len(timing) == 5
        fields = ("observed_wall_ns", "execute_steps_wall_ns", "outside_recorded_steps_ns", "area_cpu_lower_bound_ns")
        groups[cache] = {
            "measured": len(timing), "samples": timing,
            **{field: distribution([sample[field] for sample in timing]) for field in fields},
            "step_wall_ns": {step: distribution([sample["step_wall_ns"][step] for sample in timing])
                             for step in timing[0]["step_wall_ns"]},
            "status_poll_error_counts": dict(sorted(Counter(sample["status_poll_errors"] for sample in timing).items())),
            "sample_group_sha256": sha256(b"".join(line for line in complete_lines if json.loads(line)["cache"] == cache)).hexdigest(),
        }
    return groups


if __name__ == "__main__":
    print(json.dumps({
        role: audit_side(Path(path), sys.argv[3:])
        for role, path in zip(("base", "candidate"), sys.argv[1:3], strict=True)
    }, indent=2))
