#!/usr/bin/env bash
set -o pipefail
probe=/dev/shm/geopilot-p13-status-tx.6mCH8QiR
cd "$probe/production/system-prototype-v1" || exit 1
PYTHONPATH="$PWD/src" PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm \
  /home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/.venv/bin/python \
  "$probe/probe.py" 2>&1 | tee "$probe/probe.log"
result=$?
printf '%s\n' "$result" > "$probe/exit-code"
exit "$result"
