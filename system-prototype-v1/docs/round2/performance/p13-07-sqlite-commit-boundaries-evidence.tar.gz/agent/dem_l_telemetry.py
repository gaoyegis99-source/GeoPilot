import hashlib
import json
import sys
import tarfile
from pathlib import Path
from statistics import median


def timings(path):
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    with tarfile.open(path) as archive:
        member, = (item for item in archive.getmembers() if item.name.endswith("/trials.jsonl"))
        with archive.extractfile(member) as stream:
            rows = list(map(json.loads, stream))
    observations = []
    for row in rows:
        if row["kind"] != "measurement":
            continue
        assert row["cache"] == "process_cold" and row["tier"] == "L" and row["status"] == "FAIL"
        assert row["run_state"]["error"]["code"] == "PROCESS_TIMEOUT"
        telemetry = row["telemetry"]
        assert row["run_id"] == telemetry["run_id"] and telemetry["execution_status"] == "FAILED"
        steps = telemetry["steps"]
        assert len(steps) == 7 and all(step["status"] == "SUCCEEDED" for step in steps[:-1])
        assert steps[-1]["step_key"] == "calculate_area_with_equal_area_projection"
        adapter_sum = sum(step["wall_ns"] for step in steps)
        observations.append({
            "sample_id": row["sample_id"], "run_id": row["run_id"], "run_error": row["run_state"]["error"]["code"],
            "status_poll_errors": len(row.get("status_poll_errors", [])),
            "execute_steps_wall_ns": telemetry["execute_steps_wall_ns"],
            "adapter_sum_wall_ns": adapter_sum,
            "outside_adapter_wall_ns": telemetry["execute_steps_wall_ns"] - adapter_sum,
            "finalize_wall_ns": telemetry["finalize_wall_ns"],
            "step_wall_ns": {step["step_key"]: step["wall_ns"] for step in steps},
        })
    assert len(observations) == 5
    return {
        "archive": str(path.resolve()), "archive_sha256": digest, "member": member.name, "measurements": observations,
        "median": {key: median(row[key] for row in observations) for key in (
            "execute_steps_wall_ns", "adapter_sum_wall_ns", "outside_adapter_wall_ns", "finalize_wall_ns",
        )},
        "step_medians_wall_ns": {
            step: median(row["step_wall_ns"][step] for row in observations) for step in observations[0]["step_wall_ns"]
        },
    }


root, base, candidate = (Path(arg) for arg in sys.argv[1:])
result = {label: timings(path) for label, path in (("base", base), ("candidate", candidate))}
(root / "dem-l-telemetry.json").write_text(json.dumps(result, indent=2) + "\n")
for label, value in result.items():
    print(label, "median_s", {key: round(value / 1e9, 3) for key, value in value["median"].items()})
    print(label, "outside_adapter_by_measurement_s", [round(row["outside_adapter_wall_ns"] / 1e9, 3)
                                                       for row in value["measurements"]])
