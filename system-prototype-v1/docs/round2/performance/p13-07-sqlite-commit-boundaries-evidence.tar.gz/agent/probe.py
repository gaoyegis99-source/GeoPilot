import json
import os
import select
import signal
import sqlite3
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from time import monotonic, sleep

from fastapi.testclient import TestClient

from geopilot.api.app import create_app
from geopilot.domain.step_io import ExecutionStatus, StepFileRef, StepResult
from geopilot.persistence.run_repository import insert_run
from geopilot.persistence.schema import initialize_database, open_database
from geopilot.persistence.workspace import RunWorkspace, create_run_workspace
from geopilot.plans.models import AnalysisPlan
from geopilot.runs.models import Run
from geopilot.scheduler import step_executor
from geopilot.tools.registry import ToolRegistry


ROOT = Path(__file__).resolve().parent
RUN_ID = "transaction-probe"
PENDING_BYTE = 0x40000000
RESERVED_BYTE = PENDING_BYTE + 1
SHARED_FIRST = PENDING_BYTE + 2
SHARED_LAST = SHARED_FIRST + 509
PATH = f"/api/runs/{RUN_ID}"


def gate(message):
    print(message, flush=True)
    assert sys.stdin.buffer.read(1) == b"x"


def writer(directory, mode):
    request = json.loads((ROOT / "archived-request.json").read_text())
    plan_doc = request["plan"]
    plan_doc["steps"] = plan_doc["steps"][:1]
    plan_doc["expected_artifacts"] = []
    plan = AnalysisPlan.model_validate(plan_doc)
    work = create_run_workspace(directory / "workspace", plan.task_id, RUN_ID)
    database = directory / "project.sqlite"
    initialize_database(database)
    with open_database(database) as connection, connection:
        assert connection.execute("PRAGMA journal_mode").fetchone()[0] == "delete"
        assert connection.execute("PRAGMA busy_timeout").fetchone()[0] == 5000
        timestamp = datetime.now(UTC)
        connection.execute("INSERT INTO task VALUES (?, '{}', NULL, ?)", (plan.task_id, timestamp.isoformat()))
        connection.execute("INSERT INTO analysis_plan VALUES (?, ?, ?, 'confirmed', ?, ?)", (
            plan.id, plan.version, plan.task_id, plan.model_dump_json(), timestamp.isoformat(),
        ))
        insert_run(connection, Run(id=RUN_ID, plan_id=plan.id, plan_version=plan.version,
                                   execution_status=ExecutionStatus.RUNNING, workdir=str(work.path), created_at=timestamp))

    if mode == "reserved":
        create_step = RunWorkspace.create_step

        def gated_create_step(self, step_key):
            path = create_step(self, step_key)
            gate("STEP_MKDIR_FINISHED")
            return path

        RunWorkspace.create_step = gated_create_step

    def stub_gis(request, *, workdir, **unused):
        now = datetime.now(UTC)
        result = StepResult(run_id=request.run_id, step_key=request.step_key, status=ExecutionStatus.SUCCEEDED,
                            exit_code=0, outputs={}, log_path=request.log_path, warnings=[], error=None,
                            started_at=now, finished_at=now, environment={})
        log = workdir / request.log_path
        log.write_text("Synthetic tool; exit_code: 0\n")
        log.with_name("result.json").write_text(result.model_dump_json() + "\n")
        if mode != "reserved":
            gate("DISK_RESULT_WRITTEN")
        return result

    step_executor.run_step = stub_gis
    result = step_executor.execute_steps(
        database, work, plan, {role: StepFileRef.model_validate(value) for role, value in request["asset_files"].items()},
        registry=ToolRegistry(),
    )
    assert len(result) == 1 and next(iter(result.values())).exit_code == 0
    print("STEP_RESULT_COMMITTED", flush=True)


def locks_for(database):
    stat = database.stat()
    identity = f"{os.major(stat.st_dev):02x}:{os.minor(stat.st_dev):02x}:{stat.st_ino}"
    return [line.split() for line in Path("/proc/locks").read_text().splitlines()
            if len(line.split()) == 8 and line.split()[5] == identity]


def covers(entries, pid, kind, first, last=None):
    last = first if last is None else last
    return any(int(row[4]) == pid and row[3] == kind and int(row[6]) <= first
               and (row[7] == "EOF" or int(row[7]) >= last) for row in entries)


@contextmanager
def child_process(directory, role, *arguments):
    with (directory / f"{role}.stderr").open("wb") as stderr:
        process = subprocess.Popen([sys.executable, __file__, role, str(directory), *arguments],
                                   stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr)
        try:
            yield process
        finally:
            if process.poll() is None:
                process.kill()
            process.communicate(timeout=3)


def await_gate(process, expected):
    assert select.select([process.stdout], [], [], 6)[0]
    actual = process.stdout.readline().decode().strip()
    assert actual == expected, (expected, actual, process.poll())


def release_gate(process):
    process.stdin.write(b"x")
    process.stdin.flush()


def http(client, method, suffix=""):
    started = monotonic()
    reply = client.request(method, PATH + suffix)
    return {"status": reply.status_code, "elapsed_ms": round((monotonic() - started) * 1000, 3), "body": reply.json()}


def raw_lock_errors(database):
    probes = {
        "read": (database.as_uri() + "?mode=ro", "SELECT * FROM run"),
        "write": (database.as_uri(), "BEGIN IMMEDIATE"),
    }
    outcomes = {}
    for role, (uri, sql) in probes.items():
        connection = sqlite3.connect(uri, timeout=0, uri=True)
        try:
            connection.execute(sql).fetchone()
            outcomes[role] = None
        except sqlite3.OperationalError as error:
            outcomes[role] = {"code": error.sqlite_errorcode, "name": error.sqlite_errorname}
        finally:
            connection.close()
    return outcomes


def db_step(database):
    with open_database(database, read_only=True) as connection:
        return dict(connection.execute("SELECT status, result_json FROM run_step WHERE run_id = ?", (RUN_ID,)).fetchone())


def reserved_probe():
    directory = ROOT / "reserved"
    directory.mkdir()
    database = directory / "project.sqlite"
    with child_process(directory, "writer", "reserved") as process:
        await_gate(process, "STEP_MKDIR_FINISHED")
        locks = locks_for(database)
        assert covers(locks, process.pid, "WRITE", RESERVED_BYTE)
        assert not covers(locks, process.pid, "WRITE", PENDING_BYTE)
        errors = raw_lock_errors(database)
        assert errors["read"] is None and errors["write"]["code"] == sqlite3.SQLITE_BUSY
        with TestClient(create_app(database)) as client:
            get = http(client, "GET")
            cancel = http(client, "POST", "/cancel")
        assert (get["status"], cancel["status"]) == (200, 500)
        assert cancel["elapsed_ms"] >= 4_000
        release_gate(process)
        await_gate(process, "STEP_RESULT_COMMITTED")
        assert process.wait(timeout=3) == 0
        assert db_step(database)["status"] == "SUCCEEDED"
    return {"kernel_locks": locks, "zero_timeout_sqlite": errors, "GET": get, "cancel": cancel}


def pending_probe(mode):
    directory = ROOT / mode
    directory.mkdir()
    database = directory / "project.sqlite"
    with child_process(directory, "writer", mode) as process:
        await_gate(process, "DISK_RESULT_WRITTEN")
        previous = db_step(database)
        with child_process(directory, "reader") as reader:
            await_gate(reader, "READ_LOCK_HELD")
            assert previous == {"status": "RUNNING", "result_json": None}
            release_gate(process)
            deadline = monotonic() + 3
            while monotonic() < deadline:
                locks = locks_for(database)
                if covers(locks, process.pid, "WRITE", PENDING_BYTE):
                    break
                assert process.poll() is None
                sleep(0.005)
            else:
                raise AssertionError("Writer never obtained the PENDING byte while committing")
            assert covers(locks, process.pid, "WRITE", RESERVED_BYTE)
            assert not covers(locks, process.pid, "WRITE", SHARED_FIRST, SHARED_LAST)
            assert covers(locks, reader.pid, "READ", SHARED_FIRST, SHARED_LAST)
            # A stopped writer holds real kernel locks while both unmodified HTTP timeouts run.
            artificial_stall = mode == "pending-stalled"
            if artificial_stall:
                process.send_signal(signal.SIGSTOP)
                _, status = os.waitpid(process.pid, os.WUNTRACED)
                assert os.WIFSTOPPED(status)
            try:
                errors = raw_lock_errors(database)
                assert all(error["code"] == sqlite3.SQLITE_BUSY for error in errors.values())
                with TestClient(create_app(database)) as client, ThreadPoolExecutor(max_workers=2) as workers:
                    get_future = workers.submit(http, client, "GET")
                    cancel_future = workers.submit(http, client, "POST", "/cancel")
                    if not artificial_stall:
                        sleep(0.35)
                        release_gate(reader)
                        assert reader.wait(timeout=3) == 0
                    get = get_future.result(timeout=8)
                    cancel = cancel_future.result(timeout=8)
            finally:
                if artificial_stall:
                    release_gate(reader)
                    assert reader.wait(timeout=3) == 0
                    process.send_signal(signal.SIGCONT)
        if artificial_stall:
            assert (get["status"], cancel["status"]) == (500, 500)
            assert min(get["elapsed_ms"], cancel["elapsed_ms"]) >= 4_000
        else:
            assert (get["status"], cancel["status"]) == (200, 202)
        await_gate(process, "STEP_RESULT_COMMITTED")
        assert process.wait(timeout=3) == 0
    final_step = db_step(database)
    assert final_step["status"] == "SUCCEEDED" and json.loads(final_step["result_json"])["exit_code"] == 0
    return {"kernel_locks": locks, "zero_timeout_sqlite": errors, "GET": get, "cancel": cancel,
            "explicit_SIGSTOP": artificial_stall, "step_before": previous, "step_after": final_step["status"]}


if sys.argv[1:] and sys.argv[1] == "writer":
    writer(Path(sys.argv[2]), sys.argv[3])
elif sys.argv[1:] and sys.argv[1] == "reader":
    with open_database(Path(sys.argv[2]) / "project.sqlite", read_only=True) as connection:
        connection.execute("BEGIN")
        assert connection.execute("SELECT status FROM run_step").fetchone()[0] == "RUNNING"
        gate("READ_LOCK_HELD")
else:
    result = {"sqlite_version": sqlite3.sqlite_version}
    for scenario, probe in [
        ("reserved", reserved_probe),
        ("pending-release", lambda: pending_probe("pending-release")),
        ("pending-stalled", lambda: pending_probe("pending-stalled")),
    ]:
        result[scenario] = probe()
        print(scenario, json.dumps(result[scenario]), flush=True)
    (ROOT / "probe.json").write_text(json.dumps(result, indent=2) + "\n")
