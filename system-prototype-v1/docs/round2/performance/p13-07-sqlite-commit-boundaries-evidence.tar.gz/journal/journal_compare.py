import hashlib
import json
import shutil
import struct
import sys
from pathlib import Path

from geopilot.domain.step_io import StepResult
from geopilot.persistence.run_repository import get_run, get_run_step, save_run_step, update_run
from geopilot.persistence.schema import open_database


def varint(page, offset):
    value = 0
    for index in range(9):
        byte = page[offset + index]
        value = (value << (8 if index == 8 else 7)) | (byte if index == 8 else byte & 0x7F)
        if index == 8 or byte < 128:
            return value, offset + index + 1


def leaf_rowids(page):
    assert page[0] == 13
    cells = int.from_bytes(page[3:5], "big")
    return [varint(page, varint(page, int.from_bytes(page[i:i + 2], "big"))[1])[0]
            for i in range(8, 8 + 2 * cells, 2)]


def inspect_journal(journal, committed, pages):
    magic, count, nonce, initial_pages, sector, page_size = struct.unpack(">8s5I", journal[:28])
    assert len(committed) == initial_pages * page_size
    assert (len(journal) - sector) % (page_size + 8) == 0
    records = []
    for offset in range(sector, len(journal), page_size + 8):
        page_number = int.from_bytes(journal[offset:offset + 4], "big")
        image = journal[offset + 4:offset + 4 + page_size]
        checksum = int.from_bytes(journal[offset + 4 + page_size:offset + 8 + page_size], "big")
        assert (nonce + sum(image[i] for i in range(page_size - 200, 0, -200))) & 0xFFFFFFFF == checksum
        assert image == committed[(page_number - 1) * page_size:page_number * page_size]
        name, kind = pages[page_number]
        records.append({"page": page_number, "name": name, "type": kind,
                        "sha256": hashlib.sha256(image).hexdigest(),
                        "run_step_rowids": leaf_rowids(image) if name == "run_step" and kind == "leaf" else []})
    return {"magic_hex": magic.hex(), "header_record_count": count, "record_count_by_length": len(records),
            "initial_pages": initial_pages, "sector_bytes": sector, "page_bytes": page_size, "records": records}


def replay(database, committed, pages, label, write):
    copy = output / f"{label}.sqlite"
    shutil.copy2(database, copy)
    journal = copy.with_name(copy.name + "-journal")
    with open_database(copy) as connection:
        assert connection.execute("PRAGMA journal_mode").fetchone()[0] == "delete"
        connection.execute("BEGIN IMMEDIATE")
        write(connection)
        raw = journal.read_bytes()
        assert copy.read_bytes() == committed
        connection.rollback()
    assert copy.read_bytes() == committed
    (output / f"{label}-precommit.journal").write_bytes(raw)
    return inspect_journal(raw, committed, pages)


archived, output = (Path(arg).resolve() for arg in sys.argv[1:])
service = archived / "original-copies/evidence/samples/M/method/warm/service"
database = service / "project.sqlite"
journal = service / "project.sqlite-journal"
committed, original_journal = database.read_bytes(), journal.read_bytes()
run_id = "6b3d6eaa045e45a39c4d9fafb008f6d1"
step_key = "extract_by_threshold"
result_path, = (service / "workspace/tasks").glob(f"*/runs/{run_id}/steps/{step_key}/result.json")
result = StepResult.model_validate_json(result_path.read_bytes())
assert result.exit_code == 0
with open_database(database, read_only=True) as connection:
    pages = {row["pageno"]: (row["name"], row["pagetype"]) for row in connection.execute("SELECT * FROM dbstat")}
    target_rowid = connection.execute("SELECT rowid FROM run_step WHERE run_id = ? AND step_key = ?",
                                      (run_id, step_key)).fetchone()[0]
    assert target_rowid == 27


def save_result(connection):
    step = get_run_step(connection, run_id, step_key)
    assert step.status == "RUNNING" and step.result is None
    save_run_step(connection, step.model_copy(update={
        "status": result.status, "result": result, "log_path": result.log_path,
        "started_at": result.started_at, "finished_at": result.finished_at,
    }))


def save_cancel(connection):
    run = get_run(connection, run_id)
    assert run.execution_status == "RUNNING" and not run.cancel_requested
    update_run(connection, run.model_copy(update={"cancel_requested": True}))


archived_signature = inspect_journal(original_journal, committed, pages)
result_signature = replay(database, committed, pages, "result-upsert", save_result)
cancel_signature = replay(database, committed, pages, "cancel-update", save_cancel)
assert (database.read_bytes(), journal.read_bytes()) == (committed, original_journal)
report = {
    "run_id": run_id, "target_rowid": target_rowid, "database_sha256": hashlib.sha256(committed).hexdigest(),
    "archived_journal_sha256": hashlib.sha256(original_journal).hexdigest(),
    "archived": archived_signature, "result_upsert": result_signature, "cancel_update": cancel_signature,
    "archive_result_page_images_identical": archived_signature["records"] == result_signature["records"],
    "archive_cancel_page_images_identical": archived_signature["records"] == cancel_signature["records"],
}
(output / "journal-comparison.json").write_text(json.dumps(report, indent=2) + "\n")
for label in ("archived", "result_upsert", "cancel_update"):
    print(label, [(row["page"], row["name"], row["run_step_rowids"]) for row in report[label]["records"]])
print("Exact ordered archive/result page-image match", report["archive_result_page_images_identical"])
print("Exact ordered archive/cancel page-image match", report["archive_cancel_page_images_identical"])
