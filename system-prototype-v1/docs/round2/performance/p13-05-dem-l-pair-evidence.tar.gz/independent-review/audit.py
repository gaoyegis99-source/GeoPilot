"""Read-only audit of the completed DEM L strict pair."""
from collections import Counter
from hashlib import sha256
import json
import math
import re
from pathlib import Path
import shlex
from statistics import median
import sys

REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
DOCS = REPO / "docs/round2/performance"
ROOT = REPO / "artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l"
SHARD = ROOT / "dem-l"
BASE_ATTEMPT = SHARD / "base/attempt.7zlasqgn"
CANDIDATE_ATTEMPT = SHARD / "candidate/attempt.53h1my_a"
PAIR = SHARD / "pair.retzu04a/before-after.json"
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
MANIFEST = "a9c670131aa9d4feab76b63e9ad38c75a1822ac0bd8a8bb1808fadc7fa5771ff"
AREA_STEP = "calculate_area_with_equal_area_projection"
POLL_ERROR = {"http_status": 500, "body": {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}}}
RESOURCES = ("cpu_ns", "peak_rss_bytes", "disk_read_bytes", "disk_write_bytes")
METRICS = ("wall_ns", "queue_wall_ns", "execute_steps_wall_ns", "finalize_wall_ns", *RESOURCES, "peak_temp_bytes")
PROOFS = {
    "first_s": ("/tmp/geopilot-p13-05-raster-s-audit.rJKuNw/independent.json",
                "f6c4e2d81e0d269b154a5640c7aa71a4636472174bb841e86290c59c630c437b"),
    "remote_s_rerun": ("/tmp/geopilot-p13-05-remote-s-after-vector-l-audit.Gbk18m/independent.json",
                       "cbb29456d9657978bdd4a59d60f0debdedc7bcb91a38efc5b6a0f08f85c2892b"),
    "dem_m": ("/tmp/geopilot-p13-05-dem-m-pair-attempt-audit.vYP1vW/independent.json",
              "685e02b33b3977545e0c515aff591b7ee1202551f9f82d755506028009f66e42"),
}
THRESHOLD = {"intervals": [{"class_id": 7, "lower": 45, "upper": 45, "include_lower": True, "include_upper": True}]}
STEP_PARAMS = (
    {"radius_pixels": 1}, {}, {"band": 1, "vertical_unit": "metadata", "z_factor": 1.0},
    {"band": 1, "z_factor": 1.0, "terrain_output": "slope", "slope_unit": "degree"}, {},
    {"threshold": THRESHOLD}, {"area_crs": "EPSG:6933"},
)


def digest(raw):
    return sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    with path.open("rb") as stream:
        return [json.loads(line) for line in stream]


def proof(label):
    name, expected = PROOFS[label]
    raw = Path(name).read_bytes()
    assert digest(raw) == expected
    return json.loads(raw)


def observe(value):
    return {"status": "recorded" if value is not None else "unavailable", "value": value}


def distribution(items):
    values = [item["value"] for item in items if item.get("value") is not None]
    return {
        "n": len(values), "coverage": dict(Counter(item["status"] for item in items)), "values": values,
        "median": median(values) if len(values) >= 3 else None,
        "p95": sorted(values)[math.ceil(.95 * len(values)) - 1] if len(values) >= 3 else None,
    }


def check_timeout(row, expected_steps):
    run = row["run_state"]
    assert (row["status"], run["execution_status"], run["check_status"], run["current_step"]) == (
        "FAIL", "FAILED", "NOT_CHECKED", AREA_STEP,
    )
    assert run["run_id"] == row["run_id"] and run["current_report_id"] is None and not run["cancel_requested"]
    error = run["error"]
    assert (error["code"], error["phase"], error["step_key"], error["message"]) == (
        "PROCESS_TIMEOUT", "execute", AREA_STEP, "Process exceeded 60 seconds",
    )
    assert row["exit_code"] == -15 and row["error"]["type"] == "ValueError"
    assert "did not pass execution/checks" in row["error"]["message"]
    assert all(key not in row for key in ("correctness", "v1_completed_checks", "output_bytes"))
    doc = row["telemetry"]
    assert (doc["schema_version"], doc["run_id"], doc["execution_status"], doc["check_status"], doc["exit_code"]) == (
        1, row["run_id"], "FAILED", "NOT_CHECKED", -15,
    )
    steps = row["executed_steps"]
    assert len(steps) == len(doc["steps"]) == len(expected_steps) == 7
    for i, (request, event) in enumerate(zip(steps, doc["steps"], strict=True)):
        key, tool, version = expected_steps[i]
        assert request["step_key"] == event["step_key"] == key
        assert request["tool"] == {"id": tool, "version": version} == {k: event["tool"][k] for k in ("id", "version")}
        assert request["parameters"] == STEP_PARAMS[i]
        failed = i == 6
        expected_status, expected_exit = ("FAILED", -15) if failed else ("SUCCEEDED", 0)
        assert request["status"] == event["status"] == expected_status
        assert request["exit_code"] == event["exit_code"] == expected_exit
        process, = [item for item in event["processes"] if item["phase"] == "execute"]
        assert process["exit_code"] == expected_exit and process["timed_out"] == failed and not process["cancelled"]
        if failed:
            assert process["wall_ns"] >= 60_000_000_000


def metrics(row):
    doc = row["telemetry"]
    return {
        "wall_ns": observe(row["wall_ns"]), "queue_wall_ns": doc["queue_wall_ns"],
        "execute_steps_wall_ns": observe(doc["execute_steps_wall_ns"]), "finalize_wall_ns": observe(doc["finalize_wall_ns"]),
        **doc["resources"], "peak_temp_bytes": row["workspace_size"]["peak_temp_bytes"],
    }


def official_history():
    files = [DOCS / f"p13-04-{kind}-method-{size}-trials.jsonl"
             for kind, size in (("raster", "s"), ("raster", "m"), ("raster", "l"), ("remote", "sm"), ("remote", "l"))]
    rows = [row for f in files for row in jsonl(f)]
    assert len(rows) == len({row["run_id"] for row in rows}) == 84
    same = [row for row in rows if row["family"] == "raster" and row["tier"] == "L"]
    assert len(same) == 14 and {row["manifest_sha256"] for row in same} == {MANIFEST}
    for row in same:
        state = row["run_state"]
        assert (row["status"], state["execution_status"], state["check_status"], state["current_step"]) == (
            "FAIL", "FAILED", "NOT_CHECKED", AREA_STEP,
        )
        assert state["error"]["code"] == "PROCESS_TIMEOUT"
        assert [step["exit_code"] for step in row["telemetry"]["steps"]] == [0] * 6 + [-15]
    return rows, same


def prior_ids(historical, current):
    first = [rid for case in proof("first_s").values() for side in ("base", "candidate") for rid in case[side]["run_ids"]]
    later = [row["run_id"] for side in ("base", "candidate") for row in proof("remote_s_rerun")[side]["observations"]]
    medium = [row["run_id"] for side in ("baseline", "candidate") for row in proof("dem_m")[side]["observations"]]
    previous = first + later + medium + [row["run_id"] for row in historical]
    assert (len(first), len(later), len(medium), len(previous)) == (47, 28, 25, 184)
    assert len(previous + current) == len(set(previous + current))
    return {"P13-04": 84, "first_s": 47, "remote_s_rerun": 28, "dem_m": 25,
            "current_cold": len(current), "combined_unique": len(previous + current)}


CACHES = ("process_cold", "warm")
COLD_PROOF = Path("/tmp/geopilot-p13-05-dem-l-base-cold-audit.8Ey7Wg/independent.json")
COLD_PROOF_SHA = "7a7a82c456339005ddc286576291e24e772a70b67751082ff3df20e17042bb6c"
RECEIPT = "f290b7d264577770445efb0ad192777294df5e9f230050edff595c05ce2455b3"
RUNNER = {
    "run_raster.py": "9a4a9bc061d770c1fce631895bff25f819751e5a98291440f231e5ed267a3729",
    "_raster_metrics.py": "d23eb107cd1ec19eb040ca391831d8028c4523ff783f09314fdc22e05057722e",
    "_raster_reference.py": "eb54e29bbee34e05952e699e4c9b4bc99f3f342ece30773280836eec02cb19a3",
    "_raster_workloads.py": "fa6bc12a43c93487c8159feb7fdf3529ac21b0bc0acaf436fe7a73591b54dd8d",
}


def summarize_group(rows, expected_steps):
    measured = [row for row in rows if row["kind"] == "measurement"]
    assert len(rows) == 7 and len(measured) == 5
    all_readings = [metrics(row) for row in measured]
    run = {field: distribution([record[field] for record in all_readings]) for field in METRICS}
    per_step = {}
    for i, (key, _, _) in enumerate(expected_steps):
        events = [row["telemetry"]["steps"][i] for row in measured]
        per_step[key] = {
            "wall_ns": distribution([observe(event["wall_ns"]) for event in events]),
            **{field: distribution([event["resources"][field] for event in events]) for field in RESOURCES},
        }
    return {
        "warmup_failures": 2, "formal_failures": 5, "formal_successes": 0,
        "success_distribution": {field: distribution([]) for field in METRICS},
        "failed_distributions": run, "failed_step_distributions": per_step,
    }


CANDIDATE = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
BASE_PROOF = Path("/tmp/geopilot-p13-05-dem-l-base-final-audit.nlTqBt/independent.json")
BASE_PROOF_SHA = "121d8afd6a208700e83c5b19bb274c2ae830bcba9521f0df30bf6de207b009b6"
CANDIDATE_COLD_PROOF = Path("/tmp/geopilot-p13-05-dem-l-candidate-cold-audit.Nr2U7w/independent.json")
CANDIDATE_COLD_PROOF_SHA = "a24e78962759296f279406506829dec9b63e6d2d415ff6f367719cd0d942f253"


def readonly_mount(attempt, source, plan):
    disk, command = (attempt / "command.log").read_text().splitlines()
    args = shlex.split(command)
    assert disk.startswith("storage=/dev/sda2 ext4") and plan["image"] in args
    assert args[args.index("--source-commit") + 1] == source and args[args.index("--tiers") + 1] == "L"
    assert args[args.index("--cache") + 1:args.index("--cache") + 3] == list(CACHES)
    mount, = [args[i + 1] for i, item in enumerate(args) if item == "--mount" and ",dst=/inputs," in args[i + 1]]
    assert mount.endswith(",dst=/inputs,readonly")
    return mount


def threshold_file(attempt, row):
    workspace = Path(row["workspace"])
    workspace.relative_to(Path("/scratch/evidence/samples/L/method") / row["cache"])
    path = attempt / workspace.relative_to("/scratch") / "intermediate/extract_by_threshold/threshold_regions.tif"
    assert path.resolve().is_relative_to(attempt.resolve())
    assert path.is_file() and 0 < path.stat().st_size <= 256 * 1024
    payload = path.read_bytes()
    return {"path": str(path), "bytes": len(payload), "sha256": digest(payload)}


def validate_compare(file, before, after):
    label = file.stem
    assert file.with_name(f"{label}.exit-code").read_text().strip() == "0"
    assert file.with_name(f"{label}.stderr").read_bytes() == b""
    command = shlex.split(file.with_name(f"{label}.command").read_text())
    assert "--require-runtime-configuration" in command
    for key, expected in (("before", before), ("after", after)):
        assert Path(command[command.index(f"--{key}") + 1]) == Path(expected["attempt"]) / "evidence"
    result = read(file)
    assert (result["status"], result["before_source"], result["after_source"], result["candidate_all_measurements_pass"]) == (
        "MATCHED_EVIDENCE", before["source"], after["source"], False,
    )
    assert result["same_source"] == (before["source"] == after["source"])
    assert result["runtime_configuration"] == {
        "level": "application_config_and_python_proj", "schema_version": 1, "sha256": RECEIPT,
    }
    assert len(result["groups"]) == 2 and {g["group"][2] for g in result["groups"]} == set(CACHES)
    for group in result["groups"]:
        cache = group["group"][2]
        assert group["group"] == ["L", "method", cache, "p13-01", "method"]
        assert group["step_parameter_evidence"] == "normalized_step_requests"
        assert group["successful_sample_deltas"] == {}
        for label, side in (("before", before), ("after", after)):
            summary = group[label]
            assert summary["counts"] == {"PASS": 0, "FAIL": 5, "NOT_RUN": 0}
            assert summary["failure_codes"] == {"PROCESS_TIMEOUT": 5}
            for field in ("wall_ns", "peak_rss_bytes", "peak_temp_bytes"):
                assert summary[field]["PASS"] == {"samples": 0, "partial": 0, "median": None, "p95_nearest_rank": None}
                ref = side["groups"][cache]["failed_distributions"][field]
                assert summary[field]["FAIL"] == {
                    "samples": ref["n"], "partial": ref["coverage"].get("partial", 0),
                    "median": ref["median"], "p95_nearest_rank": ref["p95"],
                }
    return {"path": str(file), "sha256": digest(file.read_bytes()), "status": result["status"]}


def validate_side(attempt, source, historic, historic_input, expected_steps, plan):
    assert (attempt.parent / "COMPLETED").read_text().strip() == attempt.name
    assert (attempt / "exit-code").read_text().strip() == "1"
    mount = readonly_mount(attempt, source, plan)
    evidence = attempt / "evidence"
    report_file, receipt_file, trials = (evidence / name for name in ("report.json", "runtime-configuration.json", "trials.jsonl"))
    report, receipt = read(report_file), read(receipt_file)
    assert (report["mode"], report["status"], report["environment"]["commit"], report["family"]) == ("formal", "FAIL", source, "raster")
    assert not report.get("error") and report["implementation_sha256"] == RUNNER
    assert re.sub(r"\[.*\]", "", report["environment"]["storage"]["mount_source_and_filesystem"]) == "/dev/sda2 ext4"
    assert set(report["inputs"]) == {"L"}
    inputs = report["inputs"]["L"]
    assert inputs["directory"] == "/inputs/L" and inputs["generation_ns"] is None
    assert inputs["manifest_sha256"] == MANIFEST and inputs["reference"] == historic_input["reference"]
    assert inputs["first_fingerprints"] == inputs["last_fingerprints"] == historic_input["first_fingerprints"] == historic_input["last_fingerprints"]
    assert receipt["schema_version"] == 1 and receipt["report_files"] == {"report.json": digest(report_file.read_bytes())}
    assert receipt["before"] == receipt["after"] and receipt["before"]["sha256"] == RECEIPT
    canonical = json.dumps({key: value for key, value in receipt["before"].items() if key != "sha256"},
                           ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False)
    assert digest(canonical.encode("ascii")) == RECEIPT

    raw = trials.read_bytes().splitlines(keepends=True)
    assert len(raw) == 14 and all(line.endswith(b"\n") for line in raw)
    rows = [json.loads(line) for line in raw]
    assert [(row["cache"], row["index"]) for row in rows] == [(cache, i) for cache in CACHES for i in range(1, 8)]
    assert all(len({row[field] for row in rows}) == 14 for field in ("task_id", "plan_id", "run_id", "workspace"))
    samples = []
    artifacts = []
    for row in rows:
        index, cache = row["index"], row["cache"]
        assert (row["kind"], row["sample_id"]) == ("warmup" if index <= 2 else "measurement", f"raster/L/method/{cache}/{index:02d}")
        assert (row["family"], row["tier"], row["workload"], row["manifest_sha256"], row.get("worker_exit_code")) == (
            "raster", "L", "method", MANIFEST, 0 if cache == "process_cold" else None,
        )
        assert row["source_input_bytes"] == historic["source_input_bytes"]
        assert row["logical_source_input_bytes"] == historic["logical_source_input_bytes"] == historic_input["reference"]["raw_input_bytes"]
        assert all(row[key] == historic[key] for key in ("method", "critical_options", "confirmed_parameters", "parameters_sha256"))
        parameters = json.dumps(row["confirmed_parameters"], sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
        assert row["parameters_sha256"] == digest(parameters)
        errors = row.get("status_poll_errors", [])
        assert all(error == POLL_ERROR for error in errors)
        check_timeout(row, expected_steps)
        samples.append({
            "sample_id": row["sample_id"], "run_id": row["run_id"], "task_id": row["task_id"], "plan_id": row["plan_id"],
            "kind": row["kind"], "status_poll_errors": errors, "state": row["run_state"], "steps": row["executed_steps"],
            "readings": metrics(row),
        })
        artifacts.append({"cache": cache, "index": index, **threshold_file(attempt, row)})

    assert report["expected_groups"] == [{"tier": "L", "workload": "method", "cache": cache} for cache in CACHES]
    assert len(report["groups"]) == 2
    groups = {}
    for group, cache in zip(report["groups"], CACHES, strict=True):
        assert (group["cache"], group["tier"], group["workload"], group["expected_trials"], group["observed_trials"],
                group["trial_failures"], group["interrupted"], group["warm_worker_exit"]) == (
            cache, "L", "method", 7, 7, 7, False, None if cache == "process_cold" else 0,
        )
        assert group["input_fingerprints_before"] == group["input_fingerprints_after"] == inputs["first_fingerprints"]
        assert group["operations"]["method"] == {"passed": 0, "failed": 5, "missing": 0}
        shard = [row for row in rows if row["cache"] == cache]
        assert len({row["worker_pid"] for row in shard}) == (7 if cache == "process_cold" else 1)
        groups[cache] = summarize_group(shard, expected_steps)
    result = {
        "source": source, "attempt": str(attempt), "container_exit": 1, "readonly_inputs": mount,
        "inputs": inputs["first_fingerprints"], "runtime_configuration_sha256": RECEIPT,
        "cold_prefix_sha256": digest(b"".join(raw[:7])), "files": {str(path): digest(path.read_bytes()) for path in (trials, report_file, receipt_file)},
        "groups": groups, "samples": samples, "threshold_intermediates": artifacts,
        "status_poll_errors": sum(len(row["status_poll_errors"]) for row in samples),
    }
    result["self_comparison"] = validate_compare(attempt / "self-comparison.json", result, result)
    return result


def main(output):
    plan = read(ROOT / "plan.json")
    assert plan["commits"] == {"base": BASE, "candidate": CANDIDATE}
    assert plan["input_manifest_sha256"]["dem-l"] == MANIFEST and plan["disk"][:2] == ["/dev/sda2", "ext4"]
    hist, hist_l = official_history()
    historic = hist_l[0]
    expected_steps = [(step["step_key"], step["tool"]["id"], step["tool"]["version"]) for step in historic["telemetry"]["steps"]]
    historic_input = read(DOCS / "p13-04-raster-method-l-report.json")["inputs"]["L"]
    assert historic_input["manifest_sha256"] == MANIFEST
    base = validate_side(BASE_ATTEMPT, BASE, historic, historic_input, expected_steps, plan)
    candidate = validate_side(CANDIDATE_ATTEMPT, CANDIDATE, historic, historic_input, expected_steps, plan)
    assert base["inputs"] == candidate["inputs"] and base["readonly_inputs"] == candidate["readonly_inputs"]
    assert all(a["steps"] == b["steps"] for a, b in zip(base["samples"], candidate["samples"], strict=True))

    assert digest(BASE_PROOF.read_bytes()) == BASE_PROOF_SHA
    previous_base = read(BASE_PROOF)
    assert all(base[field] == previous_base[field] for field in ("cold_prefix_sha256", "groups", "samples"))
    assert digest(CANDIDATE_COLD_PROOF.read_bytes()) == CANDIDATE_COLD_PROOF_SHA
    previous_candidate = read(CANDIDATE_COLD_PROOF)
    assert candidate["cold_prefix_sha256"] == previous_candidate["candidate_cold_raw_sha256"]
    assert candidate["samples"][:7] == previous_candidate["samples"]
    assert candidate["groups"]["process_cold"]["failed_distributions"] == previous_candidate["candidate_failed_distributions"]
    assert candidate["groups"]["process_cold"]["failed_step_distributions"] == previous_candidate["candidate_failed_step_distributions"]
    all_artifacts = base["threshold_intermediates"] + candidate["threshold_intermediates"]
    assert len(all_artifacts) == len({item["path"] for item in all_artifacts}) == 28
    assert {(item["bytes"], item["sha256"]) for item in all_artifacts} == {
        (128239, "7a62aed10a269d83989d10d9f35b12527ef4be1be523e51bd0300649549213e8"),
    }
    samples = base["samples"] + candidate["samples"]
    assert len(samples) == len({row["task_id"] for row in samples}) == len({row["plan_id"] for row in samples}) == 28
    identity = prior_ids(hist, [row["run_id"] for row in samples])
    assert identity.pop("current_cold") == 28
    identity["dem_l_pair"] = 28
    assert identity["combined_unique"] == 212
    pair = validate_compare(PAIR, base, candidate)
    assert (base["status_poll_errors"], candidate["status_poll_errors"]) == (17, 28)

    result = {
        "scope": "DEM L both completed sides only", "input_manifest_sha256": MANIFEST,
        "pair": pair, "base": base, "candidate": candidate, "run_identity": identity,
        "successful_pair_deltas": {}, "complete_artifact_correctness_verified": False,
    }
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("both complete exit1; strict pair and self-comparisons MATCHED_EVIDENCE, receipts", RECEIPT)
    print("28 same-timeout attempts, six prior steps exit0, area timeout -15; no success percentiles/deltas")
    for label, side in (("base", base), ("candidate", candidate)):
        print(label, "HTTP status-read errors", side["status_poll_errors"], "cold-prefix SHA", side["cold_prefix_sha256"])
        for cache, group in side["groups"].items():
            d = group["failed_distributions"]
            print(label, cache, "failed wall", d["wall_ns"], "RSS", d["peak_rss_bytes"], "temp", d["peak_temp_bytes"])
            area = group["failed_step_distributions"][AREA_STEP]
            print(label, cache, "area step", area["wall_ns"], "area RSS", area["peak_rss_bytes"])
    print("28 threshold intermediate TIFFs match byte count and SHA; no complete artifact validation", all_artifacts[0]["sha256"])
    print("cold prefixes match sealed proofs; IDs disjoint", identity, "pair SHA", pair["sha256"])


if __name__ == "__main__":
    main(Path(sys.argv[1]))
