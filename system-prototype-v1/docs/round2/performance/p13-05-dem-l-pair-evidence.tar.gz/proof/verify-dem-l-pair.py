"""Verify the complete DEM L formal pair without live services."""

from hashlib import sha256
import json
from pathlib import Path
import sys

from replay import read_json, replay


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def verify_classification(root, role, reference):
    side = root / "dem-l" / role
    attempt = side / (side / "COMPLETED").read_text().strip()
    cold = read_json(root / "proof" / f"{role}-cold.json")
    lines = (attempt / "evidence/trials.jsonl").read_bytes().splitlines(keepends=True)
    assert len(lines) == 14 and sha256(b"".join(lines[:7])).hexdigest() == cold["samples_sha256"]
    rows = [json.loads(line) for line in lines]
    relative = reference["source"]["run_relative_path"]
    request_keys = set()
    for row in rows:
        state = row["run_state"]
        error = state["error"]
        assert (row["status"], state["execution_status"], state["check_status"]) == ("FAIL", "FAILED", "NOT_CHECKED")
        assert (error["code"], error["step_key"]) == ("PROCESS_TIMEOUT", "calculate_area_with_equal_area_projection")
        assert not row.get("v1_completed_checks") and "correctness" not in row
        assert len(row["executed_steps"]) == 7
        assert all((step["status"], step["exit_code"]) == ("SUCCEEDED", 0) for step in row["executed_steps"][:-1])
        assert row["executed_steps"][-1]["exit_code"] == -15
        request_keys.add(json.dumps([row["method"], row["confirmed_parameters"], row["executed_steps"]],
                                    sort_keys=True, separators=(",", ":")))
        workspace = attempt / Path(row["workspace"]).relative_to("/scratch")
        assert workspace.resolve(strict=True) == workspace and workspace.name == row["run_id"]
        request = read_json(workspace / "steps/extract_by_threshold/request.json")
        assert request["run_id"] == row["run_id"]
        assert request["output_targets"]["threshold_regions"]["path"] == relative
        classification = workspace / relative
        assert classification.stat().st_size == reference["bytes"] and digest(classification) == reference["sha256"]
    assert len(request_keys) == 1
    return request_keys


def main(root):
    replay(root, "dem-l")
    pair, = (path for path in (root / "dem-l").glob("pair.*") if (path / "before-after.json").is_file())
    result = read_json(pair / "before-after.json")
    assert result["status"] == "MATCHED_EVIDENCE" and not result["candidate_all_measurements_pass"]
    for group in result["groups"]:
        assert group["before"]["counts"] == group["after"]["counts"] == {"PASS": 0, "FAIL": 5, "NOT_RUN": 0}
        assert not group["successful_sample_deltas"]
    fixtures = root / "fixtures"
    reference = next(item for item in read_json(fixtures / "manifest.json")["fixtures"] if item["id"] == "dem-l")
    assert digest(fixtures / reference["path"]) == reference["sha256"]
    assert verify_classification(root, "base", reference) == verify_classification(root, "candidate", reference)
    print("All 28 runs reached area timeout after six successful steps; classified intermediate TIFFs and parameters match.")
    print("Both measurement groups have zero successes and no successful-run deltas.")


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve(strict=True))
