"""Copy only sealed candidate raster evidence and the registered file groups."""

import json
from pathlib import Path
import re
from shutil import copyfile
import sys

from fingerprint import copy_file_group


def copy(source, target):
    assert source.is_file() and source.resolve(strict=True) == source
    target.parent.mkdir(parents=True, exist_ok=True)
    copyfile(source, target)


def main(results, destination):
    sources = {
        "dem-s": results / "p13-05-raster-pairs.a2d2e68.TONYtP",
        "dem-m": results / "p13-05-raster-pairs.a2d2e68.after-vector-l",
        "remote-s": results / "p13-05-raster-pairs.a2d2e68.after-vector-l",
    }
    for case, root in sources.items():
        candidate = root / case / "candidate"
        marker = candidate / "COMPLETED"
        name = marker.read_text().strip()
        assert re.fullmatch(r"attempt\.[a-z0-9_]+", name)
        source = candidate / name
        target = destination / "cases" / case / name
        copy(marker, target.parent / "COMPLETED")
        for relative in ("evidence/report.json", "evidence/runtime-configuration.json", "evidence/trials.jsonl"):
            copy(source / relative, target / relative)
        raw = (source / "evidence/trials.jsonl").read_bytes()
        rows = [json.loads(line) for line in raw.splitlines()]
        assert len(rows) == 14
        for row in rows:
            relative = Path(row["workspace"]).relative_to("/scratch")
            run, copied_run = source / relative, target / relative
            assert run.resolve(strict=True) == run and run.is_relative_to(source) and run.name == row["run_id"]
            for filename in ("outputs/manifest.json", "checks/report.json"):
                copy(run / filename, copied_run / filename)
            manifest = json.loads((run / "outputs/manifest.json").read_bytes())
            for entry in manifest["artifacts"].values():
                file = Path(entry["path"])
                assert not file.is_absolute() and ".." not in file.parts
                origin, output = run / file, copied_run / file
                assert origin.resolve(strict=True) == origin
                output.parent.mkdir(parents=True, exist_ok=True)
                copy_file_group(origin, output, expected_digest=entry["fingerprint"])
        assert (source / "evidence/trials.jsonl").read_bytes() == raw
        print(case, name, "copied fourteen sets of published artifacts and their receipts")


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve(strict=True), Path(sys.argv[2]).resolve(strict=True))
