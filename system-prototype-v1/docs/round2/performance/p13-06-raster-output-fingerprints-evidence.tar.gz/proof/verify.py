"""Verify actual registered raster file groups and their run receipts."""

from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from tempfile import TemporaryDirectory

from fingerprint import copy_file_group, fingerprint_file


COMMIT = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
CASES = {
    "dem-s": ("raster", "S", 3),
    "dem-m": ("raster", "M", 3),
    "remote-s": ("remote_sensing", "S", 10),
}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def observe(folder, family, tier, expected_roles, all_ids):
    attempt_name = (folder / "COMPLETED").read_text().strip()
    assert re.fullmatch(r"attempt\.[a-z0-9_]+", attempt_name)
    attempt = folder / attempt_name
    evidence = attempt / "evidence"
    report = json.loads((evidence / "report.json").read_bytes())
    receipt = json.loads((evidence / "runtime-configuration.json").read_bytes())
    assert report["environment"]["commit"] == COMMIT and report["family"] == family
    assert receipt["schema_version"] == 1 and receipt["before"] == receipt["after"]
    assert receipt["report_files"] == {"report.json": digest(evidence / "report.json")}
    for group in report["groups"]:
        assert group["tier"] == tier and group["expected_trials"] == group["observed_trials"] == 7
        assert not group["interrupted"]
    raw = (evidence / "trials.jsonl").read_bytes()
    assert raw.endswith(b"\n")
    rows = [json.loads(line) for line in raw.splitlines()]
    assert [(row["cache"], row["index"], row["kind"]) for row in rows] == [
        (cache, n, "warmup" if n <= 2 else "measurement") for cache in ("process_cold", "warm") for n in range(1, 8)
    ]

    fingerprints = defaultdict(Counter)
    sizes = defaultdict(set)
    descriptors = defaultdict(set)
    requests, correctness, check_outcomes = set(), set(), set()
    artifact_count = observation_failures = 0
    example = None
    for row in rows:
        state = row["run_state"]
        run_id = row["run_id"]
        assert run_id not in all_ids and state["run_id"] == run_id
        all_ids.add(run_id)
        assert (state["execution_status"], state["check_status"]) == ("SUCCEEDED", "PASSED")
        assert (row["family"], row["tier"], row["manifest_sha256"]) == (
            family, tier, report["inputs"][tier]["manifest_sha256"],
        )
        assert all((step["status"], step["exit_code"]) == ("SUCCEEDED", 0) for step in row["executed_steps"])
        if row["status"] == "FAIL":
            assert row["error"]["type"] == "StatusObservationFailure"
            observation_failures += 1
        else:
            assert row["status"] == "PASS"
        requests.add(canonical([row["method"], row["manifest_sha256"], row["confirmed_parameters"], row["executed_steps"]]))
        correctness.add(canonical(row["correctness"]))
        run = attempt / Path(row["workspace"]).relative_to("/scratch")
        assert run.resolve(strict=True) == run and run.is_relative_to(attempt) and run.name == run_id
        check = json.loads((run / "checks/report.json").read_bytes())
        assert (check["run_id"], check["status"], check["completed_rules"]) == (run_id, "PASSED", row["v1_completed_checks"])
        assert all(rule["passed"] for rule in check["rules"].values())
        check_outcomes.add(canonical({key: rule["passed"] for key, rule in check["rules"].items()}))
        manifest = json.loads((run / "outputs/manifest.json").read_bytes())
        assert len(manifest["artifacts"]) == expected_roles
        for role, entry in manifest["artifacts"].items():
            path = run / entry["path"]
            assert path.resolve(strict=True) == path and path.is_relative_to(run)
            observed = fingerprint_file(path)
            assert observed.digest == entry["fingerprint"], (folder.name, run_id, role)
            fingerprints[role][observed.digest] += 1
            sizes[role].add(observed.size_bytes)
            descriptors[role].add(canonical({key: value for key, value in entry.items() if key != "fingerprint"}))
            artifact_count += 1
            if example is None and role == "threshold_regions":
                example = path, observed.digest
    assert len(fingerprints) == expected_roles and all(sum(counts.values()) == 14 for counts in fingerprints.values())
    assert len(requests) == len(correctness) == len(check_outcomes) == 1
    assert all(len(values) == 1 for values in descriptors.values())
    return {
        "case": folder.name,
        "attempt": attempt_name,
        "commit": COMMIT,
        "raw_samples_sha256": sha256(raw).hexdigest(),
        "receipt_configuration_sha256": receipt["before"]["sha256"],
        "artifact_count": artifact_count,
        "verified_terminal_runs": len(rows),
        "status_observation_failures": observation_failures,
        "distinct_request_identities": len(requests),
        "distinct_independent_correctness_reports": len(correctness),
        "distinct_check_outcomes": len(check_outcomes),
        "roles": {role: {"distinct_fingerprints": len(counts), "counts": dict(sorted(counts.items())), "bytes": sorted(sizes[role])}
                  for role, counts in sorted(fingerprints.items())},
    }, example


def sidecar_probe(source, original):
    xml = b'<PAMDataset><Metadata><MDI key="PROBE">copy only</MDI></Metadata></PAMDataset>\n'
    with TemporaryDirectory(prefix="geopilot-raster-fingerprint-", dir="/dev/shm") as directory:
        copy = Path(directory) / source.name
        copy_file_group(source, copy, expected_digest=original)
        assert fingerprint_file(copy).digest == original
        before = digest(copy)
        sidecar = copy.with_suffix(copy.suffix + ".aux.xml")
        with sidecar.open("xb") as stream:
            stream.write(xml)
        altered = fingerprint_file(copy).digest
        assert digest(copy) == before and altered != original
        sidecar.unlink()
        assert fingerprint_file(copy).digest == original
    return {"main_sha256": before, "original_group": original, "group_with_sidecar": altered, "restored_group": original}


def main(root):
    all_ids = set()
    reports = []
    for case, spec in CASES.items():
        report, example = observe(root / "cases" / case, *spec, all_ids)
        reports.append(report)
        if case == "dem-s":
            sidecar = sidecar_probe(*example)
    print(json.dumps({
        "verified_runs": len(all_ids),
        "verified_artifact_groups": sum(report["artifact_count"] for report in reports),
        "cases": reports,
        "sidecar_copy_probe": sidecar,
    }, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve(strict=True))
