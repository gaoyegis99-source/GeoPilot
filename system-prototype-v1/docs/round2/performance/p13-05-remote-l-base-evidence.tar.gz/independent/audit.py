"""Read-only audit of the completed remote sensing L baseline."""
from collections import Counter
from hashlib import sha256
from io import BytesIO
import json
import math
import re
from pathlib import Path
import shlex
from statistics import median
import subprocess
import tarfile
import sys

REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
DOCS = REPO / "docs/round2/performance"
ROOT = REPO / "artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l"
ATTEMPT = ROOT / "remote-l/base/attempt.pr0gnzp2"
TRIALS = ATTEMPT / "evidence/trials.jsonl"
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
MANIFEST = "7ca5d30de46b40955845aadb312ff02b6653a11fc708d8aeaaf8d404fb769e04"
FINAL_STEP = "calculate_change"
POLL_ERROR = {"http_status": 500, "body": {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}}}
RESOURCES = ("cpu_ns", "peak_rss_bytes", "disk_read_bytes", "disk_write_bytes")
METRICS = ("wall_ns", "queue_wall_ns", "execute_steps_wall_ns", "finalize_wall_ns", *RESOURCES, "peak_temp_bytes")
PROOFS = {
    "first_s": ("/tmp/geopilot-p13-05-raster-s-audit.rJKuNw/independent.json",
                "f6c4e2d81e0d269b154a5640c7aa71a4636472174bb841e86290c59c630c437b"),
    "remote_s_rerun": ("/tmp/geopilot-p13-05-remote-s-after-vector-l-audit.Gbk18m/independent.json",
                       "cbb29456d9657978bdd4a59d60f0debdedc7bcb91a38efc5b6a0f08f85c2892b"),
    "dem_m": ("/tmp/geopilot-p13-05-dem-m-pair-attempt-audit.vYP1vW/independent.json",
              "685e02b33b3977545e0c515aff591b7ee1202551f9f82d755506028009f66e42"),
}
DEM_L_PROOF = Path("/tmp/geopilot-p13-05-dem-l-final-pair-audit.EppAOX/independent.json")
DEM_L_PROOF_SHA = "8f0c3286971b1c44239eddaf2afd24fa71b9a9128d4961530ab3c438c0b61995"
CLASSIFICATION_SOURCE = DOCS / "p13-04-remote-l-classification-source.json"


def classification_reference(historical):
    frozen = read(CLASSIFICATION_SOURCE)
    source, = [row for row in historical if row["run_id"] == frozen["source_run_id"]]
    assert source["run_state"] == frozen["source_run_terminal_state"]
    assert frozen["fixture_manifest_sha256"] == MANIFEST
    assert frozen["source_step"] == FINAL_STEP and frozen["source_tool"] == source["telemetry"]["steps"][-1]["tool"]
    assert (frozen["shape"], frozen["valid_class_counts"], frozen["masked_pixels"]) == (
        [3072, 3072], {"1": 1572864, "2": 1572864, "3": 1572864}, 4718592,
    )
    return frozen


def staged_classification(row, frozen):
    workspace = Path(row["workspace"])
    workspace.relative_to(Path("/scratch/evidence/samples/L/method") / row["cache"])
    root = ATTEMPT / workspace.relative_to("/scratch") / "intermediate/calculate_change"
    matches = sorted(root.glob(".land-use-*/.ndvi-classification-*/classes.tif"))
    assert len(matches) <= 1
    if not matches:
        return {"status": "not_present_after_terminal_timeout"}
    path, = matches
    assert path.resolve().is_relative_to(ATTEMPT.resolve())
    assert path.is_file() and 0 < path.stat().st_size <= 256 * 1024
    payload = path.read_bytes()
    assert payload[:4] in (b"II*\0", b"MM\0*")
    return {
        "status": "matching_archived_staged_classification" if (len(payload), digest(payload)) == (frozen["bytes"], frozen["sha256"])
                  else "different_from_archived_staged_classification",
        "path": str(path), "bytes": len(payload), "sha256": digest(payload),
    }


def digest(raw):
    return sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    with path.open("rb") as stream:
        return [json.loads(line) for line in stream]


def proof(label):
    name, expected = PROOFS[label]
    raw = Path(name).read_bytes()
    assert digest(raw) == expected
    return json.loads(raw)


def observe(value):
    return {"status": "recorded" if value is not None else "unavailable", "value": value}


def distribution(items):
    values = [item["value"] for item in items if item.get("value") is not None]
    return {
        "n": len(values), "coverage": dict(Counter(item["status"] for item in items)), "values": values,
        "median": median(values) if len(values) >= 3 else None,
        "p95": sorted(values)[math.ceil(.95 * len(values)) - 1] if len(values) >= 3 else None,
    }


def check_timeout(row, expected_steps, expected_params):
    run = row["run_state"]
    assert (row["status"], run["execution_status"], run["check_status"], run["current_step"]) == (
        "FAIL", "FAILED", "NOT_CHECKED", FINAL_STEP,
    )
    assert run["run_id"] == row["run_id"] and run["current_report_id"] is None and not run["cancel_requested"]
    error = run["error"]
    assert (error["code"], error["phase"], error["step_key"], error["message"]) == (
        "PROCESS_TIMEOUT", "execute", FINAL_STEP, "Process exceeded 60 seconds",
    )
    assert row["exit_code"] == -15 and row["error"]["type"] == "ValueError"
    assert "did not pass execution/checks" in row["error"]["message"]
    assert all(key not in row for key in ("correctness", "v1_completed_checks", "output_bytes"))
    doc = row["telemetry"]
    assert (doc["schema_version"], doc["run_id"], doc["execution_status"], doc["check_status"], doc["exit_code"]) == (
        1, row["run_id"], "FAILED", "NOT_CHECKED", -15,
    )
    steps = row["executed_steps"]
    assert len(steps) == len(doc["steps"]) == len(expected_steps) == 8
    for i, (request, event) in enumerate(zip(steps, doc["steps"], strict=True)):
        key, tool, version = expected_steps[i]
        assert request["step_key"] == event["step_key"] == key
        assert request["tool"] == {"id": tool, "version": version} == {k: event["tool"][k] for k in ("id", "version")}
        assert request["parameters"] == expected_params[i]
        failed = i == 7
        expected_status, expected_exit = ("FAILED", -15) if failed else ("SUCCEEDED", 0)
        assert request["status"] == event["status"] == expected_status
        assert request["exit_code"] == event["exit_code"] == expected_exit
        process, = [item for item in event["processes"] if item["phase"] == "execute"]
        assert process["exit_code"] == expected_exit and process["timed_out"] == failed and not process["cancelled"]
        if failed:
            assert process["wall_ns"] >= 60_000_000_000


def metrics(row):
    doc = row["telemetry"]
    return {
        "wall_ns": observe(row["wall_ns"]), "queue_wall_ns": doc["queue_wall_ns"],
        "execute_steps_wall_ns": observe(doc["execute_steps_wall_ns"]), "finalize_wall_ns": observe(doc["finalize_wall_ns"]),
        **doc["resources"], "peak_temp_bytes": row["workspace_size"]["peak_temp_bytes"],
    }


def official_history():
    files = [DOCS / f"p13-04-{kind}-method-{size}-trials.jsonl"
             for kind, size in (("raster", "s"), ("raster", "m"), ("raster", "l"), ("remote", "sm"), ("remote", "l"))]
    rows = [row for f in files for row in jsonl(f)]
    assert len(rows) == len({row["run_id"] for row in rows}) == 84
    same = [row for row in rows if row["family"] == "remote_sensing" and row["tier"] == "L"]
    assert len(same) == 14 and {row["manifest_sha256"] for row in same} == {MANIFEST}
    for row in same:
        state = row["run_state"]
        assert (row["status"], state["execution_status"], state["check_status"], state["current_step"]) == (
            "FAIL", "FAILED", "NOT_CHECKED", FINAL_STEP,
        )
        assert state["error"]["code"] == "PROCESS_TIMEOUT"
        assert [step["exit_code"] for step in row["telemetry"]["steps"]] == [0] * 7 + [-15]
    return rows, same


def prior_ids(historical, current):
    first = [rid for case in proof("first_s").values() for side in ("base", "candidate") for rid in case[side]["run_ids"]]
    later = [row["run_id"] for side in ("base", "candidate") for row in proof("remote_s_rerun")[side]["observations"]]
    medium = [row["run_id"] for side in ("baseline", "candidate") for row in proof("dem_m")[side]["observations"]]
    assert digest(DEM_L_PROOF.read_bytes()) == DEM_L_PROOF_SHA
    dem_l = [row["run_id"] for side in ("base", "candidate") for row in read(DEM_L_PROOF)[side]["samples"]]
    previous = first + later + medium + dem_l + [row["run_id"] for row in historical]
    assert (len(first), len(later), len(medium), len(dem_l), len(previous)) == (47, 28, 25, 28, 212)
    assert len(previous + current) == len(set(previous + current))
    return {"P13-04": 84, "first_s": 47, "remote_s_rerun": 28, "dem_m": 25, "dem_l": 28,
            "current_cold": len(current), "combined_unique": len(previous + current)}


CACHES = ("process_cold", "warm")
COLD_PROOF = Path("/tmp/geopilot-p13-05-remote-l-base-cold-audit.bqYvh7/independent.json")
COLD_PROOF_SHA = "a7df2e90d3aa2e92e44c09dd876f3d35a214a88fa80015e9c03a0d6190b2ed97"
RECEIPT = "f290b7d264577770445efb0ad192777294df5e9f230050edff595c05ce2455b3"
RUNNER = {
    "run_raster.py": "9a4a9bc061d770c1fce631895bff25f819751e5a98291440f231e5ed267a3729",
    "_raster_metrics.py": "d23eb107cd1ec19eb040ca391831d8028c4523ff783f09314fdc22e05057722e",
    "_raster_reference.py": "eb54e29bbee34e05952e699e4c9b4bc99f3f342ece30773280836eec02cb19a3",
    "_raster_workloads.py": "fa6bc12a43c93487c8159feb7fdf3529ac21b0bc0acaf436fe7a73591b54dd8d",
}


def summarize_group(rows, expected_steps):
    measured = [row for row in rows if row["kind"] == "measurement"]
    assert len(rows) == 7 and len(measured) == 5
    all_readings = [metrics(row) for row in measured]
    run = {field: distribution([record[field] for record in all_readings]) for field in METRICS}
    per_step = {}
    for i, (key, _, _) in enumerate(expected_steps):
        events = [row["telemetry"]["steps"][i] for row in measured]
        per_step[key] = {
            "wall_ns": distribution([observe(event["wall_ns"]) for event in events]),
            **{field: distribution([event["resources"][field] for event in events]) for field in RESOURCES},
        }
    return {
        "warmup_failures": 2, "formal_failures": 5, "formal_successes": 0,
        "success_distribution": {field: distribution([]) for field in METRICS},
        "failed_distributions": run, "failed_step_distributions": per_step,
    }


def validate_self(self_file, groups):
    assert self_file.with_name("self-comparison.exit-code").read_text().strip() == "0"
    assert self_file.with_name("self-comparison.stderr").read_bytes() == b""
    args = shlex.split(self_file.with_name("self-comparison.command").read_text())
    assert "--require-runtime-configuration" in args
    assert all(Path(args[args.index(f"--{side}") + 1]) == ATTEMPT / "evidence" for side in ("before", "after"))
    result = read(self_file)
    assert (result["status"], result["same_source"], result["before_source"], result["after_source"],
            result["candidate_all_measurements_pass"]) == ("MATCHED_EVIDENCE", True, BASE, BASE, False)
    assert result["runtime_configuration"] == {
        "level": "application_config_and_python_proj", "schema_version": 1, "sha256": RECEIPT,
    }
    assert len(result["groups"]) == 2 and {g["group"][2] for g in result["groups"]} == set(CACHES)
    for group in result["groups"]:
        cache = group["group"][2]
        assert group["group"] == ["L", "method", cache, "p13-01", "method"]
        assert group["step_parameter_evidence"] == "normalized_step_requests"
        assert group["before"] == group["after"] and group["successful_sample_deltas"] == {}
        summary = group["before"]
        assert summary["counts"] == {"PASS": 0, "FAIL": 5, "NOT_RUN": 0}
        assert summary["failure_codes"] == {"PROCESS_TIMEOUT": 5}
        for field in ("wall_ns", "peak_rss_bytes", "peak_temp_bytes"):
            assert summary[field]["PASS"] == {"samples": 0, "partial": 0, "median": None, "p95_nearest_rank": None}
            ref = groups[cache]["failed_distributions"][field]
            assert summary[field]["FAIL"] == {
                "samples": ref["n"], "partial": ref["coverage"].get("partial", 0),
                "median": ref["median"], "p95_nearest_rank": ref["p95"],
            }


COLD_ARCHIVE = "system-prototype-v1/docs/round2/performance/p13-05-remote-l-base-cold-evidence.tar.gz"


def staged_change(row):
    workspace = Path(row["workspace"])
    workspace.relative_to(Path("/scratch/evidence/samples/L/method") / row["cache"])
    root = ATTEMPT / workspace.relative_to("/scratch") / "intermediate/calculate_change"
    path, = sorted(root.glob(".land-use-*/change_raster.tif"))
    assert path.resolve().is_relative_to(ATTEMPT.resolve())
    assert path.is_file() and path.stat().st_size == 311039
    raw = path.read_bytes()
    assert raw[:4] in (b"II*\0", b"MM\0*")
    return {"path": str(path), "bytes": len(raw), "sha256": digest(raw)}


def sealed_cold_intermediates(commit, samples, changes):
    raw = subprocess.check_output(["git", "-C", str(REPO), "show", f"{commit}:{COLD_ARCHIVE}"])
    root = ATTEMPT.resolve()
    with tarfile.open(fileobj=BytesIO(raw), mode="r:gz") as archive:
        for sample, change in zip(samples[:7], changes[:7], strict=True):
            for observed in (sample["staged_classification"], change):
                archive_path = "./" + str(Path(observed["path"]).resolve().relative_to(root))
                member = archive.getmember(archive_path)
                assert member.isfile() and member.size == observed["bytes"]
                with archive.extractfile(member) as stream:
                    assert digest(stream.read()) == observed["sha256"]
    return digest(raw)


def main(commit, output):
    assert (ATTEMPT.parent / "COMPLETED").read_text().strip() == ATTEMPT.name
    assert (ATTEMPT / "exit-code").read_text().strip() == "1"
    plan = read(ROOT / "plan.json")
    assert plan["commits"]["base"] == BASE and plan["input_manifest_sha256"]["remote-l"] == MANIFEST
    assert plan["disk"][:2] == ["/dev/sda2", "ext4"]
    store, docker = (ATTEMPT / "command.log").read_text().splitlines()
    args = shlex.split(docker)
    assert store.startswith("storage=/dev/sda2 ext4") and plan["image"] in args
    assert args[args.index("--source-commit") + 1] == BASE and args[args.index("--tiers") + 1] == "L"
    assert args[args.index("--cache") + 1:args.index("--cache") + 3] == list(CACHES)

    hist, historical_l = official_history()
    historic = historical_l[0]
    expected_steps = [(step["step_key"], step["tool"]["id"], step["tool"]["version"])
                      for step in historic["telemetry"]["steps"]]
    config = historic["confirmed_parameters"]
    sensor_pair = {key: config[key] for key in ("first_configuration", "second_configuration")}
    expected_params = ({}, sensor_pair, {}, {}, {}, {}, {"resampling": "nearest"},
                       {"change_threshold": 0.1, "area_crs": "EPSG:6933"})
    historical_input = read(DOCS / "p13-04-remote-method-l-report.json")["inputs"]["L"]
    archived_classes = classification_reference(historical_l)
    assert historical_input["manifest_sha256"] == MANIFEST
    ref = historical_input["reference"]
    assert ref["common_valid_pixels"] == sum(archived_classes["valid_class_counts"].values()) == 4718592

    evidence = ATTEMPT / "evidence"
    report_file, receipt_file = evidence / "report.json", evidence / "runtime-configuration.json"
    report, receipt = read(report_file), read(receipt_file)
    assert (report["mode"], report["status"], report["environment"]["commit"], report["family"]) == (
        "formal", "FAIL", BASE, "remote_sensing",
    )
    assert not report.get("error") and report["implementation_sha256"] == RUNNER
    assert re.sub(r"\[.*\]", "", report["environment"]["storage"]["mount_source_and_filesystem"]) == "/dev/sda2 ext4"
    assert set(report["inputs"]) == {"L"}
    inputs = report["inputs"]["L"]
    assert inputs["directory"] == "/inputs/L" and inputs["generation_ns"] is None
    assert inputs["manifest_sha256"] == MANIFEST and inputs["reference"] == ref
    assert inputs["first_fingerprints"] == inputs["last_fingerprints"] == historical_input["first_fingerprints"] == historical_input["last_fingerprints"]
    assert receipt["schema_version"] == 1 and receipt["report_files"] == {"report.json": digest(report_file.read_bytes())}
    assert receipt["before"] == receipt["after"] and receipt["before"]["sha256"] == RECEIPT
    canonical = json.dumps({key: value for key, value in receipt["before"].items() if key != "sha256"},
                           ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False)
    assert digest(canonical.encode("ascii")) == RECEIPT

    raw = TRIALS.read_bytes().splitlines(keepends=True)
    assert len(raw) == 14 and all(line.endswith(b"\n") for line in raw)
    assert digest(COLD_PROOF.read_bytes()) == COLD_PROOF_SHA
    previous_cold = read(COLD_PROOF)
    assert previous_cold["prefix_complete"] and digest(b"".join(raw[:7])) == previous_cold["raw_prefix_sha256"]
    rows = [json.loads(line) for line in raw]
    assert [(row["cache"], row["index"]) for row in rows] == [(cache, i) for cache in CACHES for i in range(1, 8)]
    assert all(len({row[field] for row in rows}) == 14 for field in ("task_id", "plan_id", "run_id", "workspace"))
    samples, changes = [], []
    for row in rows:
        index, cache = row["index"], row["cache"]
        assert (row["kind"], row["sample_id"]) == (
            "warmup" if index <= 2 else "measurement", f"remote_sensing/L/method/{cache}/{index:02d}",
        )
        assert (row["family"], row["tier"], row["workload"], row["manifest_sha256"], row.get("worker_exit_code")) == (
            "remote_sensing", "L", "method", MANIFEST, 0 if cache == "process_cold" else None,
        )
        assert row["source_input_bytes"] == historic["source_input_bytes"]
        assert row["logical_source_input_bytes"] == historic["logical_source_input_bytes"] == ref["raw_input_bytes"]
        assert all(row[key] == historic[key] for key in ("method", "critical_options", "confirmed_parameters", "parameters_sha256"))
        parameters = json.dumps(row["confirmed_parameters"], sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
        assert row["parameters_sha256"] == digest(parameters)
        errors = row.get("status_poll_errors", [])
        assert all(error == POLL_ERROR for error in errors)
        check_timeout(row, expected_steps, expected_params)
        classes = staged_classification(row, archived_classes)
        assert classes["status"] == "matching_archived_staged_classification"
        samples.append({
            "sample_id": row["sample_id"], "run_id": row["run_id"], "task_id": row["task_id"], "plan_id": row["plan_id"],
            "kind": row["kind"], "status_poll_errors": errors, "state": row["run_state"], "steps": row["executed_steps"],
            "readings": metrics(row), "staged_classification": classes,
        })
        changes.append(staged_change(row))
    assert samples[:7] == previous_cold["samples"]
    assert len({item["sha256"] for item in changes}) == 1
    cold_archive_sha = sealed_cold_intermediates(commit, samples, changes)
    identities = prior_ids(hist, [row["run_id"] for row in rows])
    assert identities.pop("current_cold") == 14
    identities["current"] = 14
    assert identities["combined_unique"] == 226

    assert report["expected_groups"] == [{"tier": "L", "workload": "method", "cache": cache} for cache in CACHES]
    assert len(report["groups"]) == 2
    groups = {}
    for group, cache in zip(report["groups"], CACHES, strict=True):
        assert (group["cache"], group["tier"], group["workload"], group["expected_trials"], group["observed_trials"],
                group["trial_failures"], group["interrupted"], group["warm_worker_exit"]) == (
            cache, "L", "method", 7, 7, 7, False, None if cache == "process_cold" else 0,
        )
        assert group["input_fingerprints_before"] == group["input_fingerprints_after"] == inputs["first_fingerprints"]
        assert group["operations"]["method"] == {"passed": 0, "failed": 5, "missing": 0}
        shard = [row for row in rows if row["cache"] == cache]
        assert len({row["worker_pid"] for row in shard}) == (7 if cache == "process_cold" else 1)
        groups[cache] = summarize_group(shard, expected_steps)

    assert groups["process_cold"]["failed_distributions"] == previous_cold["measured_failed_distributions"]
    assert groups["process_cold"]["failed_step_distributions"] == previous_cold["measured_failed_step_distributions"]
    self_file = ATTEMPT / "self-comparison.json"
    validate_self(self_file, groups)
    result = {
        "scope": "completed remote L baseline only", "attempt": str(ATTEMPT), "container_exit": 1,
        "input_manifest_sha256": MANIFEST, "runtime_configuration_sha256": RECEIPT,
        "cold_prefix_sha256": previous_cold["raw_prefix_sha256"], "cold_prefix_unchanged": True,
        "cold_archive_git_commit": commit, "cold_archive_sha256": cold_archive_sha,
        "files": {str(path): digest(path.read_bytes()) for path in (TRIALS, report_file, receipt_file, self_file)},
        "groups": groups, "samples": samples, "staged_change_rasters": changes, "run_identity": identities,
        "status_poll_errors": sum(len(row["status_poll_errors"]) for row in samples),
        "why_correctness_absent": previous_cold["failure"]["why_correctness_absent"],
    }
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("base exit 1, COMPLETED, self-comparison exit 0 MATCHED_EVIDENCE; receipt", RECEIPT)
    print("14 persisted calculate_change timeouts, seven successful prior steps each; status polls", result["status_poll_errors"])
    for cache, group in groups.items():
        failed = group["failed_distributions"]
        print(cache, "formal failed wall", failed["wall_ns"], "RSS", failed["peak_rss_bytes"], "temp", failed["peak_temp_bytes"])
        step = group["failed_step_distributions"][FINAL_STEP]
        print(cache, "change step wall", step["wall_ns"], "RSS", step["peak_rss_bytes"])
    print("all staged classifications", archived_classes["bytes"], archived_classes["sha256"], "staged changes", changes[0]["bytes"], changes[0]["sha256"])
    print("cold bytes and both staged TIFFs match Git archive; 14 unique runs, ID audit", identities)


if __name__ == "__main__":
    main(sys.argv[1], Path(sys.argv[2]))
