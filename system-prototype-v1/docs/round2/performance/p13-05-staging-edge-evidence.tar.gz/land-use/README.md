# P13-05 土地利用分区重投影暂存

独立分支 `codex/p13-05-managed-land-use-zones`，提交 `b126785a5d51ecff2a27bbb2c6cbefc4171e55ad`，父提交 `a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc`。分区重投影通过已声明的 `allocations` 文件找到执行器所拥有的暂存父目录。直接调用沿用目标文件的父目录。

三项专项使用一个 100 m² 片区、四个小 GeoPackage 及 EPSG:4326 分区到 EPSG:6933 的真实重投影。受控钩子先完成实际 GeoPackage 硬链接并用 Pyogrio 重开验证 CRS，再让父执行器发出取消信号。已登记工具的取消终态为 `CANCELLED/PROCESS_CANCELLED`，子进程退出 -15。测试同时核对输入文件和无关文件内容。独立 CLI 和受管正常运行均输出预期的 100 m² 分配。

| 检查 | 结果 | 原始证据 |
| --- | --- | --- |
| 修复前目标专项 | 2 失败、1 通过，退出 1。取消后残留 98,304 B | baseline.command、baseline.log、baseline.xml |
| 修复后全部小型写入回归 | 10 通过，退出 0，7.32 秒 | fixed.command、fixed.log、fixed.xml |
| 修复后原生镜像目标专项 | 3 通过，容器退出 0，3.24 秒 | native.command、native.log、native/junit.xml |

三组都限定 CPU31、nice 19、GDAL/BLAS 单线程。原生容器使用正式固定镜像和只读 Python 运行时及源码。全量测试覆盖矢量、栅格、遥感及土地利用写入的正常和中断路径。所有源码编辑位于隔离 worktree。
