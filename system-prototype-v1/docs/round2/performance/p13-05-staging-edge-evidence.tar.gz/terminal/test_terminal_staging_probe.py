import errno
import hashlib
import json
import os
from pathlib import Path

import pyogrio

from geopilot.application.plan_runner import execute_claimed_run
from geopilot.artifacts.service import list_artifacts
from geopilot.execution import output_staging
from geopilot.execution.step_support import output_staging_receipt_path
from geopilot.execution.worker_lease import exclusive_local_lock, managed_workers_stopped, worker_lease
from geopilot.persistence.plan_repository import row_for_plan
from geopilot.persistence.run_repository import get_run, get_run_step, list_run_steps
from geopilot.persistence.schema import open_database
from geopilot.persistence.workspace import RunWorkspace
from geopilot.scheduler.loop import recover_interrupted_runs, run_once


ROOT = Path(__file__).resolve().parents[2]
WORKER = ROOT / "src/geopilot/gis/tools/prepare_measurement_lines.py"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def staging_snapshot(workdir, receipt):
    records = json.loads(receipt.read_bytes())
    directories = []
    for item in records:
        location = workdir / item["path"]
        metadata = location.stat()
        assert location.is_dir() and not location.is_symlink()
        assert (metadata.st_dev, metadata.st_ino) == (item["device"], item["inode"])
        directories.append({**item, "entries": sorted(path.name for path in location.iterdir())})
    return {"receipt_sha256": digest(receipt), "directories": directories}


def test_terminal_staging_is_not_recovered_after_one_cleanup_error(queued_run, monkeypatch):
    database, workspace, registry, implementation, run_id, workdir = queued_run
    receipt = workdir / "steps/finalize/.python-output-staging.json"
    actual_rmtree = output_staging.rmtree
    failures = []

    def fail_final_cleanup_once(name, *, dir_fd):
        if receipt.is_file() and not failures:
            observed = staging_snapshot(workdir, receipt)
            owned, = observed["directories"]
            target = workdir / owned["path"]
            assert target.name == name and target.parent.stat().st_ino == os.fstat(dir_fd).st_ino
            worker_manifest = receipt.with_name("python-result.json")
            assert json.loads(worker_manifest.read_bytes())["outputs"]["roads"]["path"]
            failures.append(observed)
            raise OSError(errno.EBUSY, "probe: one transient owned-output rmtree failure")
        return actual_rmtree(name, dir_fd=dir_fd)

    with monkeypatch.context() as injection:
        injection.setattr(output_staging, "rmtree", fail_final_cleanup_once)
        assert run_once(database, lambda run: execute_claimed_run(
            database, run, workspace_root=workspace, registry=registry,
            python_implementations={implementation: WORKER, "test.measurement_middle": WORKER},
        )) == run_id
    assert output_staging.rmtree is actual_rmtree
    assert len(failures) == 1 and managed_workers_stopped(workdir)
    assert "exit_code: 0" in receipt.with_name("process.log").read_text(encoding="utf-8")

    with open_database(database, read_only=True) as connection:
        run = get_run(connection, run_id)
        steps = list_run_steps(connection, run_id)
        artifact, = list_artifacts(connection, run_id)
    assert (run.execution_status, run.check_status) == ("SUCCEEDED", "PASSED")
    assert [(step.status, step.result.exit_code) for step in steps] == [("SUCCEEDED", 0)] * 3
    assert output_staging_receipt_path(workdir, steps[-1].request.model_dump(mode="json")) == receipt
    artifact_path = workdir / artifact.uri
    assert len(pyogrio.read_dataframe(artifact_path, layer=artifact.layer)) == 3
    artifact_digest = digest(artifact_path)
    manifest_digest = digest(workdir / "outputs/manifest.json")
    before = staging_snapshot(workdir, receipt)
    assert before == failures[0]

    recovery_seen = []

    def processes_stopped(item):
        recovery_seen.append(item.id)
        return managed_workers_stopped(Path(item.workdir))

    recovered = recover_interrupted_runs(database, processes_stopped=processes_stopped)
    assert recovered == () and recovery_seen == []
    after = staging_snapshot(workdir, receipt)
    assert after == before
    explicit = None
    if os.environ.get("P13_TERMINAL_STAGING_OPERATOR_PROBE") == "1":
        retained = [workdir / item["path"] for item in before["directories"]]
        unrelated = retained[0].parent / (".python-output-" + "f" * 32)
        unrelated.mkdir()
        sentinel = unrelated / "diagnostic.txt"
        sentinel.write_text("preserve", encoding="utf-8")
        database_digest = digest(database)
        lock = database.resolve().with_name(f"{database.name}.scheduler.lock")
        with exclusive_local_lock(lock), worker_lease(workdir):
            with open_database(database, read_only=True) as connection:
                stored_run = get_run(connection, run_id)
                stored_step = get_run_step(connection, run_id, "finalize")
                assert stored_run == run and stored_step == steps[-1]
                plan = row_for_plan(connection, stored_run.plan_id, stored_run.plan_version)
                canonical_workdir = RunWorkspace(workspace.resolve(), plan["task_id"], run_id).path
                assert canonical_workdir == workdir == Path(stored_run.workdir).resolve(strict=True)
                persisted_request = stored_step.request.model_dump(mode="json")
                assert (persisted_request["run_id"], persisted_request["step_key"]) == (run_id, "finalize")
            assert staging_snapshot(workdir, receipt) == before
            output_staging.recover_output_staging(workdir, persisted_request)
        assert not receipt.exists() and all(not location.exists() for location in retained)
        assert sentinel.read_text(encoding="utf-8") == "preserve"
        assert digest(database) == database_digest
        explicit = {
            "receipt_removed": True,
            "exact_owned_directories_removed": len(retained),
            "unrelated_same_prefix_directory_preserved": str(unrelated.relative_to(workdir)),
            "database_sha256_unchanged": database_digest,
        }
    with open_database(database, read_only=True) as connection:
        assert get_run(connection, run_id) == run
        assert list_run_steps(connection, run_id) == steps
        assert list_artifacts(connection, run_id) == (artifact,)
        assert connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    assert digest(artifact_path) == artifact_digest
    assert digest(workdir / "outputs/manifest.json") == manifest_digest

    print(json.dumps({
        "injected_cleanup_failures": len(failures),
        "database": str(database),
        "run_id": run_id,
        "workdir": str(workdir),
        "run_status": [run.execution_status, run.check_status],
        "steps": [[step.step_key, step.status, step.result.exit_code] for step in steps],
        "worker_lease_free": True,
        "startup_recovered": list(recovered),
        "startup_process_checks": recovery_seen,
        "before_startup": before,
        "after_startup": after,
        "explicit_operator_recovery": explicit,
        "artifact_sha256": artifact_digest,
        "artifact_manifest_sha256": manifest_digest,
        "sqlite_integrity_check": "ok",
    }, sort_keys=True))
