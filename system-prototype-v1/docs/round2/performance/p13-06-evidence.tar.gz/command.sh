#!/bin/bash
set -o pipefail
evidence="$1"
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1 PROJ_NETWORK=OFF QT_QPA_PLATFORM=offscreen
export GEOPILOT_QGIS_PROCESS="$PWD/.environments/qgis-deb/qgis_process"
.venv/bin/python -B -m pytest -q -p no:cacheprovider -W error::pytest.PytestUnhandledThreadExceptionWarning \
  tests/cache tests/checks/test_cache_reuse.py tests/models/test_step_io.py tests/methods/test_dem_terrain_method.py \
  tests/scheduler/test_cancellation.py tests/scheduler/test_step_execution.py \
  --basetemp="$evidence/pytest" --junitxml="$evidence/junit.xml" 2>&1 | tee "$evidence/pytest.log"
status=${PIPESTATUS[0]}
printf '%s\n' "$status" > "$evidence/exit-code"
exit "$status"
