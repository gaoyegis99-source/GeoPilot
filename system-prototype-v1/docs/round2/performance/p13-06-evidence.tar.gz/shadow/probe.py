from hashlib import sha256
import json
import os
from pathlib import Path
import sys

import affine
import numpy as np
import rasterio
from rasterio.transform import Affine
import yaml

from geopilot.artifacts.dem_area_cache import _runtime_identity, _read_report
from geopilot.checks.input_checks import preflight_step_inputs
from geopilot.data.fingerprint import copy_file_group, fingerprint_file
from geopilot.domain.step_io import StepRequest
from geopilot.domain.tool_contract import ToolContract
from geopilot.execution.runner import run_step
from geopilot.gis.raster.threshold import classify_raster
from geopilot.persistence.workspace import create_run_workspace
from geopilot.tools.registry import ToolRegistry

scratch = Path(sys.argv[1])
project = scratch / "source"
input_ref = "inputs/threshold-regions.tif"
output_ref = "outputs/area-statistics.json"
worker_import = project / "src/affine.py"
actual_affine = Path(affine.__file__).resolve()
run_id = "review"
step = "calculate_area_with_equal_area_projection"
terrain = scratch / "terrain.tif"
classification = scratch / "classification.tif"
with rasterio.open(
    terrain, "w", driver="GTiff", width=3, height=2, count=1, dtype="float32", crs="EPSG:32650",
    transform=Affine(30_000, 0, 500_000, 0, -20_000, 4_400_000), nodata=-9999,
) as output:
    output.write(np.array([[5, 5, 0], [0, 5, 5]], dtype="float32"), 1)
    output.update_tags(AREA_OR_POINT="Point")
classify_raster(terrain, classification, threshold={"intervals": [
    {"class_id": 7, "lower": 4, "upper": 6, "include_lower": True, "include_upper": True},
]})
input_digest = fingerprint_file(classification).digest
tool = ToolContract.model_validate(yaml.safe_load((project / "config/tools/python-dem-area-stats.yaml").read_text()))
implementations = {tool.implementation: project / "src/geopilot/gis/tools/summarize_dem_area.py"}
registry = ToolRegistry(python_implementations=implementations)
registry.register(tool, required_modules=("rasterio", "pyproj"))
request = StepRequest(
    run_id=run_id, step_key=step, workdir_ref=run_id, tool=tool.ref,
    inputs={"threshold_regions": {"path": input_ref}}, parameters={"area_crs": "EPSG:6933"},
    output_targets={"area_statistics": {"path": output_ref}}, log_path=f"steps/{step}/process.log",
    cancel_path="cancel.flag",
)

assert os.environ["GTIFF_POINT_GEO_IGNORE"] == "FALSE"
cases = []
assert not worker_import.exists()
for setting in ("FALSE", "TRUE"):
    if setting == "TRUE":
        worker_import.write_text(
            "import os, sys\n"
            "from pathlib import Path\n"
            "if sys.argv[0].endswith('/summarize_dem_area.py'):\n"
            f'    os.environ["GTIFF_POINT_GEO_IGNORE"] = "{setting}"\n'
            f"exec(compile(Path({str(actual_affine)!r}).read_bytes(), {str(actual_affine)!r}, 'exec'))\n"
        )
    workspace = create_run_workspace(scratch / setting, "dem-terrain-analysis", run_id)
    workspace.create_step(step)
    workdir = workspace.path
    copy_file_group(classification, workdir / input_ref, expected_digest=input_digest)
    identity = _runtime_identity(workdir)
    assert (identity is not None) == (setting == "FALSE"), (setting, identity)
    result = run_step(request, registry=registry, workdir=workdir, python_implementations=implementations,
                      input_preflight=preflight_step_inputs)
    assert result.status == "SUCCEEDED" and result.exit_code == 0, result
    payload = (workdir / output_ref).read_bytes()
    _read_report(payload, workdir / input_ref, "EPSG:6933")
    cases.append({
        "child_startup_option": setting,
        "parent_option": os.environ["GTIFF_POINT_GEO_IGNORE"],
        "runtime_identity": identity,
        "request_sha256": sha256((workdir / "steps" / step / "request.json").read_bytes()).hexdigest(),
        "input_file_group_sha256": input_digest,
        "output_sha256": sha256(payload).hexdigest(),
        "area_m2": json.loads(payload)["total_area_m2"],
    })
a, b = cases
assert a["runtime_identity"] is not None and b["runtime_identity"] is None
assert a["input_file_group_sha256"] == b["input_file_group_sha256"]
assert a["request_sha256"] == b["request_sha256"]
assert a["output_sha256"] != b["output_sha256"]
worker_import.unlink()
restored_identity = _runtime_identity(workdir)
assert restored_identity == a["runtime_identity"]
assert abs(a["area_m2"] - b["area_m2"]) > 93_000
print(json.dumps({"cases": cases, "restored_identity": restored_identity,
                  "area_delta_m2": a["area_m2"] - b["area_m2"]}, indent=2))
