#!/bin/bash
p13_review=$(cd "$(dirname "$0")" && pwd)
cd "$p13_review"
env -i PATH=/usr/bin:/bin HOME=/home/mtd PYTHONPATH="$p13_review/source/src" \
  PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1 PROJ_NETWORK=OFF GTIFF_POINT_GEO_IGNORE=FALSE \
  nice -n 19 ionice -c3 taskset -c 29 /home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/.venv/bin/python -B "$p13_review/probe.py" "$p13_review"
