"""Verify the source receipt, regression counts and saved cache runs offline."""

from hashlib import sha1, sha256
import json
from pathlib import Path
import sys
from xml.etree import ElementTree

root = Path(sys.argv[1]).resolve()
object_bytes = (root / "commit-object").read_bytes()
object_hash = sha1(f"commit {len(object_bytes)}\0".encode() + object_bytes).hexdigest()
assert object_hash == (root / "source-commit").read_text().strip()
assert f"parent {(root / 'base-commit').read_text().strip()}" in object_bytes.decode()
for receipt in ("exit-code", "schema-exit-code", "cli-exit-code", "shadow/exit-code"):
    assert (root / receipt).read_text().strip() == "0", receipt
nodes = ElementTree.parse(root / "junit.xml").findall(".//testcase")
assert len(nodes) == len({(node.get("classname"), node.get("name")) for node in nodes}) == 96
assert not any(child.tag in {"failure", "error", "skipped"} for node in nodes for child in node)
assert any(node.get("name").startswith("test_real_dem_cache") for node in nodes)
assert json.loads((root / "schema-validation.json").read_bytes())["counts"]["schemas_matching"] == 12


def read(directory, name):
    return json.loads((directory / name).read_bytes())


runs = sorted((root / "runs").iterdir(), key=lambda folder: read(folder, "run.json")["created_at"])
assert len(runs) == 8
summary = []
for folder in runs:
    run = read(folder, "run.json")
    result = read(folder, "result.json")
    request = read(folder, "request.json")
    initial = read(folder, "initial-report.json")
    report = next(attempt["report_json"] for attempt in read(folder, "attempts.json")
                  if attempt["id"] == run["current_report_id"])
    assert run["execution_status"] == result["status"] == "SUCCEEDED"
    assert run["check_status"] == report["status"] == "PASSED"
    output = (folder / "area.json").read_bytes()
    payload = json.loads(output)
    reuse = result.get("reuse")
    if reuse:
        prior = folder.with_name(reuse["source_run_id"])
        assert read(prior, "result.json")["exit_code"] == 0
        assert (prior / "area.json").read_bytes() == output
        assert (prior / "input.tif").read_bytes() == (folder / "input.tif").read_bytes()
        assert read(prior, "request.json")["parameters"] == request["parameters"]
        assert sha256(output).hexdigest() == reuse["output_sha256"]
        assert result["exit_code"] is None and not (folder / "python-result.json").exists()
        assert f"cache reuse: {reuse['cache_key']}" in (folder / "process.log").read_text()
        proof = [rule for rule in report["phase_findings"]["process"] if rule["rule"] == "step_cache_reuse_matches"]
        assert len(proof) == 3 and all(rule["passed"] for rule in proof)
    else:
        assert result["exit_code"] == 0 and (folder / "python-result.json").is_file()
    summary.append({
        "run_id": folder.name, "source_run_id": reuse["source_run_id"] if reuse else None,
        "initial_check": initial["status"], "final_check": report["status"],
        "output_sha256": sha256(output).hexdigest(), "input_sha256": sha256((folder / "input.tif").read_bytes()).hexdigest(),
        "area_m2": payload["total_area_m2"], "area_crs": payload["area_crs"],
        "class_ids": [row["class_id"] for row in payload["classes"]],
    })
assert [index for index, run in enumerate(summary) if run["source_run_id"]] == [1, 2, 4]
assert summary[2]["initial_check"] == "NOT_CHECKED"
assert all(summary[index]["output_sha256"] == summary[0]["output_sha256"] for index in (1, 2, 3, 4))
assert summary[6]["class_ids"] == [9] and summary[6]["input_sha256"] != summary[0]["input_sha256"]
assert summary[7]["area_crs"] == "EPSG:8857"
shadow = read(root / "shadow", "result.json")
clean, overridden = shadow["cases"]
assert clean["runtime_identity"] == shadow["restored_identity"] and overridden["runtime_identity"] is None
for field in ("request_sha256", "input_file_group_sha256"):
    assert clean[field] == overridden[field]
assert abs(clean["area_m2"] - overridden["area_m2"]) == shadow["area_delta_m2"]
for case in shadow["cases"]:
    files = list((root / "shadow" / case["child_startup_option"]).glob("**/outputs/area-statistics.json"))
    assert len(files) == 1 and sha256(files[0].read_bytes()).hexdigest() == case["output_sha256"]
print(json.dumps({"status": "PASS", "source_commit": object_hash, "tests_passed": len(nodes),
                  "runs": summary, "shadow_area_delta_m2": shadow["area_delta_m2"]}, indent=2))
