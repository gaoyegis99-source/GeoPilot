#!/usr/bin/env bash
set -o pipefail
probe=/dev/shm/geopilot-p13-dem-m-restart.pPU5HQ1v
archive=/dev/shm/geopilot-p13-dem-m-5kzfg0pd.paT1PPQZ
cd "$probe/production-source/system-prototype-v1" || exit 1
PYTHONPATH="$PWD/src" PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm \
  /home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/.venv/bin/python \
  "$probe/restart_probe.py" "$archive" "$probe" 2>&1 | tee "$probe/restart.log"
result=$?
printf '%s\n' "$result" > "$probe/exit-code"
exit "$result"
