import errno
import hashlib
import json
import select
import shutil
import sqlite3
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path

from fastapi.testclient import TestClient

from geopilot.api.app import create_app
from geopilot.execution.worker_lease import exclusive_local_lock, managed_workers_stopped, worker_lease
from geopilot.persistence.schema import open_database
from geopilot.scheduler.loop import recover_interrupted_runs


def sha256(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def fingerprints(root, files):
    return {str(path): sha256(root / path) for path in sorted(files)}


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def snapshot(database, run_id):
    with open_database(database, read_only=True) as connection:
        assert connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        run = dict(connection.execute("SELECT * FROM run WHERE id = ?", (run_id,)).fetchone())
        steps = [dict(row) for row in connection.execute(
            "SELECT * FROM run_step WHERE run_id = ? ORDER BY position", (run_id,),
        )]
        others = [dict(row) for row in connection.execute("SELECT * FROM run WHERE id <> ? ORDER BY id", (run_id,))]
        artifacts = [dict(row) for row in connection.execute("SELECT * FROM artifact WHERE run_id = ?", (run_id,))]
        checks = [dict(row) for row in connection.execute("SELECT * FROM check_report WHERE run_id = ?", (run_id,))]
    return {"run": run, "steps": steps, "other_runs": others, "artifacts": artifacts, "checks": checks}


@contextmanager
def inherited_lease(lease):
    with lease as fd:
        child = subprocess.Popen(
            [sys.executable, "-c", "import os, sys; os.fstat(int(sys.argv[1])); "
             "print('ready', flush=True); sys.stdin.buffer.read(1)", str(fd)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, pass_fds=(fd,),
        )
    try:
        assert select.select([child.stdout], [], [], 5)[0]
        assert child.stdout.readline() == b"ready\n"
        assert child.poll() is None
        yield child.pid
        stdout, stderr = child.communicate(input=b"1", timeout=5)
        assert (child.returncode, stdout, stderr) == (0, b"", b"")
    finally:
        if child.poll() is None:
            child.kill()
        child.communicate(timeout=5)


def error_code(row):
    return json.loads(row["error_json"])["code"] if row["error_json"] else None


def summary(state):
    run = state["run"]
    return {
        "run": {**run, "error_json": json.loads(run["error_json"]) if run["error_json"] else None},
        "steps": [
            {**{k: v for k, v in step.items() if k not in {"result_json", "request_json"}},
             "request_persisted": step["request_json"] is not None,
             "result": json.loads(step["result_json"]) if step["result_json"] else None}
            for step in state["steps"]
        ],
        "other_run_error_codes": {row["id"]: error_code(row) for row in state["other_runs"]},
        "artifact_count": len(state["artifacts"]), "check_report_count": len(state["checks"]),
    }


archive, output = (Path(arg).resolve() for arg in sys.argv[1:])
assert output.is_relative_to(Path("/dev/shm"))
prior = json.loads((archive / "warm04.json").read_text())
source = Path(prior["source"])
assert source.name == "attempt.5kzfg0pd"
archive_copies = archive / "original-copies"
archived_manifest = json.loads((archive / "source-after.json").read_text())["files"]
run_id = prior["sql_run_id"]
assert run_id == "6b3d6eaa045e45a39c4d9fafb008f6d1"
archive_service = Path("evidence/samples/M/method/warm/service")
relative_run = Path(prior["raw_trial"]["run_state"]["run_id"])
archived_workdir, = (archive_copies / archive_service / "workspace/tasks").glob(f"*/runs/{relative_run}")
run_source = source / archived_workdir.relative_to(archive_copies)
archived_files = [Path(path) for path in archived_manifest]
extra_files = [path.relative_to(source) for path in (run_source / "intermediate").rglob("*") if path.is_file()]
assert sum((source / path).stat().st_size for path in extra_files) < 1_000_000
before_original = fingerprints(source, [*archived_files, *extra_files])
before_archive = fingerprints(archive_copies, archived_files)
assert before_archive == {path: row["sha256"] for path, row in archived_manifest.items()}
assert all(before_original[path] == digest for path, digest in before_archive.items())
save(output / "source-before.json", {"original": before_original, "archive": before_archive})

service = output / "service"
service.mkdir()
db_names = ["project.sqlite", "project.sqlite-journal", "project.sqlite.scheduler.lock"]
for name in db_names:
    shutil.copy2(archive_copies / archive_service / name, service / name)
database = service / "project.sqlite"
workdir = service / "workspace" / archived_workdir.relative_to(archive_copies / archive_service / "workspace")
shutil.copytree(archived_workdir, workdir)
shutil.copytree(run_source / "intermediate", workdir / "intermediate")
original_run_files = [path.relative_to(workdir) for path in workdir.rglob("*") if path.is_file()]
preserved = fingerprints(workdir, original_run_files)
assert all(before_original[str(run_source.relative_to(source) / path)] == preserved[str(path)]
           for path in original_run_files)
assert not (workdir / "inputs").exists()


def db_files():
    return fingerprints(service, [Path(name) for name in db_names if (service / name).exists()])


stages = {"archived_copy": db_files()}
before = snapshot(database, run_id)
assert before["run"]["execution_status"] == "RUNNING" and error_code(before["run"]) is None
assert all(row["execution_status"] == "FAILED" for row in before["other_runs"])
old_workdir = before["run"]["workdir"]
relocation = "UPDATE run SET workdir = ? WHERE id = ? AND workdir = ?"
with open_database(database) as connection, connection:
    assert connection.execute(relocation, (str(workdir), run_id, old_workdir)).rowcount == 1
relocated = snapshot(database, run_id)
assert relocated == {**before, "run": {**before["run"], "workdir": str(workdir)}}
stages["relocated"] = db_files()
print("Relocated one copied run workdir; every other queried value is identical", flush=True)


dispatched = []


def unexpected_dispatch(run):
    dispatched.append(run.id)
    raise AssertionError(f"Unexpected scheduler dispatch {run.id}")


def startup():
    return TestClient(create_app(database, workspace_root=service / "workspace", execute_run=unexpected_dispatch))


scheduler_path = database.resolve().with_name(f"{database.name}.scheduler.lock")
rejections = {}
with inherited_lease(exclusive_local_lock(scheduler_path)) as pid:
    try:
        with startup():
            raise AssertionError("Startup took an occupied scheduler lease")
    except BlockingIOError as error:
        assert error.errno in {errno.EACCES, errno.EAGAIN}
        rejections["scheduler"] = {"lease_child_pid": pid, "errno": error.errno, "message": str(error)}
assert snapshot(database, run_id) == relocated
stages["scheduler_lease_refused"] = db_files()
assert stages["scheduler_lease_refused"] == stages["relocated"]
print(f"Startup refused inherited scheduler lease from PID {pid}", flush=True)

with inherited_lease(worker_lease(workdir)) as pid:
    assert not managed_workers_stopped(workdir)
    try:
        with startup():
            raise AssertionError("Startup took an occupied worker lease")
    except RuntimeError as error:
        assert str(error) == f"Cannot recover run {run_id!r} until its managed processes have stopped"
        rejections["worker"] = {"lease_child_pid": pid, "message": str(error)}
assert snapshot(database, run_id) == relocated
stages["worker_lease_refused"] = db_files()
assert stages["worker_lease_refused"] == stages["relocated"]
print(f"Startup refused inherited run worker lease from PID {pid}", flush=True)

assert managed_workers_stopped(workdir)
with startup() as client:
    statuses = {}
    for endpoint in ("", "/steps", "/artifacts"):
        response = client.get(f"/api/runs/{run_id}{endpoint}")
        assert response.status_code == 200
        statuses[endpoint or "/status"] = response.json()
assert not dispatched
recovered = snapshot(database, run_id)
stages["recovered"] = db_files()
state = recovered["run"]
assert (state["execution_status"], state["check_status"], state["cancel_requested"]) == ("FAILED", "NOT_CHECKED", 0)
assert state["current_step"] == "extract_by_threshold" and error_code(state) == "RUN_INTERRUPTED"
assert statuses["/status"]["error"]["code"] == "RUN_INTERRUPTED"
assert recovered["steps"][:5] == relocated["steps"][:5]
interrupted = recovered["steps"][5]
previous = relocated["steps"][5]
assert interrupted["status"] == "FAILED" and interrupted["started_at"] == previous["started_at"]
assert interrupted["finished_at"] >= interrupted["started_at"]
assert interrupted["request_json"] == previous["request_json"]
result = json.loads(interrupted["result_json"])
assert result["error"]["code"] == "RUN_INTERRUPTED" and result["exit_code"] is None and result["outputs"] == {}
assert interrupted["log_path"] == result["error"]["log_path"] == "steps/extract_by_threshold/process.log"
pending = recovered["steps"][6]
assert pending == relocated["steps"][6] and pending["status"] == "NOT_STARTED"
assert not any(pending[field] for field in ("started_at", "finished_at", "request_json", "result_json"))
assert recovered["other_runs"] == relocated["other_runs"]
assert not recovered["artifacts"] and not recovered["checks"] and not statuses["/artifacts"]["artifacts"]
assert not (workdir / "outputs/manifest.json").exists() and not (workdir / "checks/report.json").exists()
assert not any((workdir / parent / pending["step_key"]).exists() for parent in ("steps", "intermediate", "outputs"))
original_threshold_result = json.loads((workdir / "steps/extract_by_threshold/result.json").read_text())
assert (original_threshold_result["status"], original_threshold_result["exit_code"]) == ("SUCCEEDED", 0)
assert any(row["path"] == interrupted["log_path"] and row["readable"] for row in statuses["/artifacts"]["diagnostics"])
assert (workdir / "intermediate/extract_by_threshold/threshold_regions.tif").is_file()
print("Startup committed FAILED/RUN_INTERRUPTED; area still NOT_STARTED, zero published artifacts/reports", flush=True)

with exclusive_local_lock(scheduler_path):
    again = recover_interrupted_runs(database, processes_stopped=lambda run: managed_workers_stopped(Path(run.workdir)))
assert again == ()
with startup() as client:
    assert client.get(f"/api/runs/{run_id}").json() == statuses["/status"]
assert not dispatched and snapshot(database, run_id) == recovered
stages["idempotent"] = db_files()
assert stages["idempotent"] == stages["recovered"]
assert fingerprints(workdir, original_run_files) == preserved
assert {path.relative_to(workdir) for path in workdir.rglob("*") if path.is_file()} == set(original_run_files)

after_original = fingerprints(source, [*archived_files, *extra_files])
after_archive = fingerprints(archive_copies, archived_files)
assert (after_original, after_archive) == (before_original, before_archive)
save(output / "source-after.json", {"original": after_original, "archive": after_archive})
save(output / "restart.json", {
    "sqlite_version": sqlite3.sqlite_version,
    "source_revision": (output / "production-source/REVISION").read_text().strip(),
    "run_id": run_id, "workdir_relocation": {"sql": relocation, "old": old_workdir, "new": str(workdir)},
    "source_file_count": len(before_original), "archived_file_count": len(before_archive),
    "rejections": rejections, "before": summary(before), "after": summary(recovered), "api": statuses,
    "original_threshold_result": original_threshold_result,
    "database_sha256_stages": stages, "preserved_workdir_files_sha256": preserved,
    "direct_recovery_repeat": again, "repeat_app_status_unchanged": True, "scheduler_dispatches": dispatched,
})
print(f"Repeat recovery returned {again!r}; recovered database, {len(preserved)} run files, "
      f"{len(before_original)} original files and {len(before_archive)} archive files stayed byte-identical", flush=True)
