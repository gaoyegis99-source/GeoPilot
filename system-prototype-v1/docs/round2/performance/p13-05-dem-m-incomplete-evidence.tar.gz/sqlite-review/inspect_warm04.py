import hashlib
import json
import re
import shutil
import sqlite3
import sys
from datetime import UTC, datetime
from pathlib import Path


def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def inventory(root, paths):
    return {
        path.as_posix(): {
            "sha256": digest(root / path),
            "size": (stat := (root / path).stat()).st_size,
            "mtime_utc": datetime.fromtimestamp(stat.st_mtime, UTC).isoformat(),
        }
        for path in paths
    }


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def result_details(result):
    return {key: result[key] for key in ("status", "exit_code", "error")}


source = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
copies = output / "original-copies"
query = output / "query-copy"
copies.mkdir()
query.mkdir()
warm = Path("evidence/samples/M/method/warm")
service = warm / "service"
trial_path = warm / "04-measurement/trial.json"
trial = json.loads((source / trial_path).read_text())
assert trial["sample_id"] == "raster/M/method/warm/04"
run_id = trial["run_id"]
run = service / "workspace/tasks" / trial["task_id"] / "runs" / run_id
files = sorted(set([
    Path("command.log"), Path("container.log"), Path("exit-code"), Path("container-name"),
    Path("evidence/report.json"), Path("evidence/trials.jsonl"), trial_path,
    service / "worker.log", run / "request.json", run / ".worker.lock",
] + [path.relative_to(source) for path in (source / service).glob("project.sqlite*")]
  + [path.relative_to(source) for path in (source / run / "steps").glob("*/*") if path.is_file()]))
before = inventory(source, files)
save(output / "source-before.json", {"source": str(source), "files": before})
for path in files:
    target = copies / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / path, target)
assert inventory(copies, files) == before

database_name = "project.sqlite"
journal_name = f"{database_name}-journal"
database = query / database_name
journal = query / journal_name
db_files = [path.name for path in files if path.parent == service and path.name in {
    database_name, journal_name, f"{database_name}-wal", f"{database_name}-shm",
}]
for name in db_files:
    shutil.copy2(copies / service / name, query / name)
journal_header = None
if journal.exists():
    with journal.open("rb") as file:
        journal_header = file.read(28).hex()
query_before = inventory(query, [Path(name) for name in db_files])

sql = {
    "integrity": "PRAGMA integrity_check",
    "run": "SELECT id, plan_id, plan_version, execution_status, check_status, current_step, cancel_requested, current_report_id, error_json, created_at FROM run WHERE id = ?",
    "steps": "SELECT step_key, position, status, started_at, finished_at, request_json, result_json FROM run_step WHERE run_id = ? ORDER BY position",
    "artifact_count": "SELECT count(*) FROM artifact WHERE run_id = ?",
    "check_report_count": "SELECT count(*) FROM check_report WHERE run_id = ?",
    "warm_runs": "SELECT id, execution_status, check_status, current_step, error_json FROM run ORDER BY created_at",
}


def inspect(connection):
    connection.row_factory = sqlite3.Row
    integrity = [row[0] for row in connection.execute(sql["integrity"])]
    connection.execute("PRAGMA query_only = ON")
    state = dict(connection.execute(sql["run"], (run_id,)).fetchone())
    steps = []
    for step in connection.execute(sql["steps"], (run_id,)):
        record = dict(step)
        record["request_persisted"] = record.pop("request_json") is not None
        result = record.pop("result_json")
        record["result"] = result_details(json.loads(result)) if result else None
        steps.append(record)
    warm_runs = []
    for row in connection.execute(sql["warm_runs"]):
        record = dict(row)
        error = record.pop("error_json")
        record["error_code"] = json.loads(error)["code"] if error else None
        warm_runs.append(record)
    return {
        "integrity_check": integrity, "run": state, "steps": steps, "warm_runs": warm_runs,
        "artifact_count": connection.execute(sql["artifact_count"], (run_id,)).fetchone()[0],
        "check_report_count": connection.execute(sql["check_report_count"], (run_id,)).fetchone()[0],
    }


try:
    connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)
    try:
        persisted = inspect(connection)
        read_mode = "read_only"
    finally:
        connection.close()
except sqlite3.OperationalError as error:
    if error.sqlite_errorcode != sqlite3.SQLITE_READONLY_ROLLBACK:
        raise
    read_mode = "disposable_copy_after_sqlite_rollback"
    connection = sqlite3.connect(database)
    try:
        persisted = inspect(connection)
    finally:
        connection.close()
query_after = inventory(query, [Path(name) for name in db_files if (query / name).exists()])

rows = map(json.loads, (copies / "evidence/trials.jsonl").read_text().splitlines())
raw = next(row for row in rows if row.get("run_id") == run_id)
assert all(raw[key] == value for key, value in trial.items())
request = json.loads((copies / run / "request.json").read_text())
assert request["run_id"] == run_id
area_step = "calculate_area_with_equal_area_projection"
run_source = source / run
observed_steps = []
for path in sorted((copies / run / "steps").glob("*/result.json")):
    row = json.loads(path.read_text())
    assert row["run_id"] == run_id
    log = (path.parent / "process.log").read_text()
    observed_steps.append({
        "step_key": row["step_key"], "started_at": row["started_at"], "finished_at": row["finished_at"],
        **result_details(row), "process_log_exit_codes": re.findall(r"^exit_code: (-?\d+)$", log, re.M),
        "has_python_result": (path.parent / "python-result.json").is_file(),
    })

after = inventory(source, files)
save(output / "source-after.json", {"source": str(source), "files": after})
assert before == after == inventory(copies, files)
report = json.loads((copies / "evidence/report.json").read_text())
result = {
    "source": str(source), "evidence_files_verified": len(files), "sqlite_version": sqlite3.sqlite_version,
    "read_mode": read_mode, "rollback_journal_first_28_bytes_hex": journal_header,
    "query_copy_before": query_before, "query_copy_after": query_after, "sql": sql, "sql_run_id": run_id,
    "persisted": persisted,
    "raw_trial": {key: raw[key] for key in ("sample_id", "status", "worker_pid", "worker_exit_code", "wall_ns",
                                           "run_state", "status_poll_errors", "cancellation", "stop_group", "error")},
    "report_status": report["status"], "attempt_exit_code": int((copies / "exit-code").read_text()),
    "worker_log": (copies / service / "worker.log").read_text().splitlines(),
    "disk_step_results": observed_steps,
    "planned_step_keys": [step.get("key", step.get("step_key", step.get("id"))) for step in request["plan"]["steps"]],
    "area_path_exists": {
        parent: (run_source / parent / area_step).exists() for parent in ("steps", "intermediate", "outputs")
    },
    "observed_run_directories": {
        parent: sorted(path.name for path in (run_source / parent).iterdir()) if (run_source / parent).is_dir() else []
        for parent in ("steps", "intermediate", "outputs", "checks")
    },
}
save(output / "warm04.json", result)
print(json.dumps({key: result[key] for key in ("source", "evidence_files_verified", "sqlite_version", "read_mode",
                                                "persisted", "planned_step_keys", "area_path_exists")}, indent=2))
