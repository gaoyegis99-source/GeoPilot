"""Check actual DEM M metadata and mock the same-root retry with tiny synthetic fixtures."""
import fcntl
import importlib.util
import json
import os
import shlex
import subprocess
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch


HERE = Path(__file__).resolve().parent
ARTIFACTS = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/artifacts/test-results")
PLAN = ARTIFACTS / "p13-05-raster-plan-a2d2e68.TONYtP"
OUTPUT = ARTIFACTS / "p13-05-raster-pairs.a2d2e68.after-vector-l"
CASE = "dem-m"
CANDIDATE = OUTPUT / CASE / "candidate"
BASE = OUTPUT / CASE / "base"
CANDIDATE_ATTEMPT = CANDIDATE / "attempt.f0puyhqd"
BASE_ATTEMPT = BASE / "attempt.5kzfg0pd"
spec = importlib.util.spec_from_file_location("frozen_test_fixture", PLAN / "test_launcher.py")
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
launcher = fixture.launcher


def require_busy(path):
    try:
        with launcher.lease(path, read_only=True):
            raise AssertionError(f"Expected a held lease at {path}")
    except ValueError as error:
        assert "already holds" in str(error), error


def evidence_fingerprints():
    paths = [
        OUTPUT / "plan.json", CANDIDATE / "COMPLETED",
        CANDIDATE_ATTEMPT / "command.log", CANDIDATE_ATTEMPT / "container.log", CANDIDATE_ATTEMPT / "exit-code",
        CANDIDATE_ATTEMPT / "self-comparison.json", CANDIDATE_ATTEMPT / "self-comparison.exit-code",
        BASE_ATTEMPT / "command.log", BASE_ATTEMPT / "container.log", BASE_ATTEMPT / "exit-code",
    ]
    for attempt in (CANDIDATE_ATTEMPT, BASE_ATTEMPT):
        paths.extend(attempt / "evidence" / name for name in ("report.json", "trials.jsonl"))
    paths.append(CANDIDATE_ATTEMPT / "evidence/runtime-configuration.json")
    return {str(path.relative_to(OUTPUT)): launcher.digest(path) for path in paths}


def normalize(cmd):
    cmd = list(cmd)
    cmd[cmd.index("--name") + 1] = "<attempt container name>"
    mounts = [i for i, arg in enumerate(cmd) if arg.startswith("type=bind,src=") and arg.endswith(",dst=/scratch")]
    assert len(mounts) == 1
    cmd[mounts[0]] = "<new attempt scratch>"
    return cmd


def check_actual():
    before = evidence_fingerprints()
    (HERE / "actual-before.json").write_text(json.dumps(before, indent=2) + "\n")
    assert (CANDIDATE / "COMPLETED").read_text().strip() == CANDIDATE_ATTEMPT.name
    assert not (BASE / "COMPLETED").exists()
    assert not (BASE_ATTEMPT / "evidence/runtime-configuration.json").exists()
    contracts = {case: launcher.input_contract(case) for case in launcher.CASES}
    assert launcher.read_json(OUTPUT / "plan.json") == launcher.session_identity(contracts)
    contract = contracts[CASE]
    candidate = launcher.verify_attempt(CANDIDATE_ATTEMPT, "candidate", contract)
    candidate_comparison = subprocess.check_output(
        [sys.executable, "-B", launcher.PLAN / "runner/run_memory_profile.py", "--kind", "raster",
         "--require-runtime-configuration", "--before", candidate, "--after", candidate],
    )
    assert candidate_comparison == (CANDIDATE_ATTEMPT / "self-comparison.json").read_bytes()
    (HERE / "actual-candidate-self.json").write_bytes(candidate_comparison)
    try:
        launcher.verify_attempt(BASE_ATTEMPT, "base", contract)
    except ValueError as error:
        assert "Attempt incomplete" in str(error), error
        print(f"Original interrupted attempt rejected: {error}")
    else:
        raise AssertionError("Interrupted original attempt incorrectly accepted")
    cmd = [sys.executable, "-B", PLAN / "run-raster-pairs.py", "--dry-run",
           "--case", CASE, "--output-root", OUTPUT]
    (HERE / "dry-run.command").write_text(shlex.join(map(str, cmd)) + "\n")
    with (HERE / "dry-run.log").open("w") as log:
        result = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=False)
    (HERE / "dry-run.exit-code").write_text(f"{result.returncode}\n")
    assert result.returncode == 0
    lines = (HERE / "dry-run.log").read_text().splitlines()
    previews = [shlex.split(line) for line in lines if line.startswith("docker ")]
    assert len(previews) == 2
    for side, attempt, preview in zip(launcher.sides(CASE), (CANDIDATE_ATTEMPT, BASE_ATTEMPT), previews, strict=True):
        original = shlex.split((attempt / "command.log").read_text().splitlines()[1])
        assert preview[-1] == launcher.COMMITS[side]
        assert normalize(original) == normalize(preview), side
    candidate_summary = launcher.read_json(candidate / "report.json")
    base_summary = launcher.read_json(BASE_ATTEMPT / "evidence/report.json")
    for name, report in (("candidate", candidate_summary), ("interrupted original", base_summary)):
        print(name, [(g["cache"], g["observed_trials"], g["expected_trials"],
                       g["trial_failures"], g["interrupted"]) for g in report["groups"]])
    print("Existing plan identity, candidate receipt and strict self-comparison verified; dry-run changes only attempt names and scratch paths")
    return before, contract


def check_mock(contract):
    with tempfile.TemporaryDirectory(prefix="dem-m-retry-fixture.", dir=HERE) as scratch:
        root = Path(scratch)
        case = root / CASE
        data = fixture.EvidenceTest()
        data.root, data.contract = case, contract
        candidate = data.fixture("candidate", passes=True)
        (candidate.parent / "COMPLETED").write_text(candidate.name + "\n")
        interrupted = case / "base/attempt.interrupted"
        interrupted.mkdir(parents=True)
        (interrupted / "container-name").write_text("synthetic-interrupted-container\n")
        (interrupted / "sentinel").write_text("keep incomplete evidence\n")
        different_case = root / "dem-l"
        different_case.mkdir()
        (different_case / "sentinel").write_text("keep other case\n")
        lock = root / "fake-vector-lock"
        lock.touch()
        own_lock = root / ".orchestrator.lock"
        own_lock.touch()
        board = root / "board"
        board.write_text("| P13-03 | | | | | ACCEPTED |\n"
                         "| P13-04 | | | | | ACCEPTED |\n"
                         "| P13-05 | | | | | DOING |\n")
        identity = {"fixture": True}
        (root / "plan.json").write_text(json.dumps(identity))
        original_candidate = {path.relative_to(candidate): launcher.digest(path) for path in candidate.rglob("*")
                              if path.is_file()}
        calls = []
        active = "synthetic-interrupted-container\n"
        actual_run = subprocess.run
        actual_output = subprocess.check_output

        def process(cmd, **kwargs):
            if cmd[:2] != ["docker", "run"]:
                return actual_run(cmd, **kwargs)
            require_busy(lock)
            require_busy(own_lock)
            assert cmd[-1] == launcher.COMMITS["base"]
            bind = next(arg for arg in cmd if arg.startswith("type=bind,src=") and arg.endswith(",dst=/scratch"))
            attempt = Path(bind.removeprefix("type=bind,src=").removesuffix(",dst=/scratch"))
            assert attempt.parent == interrupted.parent and attempt != interrupted
            calls.append(attempt)
            data.fixture("base", passes=False, attempt=attempt)
            return subprocess.CompletedProcess(cmd, 1)

        def output(cmd, **kwargs):
            if cmd[:2] == ["docker", "ps"]:
                require_busy(lock)
                require_busy(own_lock)
                return active
            return actual_output(cmd, **kwargs)

        def run():
            launcher.run_live(root, [CASE], {CASE: contract}, identity)

        def assert_rejected(message):
            try:
                run()
            except ValueError as error:
                assert message in str(error), error
            else:
                raise AssertionError(f"Unexpected acceptance: {message}")

        with (patch.object(launcher, "VECTOR_LOCK", lock), patch.object(launcher, "BOARD", board),
              patch.object(launcher, "check_disk"), patch.object(launcher, "check_seals"),
              patch.object(subprocess, "check_output", side_effect=output),
              patch.object(subprocess, "run", side_effect=process)):
            with launcher.lease(lock, read_only=True):
                assert_rejected("formal measurement already holds")
            with launcher.lease(own_lock, read_only=True):
                assert_rejected("formal measurement already holds")
            assert_rejected("Earlier container remains active")
            assert not calls and not (interrupted.parent / "COMPLETED").exists()
            active = ""
            run()
        assert len(calls) == 1 and (interrupted.parent / "COMPLETED").read_text().strip() == calls[0].name
        assert (candidate.parent / "COMPLETED").read_text().strip() == candidate.name
        assert original_candidate == {path.relative_to(candidate): launcher.digest(path) for path in candidate.rglob("*")
                                      if path.is_file()}
        assert (interrupted / "sentinel").read_text() == "keep incomplete evidence\n"
        assert (different_case / "sentinel").read_text() == "keep other case\n"
        pair, = case.glob("pair.*")
        result = launcher.read_json(pair / "before-after.json")
        assert result["status"] == "MATCHED_EVIDENCE" and not result["same_source"]
        assert (pair / "before-after.exit-code").read_text().strip() == "0"
        for group in result["groups"]:
            assert group["before"]["counts"]["FAIL"] == 5 and group["successful_sample_deltas"] == {}
        print("Synthetic fixture: both locks and active-container rejection passed; one new base attempt, candidate unchanged, strict comparator exit=0")


def main():
    before, contract = check_actual()
    check_mock(contract)
    after = evidence_fingerprints()
    (HERE / "actual-after.json").write_text(json.dumps(after, indent=2) + "\n")
    assert before == after
    assert not (HERE / "forbid-docker/docker.calls").exists()
    print("Actual metadata hashes unchanged (candidate, failed base and plan); no real Docker invocation")


if __name__ == "__main__":
    main()
