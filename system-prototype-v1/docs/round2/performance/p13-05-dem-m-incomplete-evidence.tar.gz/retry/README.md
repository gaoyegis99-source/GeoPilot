# P13-05 DEM M 原版单侧重试预检

正式窗口由主控在现行栅格与 T14 队列结束后安排。已准备的正式命令保存在 `formal.command`。启动器和结果根沿用正在使用的冻结计划。

```bash
python3 -B /home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/artifacts/test-results/p13-05-raster-plan-a2d2e68.TONYtP/run-raster-pairs.py \
  --run --case dem-m \
  --output-root /home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l
```

## 原始分片与执行条件

- `candidate/COMPLETED` 指向 `attempt.f0puyhqd`。原生容器退出 1，报告是完整 FAIL，冷暖各 7 次，运行配置回执有效。正式样本冷态 5 通过，暖态 4 通过和 1 状态观察失败。暖态 2 次预热亦计为状态观察失败。
- 原版 `attempt.5kzfg0pd` 原生容器退出 1，计划退出 2。冷态 7/7，暖态在第 4/7 轮连续三次 GET 500 后停止。报告无配置回执，旧原版没有完成指针。
- 同一结果根的计划身份匹配冻结启动器、镜像、两棵源码树、包装器、比较器、五份输入清单和存储。正式重试还会验证整树与原生绑定，获取共用 M 锁和本根锁，检查根内已记录容器均已退出。看板需要 P13-03、P13-04 已签收且 P13-05 进行中。
- `dem-m` 的顺序先校验复用候选，再开独立原版 attempt。原版新尝试重新完成两个冷热组，每组 2 次预热和 5 次正式计量。保留旧中断分片。新原版通过分片验收并签发回执后，用严格比较器在新 `pair.*` 下生成结果。原版若完整 FAIL 且两侧匹配，启动器可退出 0；再次中断或证据失配会退出 2。

## 验证结果

实际候选通过冻结 `verify_attempt`，强制回执自比较结果与原文件逐字节相同。旧中断原版被正确拒绝。当前根预演退出 0，显示的两侧命令各自与原命令逐参数一致，只有尝试名和 scratch 路径变化。预演会打印两个计划命令。实际复用由完成指针决定。

合成小夹具执行真实控制流及严格比较器，替换 Docker 调用和设备检查。验证全局或结果根锁忙及已记录活动容器均阻止执行；释放后只模拟一次新的原版调用，保留候选、旧中断尝试及其他场景，严格比较退出 0。实际候选、旧原版及计划小文件前后 SHA-256 一致。仅在本临时目录写入证据。

- `check.command`、`check.log`、`check.exit-code` 保存原始执行。CPU31、nice 19、ionice idle。
- `dry-run.command`、`dry-run.log`、`dry-run.exit-code` 保存当前根预演。
- `actual-before.json`、`actual-after.json`、`actual-candidate-self.json` 保存正式证据的只读核对。
