"""Independent small-file audit of the completed frozen L split-by-area pair."""
from collections import Counter
import gzip
from hashlib import sha256
import json
import math
import re
from pathlib import Path
import re
import shlex
from statistics import median
import sys

REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
RECORDS = REPO / "docs/round2/performance"
PLAN = REPO / "artifacts/test-results/p13-05-vector-l-plan.a2d2e68.C905zE"
ROOT = Path("/mnt/datab/geopilot-p13-05-vector-l.a2d2e68.C905zE")
WORKLOAD = "t14-split_by_area"
SHARD = ROOT / WORKLOAD
COMMITS = {
    "base": "977ab412d9f6e7558d22a5c431fac0ada90b07be",
    "candidate": "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc",
}
OLD = "37cb329be04eaddfeb23ac62789926d0fcdb63aa"
TREE_HASHES = {
    "base": "19bf6a3df70aee71ea6bf87f690a7b13b28b2cfc08ad3e79aa01c3e72b6e4277",
    "candidate": "ff853a59c4dea94bd0cf1046c34d1980904a3661744ee3827e7911303b51fac7",
}
FROZEN_RUNNER_HASH = "b0b83f6fa51bf097a28b8ae69e828e0ef401e35981e7262f469eca52c95c5af2"
IMAGE = "sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87"
FILESYSTEM = "/dev/sdb1 ext4"
RELATION = {"spatial_relation": "intersects"}
ALLOCATION = {"boundary_assignment": "split_by_area", "boundary_tie": "unassigned", "area_crs": "EPSG:6933"}
OPTIONS = {**RELATION, **ALLOCATION}
STEPS = (
    ("apply_spatial_relation", "python-select-spatial-relation", RELATION),
    ("clip_back_to_analysis_extent", "python-clip-vector-to-extent", {}),
    ("aggregate_by_zone", "python-polygon-zone-statistics", {**ALLOCATION, "area_unit": "square_meter"}),
)
CACHES = ("process_cold", "warm")
PHASES = (("warmup", 2), ("measurement", 5))
PLANNED = [(cache, phase, i) for cache in CACHES for phase, n in PHASES for i in range(1, n + 1)]
RESOURCES = ("cpu_ns", "peak_rss_bytes", "disk_read_bytes", "disk_write_bytes")
METRICS = ("wall_ns", "queue_wall_ns", "execute_steps_wall_ns", "finalize_wall_ns",
           *RESOURCES, "peak_temp_bytes", "input_bytes", "output_bytes")


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def snapshot_digest(snapshot):
    payload = {name: value for name, value in snapshot.items() if name != "sha256"}
    encoded = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return sha256(encoded.encode("ascii")).hexdigest()


def archived_rows(path):
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        return [json.loads(line) for line in stream]


def live_rows(path, terminal):
    if not path.is_file():
        assert not terminal
        return []
    raw = path.read_bytes()
    if raw and not raw.endswith(b"\n"):
        assert not terminal
        raw = raw[:raw.rfind(b"\n") + 1]
    return [json.loads(line) for line in raw.splitlines()]


def distribution(readings):
    values = sorted(item["value"] for item in readings if item.get("value") is not None)
    return {
        "samples": len(values),
        "coverage": dict(Counter(item["status"] for item in readings)),
        "median": median(values) if len(values) >= 3 else None,
        "p95": values[math.ceil(.95 * len(values)) - 1] if len(values) >= 3 else None,
    }


def reading(value):
    return {"status": "recorded" if value is not None else "unavailable", "value": value}


def measure_columns(row):
    sidecar = row["telemetry"]["document"]
    return {
        "wall_ns": reading(row["wall_ns"]),
        "queue_wall_ns": sidecar["queue_wall_ns"],
        "execute_steps_wall_ns": reading(sidecar["execute_steps_wall_ns"]),
        "finalize_wall_ns": reading(sidecar["finalize_wall_ns"]),
        **sidecar["resources"],
        "peak_temp_bytes": row["peak_temp_bytes"],
        "input_bytes": reading(row["input_bytes"]),
        "output_bytes": reading(row.get("output_bytes")),
    }


def one_run(row, expected):
    assert (row["tier"], row["workload"], row["input_profile"], row["input_manifest_sha256"]) == (
        "L", WORKLOAD, "p13-01", expected["input_manifest_sha256"],
    )
    package = next(file for file in expected["files"] if file["path"] == "t14.gpkg")
    assert row["input"] == package and row["input_bytes"] == package["bytes"]
    assert row["method"] == {"id": "polygon-zone-statistics", "version": 1}
    assert row["critical_options"] == OPTIONS and row["plan_version"] == 1
    assert isinstance(row["wall_ns"], int) and row["wall_ns"] > 0 and row["submission_attempted"]
    assert (row.get("input_preread_ns", 0) > 0) == (row["cache"] == "warm")
    assert row["checks_only_ns"] == {
        "status": "unavailable", "reason": "sidecar_finalization_includes_artifact_registration",
    }
    state = row["run_status"]
    doc = row["telemetry"]["document"]
    assert row["telemetry"]["status"] == "recorded"
    assert doc["schema_version"] == 1 and doc["wall_scope"] == "execution_through_finalization"
    assert state["run_id"] == doc["run_id"] == row["run_id"]
    assert (state["execution_status"], state["check_status"]) == (doc["execution_status"], doc["check_status"])
    assert not state["cancel_requested"]
    assert len(row["steps"]) == len(STEPS)
    events = {event["step_key"]: event for event in doc["steps"]}
    assert len(events) == len(doc["steps"])
    for step, (key, tool, parameters) in zip(row["steps"], STEPS, strict=True):
        assert step["key"] == key
        if step["status"] == "NOT_STARTED":
            assert key not in events and all(step[name] is None for name in ("tool", "parameters", "exit_code", "error"))
            continue
        event = events[key]
        assert step["tool"] == {"id": tool, "version": 1} and step["parameters"] == parameters
        assert event["tool"]["id"] == tool and event["tool"]["version"] == 1
        assert (step["status"], step["exit_code"]) == (event["status"], event["exit_code"])
        assert any(proc["phase"] == "execute" for proc in event["processes"])
    assert row["status"] == "FAIL"
    return {
        "cache": row["cache"], "phase": row["phase"], "repeat": row["repeat"],
        "run_id": row["run_id"], "plan_id": row["plan_id"], "workdir": row["workdir"],
        "status": row["status"], "terminal": [state["execution_status"], state["check_status"]],
        "exit_code": doc["exit_code"], "error": state["error"], "wall_ns": row["wall_ns"],
        "steps": [{"key": step["key"], "status": step["status"], "exit_code": step["exit_code"],
                   "timed_out": any(p["timed_out"] for p in events.get(step["key"], {}).get("processes", []))}
                  for step in row["steps"]],
        "status_read_errors": row.get("status_read_errors", []), "correctness": row.get("correctness"),
        "resources": measure_columns(row),
        "artifacts": row.get("artifacts"), "checks": row.get("checks"),
    }


def timeout_prefix(row, failure_index):
    failure = row["run_status"]["error"]
    failed_key = STEPS[failure_index][0]
    assert (row["status"], row["run_status"]["execution_status"], row["run_status"]["check_status"]) == (
        "FAIL", "FAILED", "NOT_CHECKED",
    )
    assert row["error"] == "ValueError: Run state is FAILED/NOT_CHECKED"
    assert (failure["code"], failure["phase"], failure["step_key"], failure["message"]) == (
        "PROCESS_TIMEOUT", "execute", failed_key, "Process exceeded 60 seconds",
    )
    assert row["run_status"]["current_step"] == failed_key and row["run_status"]["current_report_id"] is None
    assert all(name not in row for name in ("correctness", "checks", "artifacts"))

    steps = row["steps"]
    for completed in steps[:failure_index]:
        assert completed["status"] == "SUCCEEDED" and completed["exit_code"] == 0 and completed["error"] is None
    failed = steps[failure_index]
    assert failed["status"] == "FAILED" and failed["exit_code"] == -15 and failed["error"] == failure
    for unstarted in steps[failure_index + 1:]:
        assert unstarted["status"] == "NOT_STARTED"
        assert all(unstarted[field] is None for field in ("exit_code", "error", "tool", "parameters"))
    sidecar = row["telemetry"]["document"]
    assert sidecar["exit_code"] == -15
    assert [event["step_key"] for event in sidecar["steps"]] == [step[0] for step in STEPS[:failure_index + 1]]
    for index, event in enumerate(sidecar["steps"]):
        process, = [proc for proc in event["processes"] if proc["phase"] == "execute"]
        assert process["cancelled"] is False
        if index == failure_index:
            assert event["exit_code"] == process["exit_code"] == -15 and event["status"] == "FAILED"
            assert process["timed_out"] is True and process["wall_ns"] >= 60_000_000_000
        else:
            assert event["exit_code"] == process["exit_code"] == 0 and event["status"] == "SUCCEEDED"
            assert process["timed_out"] is False
    if failure_index == 1:
        selected = row["step_logs"]["steps/apply_spatial_relation/process.log"]
        assert not selected["truncated"]
        assert "Selected 131072 of 131072 complete target(s) using intersects" in selected["text"]


def audit_runs(rows, expected, *, complete, failure_index):
    keys = [(row["cache"], row["phase"], row["repeat"]) for row in rows]
    assert keys == PLANNED[:len(rows)] and (not complete or keys == PLANNED)
    for field in ("run_id", "workdir"):
        assert len({row[field] for row in rows}) == len(rows)
    records = []
    for row in rows:
        record = one_run(row, expected)
        timeout_prefix(row, failure_index)
        records.append(record)

    groups = {}
    for cache in CACHES:
        group = [r for r in rows if r["cache"] == cache]
        plans = {r["plan_id"] for r in group}
        assert len(plans) == (len(group) if cache == "process_cold" else bool(group))
        assert [r["service_reused"] for r in group] == [cache == "warm" and i > 0 for i in range(len(group))]
        measured = [r for r in group if r["phase"] == "measurement"]
        by_status = {}
        for outcome in ("PASS", "FAIL"):
            selected = [r for r in measured if r["status"] == outcome]
            columns = [measure_columns(r) for r in selected]
            by_status[outcome] = {field: distribution([m[field] for m in columns]) for field in METRICS}
            by_status[outcome]["steps"] = {}
            for step_key, _, _ in STEPS:
                events = [event for row in selected for event in row["telemetry"]["document"]["steps"]
                          if event["step_key"] == step_key]
                by_status[outcome]["steps"][step_key] = {
                    "wall_ns": distribution([reading(e["wall_ns"]) for e in events]),
                    **{name: distribution([e["resources"][name] for e in events]) for name in RESOURCES},
                }
        groups[cache] = {
            "counts": {phase: dict(Counter(r["status"] for r in group if r["phase"] == phase))
                       for phase, _ in PHASES},
            "measured_distributions": by_status,
        }
    plans = {cache: {r["plan_id"] for r in rows if r["cache"] == cache} for cache in CACHES}
    assert plans["process_cold"].isdisjoint(plans["warm"])
    return {"rows": records, "groups": groups}


def reported_distribution(report, field, dist):
    assert (report[f"{field}_n"], report[f"{field}_partial_n"]) == (
        dist["samples"], dist["coverage"].get("partial", 0),
    )
    assert (report[f"{field}_median"], report[f"{field}_p95"]) == (dist["median"], dist["p95"])


def compare_summary(summary, side):
    assert summary["finished_utc"] and not summary["probe"]
    totals = Counter(r["status"] for r in side["rows"])
    assert summary["sample_counts"] == {status: totals[status] for status in ("PASS", "FAIL", "NOT_RUN")}
    assert summary["status"] == ("INCOMPLETE" if totals["FAIL"] else "PASS")
    assert len(summary["groups"]) == 2 and {g["cache"] for g in summary["groups"]} == set(CACHES)
    step_groups = {(g["cache"], g["step"]): g for g in summary["step_groups"]}
    assert len(step_groups) == len(summary["step_groups"])
    for group in summary["groups"]:
        cache = group["cache"]
        assert (group["tier"], group["workload"], group["input_profile"]) == ("L", WORKLOAD, "p13-01")
        actual = side["groups"][cache]
        n = actual["counts"]["measurement"].get("PASS", 0)
        assert group["status"] == ("COMPLETE" if n == 5 else "PARTIAL" if n >= 3 else "INSUFFICIENT")
        for phase, tag in (("warmup", "warmup"), ("measurement", "measured")):
            for status in ("PASS", "FAIL", "NOT_RUN"):
                assert group[f"{tag}_{status.lower()}"] == actual["counts"][phase].get(status, 0)
        observed_errors = sum(bool(row["status_read_errors"]) for row in side["rows"]
                              if (row["cache"], row["phase"], row["status"]) == (cache, "measurement", "PASS"))
        assert group["probe_pass"] == 0 and group["measured_pass_with_status_read_errors"] == observed_errors
        correct = actual["measured_distributions"]["PASS"]
        for field in METRICS:
            reported_distribution(group, field, correct[field])
        for key, tool, _ in STEPS:
            step = step_groups.pop((cache, key), None)
            if n:
                assert step is not None
                assert (step["tier"], step["workload"], step["input_profile"], step["tool"], step["tool_version"]) == (
                    "L", WORKLOAD, "p13-01", tool, 1,
                )
                for field in ("wall_ns", *RESOURCES):
                    reported_distribution(step, field, correct["steps"][key][field])
            else:
                assert step is None
    assert not step_groups


def final_metadata(attempt, expected, side):
    evidence = attempt / "evidence"
    assert (attempt.parent / "COMPLETED").read_text().strip() == attempt.name
    container_exit = int((attempt / "container-exit").read_text())
    logging_exit = int((attempt / "logging-exit").read_text())
    assert container_exit == int(any(row["status"] == "FAIL" for row in side["rows"]))
    assert logging_exit == 0
    compare_summary(read(evidence / "summary.json"), side)
    receipt = read(evidence / "runtime-configuration.json")
    assert receipt["schema_version"] == 1 and receipt["before"] == receipt["after"]
    assert receipt["report_files"] == {name: digest(evidence / name) for name in ("summary.json", "environment.json")}
    assert receipt["before"]["sha256"] == snapshot_digest(receipt["before"])
    inputs = read(evidence / "inputs.json")
    assert set(inputs) == {"L"}
    frozen = inputs["L"]
    assert frozen["input_manifest_sha256"] == expected["input_manifest_sha256"]
    assert frozen["files_before"] == frozen["files_after"] == expected["files"]
    assert digest(evidence / "input-L/manifest.json") == expected["input_manifest_sha256"]
    return {
        "container_exit": container_exit, "logging_exit": logging_exit,
        "finished_utc": (attempt / "finished-utc").read_text().strip(),
        "runtime_configuration_sha256": receipt["before"]["sha256"],
        "report_hashes": {name: digest(evidence / name) for name in
                          ("summary.json", "environment.json", "samples.jsonl", "runtime-configuration.json", "inputs.json")},
    }


def side_environment(attempt, side):
    command, filesystem = (attempt / "command.log").read_text().splitlines()
    args = shlex.split(command)
    assert IMAGE in args and filesystem == FILESYSTEM
    assert digest(attempt / "source-tree.sha256") == TREE_HASHES[side]
    assert digest(attempt / "frozen-runner.sha256") == FROZEN_RUNNER_HASH
    assert args[args.index("--source-commit") + 1] == COMMITS[side]
    assert args[args.index("--workload") + 1] == WORKLOAD
    assert args[args.index("--tier") + 1] == "L"
    assert [args[i+1] for i, arg in enumerate(args) if arg == "--cache-state"] == list(CACHES)
    environment_path = attempt / "evidence/environment.json"
    if not environment_path.is_file():
        return None
    env = read(environment_path)
    assert env["source_commit"] == COMMITS[side] and env["probe"] is False
    assert (env["planned_warmups"], env["planned_repeats"], env["run_wait_seconds"], env["budget_seconds"]) == (2, 5, 600, None)
    assert env["runner_sha256"] == {
        "run_vector.py": "52b254fcd93b08521ae7347c44e27f9dda3979bcda7fd8b97f1d72a5cd232063",
        "_vector_reference.py": "2aad7d57adba3a9a98cf93e68c40e60d717268b6fd5f229ad54e59bfd46d41f1",
        "_vector_road_profile.py": "31aefb282de59a63882e7b1bcca436fe1f10204bf60e6c07f0f8c6d0d5117232",
    }
    assert env["qgis_version"]["exit_code"] == 0
    return {name: env[name] for name in ("source_commit", "started_utc", "qgis_version", "runner_sha256", "storage_filesystem")}


def id_sets(audit):
    return {field: {row[field] for row in audit["rows"]} for field in ("run_id", "plan_id", "workdir")}


def comparison_distribution(source):
    return {
        "samples": source["samples"], "partial": source["coverage"].get("partial", 0),
        "median": source["median"], "p95_nearest_rank": source["p95"],
    }


def check_comparison(result, sides, paired):
    old, new = sides["before"], sides["after"]
    assert result["status"] == "MATCHED_EVIDENCE" and result["same_source"] == (not paired)
    assert result["before_source"] == old["environment"]["source_commit"]
    assert result["after_source"] == new["environment"]["source_commit"]
    assert old["runtime_configuration_sha256"] == new["runtime_configuration_sha256"]
    assert result["runtime_configuration"]["sha256"] == old["runtime_configuration_sha256"]
    assert result["candidate_all_measurements_pass"] == all(
        new["groups"][cache]["counts"]["measurement"].get("PASS", 0) == 5 for cache in CACHES
    )
    assert len(result["groups"]) == 2 and {g["group"][2] for g in result["groups"]} == set(CACHES)
    fields = ("wall_ns", "peak_rss_bytes", "peak_temp_bytes")
    for group in result["groups"]:
        tier, workload, cache, profile = group["group"]
        assert (tier, workload, profile) == ("L", WORKLOAD, "p13-01")
        for label, side in sides.items():
            actual = side["groups"][cache]
            observed = group[label]
            assert observed["counts"] == {
                status: actual["counts"]["measurement"].get(status, 0) for status in ("PASS", "FAIL", "NOT_RUN")
            }
            assert observed["failure_codes"] == Counter(
                (row["error"] or {}).get("code", "unspecified") for row in side["rows"]
                if (row["cache"], row["phase"], row["status"]) == (cache, "measurement", "FAIL")
            )
            for status in ("PASS", "FAIL"):
                for field in fields:
                    source = actual["measured_distributions"][status][field]
                    assert observed[field][status] == comparison_distribution(source)
        expected_deltas = {}
        for field in fields:
            a, b = (group[label][field]["PASS"] for label in ("before", "after"))
            counts = (group[label]["counts"]["PASS"] for label in ("before", "after"))
            if len({a["samples"], b["samples"], *counts}) == 1 and all(
                item["samples"] >= 3 and item["partial"] == 0 for item in (a, b)
            ):
                expected_deltas[field] = {key: b[key] - a[key] for key in ("median", "p95_nearest_rank")}
        assert group["successful_sample_deltas"] == expected_deltas


def inspect_side(side, expected, prior):
    marker = SHARD / side / "COMPLETED"
    assert marker.is_file(), f"{side} has not reached verified terminal evidence"
    attempt = marker.parent / marker.read_text().strip()
    rows = live_rows(attempt / "evidence/samples.jsonl", True)
    result = audit_runs(rows, expected, complete=True, failure_index=0 if side == "base" else 1)
    result["attempt"] = str(attempt)
    result["environment"] = side_environment(attempt, side)
    result.update(final_metadata(attempt, expected, result))
    for field, values in id_sets(result).items():
        assert values.isdisjoint({row[field] for row in prior})
    check_comparison(read(attempt / "self-comparison.json"), {"before": result, "after": result}, paired=False)
    return result


def print_distributions(side, record):
    status = "FAIL"
    print(side, "container/log exit", record["container_exit"], record["logging_exit"],
          "finished UTC", record["finished_utc"], "runtime SHA", record["runtime_configuration_sha256"])
    for cache, group in record["groups"].items():
        d = group["measured_distributions"][status]
        print(side, cache, status, "E2E ns", d["wall_ns"], "RSS bytes", d["peak_rss_bytes"],
              "temp bytes", d["peak_temp_bytes"])
        for key, step in d["steps"].items():
            print(side, cache, key, "step ns", step["wall_ns"], "RSS bytes", step["peak_rss_bytes"])


POINTS_PROOF = Path("/tmp/geopilot-p13-05-vector-l-points-final-audit.DXmSFT/independent.json")
POINTS_PROOF_SHA = "b50d0bec84e1cf18397517674996851c8789f387010a97045b9547b8c108f2c2"
LINES_PROOF = Path("/tmp/geopilot-p13-05-vector-l-lines-final-audit.0a1cK7/independent.json")
LINES_PROOF_SHA = "63166a67addfc329017e13b786f6ea4ee9a0070cc0787bc8303407ebcdee32b2"
BASE_PROOF = Path("/tmp/geopilot-p13-05-vector-l-t14-base-final-audit.VzcZkK/independent.json")
BASE_PROOF_SHA = "d0582d083b744f4748104689dfa7b0120418096f2cfdf71f87f25db89686deda"


def proof_rows(path, expected_digest):
    assert digest(path) == expected_digest
    proof = read(path)
    rows = [row for side in ("base", "candidate") for row in proof[side]["rows"]]
    assert len(rows) == len({row["run_id"] for row in rows}) == 28
    return rows, proof["base"]["runtime_configuration_sha256"]


def main(output):
    expected = read(PLAN / "proof/expected-inputs.json")
    prior_files = [RECORDS / f"p13-03-L-{suffix}-samples.jsonl.gz" for suffix in ("formal", "remaining")]
    prior = [row for archive in prior_files for row in archived_rows(archive)]
    assert len(prior) == len({row["run_id"] for row in prior}) == 140
    old_input = read(RECORDS / "p13-03-L-formal-inputs.json")["L"]
    assert old_input["files_before"] == old_input["files_after"] == expected["files"]
    assert old_input["input_manifest_sha256"] == expected["input_manifest_sha256"]
    old_t14 = [row for row in prior if row["workload"] == WORKLOAD]
    assert len(old_t14) == 14
    historical = audit_runs(old_t14, expected, complete=True, failure_index=0)

    base, candidate = (inspect_side(side, expected, prior) for side in ("base", "candidate"))
    assert (base["container_exit"], base["logging_exit"], candidate["container_exit"], candidate["logging_exit"]) == (1, 0, 1, 0)
    assert len(base["rows"]) == len(candidate["rows"]) == 14
    for field, values in id_sets(base).items():
        assert values.isdisjoint(id_sets(candidate)[field])
    assert len(id_sets(base)["run_id"] | id_sets(candidate)["run_id"]) == 28
    assert digest(BASE_PROOF) == BASE_PROOF_SHA and read(BASE_PROOF)["base"] == base

    points, points_config = proof_rows(POINTS_PROOF, POINTS_PROOF_SHA)
    lines, lines_config = proof_rows(LINES_PROOF, LINES_PROOF_SHA)
    earlier = points + lines + prior
    assert len(earlier) == len({row["run_id"] for row in earlier}) == 196
    assert len({row["run_id"] for row in earlier + base["rows"] + candidate["rows"]}) == 224
    for side in (base, candidate):
        for field, values in id_sets(side).items():
            assert values.isdisjoint({row[field] for row in points + lines})
        assert side["runtime_configuration_sha256"] == points_config == lines_config

    pair_file, = SHARD.glob("comparison.*/result.json")
    assert pair_file.with_name("stderr.log").read_bytes() == b""
    assert pair_file.with_name("evidence-paths").read_text().splitlines() == [
        str(Path(side["attempt"]) / "evidence") for side in (base, candidate)
    ]
    pair = read(pair_file)
    check_comparison(pair, {"before": base, "after": candidate}, paired=True)
    assert not pair["candidate_all_measurements_pass"]
    assert all(group["successful_sample_deltas"] == {} for group in pair["groups"])

    result = {
        "evidence_root": str(SHARD), "input_manifest_sha256": expected["input_manifest_sha256"],
        "historic_archives": {str(f): digest(f) for f in prior_files}, "historic_unique_run_count": 140,
        "historic_t14_groups": historical["groups"], "prior_unique_run_count": 196,
        "current_unique_run_count": 28, "combined_unique_run_count": 224,
        "base": base, "candidate": candidate, "pair_path": str(pair_file), "pair_sha256": digest(pair_file),
        "pair_status": pair["status"],
        "status_read_errors": {label: sum(len(row["status_read_errors"]) for row in side["rows"])
                               for label, side in (("base", base), ("candidate", candidate))},
    }
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    for label, side in (("base", base), ("candidate", candidate)):
        print_distributions(label, side)
    print("status read errors", result["status_read_errors"])
    print("28 distinct IDs; 224 unique including historical L, point pair and line pair")
    print("base: select timeout, clip and aggregate not started; candidate: select succeeds, clip timeout, aggregate not started")
    print("strict matched evidence, both sides zero correct samples, success deltas empty", pair_file)


if __name__ == "__main__":
    main(Path(sys.argv[1]))
