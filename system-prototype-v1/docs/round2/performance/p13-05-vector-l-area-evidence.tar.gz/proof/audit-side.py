"""Recompute L vector observations from a retained formal attempt."""
import argparse
from collections import Counter, defaultdict
import gzip
from hashlib import sha256
import json
from math import ceil
from pathlib import Path
import runpy
from statistics import median

SOURCES = {
    "base": "977ab412d9f6e7558d22a5c431fac0ada90b07be",
    "candidate": "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc",
}
CACHES = ("process_cold", "warm")
STATUSES = ("FAIL", "NOT_RUN", "PASS")
SLOTS = [(cache, phase, repeat) for cache in CACHES
         for phase, count in (("warmup", 2), ("measurement", 5)) for repeat in range(1, count + 1)]


def load(path):
    return json.loads(path.read_bytes())


def distribution(observations, complete):
    readings = sorted(item["value"] for item in observations if item.get("value") is not None)
    count = len(readings)
    return {
        "samples": count,
        "partial": sum(item.get("status") == "partial" and item.get("value") is not None for item in observations),
        "median": median(readings) if complete and count >= 3 else None,
        "p95_nearest_rank": readings[ceil(.95 * count) - 1] if complete and count >= 3 else None,
    }


def metrics(row):
    return {
        "wall_ns": {"value": row["wall_ns"]},
        "peak_rss_bytes": row["telemetry"]["document"]["resources"]["peak_rss_bytes"],
        "peak_temp_bytes": row["peak_temp_bytes"],
    }


def step_profiles(rows, complete):
    recorded = defaultdict(list)
    for row in rows:
        for step in row["telemetry"]["document"]["steps"]:
            recorded[step["step_key"], step["status"]].append(step)
    steps = {}
    for (key, status), observations in recorded.items():
        steps.setdefault(key, {})[status] = {
            "count": len(observations),
            "wall_ns": distribution([{"value": step["wall_ns"]} for step in observations], complete),
            "peak_rss_bytes": distribution([step["resources"]["peak_rss_bytes"] for step in observations], complete),
        }
    return steps


def group(rows, cache):
    selected = [row for row in rows if row["cache"] == cache]
    measured = [row for row in selected if row["phase"] == "measurement"]
    complete = len(measured) == 5
    failures = Counter()
    for row in measured:
        if row["status"] == "FAIL":
            error = row["run_status"].get("error")
            failures[f'{error["code"]}/{error["step_key"]}' if error else "independent_validation"] += 1
    return {
        "observed_slots": len(selected), "measurement_slots": len(measured),
        "measurement_complete": complete,
        "counts": {state: sum(row["status"] == state for row in measured) for state in STATUSES},
        "failure_locations": dict(sorted(failures.items())),
        "metrics": {
            name: {state: distribution([metrics(row)[name] for row in measured if row["status"] == state], complete)
                   for state in ("PASS", "FAIL")}
            for name in ("wall_ns", "peak_rss_bytes", "peak_temp_bytes")
        },
        "steps": step_profiles(measured, complete),
    }


def historical_ids(directory):
    ids = set()
    for label in ("L-formal", "L-remaining"):
        with gzip.open(directory / f"p13-03-{label}-samples.jsonl.gz", "rt", encoding="utf-8") as raw:
            for row in map(json.loads, raw):
                assert row["run_id"] not in ids
                ids.add(row["run_id"])
    assert len(ids) == 140
    return ids


def verify_complete(attempt, rows, counts, workload):
    assert len(rows) == len(SLOTS), "Incomplete formal sample schedule"
    report = load(attempt / "evidence/summary.json")
    assert report["sample_counts"] == counts and report["finished_utc"]
    assert report["status"] == ("INCOMPLETE" if counts["FAIL"] else "PASS")
    assert (attempt / "container-exit").read_text().strip() == ("1" if counts["FAIL"] else "0")
    groups = report["groups"]
    assert len(groups) == len(CACHES) and {item["cache"] for item in groups} == set(CACHES)
    for item in groups:
        assert (item["tier"], item["workload"], item["input_profile"]) == ("L", workload, "p13-01")
        for phase, prefix in (("warmup", "warmup"), ("measurement", "measured")):
            for status in STATUSES:
                assert item[f"{prefix}_{status.lower()}"] == sum(
                    (row["cache"], row["phase"], row["status"]) == (item["cache"], phase, status) for row in rows
                )


def verify_comparison(document, workload, side, groups):
    recorded_side = "before" if side == "base" else "after"
    assert document["status"] == "MATCHED_EVIDENCE" and document[f"{recorded_side}_source"] == SOURCES[side]
    expected_keys = {("L", workload, cache, "p13-01") for cache in CACHES}
    assert {tuple(item["group"]) for item in document["groups"]} == expected_keys
    for item in document["groups"]:
        expected = groups[item["group"][2]]
        recorded = item[recorded_side]
        assert recorded["counts"] == expected["counts"]
        for metric, observed in expected["metrics"].items():
            assert observed == recorded[metric], f"{item['group']}: {metric} differs from raw observations"
        if expected["counts"]["PASS"] == 0:
            assert not item["successful_sample_deltas"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("attempt", type=Path)
    parser.add_argument("proof", type=Path)
    parser.add_argument("history", type=Path)
    parser.add_argument("side", choices=SOURCES)
    parser.add_argument("workload")
    parser.add_argument("--complete", action="store_true")
    parser.add_argument("--comparison", type=Path)
    args = parser.parse_args()
    if args.comparison and not args.complete:
        parser.error("--comparison requires --complete")
    evidence = args.attempt / "evidence"
    verifier = runpy.run_path(str(args.proof / "check-side.py"))
    expected = load(args.proof / "expected-inputs.json")
    environment = load(evidence / "environment.json")
    assert environment["source_commit"] == SOURCES[args.side] and environment["probe"] is False
    assert environment["runner_sha256"] == verifier["RUNNER"]
    manifest = (evidence / "input-L/manifest.json").read_bytes()
    assert sha256(manifest).hexdigest() == expected["input_manifest_sha256"]
    assert json.loads(manifest)["files"] == expected["files"]
    lines = (evidence / "samples.jsonl").read_bytes().splitlines(keepends=True)
    if lines and not lines[-1].endswith(b"\n"):
        assert not args.complete, "Incomplete last record"
        lines.pop()
    rows = [json.loads(line) for line in lines]
    assert [(row["cache"], row["phase"], row["repeat"]) for row in rows] == SLOTS[:len(rows)]
    ids = historical_ids(args.history)
    for row in rows:
        assert row["run_id"] not in ids, f'Duplicate run ID {row["run_id"]}'
        ids.add(row["run_id"])
        assert (row["tier"], row["workload"], row["input_profile"], row["input_manifest_sha256"]) == (
            "L", args.workload, "p13-01", expected["input_manifest_sha256"],
        )
        verifier["verify_sample"](row, args.workload, expected["correctness"][args.workload])
    counts = {state: sum(row["status"] == state for row in rows) for state in STATUSES}
    if args.complete:
        verify_complete(args.attempt, rows, counts, args.workload)
    groups = {cache: group(rows, cache) for cache in CACHES}
    if args.comparison:
        verify_comparison(load(args.comparison), args.workload, args.side, groups)
    result = {
        "state": "COMPLETE" if args.complete else "OBSERVED_PREFIX",
        "workload": args.workload, "side": args.side, "source_commit": SOURCES[args.side],
        "observed_rows_sha256": sha256(b"".join(lines)).hexdigest(), "rows": len(rows), "counts": counts,
        "historic_run_ids_excluded": 140, "groups": groups,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
