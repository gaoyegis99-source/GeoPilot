"""Verify a single L vector shard, including persisted failed runs."""

from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import sys


CACHES = ("process_cold", "warm")
PHASES = {"warmup": range(1, 3), "measurement": range(1, 6)}
SHARD_WORKLOADS = {"t13-points-intersects", "t13-lines-intersects", "t14-split_by_area"}
RUNNER = {
    "run_vector.py": "52b254fcd93b08521ae7347c44e27f9dda3979bcda7fd8b97f1d72a5cd232063",
    "_vector_reference.py": "2aad7d57adba3a9a98cf93e68c40e60d717268b6fd5f229ad54e59bfd46d41f1",
    "_vector_road_profile.py": "31aefb282de59a63882e7b1bcca436fe1f10204bf60e6c07f0f8c6d0d5117232",
}
RELATION = {"spatial_relation": "intersects"}
ALLOCATION = {"boundary_assignment": "split_by_area", "boundary_tie": "unassigned", "area_crs": "EPSG:6933"}
T13_STEPS = (
    ("apply_spatial_relation", "python-select-spatial-relation", RELATION),
    ("clip_back_to_analysis_extent", "python-clip-vector-to-extent", {}),
)
T14_STEPS = T13_STEPS + (
    ("aggregate_by_zone", "python-polygon-zone-statistics", {**ALLOCATION, "area_unit": "square_meter"}),
)
TERMINAL_EXECUTION = {"SUCCEEDED", "FAILED", "CANCELLED"}
TERMINAL_CHECK = {"PASSED", "FAILED", "WARNING", "NOT_CHECKED"}


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify_sample(row, workload, expected_correctness):
    """Check the actual executed prefix against the confirmed method contract."""
    polygon = workload == "t14-split_by_area"
    steps = T14_STEPS if polygon else T13_STEPS
    method = "polygon-zone-statistics" if polygon else "spatial-select-and-clip"
    options = {**RELATION, **ALLOCATION} if polygon else RELATION
    run_id = row["run_id"]
    require(row["method"] == {"id": method, "version": 1} and row["critical_options"] == options,
            f"{run_id}: method or options differ")
    run = row["run_status"]
    state = (run["execution_status"], run["check_status"])
    require(run_id and run_id == run["run_id"] and state[0] in TERMINAL_EXECUTION and state[1] in TERMINAL_CHECK,
            f"{run_id}: missing persisted terminal status")
    require(type(row["wall_ns"]) is int and row["wall_ns"] > 0, f"{run_id}: missing terminal wall time")
    raw_steps = row["steps"]
    require([step["key"] for step in raw_steps] == [key for key, _, _ in steps],
            f"{run_id}: planned step sequence differs")
    executed = []
    stopped = False
    for step, (key, tool, parameters) in zip(raw_steps, steps):
        status, exit_code = step["status"], step["exit_code"]
        if status == "NOT_STARTED":
            require(all(step[name] is None for name in ("tool", "parameters", "exit_code", "error")),
                    f"{run_id}/{key}: unstarted step contains execution evidence")
            stopped = True
            continue
        require(not stopped and status in TERMINAL_EXECUTION, f"{run_id}/{key}: invalid executed step prefix")
        require(step["tool"] == {"id": tool, "version": 1} and step["parameters"] == parameters,
                f"{run_id}/{key}: executed tool or parameters differ")
        require(status != "SUCCEEDED" or exit_code == 0, f"{run_id}/{key}: successful step has a nonzero exit")
        executed.append((key, tool, 1, status, exit_code))
        stopped = status != "SUCCEEDED"
    telemetry = row["telemetry"]
    require(telemetry["status"] == "recorded", f"{run_id}: missing terminal telemetry")
    document = telemetry["document"]
    require(document["run_id"] == run_id and (document["execution_status"], document["check_status"]) == state,
            f"{run_id}: terminal telemetry differs")
    observed = [(step["step_key"], step["tool"]["id"], step["tool"]["version"], step["status"], step["exit_code"])
                for step in document["steps"]]
    require(observed == executed, f"{run_id}: executed step telemetry differs")
    failure = run.get("error") or {}
    error_code = failure.get("code")
    if error_code == "PROCESS_TIMEOUT":
        require(executed and executed[-1][0] == failure["step_key"] and executed[-1][3] == "FAILED"
                and type(executed[-1][4]) is int and document["exit_code"] == executed[-1][4],
                f"{run_id}: incomplete or inconsistent timeout evidence")
        timeout = raw_steps[len(executed) - 1].get("error") or {}
        require((timeout.get("code"), timeout.get("step_key")) == (error_code, failure["step_key"]),
                f"{run_id}: failed step lacks its timeout error")
    if row["status"] == "PASS":
        require(state == ("SUCCEEDED", "PASSED") and len(executed) == len(steps) and not stopped
                and document["exit_code"] == 0 and row["correctness"] == expected_correctness,
                f"{run_id}: successful run lacks the independently expected outputs")
        artifacts = {"clipped_targets", "original_targets"}
        if polygon:
            artifacts.update(("allocation_details", "zone_statistics"))
        rules = row["checks"]["rules"]
        require(set(row["artifacts"]) == artifacts and rules and all(value is True for value in rules.values()),
                f"{run_id}: successful run lacks artifact or check evidence")
    else:
        require(row["status"] == "FAIL" and (error_code or row.get("error")),
                f"{run_id}: attempted failure has no cause")
    return executed, error_code


def verify_shard(root, commit, workload, expected):
    def read(name):
        return json.loads((root / name).read_bytes())

    require(workload in SHARD_WORKLOADS, "Unexpected L workload")
    environment, summary, receipt = (read(name) for name in
                                     ("environment.json", "summary.json", "runtime-configuration.json"))
    require(environment["source_commit"] == commit and environment["runner_sha256"] == RUNNER,
            "Unexpected source or vector runner")
    require(environment["probe"] is False and summary["probe"] is False and summary["finished_utc"],
            "Complete formal report required")
    require((environment["planned_repeats"], environment["planned_warmups"]) == (5, 2)
            and environment["run_wait_seconds"] == 600 and environment["budget_seconds"] is None,
            "Unexpected repeat, wait or budget")
    require((root.parent / "logging-exit").read_text().strip() == "0", "Console log was not fully preserved")
    require(receipt["before"] == receipt["after"], "Runtime configuration drift")
    inputs = read("inputs.json")
    require(set(inputs) == {"L"}, "Unexpected input tiers")
    record = inputs["L"]
    require("road_position_correction" not in record and record["files_before"] == record["files_after"]
            == expected["files"] and record["input_manifest_sha256"] == expected["input_manifest_sha256"],
            "Generated inputs differ from the original L fingerprints")
    input_root = root / "input-L"
    require(digest(input_root / "manifest.json") == expected["input_manifest_sha256"],
            "Stored input manifest digest differs")
    for item in expected["files"]:
        path = input_root / item["path"]
        require(path.stat().st_size == item["bytes"] and digest(path) == item["sha256"],
                f"Stored input differs for {path.name}")

    groups = {g["cache"]: g for g in summary["groups"]}
    require(len(summary["groups"]) == 2 and set(groups) == set(CACHES)
            and all((g["tier"], g["workload"], g["input_profile"]) == ("L", workload, "p13-01")
                    for g in groups.values()), "Unexpected summary groups")
    package = "t14.gpkg" if workload == "t14-split_by_area" else "relations.gpkg"
    expected_package = next(item for item in expected["files"] if item["path"] == package)
    planned = {(cache, phase, repeat) for cache in CACHES for phase, repeats in PHASES.items() for repeat in repeats}
    runs, keys = set(), set()
    counts = Counter()
    plan_ids = {cache: set() for cache in CACHES}
    coverage = {cache: {"executed": Counter(), "successful": Counter(), "failure_codes": Counter()} for cache in CACHES}
    with (root / "samples.jsonl").open(encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            key = row["cache"], row["phase"], row["repeat"]
            require(key in planned and key not in keys and row["run_id"] not in runs, f"Duplicate or unexpected trial {key}")
            require((row["tier"], row["workload"], row["input_profile"], row["input_manifest_sha256"])
                    == ("L", workload, "p13-01", expected["input_manifest_sha256"]), f"{key}: unexpected sample input")
            require(row["input"] == expected_package and row["input_bytes"] == expected_package["bytes"],
                    f"{key}: unexpected sample package fingerprint")
            keys.add(key)
            runs.add(row["run_id"])
            plan_ids[row["cache"]].add(row["plan_id"])
            counts[(row["cache"], row["phase"], row["status"])] += 1
            executed, error_code = verify_sample(row, workload, expected["correctness"][workload])
            observed = coverage[row["cache"]]
            observed["executed"].update(step[0] for step in executed)
            observed["successful"].update(step[0] for step in executed if step[3] == "SUCCEEDED")
            if row["status"] == "FAIL":
                observed["failure_codes"][error_code or "independent_validation"] += 1
    require(keys == planned, "Incomplete trial schedule")
    require(len(plan_ids["process_cold"]) == 7 and len(plan_ids["warm"]) == 1
            and plan_ids["process_cold"].isdisjoint(plan_ids["warm"]), "Cold or warm plan reuse differs")
    totals = {status: sum(n for (_, _, state), n in counts.items() if state == status)
              for status in ("PASS", "FAIL", "NOT_RUN")}
    require(summary["sample_counts"] == totals, "Summary counts disagree with raw runs")
    for cache, group in groups.items():
        for phase, prefix in (("warmup", "warmup"), ("measurement", "measured")):
            for status in totals:
                require(group[f"{prefix}_{status.lower()}"] == counts[cache, phase, status],
                        f"{cache}/{phase}: summary counts disagree with raw runs")
    outcome = ("1", "INCOMPLETE") if totals["FAIL"] else ("0", "PASS")
    require(((root.parent / "container-exit").read_text().strip(), summary["status"]) == outcome,
            "Container exit does not agree with the complete formal report")
    return {"source_commit": commit, "workload": workload, "status": summary["status"], "sample_counts": totals,
            "input_manifest_sha256": record["input_manifest_sha256"],
            "runtime_configuration_sha256": receipt["before"]["sha256"], "step_coverage": coverage}


if __name__ == "__main__":
    try:
        root = Path(sys.argv[1])
        commit, workload = sys.argv[2:]
        expected = json.loads(Path(__file__).with_name("expected-inputs.json").read_bytes())
        result = verify_shard(root, commit, workload, expected)
    except (KeyError, OSError, TypeError, ValueError) as error:
        raise SystemExit(str(error)) from error
    print(json.dumps(result, indent=2))
