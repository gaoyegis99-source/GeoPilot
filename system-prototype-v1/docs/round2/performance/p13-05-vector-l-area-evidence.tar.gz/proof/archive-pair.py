"""Archive a completed formal L vector pair without duplicating input GPKGs."""
import argparse
import json
from pathlib import Path
import re
from shutil import copyfile

ATTEMPT_FILES = (
    "command.log", "run.log", "container-exit", "logging-exit", "started-utc", "finished-utc",
    "storage-and-start-load.log", "shard-verification.json", "self-comparison.json",
    "source-tree.sha256", "frozen-runner.sha256", "evidence/command.log", "evidence/summary.json",
    "evidence/environment.json", "evidence/inputs.json", "evidence/samples.jsonl",
    "evidence/runtime-configuration.json", "evidence/input-L/manifest.json",
)


def copy_files(source, destination, names):
    for name in names:
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        copyfile(source / name, target)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("archive", type=Path)
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    roles = ("base", "candidate")
    markers = {role: (source / role / "COMPLETED").read_text().strip() for role in roles}
    assert all(re.fullmatch(r"attempt\.[A-Za-z0-9]+", marker) for marker in markers.values())
    paths = {role: source / role / marker for role, marker in markers.items()}
    expect = [str(paths[role] / "evidence") for role in roles]
    matches = [
        child for child in sorted(source.glob("comparison.*"))
        if (child / "result.json").is_file() and (child / "evidence-paths").read_text().splitlines() == expect
    ]
    pair, = matches
    result = json.loads((pair / "result.json").read_bytes())
    assert result["status"] == "MATCHED_EVIDENCE" and not (pair / "stderr.log").read_bytes()
    target = args.archive / source.name
    target.mkdir(parents=True, exist_ok=False)
    for role, path in paths.items():
        copy_files(path, target / role / markers[role], ATTEMPT_FILES)
        copy_files(path.parent, target / role, ("COMPLETED",))
    copy_files(pair, target / pair.name, ("result.json", "stderr.log", "evidence-paths"))
    print(target / pair.name / "result.json")


if __name__ == "__main__":
    main()
