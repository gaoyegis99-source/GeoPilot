"""Integrate the actual DEM L class boundary at fixed densities, as an isolated comparison."""
from collections import Counter
from hashlib import sha256
import json
import math
from pathlib import Path
import sys
import time

import numpy as np
from pyproj import Transformer
import rasterio

# Per cell, follow top, right, bottom, left in ring order.
EDGES = (
    ((0, 0), (0, 1), (slice(None, -2), slice(1, -1))),
    ((0, 1), (1, 1), (slice(1, -1), slice(2, None))),
    ((1, 1), (1, 0), (slice(2, None), slice(1, -1))),
    ((1, 0), (0, 0), (slice(1, -1), slice(None, -2))),
)


def tile_boundary(labels, offset, affine, transform, along):
    neighbors = np.pad(labels, 1)
    selected = labels == 7
    origin_x, origin_y = transform.transform(*(affine * (offset[1], offset[0])), errcheck=True)
    integrals = []
    edge_count = 0
    for (row_start, col_start), (row_end, col_end), neighbor in EDGES:
        rows, cols = np.nonzero(selected & (labels != neighbors[neighbor]))
        if rows.size == 0:
            continue
        edge_count += rows.size
        row = rows[:, None] + offset[0] + row_start + (row_end - row_start) * along
        col = cols[:, None] + offset[1] + col_start + (col_end - col_start) * along
        x, y = transform.transform(*(affine * (col, row)), errcheck=True)
        x, y = x - origin_x, y - origin_y
        integrals.append(float(np.sum(x[:, :-1] * y[:, 1:] - y[:, :-1] * x[:, 1:]) * 0.5))
    return math.fsum(integrals), edge_count


def full_area(fixture, segments):
    begin = time.monotonic_ns()
    cpu = time.process_time_ns()
    along = np.linspace(0.0, 1.0, segments + 1)
    areas, counts = [], Counter()
    edges = 0
    with rasterio.open(fixture) as raster:
        assert raster.crs.to_string() == "EPSG:32650" and raster.shape == (8190, 8190)
        projector = Transformer.from_crs(raster.crs, "EPSG:6933", always_xy=True, allow_ballpark=False, only_best=True)
        for _, tile in raster.block_windows(1):
            pixels = raster.read(1, window=tile, masked=True)
            mask = np.ma.getmaskarray(pixels)
            labels = np.where(mask, 0, pixels.data)
            classes, number = np.unique(labels, return_counts=True)
            counts.update({int(key): int(value) for key, value in zip(classes, number, strict=True)})
            area, count = tile_boundary(labels, (int(tile.row_off), int(tile.col_off)), raster.transform, projector, along)
            areas.append(area)
            edges += count
    assert counts == {7: 67039236, 0: 36864}
    assert all(area <= 0 for area in areas)
    return {
        "segments": segments, "area_m2": abs(math.fsum(areas)), "selected_pixels": counts[7], "masked_pixels": counts[0],
        "edges": edges, "projected_edge_points": edges * (segments + 1),
        "wall_ns": time.monotonic_ns() - begin, "cpu_ns": time.process_time_ns() - cpu,
    }


fixture, report_path = (Path(value) for value in sys.argv[1:])
report = json.loads(report_path.read_bytes())
assert report["boundary_convergence"]["max_segments_per_edge_used"] == 8
assert sha256(fixture.read_bytes()).hexdigest() == "7a62aed10a269d83989d10d9f35b12527ef4be1be523e51bd0300649549213e8"
records = [full_area(fixture, segments) for segments in (4, 8, 16)]
assert len({row["edges"] for row in records}) == 1
observed = report["total_area_m2"]
for record in records:
    record["difference_from_production_m2"] = record["area_m2"] - observed
assert abs(records[1]["difference_from_production_m2"]) <= 0.02
assert sha256(fixture.read_bytes()).hexdigest() == "7a62aed10a269d83989d10d9f35b12527ef4be1be523e51bd0300649549213e8"
print(json.dumps({"production_m2": observed, "probe": records}, indent=2))
