#!/bin/bash
set -euo pipefail
proof="$1"
baseline_report="$2"
env PROJ_NETWORK=OFF OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 GDAL_NUM_THREADS=1 \
  nice -n 19 ionice -c3 taskset -c 29 /usr/bin/time -v -o "$proof/resources.log" \
  .venv/bin/python -B "$proof/boundary.py" benchmarks/raster/area-fixtures/dem-l.tif \
  "$baseline_report" | tee "$proof/result.json"
