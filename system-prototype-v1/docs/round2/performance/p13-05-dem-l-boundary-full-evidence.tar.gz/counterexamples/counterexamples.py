from collections import Counter
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import sys

import numpy as np
from pyproj import Geod, Transformer
import rasterio
from rasterio.transform import Affine

from geopilot.gis.measurement.coverage import MeasurementPolicyError
from geopilot.gis.raster import area_stats

root = Path(sys.argv[1])
geod = Geod(ellps="WGS84")
assert os.sched_getaffinity(0) == {30}
assert os.getpriority(os.PRIO_PROCESS, 0) == 19


def cell_edges(c, r):
    corners = [(c, r), (c + 1, r), (c + 1, r + 1), (c, r + 1)]
    return zip(corners, corners[1:] + corners[:1], strict=True)


def boundary(cells):
    edges = Counter(edge for c, r in cells for edge in cell_edges(c, r))
    result = []
    for (a, b), count in edges.items():
        assert count == 1
        if (b, a) not in edges:
            result.append((a, b))
    return result


def projected_signed_area(edges, affine, source, target, segments):
    transformer = Transformer.from_crs(source, target, always_xy=True, allow_ballpark=False, only_best=True)
    edges = np.asarray(edges, dtype=float)
    fraction = np.linspace(0, 1, segments + 1)
    coordinates = edges[:, 0, :, None] + (edges[:, 1, :] - edges[:, 0, :])[:, :, None] * fraction
    xs, ys = coordinates[:, 0], coordinates[:, 1]
    # Accumulate one signed shoelace sum over the oriented boundary; reverse shared edges canceled.
    # Translate the projected coordinates by a shared origin to reduce cancellation.
    px, py = transformer.transform(affine.a * xs + affine.b * ys + affine.c,
                                   affine.d * xs + affine.e * ys + affine.f, errcheck=True)
    px = px - px.flat[0]
    py = py - py.flat[0]
    assert np.isfinite(px).all() and np.isfinite(py).all()
    return math.fsum((px[:, :-1] * py[:, 1:] - py[:, :-1] * px[:, 1:]).ravel()) / 2


def independent_area(cells, affine, source, segments=4096):
    geographic = Transformer.from_crs(source, "EPSG:4326", always_xy=True, allow_ballpark=False, only_best=True)
    results = []
    for c, r in cells:
        edges = list(cell_edges(c, r))
        coordinates = np.concatenate([np.linspace(a, b, segments, endpoint=False) for a, b in edges])
        x = [affine * (i, j) for i, j in coordinates]
        lon, lat = geographic.transform(*np.asarray(x).T, errcheck=True)
        a, _ = geod.polygon_area_perimeter(lon, lat)
        results.append(abs(a))
    return math.fsum(results)


def run_case(name, values, affine, source="EPSG:32650", target="EPSG:6933", check_independent=True):
    matrix = np.asarray(values, dtype=np.uint8)
    tif = root / f"{name}.tif"
    with rasterio.open(tif, "w", driver="GTiff", height=matrix.shape[0], width=matrix.shape[1], count=1,
                       dtype=matrix.dtype, crs=source, transform=affine, nodata=255) as dataset:
        dataset.write(matrix, 1)
    digest = sha256(tif.read_bytes()).hexdigest()
    try:
        report = area_stats.summarize_threshold_area(tif, area_crs=target)
        outcome = {"report": report}
    except (MeasurementPolicyError, ValueError) as exc:
        outcome = {"exception": type(exc).__name__, "message": str(exc)}
    classes = {}
    for cls in np.unique(matrix):
        if cls in (0, 255):
            continue
        cells = [(int(c), int(r)) for r, c in zip(*np.nonzero(matrix == cls), strict=True)]
        perimeter = boundary(cells)
        density = (2, 4, 8, 16, 32, 64, 128, 256)
        measures = {segments: abs(projected_signed_area(perimeter, affine, source, target, segments))
                    for segments in density}
        per_cell = {segments: [abs(projected_signed_area(list(cell_edges(c, r)), affine, source, target, segments))
                               for c, r in cells] for segments in (2, 4, 8)}
        record = {"count": len(cells), "unique_exterior_or_hole_edges": len(perimeter), "boundary_m2": measures,
                  "per_cell_m2": per_cell}
        if check_independent:
            ref = independent_area(cells, affine, source)
            record.update(geodetic_reference_m2=ref, fixed_8_error_m2=measures[8] - ref)
        if "report" in outcome:
            measured, = [entry["area_m2"] for entry in outcome["report"]["classes"] if entry["class_id"] == int(cls)]
            tolerance = max(1e-6, measured * 1e-8)
            record.update(fixed_8_minus_production_m2=measures[8] - measured, existing_tolerance_m2=tolerance)
        classes[str(cls)] = record
    assert digest == sha256(tif.read_bytes()).hexdigest()
    return {"shape": list(matrix.shape), "affine": list(affine)[:6], "source": source, "target": target,
            "tif_sha256": digest, "production": outcome, "class_results": classes}


cases = {}
cases["coarse_utm"] = run_case("coarse_utm", [[1]], Affine(100000, 0, 500020, 0, -100000, 4400050))
cases["coarse_sheared"] = run_case("coarse_sheared", [[7, 7, 2], [7, 255, 2]],
                                    Affine(90000, 15000, 420000, 20000, -95000, 4550000))
cases["antimeridian"] = run_case("antimeridian", [[7, 7, 7]], Affine(0.1, 0, 179.85, 0, -0.05, 0.03),
                                 source="EPSG:4326")
cases["collapsed"] = run_case("collapsed", [[7, 7]] * 4, Affine(10, 0, 500000, 0, -4.5e-10, 4400000),
                               check_independent=False)
cases["canceling_cells"] = run_case("canceling_cells", [[7, 7]], Affine(-36887, 26151, 431254, 17130, 46884, 6201471))
cases["utm_10m"] = run_case("utm_10m", [[7, 7], [7, 7]], Affine(10, 0, 500020, 0, -10, 4400050))
coarse = cases["coarse_utm"]
assert coarse["production"]["report"]["boundary_convergence"]["max_segments_per_edge_used"] >= 64
coarse1 = coarse["class_results"]["1"]
assert abs(coarse1["fixed_8_minus_production_m2"]) > coarse1["existing_tolerance_m2"]
for entry in cases["coarse_sheared"]["class_results"].values():
    assert abs(entry["fixed_8_minus_production_m2"]) > entry["existing_tolerance_m2"]
seam = cases["antimeridian"]
assert seam["production"]["exception"] == "MeasurementPolicyError"
assert "within a single longitude interval" in seam["production"]["message"]
seam7 = seam["class_results"]["7"]
assert seam7["boundary_m2"][8] / seam7["geodetic_reference_m2"] > 1000
collapsed = cases["collapsed"]
assert collapsed["production"]["exception"] == "ValueError"
assert "no finite positive area" in collapsed["production"]["message"]
collapsed7 = collapsed["class_results"]["7"]
assert collapsed7["boundary_m2"][8] > 0 and 0 in collapsed7["per_cell_m2"][8]
cancel = cases["canceling_cells"]
assert cancel["production"]["report"]["boundary_convergence"]["max_segments_per_edge_used"] > 8
cancel7 = cancel["class_results"]["7"]
for earlier, later in ((2, 4), (4, 8)):
    aggregate_delta = cancel7["boundary_m2"][later] - cancel7["boundary_m2"][earlier]
    aggregate_tol = max(1e-6, cancel7["boundary_m2"][later] * 1e-8)
    cell_deltas = [new - old for old, new in zip(cancel7["per_cell_m2"][earlier], cancel7["per_cell_m2"][later], strict=True)]
    cell_tolerances = [max(1e-6, area * 1e-8) for area in cancel7["per_cell_m2"][later]]
    assert abs(aggregate_delta) < aggregate_tol and cell_deltas[0] * cell_deltas[1] < 0
    assert all(abs(delta) > tol for delta, tol in zip(cell_deltas, cell_tolerances, strict=True))
    cancel7[f"{earlier}_to_{later}_change"] = {"aggregate_delta_m2": aggregate_delta, "aggregate_tol_m2": aggregate_tol,
                                                  "per_cell_deltas_m2": cell_deltas, "per_cell_tolerances_m2": cell_tolerances}
control = cases["utm_10m"]["class_results"]["7"]
assert abs(control["fixed_8_minus_production_m2"]) <= control["existing_tolerance_m2"]
summary = {"source_module_sha256": sha256(Path(area_stats.__file__).read_bytes()).hexdigest(),
           "process_affinity": sorted(os.sched_getaffinity(0)), "nice": os.getpriority(os.PRIO_PROCESS, 0),
           "cases": cases}
(root / "independent.json").write_text(json.dumps(summary, indent=2) + "\n")
for name, case in cases.items():
    print(name, case["production"].get("message", "PASS"))
    for cls, item in case["class_results"].items():
        print(f"  class {cls}: boundary 4={item['boundary_m2'][4]:.12g} / 8={item['boundary_m2'][8]:.12g}; "
              f"production delta={item.get('fixed_8_minus_production_m2')}; "
              f"geodetic delta={item.get('fixed_8_error_m2')}; tol={item.get('existing_tolerance_m2')}")
