#!/usr/bin/env bash
set -euo pipefail
proof=$1
p13_remote_attempt="$PWD/artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l/remote-l/base/attempt.pr0gnzp2"
p13_remote_inputs="$PWD/artifacts/test-results/p13-04-formal-tools.pN5DMz/remote-sensing/inputs/L/manifest.json"
env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1 PROJ_NETWORK=OFF nice -n 15 \
  .venv/bin/python -B "$proof/verify-remote-cold.py" "$proof/portable" --attempt "$p13_remote_attempt" \
  --prototype "$PWD" --input-manifest "$p13_remote_inputs" > "$proof/full-cold.json"
