"""Read only the committed JSONL prefix for the remote sensing L baseline cold group."""
from collections import Counter
from hashlib import sha256
from itertools import islice
import json
import math
from pathlib import Path
import shlex
from statistics import median
import sys

REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
DOCS = REPO / "docs/round2/performance"
ROOT = REPO / "artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l"
ATTEMPT = ROOT / "remote-l/base/attempt.pr0gnzp2"
TRIALS = ATTEMPT / "evidence/trials.jsonl"
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
MANIFEST = "7ca5d30de46b40955845aadb312ff02b6653a11fc708d8aeaaf8d404fb769e04"
FINAL_STEP = "calculate_change"
POLL_ERROR = {"http_status": 500, "body": {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}}}
RESOURCES = ("cpu_ns", "peak_rss_bytes", "disk_read_bytes", "disk_write_bytes")
METRICS = ("wall_ns", "queue_wall_ns", "execute_steps_wall_ns", "finalize_wall_ns", *RESOURCES, "peak_temp_bytes")
PROOFS = {
    "first_s": ("/tmp/geopilot-p13-05-raster-s-audit.rJKuNw/independent.json",
                "f6c4e2d81e0d269b154a5640c7aa71a4636472174bb841e86290c59c630c437b"),
    "remote_s_rerun": ("/tmp/geopilot-p13-05-remote-s-after-vector-l-audit.Gbk18m/independent.json",
                       "cbb29456d9657978bdd4a59d60f0debdedc7bcb91a38efc5b6a0f08f85c2892b"),
    "dem_m": ("/tmp/geopilot-p13-05-dem-m-pair-attempt-audit.vYP1vW/independent.json",
              "685e02b33b3977545e0c515aff591b7ee1202551f9f82d755506028009f66e42"),
}
DEM_L_PROOF = Path("/tmp/geopilot-p13-05-dem-l-final-pair-audit.EppAOX/independent.json")
DEM_L_PROOF_SHA = "8f0c3286971b1c44239eddaf2afd24fa71b9a9128d4961530ab3c438c0b61995"
CLASSIFICATION_SOURCE = DOCS / "p13-04-remote-l-classification-source.json"


def classification_reference(historical):
    frozen = read(CLASSIFICATION_SOURCE)
    source, = [row for row in historical if row["run_id"] == frozen["source_run_id"]]
    assert source["run_state"] == frozen["source_run_terminal_state"]
    assert frozen["fixture_manifest_sha256"] == MANIFEST
    assert frozen["source_step"] == FINAL_STEP and frozen["source_tool"] == source["telemetry"]["steps"][-1]["tool"]
    assert (frozen["shape"], frozen["valid_class_counts"], frozen["masked_pixels"]) == (
        [3072, 3072], {"1": 1572864, "2": 1572864, "3": 1572864}, 4718592,
    )
    return frozen


def staged_classification(row, frozen):
    workspace = Path(row["workspace"])
    workspace.relative_to("/scratch/evidence/samples/L/method/process_cold")
    root = ATTEMPT / workspace.relative_to("/scratch") / "intermediate/calculate_change"
    matches = sorted(root.glob(".land-use-*/.ndvi-classification-*/classes.tif"))
    assert len(matches) <= 1
    if not matches:
        return {"status": "not_present_after_terminal_timeout"}
    path, = matches
    assert path.resolve().is_relative_to(ATTEMPT.resolve())
    assert path.is_file() and 0 < path.stat().st_size <= 256 * 1024
    payload = path.read_bytes()
    assert payload[:4] in (b"II*\0", b"MM\0*")
    return {
        "status": "matching_archived_staged_classification" if (len(payload), digest(payload)) == (frozen["bytes"], frozen["sha256"])
                  else "different_from_archived_staged_classification",
        "path": str(path), "bytes": len(payload), "sha256": digest(payload),
    }


def digest(raw):
    return sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    with path.open("rb") as stream:
        return [json.loads(line) for line in stream]


def proof(label):
    name, expected = PROOFS[label]
    raw = Path(name).read_bytes()
    assert digest(raw) == expected
    return json.loads(raw)


def observe(value):
    return {"status": "recorded" if value is not None else "unavailable", "value": value}


def distribution(items):
    values = [item["value"] for item in items if item.get("value") is not None]
    return {
        "n": len(values), "coverage": dict(Counter(item["status"] for item in items)), "values": values,
        "median": median(values) if len(values) >= 3 else None,
        "p95": sorted(values)[math.ceil(.95 * len(values)) - 1] if len(values) >= 3 else None,
    }


def check_timeout(row, expected_steps, expected_params):
    run = row["run_state"]
    assert (row["status"], run["execution_status"], run["check_status"], run["current_step"]) == (
        "FAIL", "FAILED", "NOT_CHECKED", FINAL_STEP,
    )
    assert run["run_id"] == row["run_id"] and run["current_report_id"] is None and not run["cancel_requested"]
    error = run["error"]
    assert (error["code"], error["phase"], error["step_key"], error["message"]) == (
        "PROCESS_TIMEOUT", "execute", FINAL_STEP, "Process exceeded 60 seconds",
    )
    assert row["exit_code"] == -15 and row["error"]["type"] == "ValueError"
    assert "did not pass execution/checks" in row["error"]["message"]
    assert all(key not in row for key in ("correctness", "v1_completed_checks", "output_bytes"))
    doc = row["telemetry"]
    assert (doc["schema_version"], doc["run_id"], doc["execution_status"], doc["check_status"], doc["exit_code"]) == (
        1, row["run_id"], "FAILED", "NOT_CHECKED", -15,
    )
    steps = row["executed_steps"]
    assert len(steps) == len(doc["steps"]) == len(expected_steps) == 8
    for i, (request, event) in enumerate(zip(steps, doc["steps"], strict=True)):
        key, tool, version = expected_steps[i]
        assert request["step_key"] == event["step_key"] == key
        assert request["tool"] == {"id": tool, "version": version} == {k: event["tool"][k] for k in ("id", "version")}
        assert request["parameters"] == expected_params[i]
        failed = i == 7
        expected_status, expected_exit = ("FAILED", -15) if failed else ("SUCCEEDED", 0)
        assert request["status"] == event["status"] == expected_status
        assert request["exit_code"] == event["exit_code"] == expected_exit
        process, = [item for item in event["processes"] if item["phase"] == "execute"]
        assert process["exit_code"] == expected_exit and process["timed_out"] == failed and not process["cancelled"]
        if failed:
            assert process["wall_ns"] >= 60_000_000_000


def metrics(row):
    doc = row["telemetry"]
    return {
        "wall_ns": observe(row["wall_ns"]), "queue_wall_ns": doc["queue_wall_ns"],
        "execute_steps_wall_ns": observe(doc["execute_steps_wall_ns"]), "finalize_wall_ns": observe(doc["finalize_wall_ns"]),
        **doc["resources"], "peak_temp_bytes": row["workspace_size"]["peak_temp_bytes"],
    }


def official_history():
    files = [DOCS / f"p13-04-{kind}-method-{size}-trials.jsonl"
             for kind, size in (("raster", "s"), ("raster", "m"), ("raster", "l"), ("remote", "sm"), ("remote", "l"))]
    rows = [row for f in files for row in jsonl(f)]
    assert len(rows) == len({row["run_id"] for row in rows}) == 84
    same = [row for row in rows if row["family"] == "remote_sensing" and row["tier"] == "L"]
    assert len(same) == 14 and {row["manifest_sha256"] for row in same} == {MANIFEST}
    for row in same:
        state = row["run_state"]
        assert (row["status"], state["execution_status"], state["check_status"], state["current_step"]) == (
            "FAIL", "FAILED", "NOT_CHECKED", FINAL_STEP,
        )
        assert state["error"]["code"] == "PROCESS_TIMEOUT"
        assert [step["exit_code"] for step in row["telemetry"]["steps"]] == [0] * 7 + [-15]
    return rows, same


def prior_ids(historical, current):
    first = [rid for case in proof("first_s").values() for side in ("base", "candidate") for rid in case[side]["run_ids"]]
    later = [row["run_id"] for side in ("base", "candidate") for row in proof("remote_s_rerun")[side]["observations"]]
    medium = [row["run_id"] for side in ("baseline", "candidate") for row in proof("dem_m")[side]["observations"]]
    assert digest(DEM_L_PROOF.read_bytes()) == DEM_L_PROOF_SHA
    dem_l = [row["run_id"] for side in ("base", "candidate") for row in read(DEM_L_PROOF)[side]["samples"]]
    previous = first + later + medium + dem_l + [row["run_id"] for row in historical]
    assert (len(first), len(later), len(medium), len(dem_l), len(previous)) == (47, 28, 25, 28, 212)
    assert len(previous + current) == len(set(previous + current))
    return {"P13-04": 84, "first_s": 47, "remote_s_rerun": 28, "dem_m": 25, "dem_l": 28,
            "current_cold": len(current), "combined_unique": len(previous + current)}


def main(output, allow_prefix=False):
    plan = read(ROOT / "plan.json")
    assert plan["commits"]["base"] == BASE and plan["input_manifest_sha256"]["remote-l"] == MANIFEST
    assert plan["disk"][:2] == ["/dev/sda2", "ext4"]
    store, docker = (ATTEMPT / "command.log").read_text().splitlines()
    args = shlex.split(docker)
    assert store.startswith("storage=/dev/sda2 ext4") and plan["image"] in args
    assert args[args.index("--source-commit") + 1] == BASE and args[args.index("--tiers") + 1] == "L"

    historical, historical_l = official_history()
    historic = historical_l[0]
    expected_steps = [(step["step_key"], step["tool"]["id"], step["tool"]["version"])
                      for step in historic["telemetry"]["steps"]]
    assert expected_steps[-1][0] == FINAL_STEP
    report = read(DOCS / "p13-04-remote-method-l-report.json")
    historic_input = report["inputs"]["L"]
    assert historic_input["manifest_sha256"] == MANIFEST
    assert historic_input["first_fingerprints"] == historic_input["last_fingerprints"]
    reference = historic_input["reference"]
    archived_classes = classification_reference(historical_l)
    assert reference["grids"]["landsat"]["shape"] == archived_classes["shape"]
    assert reference["transform"] == archived_classes["transform"] and reference["crs"] == archived_classes["crs"]
    assert reference["common_valid_pixels"] == sum(archived_classes["valid_class_counts"].values()) == 4718592
    assert reference["nodata_pixels"] == archived_classes["masked_pixels"]
    config = historic["confirmed_parameters"]
    sensor_pair = {key: config[key] for key in ("first_configuration", "second_configuration")}
    assert {key: config[key] for key in ("resampling", "change_threshold", "area_crs")} == {
        "resampling": "nearest", "change_threshold": 0.1, "area_crs": "EPSG:6933",
    }
    expected_params = ({}, sensor_pair, {}, {}, {}, {}, {"resampling": "nearest"},
                       {"change_threshold": 0.1, "area_crs": "EPSG:6933"})
    input_mount, = [args[i + 1] for i, item in enumerate(args) if item == "--mount" and ",dst=/inputs," in args[i + 1]]
    assert input_mount.endswith(",dst=/inputs,readonly")

    with TRIALS.open("rb") as stream:
        raw = [line for line in islice(stream, 7) if line.endswith(b"\n")]
    rows = [json.loads(line) for line in raw]
    assert rows and (allow_prefix or len(rows) == 7)
    for field in ("task_id", "plan_id", "worker_pid", "run_id", "workspace"):
        assert len({row[field] for row in rows}) == len(rows)
    samples = []
    for index, row in enumerate(rows, 1):
        assert (row["cache"], row["index"], row["kind"], row["sample_id"]) == (
            "process_cold", index, "warmup" if index <= 2 else "measurement", f"remote_sensing/L/method/process_cold/{index:02d}",
        )
        assert (row["family"], row["tier"], row["workload"], row["manifest_sha256"], row["worker_exit_code"]) == (
            "remote_sensing", "L", "method", MANIFEST, 0,
        )
        assert row["source_input_bytes"] == historic["source_input_bytes"]
        assert row["logical_source_input_bytes"] == historic["logical_source_input_bytes"] == reference["raw_input_bytes"]
        assert all(row[key] == historic[key] for key in ("method", "critical_options", "confirmed_parameters", "parameters_sha256"))
        parameter_bytes = json.dumps(row["confirmed_parameters"], sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
        assert row["parameters_sha256"] == digest(parameter_bytes)
        errors = row.get("status_poll_errors", [])
        assert all(error == POLL_ERROR for error in errors)
        check_timeout(row, expected_steps, expected_params)
        samples.append({
            "sample_id": row["sample_id"], "run_id": row["run_id"], "task_id": row["task_id"], "plan_id": row["plan_id"],
            "kind": row["kind"], "status_poll_errors": errors, "state": row["run_state"],
            "steps": row["executed_steps"], "readings": metrics(row),
            "staged_classification": staged_classification(row, archived_classes),
        })
    identified = prior_ids(historical, [row["run_id"] for row in rows])
    measured = [row for row in rows if row["kind"] == "measurement"]
    all_readings = [metrics(row) for row in measured]
    recorded = {field: distribution([record[field] for record in all_readings]) for field in METRICS}
    per_step = {}
    for i, (key, _, _) in enumerate(expected_steps):
        events = [row["telemetry"]["steps"][i] for row in measured]
        per_step[key] = {
            "wall_ns": distribution([observe(event["wall_ns"]) for event in events]),
            **{field: distribution([event["resources"][field] for event in events]) for field in RESOURCES},
        }
    historic_cold = [row for row in historical_l if row["cache"] == "process_cold" and row["kind"] == "measurement"]
    historic_stats = distribution([observe(row["wall_ns"]) for row in historic_cold])
    guard_source = REPO / "artifacts/test-results/p13-05-revised-pair-source.a2d2e68/base/scripts/bench/_raster_workloads.py"
    guard = guard_source.read_text()
    assert guard.index('telemetry["check_status"]) == (1, run_id, "SUCCEEDED", "PASSED")') < guard.index(
        'trial["correctness"], trial["output_bytes"] = self._verify_artifacts('
    )

    result = {
        "scope": "baseline process-cold records only",
        "prefix_complete": len(rows) == 7, "sample_prefix_file": str(TRIALS), "raw_prefix_sha256": digest(b"".join(raw)),
        "source_commit": BASE, "input_manifest_sha256": MANIFEST, "readonly_input_mount": input_mount,
        "input_fingerprints_from_p13_04": historic_input["first_fingerprints"],
        "archived_classification_reference": archived_classes,
        "staged_classification_counts": dict(Counter(sample["staged_classification"]["status"] for sample in samples)),
        "samples": samples, "run_identity": identified,
        "failure": {"step": FINAL_STEP, "code": "PROCESS_TIMEOUT", "count": len(rows),
                    "why_correctness_absent": "Benchmark verifies artifacts after the terminal telemetry SUCCEEDED/PASSED gate.",
                    "verification_source": str(guard_source)},
        "measured_counts": {"PASS": 0, "FAIL": len(measured), "not_observed": 5 - len(measured)},
        "measured_failed_distributions": recorded, "measured_failed_step_distributions": per_step,
        "p13_04_remote_l_failed_cold_wall_distribution": historic_stats,
    }
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("Remote L baseline cold", len(rows), "/7; all seven preceding steps succeeded, calculate_change PROCESS_TIMEOUT -15")
    for sample in samples:
        print(sample["sample_id"], sample["run_id"], "poll errors", len(sample["status_poll_errors"]),
              "staged classification", sample["staged_classification"]["status"])
    for field in ("wall_ns", "peak_rss_bytes", "peak_temp_bytes", "queue_wall_ns"):
        print("formal failed", field, recorded[field])
    print("calculate_change", per_step[FINAL_STEP]["wall_ns"], "step RSS", per_step[FINAL_STEP]["peak_rss_bytes"])
    print("staged classification", result["staged_classification_counts"], archived_classes["bytes"], archived_classes["sha256"])
    print("P13-04 same cold failed wall", historic_stats)
    print("no successful correctness verification or success percentiles; run identity", identified)


if __name__ == "__main__":
    main(Path(sys.argv[1]), allow_prefix="--allow-prefix" in sys.argv[2:])
