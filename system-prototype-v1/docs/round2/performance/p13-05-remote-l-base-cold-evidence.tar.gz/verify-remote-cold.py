"""Capture or replay an append-only P13-05 remote L original cold prefix."""

import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import shutil
from statistics import median

import numpy as np
import rasterio


PREFIX = "remote_sensing/L/method/process_cold/"
STEP = "calculate_change"
STEPS = (
    "read_product_metadata", "lookup_sensor_configuration", "map_band_roles", "apply_scale_and_offset",
    "build_quality_mask", "calculate_ndvi", "align_two_dates", STEP,
)
HISTORY = "p13-04-remote-method-l-trials.jsonl"


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def sample_directory(row):
    return Path("evidence/samples/L/method/process_cold") / f"{row['index']:02d}-{row['kind']}"


def paths(row):
    workspace = Path(row["workspace"]).relative_to("/scratch")
    sample = sample_directory(row)
    assert workspace == sample / "service/workspace/tasks" / row["task_id"] / "runs" / row["run_id"]
    return sample, workspace


def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)


def capture(attempt, root, prototype, count):
    source_lines = (attempt / "evidence/trials.jsonl").read_bytes().splitlines(keepends=True)
    lines = source_lines[:count]
    assert len(lines) == count and all(line.endswith(b"\n") for line in lines)
    (root / "evidence").mkdir(parents=True)
    (root / "evidence/trials.jsonl").write_bytes(b"".join(lines))
    (root / "evidence/container.log").write_bytes(b"".join(
        (attempt / "container.log").read_bytes().splitlines(keepends=True)[:count]
    ))
    copy(attempt / "command.log", root / "evidence/command.log")
    fixtures = prototype / "benchmarks/raster/area-fixtures"
    for name in ("manifest.json", "remote-l.tif"):
        copy(fixtures / name, root / "reference" / name)
    copy(prototype / "docs/round2/performance" / HISTORY, root / "reference" / HISTORY)
    for line in lines:
        row = json.loads(line)
        assert row["sample_id"].startswith(PREFIX)
        sample, workspace = paths(row)
        copy(attempt / sample / "trial.json", root / sample / "trial.json")
        published = attempt / workspace / "outputs/manifest.json"
        assert not published.exists()
        targets = read(attempt / workspace / "steps" / STEP / "request.json")["output_targets"]
        assert all(not (attempt / workspace / output["path"]).exists() for output in targets.values())
        for step in row["executed_steps"]:
            for name in ("request.json", "result.json"):
                relative = workspace / "steps" / step["step_key"] / name
                copy(attempt / relative, root / relative)
        relative = workspace / "steps" / STEP / "process.log"
        copy(attempt / relative, root / relative)
        staging = workspace / "intermediate" / STEP
        for source in sorted((attempt / staging).rglob("*.tif")):
            copy(source, root / source.relative_to(attempt))


def inspect_reference(root, reference):
    path = root / "reference" / reference["path"]
    assert (path.stat().st_size, digest(path)) == (reference["bytes"], reference["sha256"])
    counts = Counter()
    masked = 0
    with rasterio.open(path, driver="GTiff") as dataset:
        assert dataset.crs.to_string() == "EPSG:32632"
        assert (dataset.width, dataset.height, dataset.dtypes, dataset.nodata) == (3072, 3072, ("uint8",), 255)
        assert tuple(dataset.transform)[:6] == (30, 0, 500000, 0, -30, 5100000)
        for _, window in dataset.block_windows(1):
            block = dataset.read(1, window=window, masked=True)
            masked += int(np.ma.getmaskarray(block).sum())
            counts.update(dict(zip(*np.unique(block.compressed(), return_counts=True), strict=True)))
    assert counts == {1: 1572864, 2: 1572864, 3: 1572864} and masked == 4718592
    return {"counts": {int(key): int(value) for key, value in sorted(counts.items())}, "masked": masked}


def inspect_trial(root, row, index, reference):
    kind = "warmup" if index < 3 else "measurement"
    assert (row["sample_id"], row["index"], row["kind"], row["status"]) == (f"{PREFIX}{index:02d}", index, kind, "FAIL")
    sample, workspace = paths(row)
    trial = read(root / sample / "trial.json")
    assert trial == {k: v for k, v in row.items() if k not in {"worker_exit_code", "worker_log"}}
    state = row["run_state"]
    assert (state["run_id"], state["execution_status"], state["check_status"]) == (row["run_id"], "FAILED", "NOT_CHECKED")
    assert (state["error"]["code"], state["error"]["step_key"], state["error"]["message"]) == (
        "PROCESS_TIMEOUT", STEP, "Process exceeded 60 seconds",
    )
    assert "correctness" not in row and not state["current_report_id"]
    assert tuple(step["step_key"] for step in row["executed_steps"]) == STEPS
    for step, timing in zip(row["executed_steps"], row["telemetry"]["steps"], strict=True):
        name = step["step_key"]
        expected = ("FAILED", -15) if name == STEP else ("SUCCEEDED", 0)
        request = read(root / workspace / "steps" / name / "request.json")
        result = read(root / workspace / "steps" / name / "result.json")
        assert request["run_id"] == result["run_id"] == row["run_id"]
        assert request["step_key"] == result["step_key"] == timing["step_key"] == name
        assert request["parameters"] == step["parameters"]
        assert request["tool"] == step["tool"]
        for observation in (step, timing, result):
            assert (observation["status"], observation["exit_code"]) == expected
    assert name == STEP and result["outputs"] == {} and result["error"] == state["error"]
    assert request["parameters"] == {"change_threshold": 0.1, "area_crs": "EPSG:6933"}
    process, = timing["processes"]
    assert process["timed_out"] and not process["cancelled"] and process["exit_code"] == -15
    log = (root / workspace / "steps" / STEP / "process.log").read_text()
    assert "exit_code: -15" in log and "PROCESS_TIMEOUT: Process exceeded 60 seconds" in log
    errors = row.get("status_poll_errors", [])
    assert all(e["http_status"] == 500 and e["body"]["detail"]["code"] == "STORAGE_FAILED" for e in errors)
    retained = list((root / workspace / "intermediate" / STEP).rglob("*.tif"))
    assert len(retained) == 2
    files = {p.name: p for p in retained}
    assert set(files) == {"classes.tif", "change_raster.tif"}
    assert (files["classes.tif"].stat().st_size, digest(files["classes.tif"])) == (reference["bytes"], reference["sha256"])
    return {
        "run_id": row["run_id"], "kind": kind, "wall_ns": row["wall_ns"],
        "calculate_change_wall_ns": timing["wall_ns"], "status_get_500": len(errors),
        "run_peak_rss_bytes": row["telemetry"]["resources"]["peak_rss_bytes"],
        "step_peak_rss_bytes": timing["resources"]["peak_rss_bytes"],
        "step_cpu_ns": timing["resources"]["cpu_ns"],
        "temp_peak_bytes": row["workspace_size"]["peak_temp_bytes"],
        "remaining_temp_files": {name: {"bytes": path.stat().st_size, "sha256": digest(path)} for name, path in sorted(files.items())},
    }


def summarize(root, count):
    trials = root / "evidence/trials.jsonl"
    rows = [json.loads(line) for line in trials.read_bytes().splitlines()]
    assert len(rows) == count
    history = [json.loads(line) for line in (root / "reference" / HISTORY).read_bytes().splitlines()]
    assert len(history) == 14
    assert {row["manifest_sha256"] for row in history + rows} == {digest(root / "reference/input-manifest.json")}
    assert {row["parameters_sha256"] for row in history + rows} == {rows[0]["parameters_sha256"]}
    ids = {row["run_id"] for row in rows}
    assert len(ids) == count and ids.isdisjoint(row["run_id"] for row in history)
    reference = next(x for x in read(root / "reference/manifest.json")["fixtures"] if x["id"] == "remote-l")
    raster = inspect_reference(root, reference)
    summaries = [inspect_trial(root, row, index, reference) for index, row in enumerate(rows, 1)]
    logs = (root / "evidence/container.log").read_text().splitlines()
    assert logs == [f'{row["sample_id"]} {row["kind"]} FAIL {row["wall_ns"]}' for row in rows]
    measurements = [item for item in summaries if item["kind"] == "measurement"]
    result = {
        "trials_sha256": digest(trials), "input_manifest_sha256": rows[0]["manifest_sha256"],
        "parameters_sha256": rows[0]["parameters_sha256"], "reference_sha256": reference["sha256"],
        "reference_raster": raster, "rows": summaries, "measurement_count": len(measurements),
        "status_get_500": sum(item["status_get_500"] for item in summaries),
    }
    if len(measurements) == 5:
        result["failure_measurements"] = {}
        for key in ("wall_ns", "calculate_change_wall_ns"):
            values = [item[key] for item in measurements]
            result["failure_measurements"][key] = {"median": median(values), "p95_nearest_rank": max(values)}
        result["failure_measurements"]["rss_quality"] = dict(Counter(item["run_peak_rss_bytes"]["status"] for item in measurements))
        result["failure_measurements"]["temp_peak_bytes"] = median(item["temp_peak_bytes"]["value"] for item in measurements)
    print(json.dumps(result, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--attempt", type=Path)
    parser.add_argument("--prototype", type=Path)
    parser.add_argument("--input-manifest", type=Path)
    parser.add_argument("--count", type=int, default=7, choices=range(1, 8))
    args = parser.parse_args()
    if args.attempt is not None:
        if args.prototype is None or args.input_manifest is None:
            parser.error("--attempt requires --prototype and --input-manifest")
        capture(args.attempt, args.root, args.prototype, args.count)
        copy(args.input_manifest, args.root / "reference/input-manifest.json")
    summarize(args.root, args.count)


if __name__ == "__main__":
    main()
