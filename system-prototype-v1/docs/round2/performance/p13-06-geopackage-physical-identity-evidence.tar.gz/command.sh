#!/bin/bash
set -euo pipefail
geo_gpkg_proof="$1"
export PYTHONPATH="$PWD/src" PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 TMPDIR=/dev/shm
mkdir "$geo_gpkg_proof"/{first,second}
nice -n 19 ionice -c3 taskset -c 29 .venv/bin/python -B "$geo_gpkg_proof/generate.py" "$geo_gpkg_proof" \
  tests/fixtures/vector/road-buffer.gpkg > "$geo_gpkg_proof/generate.log"
nice -n 19 ionice -c3 taskset -c 29 .venv/bin/python -B "$geo_gpkg_proof/verify.py" "$geo_gpkg_proof" > "$geo_gpkg_proof/verified.json"
