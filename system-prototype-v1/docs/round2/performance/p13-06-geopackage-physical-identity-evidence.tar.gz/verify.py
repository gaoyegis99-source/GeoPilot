"""Compare logical GeoPackage contents and verify the physical copy contract."""
from contextlib import closing
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import sqlite3
import sys

from geopilot.data.fingerprint import copy_file_group, fingerprint_file
from geopilot.data.geopackage_reader import read_geopackage_metadata

EXPECTED = (
    "building-buffer-boundary", "building-east", "building-edge-road",
    "building-overlap", "building-unaffected", "building-west", "building-zone-boundary",
)


def tables(path):
    with closing(sqlite3.connect(path.as_uri() + "?mode=ro&immutable=1", uri=True)) as db:
        assert db.execute("PRAGMA integrity_check").fetchone() == ("ok",)
        schema = db.execute("SELECT type, name, tbl_name, sql FROM sqlite_schema ORDER BY type, name").fetchall()
        contents = {}
        for kind, name, _, _ in schema:
            if kind == "table":
                quoted = '"' + name.replace('"', '""') + '"'
                contents[name] = sorted(db.execute(f"SELECT * FROM {quoted}").fetchall(), key=repr)
        fields = [row[1] for row in db.execute("PRAGMA table_info(gpkg_contents)")]
        timestamp, = db.execute("SELECT last_change FROM gpkg_contents").fetchone()
        identifiers = tuple(row[0] for row in db.execute(
            'SELECT source_feature_id FROM "' + path.stem + '" ORDER BY source_feature_id'
        ))
        return schema, contents, fields.index("last_change"), timestamp, identifiers


def check(root, role):
    first, second = (root / label / f"{role}.gpkg" for label in ("first", "second"))
    left_schema, left_tables, left_column, left_date, left_ids = tables(first)
    right_schema, right_tables, right_column, right_date, right_ids = tables(second)
    assert left_schema == right_schema and left_column == right_column
    assert left_date != right_date
    assert set(left_tables) == set(right_tables)
    differences = [name for name in left_tables if left_tables[name] != right_tables[name]]
    assert differences == ["gpkg_contents"]
    def without_timestamp(rows):
        return [row[:left_column] + row[left_column + 1:] for row in rows]

    assert without_timestamp(left_tables["gpkg_contents"]) == without_timestamp(right_tables["gpkg_contents"])
    assert left_ids == right_ids == EXPECTED
    left, right = first.read_bytes(), second.read_bytes()
    assert left.count(left_date.encode()) == right.count(right_date.encode()) == 1
    assert left.replace(left_date.encode(), right_date.encode()) == right
    original = fingerprint_file(first)
    replacement = fingerprint_file(second)
    assert original.digest != replacement.digest
    with TemporaryDirectory(prefix="geopilot-cache-gpkg-reopen.") as scratch:
        renamed = Path(scratch) / "renamed.gpkg"
        copy_file_group(first, renamed, expected_digest=original.digest)
        assert renamed.read_bytes() == left
        layer, metadata = read_geopackage_metadata(renamed, role)
        assert layer == role and metadata.feature_count == len(EXPECTED) and metadata.crs == "EPSG:32650"
        rejected = Path(scratch) / "rejected.gpkg"
        try:
            copy_file_group(second, rejected, expected_digest=original.digest)
        except OSError:
            assert not rejected.exists()
        else:
            raise AssertionError("Accepted a mismatched physical file group")
    return {
        "rows": len(left_ids), "source_ids": list(left_ids),
        "changed_tables": differences, "last_change": [left_date, right_date],
        "byte_differences": sum(x != y for x, y in zip(left, right, strict=True)),
        "byte_sha256": [sha256(content).hexdigest() for content in (left, right)],
        "physical_file_group": [original.digest, replacement.digest], "copy_reopened": True,
        "wrong_digest_rejected_and_removed": True,
    }


root = Path(sys.argv[1]).resolve()
print(json.dumps({role: check(root, role) for role in ("targets", "original_targets")}, indent=2))
