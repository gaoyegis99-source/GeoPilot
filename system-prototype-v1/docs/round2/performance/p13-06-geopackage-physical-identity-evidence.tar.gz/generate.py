"""Produce two independent outputs with the integrated vector tool."""
from hashlib import sha256
from pathlib import Path
import sys
import time

from geopilot.gis.tools.clip_vector_to_extent import clip_vector_to_extent

bundle, fixture = (Path(value).resolve() for value in sys.argv[1:])
roles = ("targets", "original_targets")
before = sha256(fixture.read_bytes()).hexdigest()
for label in ("first", "second"):
    output = bundle / label
    targets = {role: {"path": str(output / f"{role}.gpkg"), "layer": role} for role in roles}
    request = {
        "inputs": {"targets": {"path": str(fixture), "layer": "targets"},
                   "area": {"path": str(fixture), "layer": "analysis_extent"}},
        "output_targets": targets,
    }
    assert clip_vector_to_extent(request) == targets
    if label == "first":
        time.sleep(1.05)
assert sha256(fixture.read_bytes()).hexdigest() == before
print(f"Input preserved {before}")
