"""Compare the two completed extended-budget worker receipts."""
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
baseline, frozen = (root / role for role in ("baseline", "frozen"))
for filename in ("production-report.json", "environment.json"):
    assert (baseline / filename).read_bytes() == (frozen / filename).read_bytes()
old, new = (json.loads((root / "proof" / f"{role}-replayed.json").read_bytes()) for role in ("baseline", "frozen"))
assert old["input"] == new["input"]
assert old["observed_m2"] == new["observed_m2"] and old["convergence"] == new["convergence"]
print(json.dumps({
    "reports_byte_equal": True, "environments_byte_equal": True,
    "core_wall_reduction_percent": (1 - new["core_wall_ns"] / old["core_wall_ns"]) * 100,
    "core_cpu_reduction_percent": (1 - new["core_cpu_ns"] / old["core_cpu_ns"]) * 100,
    "rss_change_bytes": new["rss_peak_bytes"] - old["rss_peak_bytes"],
    "rss_change_percent": (new["rss_peak_bytes"] / old["rss_peak_bytes"] - 1) * 100,
}, indent=2))
