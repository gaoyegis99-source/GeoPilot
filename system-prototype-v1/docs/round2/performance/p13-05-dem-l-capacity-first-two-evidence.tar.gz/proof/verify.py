"""Independently replay a sealed DEM L worker reference and receipt."""
from hashlib import sha256
import json
import math
from pathlib import Path
import sys

from verify_area_fixtures import verify_fixture


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


root, fixture_dir = (Path(arg) for arg in sys.argv[1:3])
variant = sys.argv[3] if len(sys.argv) > 3 else "baseline"
assert variant in {"baseline", "frozen"}
worker = root / variant
proof = root / "proof"
plan = load(root / "plan.json")
contract = load(proof / "contract.json")
source = plan["sources"][variant]
receipt = load(worker / "receipt.json")
files = ("environment.json", "production-report.json", "result.json")
if receipt["files_sha256"] != {name: digest(worker / name) for name in files}:
    raise ValueError("Published worker files differ from the receipt")
manifest = proof / f"{variant}.sha256"
assert digest(manifest) == source["source_manifest_sha256"]
assert len(manifest.read_bytes().splitlines()) == source["source_files"]
assert digest(proof / f"{variant}-area_stats.py") == source["area_module_sha256"]
result = load(worker / "result.json")
assert result["status"] == "PASS" and result["commit"] == receipt["commit"] == source["commit"]
assert result["area_module_sha256"] == source["area_module_sha256"]
assert (worker / "exit-code").read_text().strip() == "0"
assert receipt["container_exit_code"] == receipt["worker_exit_code"] == 0 and receipt["timed_out"] is False
assert receipt["scope"] == plan["scope"] == "direct_area_capacity_probe"
assert receipt["runtime_tree"] == contract["runtime_tree"]
assert receipt["worker_wall_budget_s"] == plan["each_worker_wall_budget_s"] == 1800
env = result["environment"]
assert env == load(worker / "environment.json")
assert env["affinity"] == [31] and env["nice"] == 19 and env["variables"] == contract["runtime_variables"]
assert env["python"] == contract["python_version"]
assert result["report"] == load(worker / "production-report.json")
fixture = contract["fixture"]
assert digest(fixture_dir / "manifest.json") == contract["fixture_manifest_sha256"]
assert load(fixture_dir / "manifest.json") == load(proof / "manifest.json")
assert fixture == next(item for item in load(proof / "manifest.json")["fixtures"] if item["id"] == "dem-l")
independent = verify_fixture(fixture_dir, fixture)
assert result["input_sha256_before"] == result["input_sha256_after"] == plan["input_sha256"] == independent["sha256"]
assert independent["maximum_absolute_pixel_error"] == 0
report = result["report"]
classification, = report["classes"]
assert classification["class_id"] == 7
assert classification["pixel_count"] == report["selected_pixel_count"] == independent["valid_class_counts"]["7"]
assert report["nodata_pixel_count"] == independent["masked_pixels"]
assert report["area_crs"] == contract["area_reference"]["crs"] and report["resampling"] == "none"
assert report["total_area_m2"] == classification["area_m2"]
actual = classification["area_m2"]
expected = independent["area_m2"]["7"]
rule = contract["area_reference"]
assert math.isclose(actual, expected, rel_tol=rule["relative_tolerance"], abs_tol=rule["absolute_tolerance_m2"])
assert 0 < result["core_cpu_ns"] <= receipt["wall_ns"] and result["core_wall_ns"] <= receipt["wall_ns"]
assert receipt["rss_samples"] > 0 and receipt["peak_rss_bytes"] >= receipt["sampled_rss_peak_bytes"] > 0
print(json.dumps({
    "scope": receipt["scope"], "commit": source["commit"], "input": independent,
    "observed_m2": actual, "difference_from_recomputed_m2": actual - expected,
    "core_wall_ns": result["core_wall_ns"], "core_cpu_ns": result["core_cpu_ns"],
    "supervisor_wall_ns": receipt["wall_ns"], "rss_peak_bytes": receipt["peak_rss_bytes"],
    "rss_samples": receipt["rss_samples"], "convergence": report["boundary_convergence"],
}, indent=2))
