from hashlib import sha256
import json
from pathlib import Path
import shlex
import sys
import tarfile

root = Path(sys.argv[1])
ref = root / "reference"
roles = ("baseline", "frozen")
source_commits = {
    "baseline": "977ab412d9f6e7558d22a5c431fac0ada90b07be",
    "frozen": "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc",
}


def digest(raw):
    return sha256(raw).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def normalize_command(args, path, source, image):
    command = list(args)
    for flag, value in {
        "--name": (path / "container-name").read_text().strip(),
        "--commit": source["commit"], "--source-sha": source["area_module_sha256"],
    }.items():
        i = command.index(flag) + 1
        assert command[i] == value
        command[i] = "<varies>"
    for index, value in enumerate(command):
        for mount in (f"/snapshots/{path.name},dst=/project,readonly", f"/{path.name},dst=/scratch"):
            if value.endswith(mount):
                command[index] = value[:-len(mount)] + mount.replace(path.name, "<role>", 1)
    for flag, value in {
        "--cpuset-cpus": "31", "--network": "none", "--pull=never": None,
        "--budget-seconds": "1800", "--input": "/fixture/dem-l.tif", "--output": "/scratch",
    }.items():
        assert flag in args
        if value is not None:
            assert args[args.index(flag) + 1] == value
    assert args[args.index(image) + 1:args.index("--input")] == [
        "-n", "19", "/usr/bin/ionice", "-c", "3", "/runtime/venv/bin/python", "-B", "/probe/probe.py",
    ]
    for target in ("/project", "/runtime", "/fixture/dem-l.tif", "/probe/probe.py", "/probe/contract.json"):
        assert any(value.endswith(f"dst={target},readonly") for value in args)
    return command


native = load(ref / "native-bindings.json")
old = load(ref / "baseline-audit.json")
fixture, = [f for f in load(ref / "fixture-manifest.json")["fixtures"] if f["id"] == "dem-l"]
sides, commands, reports, environments = {}, {}, {}, {}
with tarfile.open(ref / "capacity-plan.tar.gz", "r:gz") as tar:
    source_manifest = json.load(tar.extractfile("agent/snapshots/source-manifest.json"))
    contract_raw = tar.extractfile("agent/snapshots/contract.json").read()
    contract = json.loads(contract_raw)
    assert digest(contract_raw) == old["contract_sha256"]
    assert fixture == contract["fixture"]
    for role in roles:
        path = root / role
        result = load(path / "result.json")
        receipt = load(path / "receipt.json")
        budget = load(path / "budget.json")
        env = load(path / "environment.json")
        report = load(path / "production-report.json")
        source = source_manifest[role]
        inventory = tar.extractfile(f"agent/snapshots/{role}.sha256").read()
        assert digest(inventory) == source["source_manifest_sha256"] and len(inventory.splitlines()) == source["source_files"]
        module, = [line.split()[0] for line in inventory.decode().splitlines()
                   if line.endswith("  ./src/geopilot/gis/raster/area_stats.py")]
        blob = "area_stats.py" if role == "baseline" else "frozen-area_stats.py"
        assert module == digest((ref / blob).read_bytes()) == source["area_module_sha256"] == result["area_module_sha256"]
        assert source["commit"] == source_commits[role] == receipt["commit"] == result["commit"]
        assert receipt["scope"] == old["scope"] == "direct_area_capacity_probe"
        assert receipt["runtime_tree"] == contract["runtime_tree"] == native["runtime_tree"]
        assert env == result["environment"] == old["environment"]
        assert env["variables"] == contract["runtime_variables"] == native["runtime_variables"]
        assert env["affinity"] == [31] and env["nice"] == 19 and native["ionice"] == "idle"
        assert env["python"] == contract["python_version"] == native["python"]["version"]
        assert result["input_sha256_before"] == result["input_sha256_after"] == fixture["sha256"] == old["fixture_sha256"]
        assert result["status"] == "PASS" and receipt["timed_out"] is False
        assert receipt["worker_wall_budget_s"] == budget["worker_wall_budget_s"] == 1800
        assert budget["outer_container_wall_budget_s"] == 1890
        assert int((path / "exit-code").read_text()) == receipt["worker_exit_code"] == receipt["container_exit_code"] == 0
        assert not (path / "container.log").read_bytes()
        assert set(receipt["files_sha256"]) == {"environment.json", "production-report.json", "result.json"}
        for name, checksum in receipt["files_sha256"].items():
            assert digest((path / name).read_bytes()) == checksum
        assert report == result["report"] and result["area_reference"] == contract["area_reference"]
        measured, = report["classes"]
        assert measured == {"class_id": 7, "pixel_count": fixture["valid_class_counts"]["7"], "area_m2": old["observed_area_m2"]}
        assert report["total_area_m2"] == measured["area_m2"]
        assert report["nodata_pixel_count"] == fixture["masked_pixels"]
        assert result["reference_checks"]["7"]["difference_m2"] == old["signed_area_error_m2"]
        args = shlex.split((path / "command.log").read_text())
        commands[role] = normalize_command(args, path, source, native["image_required"])
        reports[role] = (path / "production-report.json").read_bytes()
        environments[role] = (path / "environment.json").read_bytes()
        metrics = {
            "core_wall_s": result["core_wall_ns"] / 1e9,
            "core_cpu_s": result["core_cpu_ns"] / 1e9,
            "worker_wall_s": receipt["wall_ns"] / 1e9,
            "worker_cpu_s": receipt["cpu_user_s"] + receipt["cpu_system_s"],
            "peak_rss_bytes": receipt["peak_rss_bytes"],
        }
        assert 60 < metrics["core_cpu_s"] <= metrics["core_wall_s"] < metrics["worker_wall_s"] < receipt["worker_wall_budget_s"]
        assert metrics["core_cpu_s"] <= metrics["worker_cpu_s"] < metrics["worker_wall_s"]
        assert receipt["peak_rss_bytes"] == receipt["sampled_rss_peak_bytes"] > 0 and receipt["rss_samples"] > 0
        sides[role] = {"source": source, "metrics": metrics, "rss_samples": receipt["rss_samples"],
                       "started_utc": budget["started_utc"], "exit_code": receipt["container_exit_code"],
                       "files_sha256": receipt["files_sha256"]}

assert commands["baseline"] == commands["frozen"]
assert reports["baseline"] == reports["frozen"] and environments["baseline"] == environments["frozen"]
formal = load(ref / "formal-comparison.json")
assert formal["before_source"] == source_commits["baseline"] and formal["after_source"] == source_commits["frozen"]
for group in formal["groups"]:
    assert not group["successful_sample_deltas"]
    for label in ("before", "after"):
        assert group[label]["counts"] == {"FAIL": 5, "NOT_RUN": 0, "PASS": 0}
        assert group[label]["failure_codes"] == {"PROCESS_TIMEOUT": 5}

changes = {}
for key, before in sides["baseline"]["metrics"].items():
    after = sides["frozen"]["metrics"][key]
    changes[key] = {"baseline": before, "frozen": after, "absolute": after - before, "percent": (after - before) / before * 100}
summary = {
    "scope": "Two finalized direct capacity probe observations; one worker each at a 1800 s budget.",
    "formal_method_new_trials": 0, "formal_method_prior_limit_s": 60,
    "same_production_report_bytes": True, "production_report_bytes": len(reports["baseline"]),
    "production_report_sha256": digest(reports["baseline"]),
    "same_environment_bytes": True, "environment_sha256": digest(environments["baseline"]),
    "same_command_except_role_identity_and_paths": True,
    "image": native["image_required"], "runtime_tree": contract["runtime_tree"],
    "input_sha256": fixture["sha256"], "area_m2": old["observed_area_m2"],
    "area_error_m2": old["signed_area_error_m2"], "sides": sides, "frozen_minus_baseline": changes,
}
(root / "independent.json").write_text(json.dumps(summary, indent=2) + "\n")
for key, change in changes.items():
    print(key, change)
print(f"production report {len(reports['baseline'])} bytes and environment byte-identical; both direct workers exit 0")
