from hashlib import sha256
import json
import math
from pathlib import Path
import shlex
import sys
import tarfile

root = Path(sys.argv[1])
base, refs = root / "baseline", root / "reference"


def digest(data):
    return sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


report = load(base / "production-report.json")
result = load(base / "result.json")
receipt = load(base / "receipt.json")
env = load(base / "environment.json")
budget = load(base / "budget.json")
native = load(refs / "native-bindings.json")
manifest = load(refs / "fixture-manifest.json")
fixture, = [item for item in manifest["fixtures"] if item["id"] == "dem-l"]
reference = manifest["area_reference"]
with tarfile.open(refs / "capacity-plan.tar.gz", "r:gz") as archive:
    contract_raw = archive.extractfile("agent/snapshots/contract.json").read()
    contract = json.loads(contract_raw)
    source = json.load(archive.extractfile("agent/snapshots/source-manifest.json"))["baseline"]
    inventory = archive.extractfile("agent/snapshots/baseline.sha256").read()
assert fixture == contract["fixture"] and reference == contract["area_reference"]
assert digest((refs / "fixture-manifest.json").read_bytes()) == contract["fixture_manifest_sha256"]
assert digest((refs / "native-bindings.json").read_bytes()) == contract["native_seal_sha256"]
assert digest(inventory) == source["source_manifest_sha256"] and len(inventory.splitlines()) == source["source_files"]
module, = [line.split()[0] for line in inventory.decode().splitlines()
           if line.endswith("  ./src/geopilot/gis/raster/area_stats.py")]
assert module == source["area_module_sha256"] == result["area_module_sha256"]
assert module == digest((refs / "area_stats.py").read_bytes())
assert source["commit"] == receipt["commit"] == result["commit"] == "977ab412d9f6e7558d22a5c431fac0ada90b07be"
assert result["status"] == "PASS" and receipt["scope"] == "direct_area_capacity_probe"
assert set(receipt["files_sha256"]) == {"environment.json", "production-report.json", "result.json"}
for name, expected in receipt["files_sha256"].items():
    assert digest((base / name).read_bytes()) == expected

args = shlex.split((base / "command.log").read_text())
for name, val in {"--name": (base / "container-name").read_text().strip(), "--network": "none", "--cpuset-cpus": "31",
                  "--budget-seconds": "1800", "--source-sha": module, "--commit": source["commit"],
                  "--input": "/fixture/dem-l.tif", "--contract": "/probe/contract.json", "--output": "/scratch"}.items():
    assert args[args.index(name) + 1] == val
image = native["image_required"]
assert args[args.index(image) + 1:args.index("--input")] == [
    "-n", "19", "/usr/bin/ionice", "-c", "3", "/runtime/venv/bin/python", "-B", "/probe/probe.py",
]
mounts = [args[index + 1] for index, token in enumerate(args) if token == "--mount"]
for destination in ("/project", "/fixture/dem-l.tif", "/runtime", "/probe/probe.py", "/probe/contract.json",
                    "/usr/bin/qgis_process", "/usr/bin/qgis_process.bin"):
    entry, = [value for value in mounts if f"dst={destination}" in value.split(",")]
    assert entry.endswith(",readonly")
assert any("/snapshots/baseline,dst=/project,readonly" in entry for entry in mounts)
assert receipt["runtime_tree"] == native["runtime_tree"] == contract["runtime_tree"]
assert env == result["environment"] and env["variables"] == native["runtime_variables"] == contract["runtime_variables"]
assert env["python"] == native["python"]["version"] == contract["python_version"]
assert env["affinity"] == native["cpu"] == [31] and env["nice"] == 19 and native["ionice"] == "idle"

tif = (refs / "dem-l.tif").read_bytes()
assert len(tif) == fixture["bytes"] and tif[:4] in (b"II*\0", b"MM\0*")
assert digest(tif) == fixture["sha256"] == result["input_sha256_before"] == result["input_sha256_after"]
verification_log = (refs / "fixture-verification.log").read_text()
verification, _ = json.JSONDecoder().raw_decode(verification_log[verification_log.index("{"):])
assert verification["status"] == "PASS" and verification["area_crs"] == reference["crs"]
validation, = [entry for entry in verification["fixtures"] if entry["id"] == "dem-l"]
assert validation["maximum_absolute_pixel_error"] == 0.0
for key in ("bytes", "sha256", "valid_class_counts", "masked_pixels"):
    assert validation[key] == fixture[key]
assert validation["area_m2"] == fixture["expected_area_m2"]
assert report == result["report"] and result["area_reference"] == reference
assert (report["source_crs"], report["area_crs"], report["area_method"], report["area_unit"],
        report["cell_area_method"], report["resampling"]) == (
    fixture["grid"]["crs"], reference["crs"], "equal_area", "square_meter", "projected_cell_boundary", "none",
)
row, = report["classes"]
pixels, masked = fixture["valid_class_counts"]["7"], fixture["masked_pixels"]
assert row["class_id"] == 7 and row["pixel_count"] == report["selected_pixel_count"] == report["valid_pixel_count"] == pixels
assert report["unselected_pixel_count"] == 0 and report["nodata_pixel_count"] == masked
assert pixels + masked == math.prod(fixture["grid"]["shape"]) == 8190**2
expected, observed = fixture["expected_area_m2"]["7"], row["area_m2"]
error = observed - expected
assert observed == report["total_area_m2"] and abs(error) < reference["absolute_tolerance_m2"]
assert math.isclose(observed, expected, rel_tol=reference["relative_tolerance"], abs_tol=reference["absolute_tolerance_m2"])
assert result["reference_checks"] == {"7": {"expected_m2": expected, "observed_m2": observed,
                                             "difference_m2": error, "pixel_count": pixels}}
assert report["boundary_convergence"] == {"absolute_tolerance_m2": 1e-6, "relative_tolerance": 1e-8,
                                          "max_segments_per_edge_used": 8}

assert int((base / "exit-code").read_text()) == receipt["container_exit_code"] == receipt["worker_exit_code"] == 0
assert receipt["timed_out"] is False
worker_budget = receipt["worker_wall_budget_s"]
assert worker_budget == budget["worker_wall_budget_s"] == 1800 and budget["outer_container_wall_budget_s"] == 1890
assert 60 < result["core_wall_ns"] / 1e9 < receipt["wall_ns"] / 1e9 < worker_budget
worker_cpu = receipt["cpu_user_s"] + receipt["cpu_system_s"]
assert 0 < result["core_cpu_ns"] / 1e9 <= worker_cpu <= receipt["wall_ns"] / 1e9
assert receipt["peak_rss_bytes"] == receipt["sampled_rss_peak_bytes"] > 0 and receipt["rss_samples"] > 0

formal = load(refs / "formal-comparison.json")
assert formal["status"] == "MATCHED_EVIDENCE" and formal["before_source"] == source["commit"]
assert {g["group"][2] for g in formal["groups"]} == {"process_cold", "warm"} and not formal["candidate_all_measurements_pass"]
for group in formal["groups"]:
    assert group["group"][:2] == ["L", "method"] and not group["successful_sample_deltas"]
    for label in ("before", "after"):
        assert group[label]["counts"] == {"PASS": 0, "FAIL": 5, "NOT_RUN": 0}
        assert group[label]["failure_codes"] == {"PROCESS_TIMEOUT": 5}
historical = load(refs / "historical-source.json")
state = historical["run_state"]
assert historical["run_id"] == fixture["source"]["run_id"] == state["run_id"]
assert state["execution_status"] == "FAILED" and state["check_status"] == "NOT_CHECKED"
assert state["error"]["code"] == "PROCESS_TIMEOUT" and state["error"]["message"] == "Process exceeded 60 seconds"

summary = {
    "scope": receipt["scope"], "source": source, "native_image": image, "environment": env,
    "runtime_tree": receipt["runtime_tree"], "contract_sha256": digest(contract_raw),
    "fixture_sha256": digest(tif), "fixture_shape": fixture["grid"]["shape"], "class_counts": {"7": pixels},
    "masked_pixels": masked, "area_crs": report["area_crs"], "expected_area_m2": expected,
    "observed_area_m2": observed, "signed_area_error_m2": error, "absolute_area_error_m2": abs(error),
    "core_wall_s": result["core_wall_ns"] / 1e9, "core_cpu_s": result["core_cpu_ns"] / 1e9,
    "worker_wall_s": receipt["wall_ns"] / 1e9, "worker_cpu_user_s": receipt["cpu_user_s"],
    "worker_cpu_system_s": receipt["cpu_system_s"], "worker_cpu_total_s": worker_cpu,
    "peak_rss_bytes": receipt["peak_rss_bytes"], "peak_rss_mib": receipt["peak_rss_bytes"] / 2**20,
    "rss_samples": receipt["rss_samples"], "worker_wall_budget_s": worker_budget,
    "container_exit_code": receipt["container_exit_code"],
    "formal_method": {"prior_limit_s": 60, "prior_successful_sample_deltas": {}, "new_formal_trials": 0},
    "evidence_scope": "Read-only baseline receipt and archived fixture/source. The original area call used one extended-budget direct worker.",
}
(root / "independent.json").write_text(json.dumps(summary, indent=2) + "\n")
print(f"PASS baseline area={observed:.6f} m² delta={error:.12f} m²; 8190x8190, class7={pixels}, NoData={masked}")
print(f"core wall={summary['core_wall_s']:.9f}s cpu={summary['core_cpu_s']:.9f}s; "
      f"worker wall={summary['worker_wall_s']:.9f}s cpu={worker_cpu:.9f}s")
print(f"RSS={receipt['peak_rss_bytes']} bytes / {summary['peak_rss_mib']:.3f} MiB across {receipt['rss_samples']} reads")
print("Container and worker exit 0; direct worker budget=1800s; formal 60s method unchanged.")
