"""Verify the first frozen-candidate remote L warmup against its actual artifacts."""

from hashlib import sha256
import json
from math import isclose
from pathlib import Path
import sys

from geopilot.data.fingerprint import fingerprint_file


def read(path):
    return json.loads(path.read_bytes())


def main(root):
    row = read(root / "trial.jsonl")
    assert row["sample_id"] == "remote_sensing/L/method/process_cold/01" and row["kind"] == "warmup"
    assert row["status"] == "FAIL" and row["error"]["type"] == "StatusObservationFailure"
    errors = row["status_poll_errors"]
    assert len(errors) == 3 and all(error["http_status"] == 500 for error in errors)
    state = row["run_state"]
    assert (state["run_id"], state["execution_status"], state["check_status"]) == (row["run_id"], "SUCCEEDED", "PASSED")
    steps = row["executed_steps"]
    assert len(steps) == 8 and all((step["status"], step["exit_code"]) == ("SUCCEEDED", 0) for step in steps)
    step = row["telemetry"]["steps"][-1]
    assert step["step_key"] == "calculate_change" and step["wall_ns"] < 60_000_000_000
    reference = next(item for item in read(root / "fixture-manifest.json")["fixtures"] if item["id"] == "remote-l")
    run = root / "workspace"
    report = read(run / "checks/report.json")
    assert (report["report_id"], report["run_id"], report["status"]) == (state["current_report_id"], row["run_id"], "PASSED")
    assert report["completed_rules"] == row["v1_completed_checks"]
    last_result = read(run / "steps/calculate_change/result.json")
    assert (last_result["run_id"], last_result["status"], last_result["exit_code"]) == (row["run_id"], "SUCCEEDED", 0)
    artifacts = read(run / "outputs/manifest.json")["artifacts"]
    assert len(artifacts) == 10
    verified = {}
    for role, record in artifacts.items():
        path = run / record["path"]
        evidence = fingerprint_file(path)
        assert evidence.digest == record["fingerprint"]
        verified[role] = {"file_group_sha256": evidence.digest, "bytes": evidence.size_bytes}
    assert sum(value["bytes"] for value in verified.values()) == row["output_bytes"]

    classification = run / artifacts["change_classes"]["path"]
    difference = run / artifacts["change_raster"]["path"]
    assert sha256(classification.read_bytes()).hexdigest() == reference["sha256"]
    assert sha256(difference.read_bytes()).hexdigest() == "d215839bf661e72c290c0237ef1a52f98fcb4605c64f5b5a460f2346f6dd020d"
    area = read(run / artifacts["area_statistics"]["path"])
    assert area == row["correctness"]["area_statistics"]["observed"]
    assert (area["source_crs"], area["area_crs"], area["area_method"], area["direction"]) == (
        "EPSG:32632", "EPSG:6933", "equal_area", "second_minus_first",
    )
    assert area["nodata_pixel_count"] == reference["masked_pixels"]
    assert len(area["classes"]) == 3
    deviations = {}
    for record in area["classes"]:
        key = str(record["class_id"])
        expected = reference["expected_area_m2"][key]
        assert record["pixel_count"] == reference["valid_class_counts"][key]
        assert isclose(record["area_m2"], expected, rel_tol=2e-7, abs_tol=.02)
        deviations[key] = record["area_m2"] - expected
    print(json.dumps({
        "run_id": row["run_id"], "benchmark_status": row["status"], "terminal_status": [state["execution_status"], state["check_status"]],
        "status_get_500": len(errors), "change_step_wall_ns": step["wall_ns"], "total_area_m2": area["total_area_m2"],
        "area_difference_from_sealed_reference_m2": deviations, "verified_file_groups": verified,
    }, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve(strict=True))
