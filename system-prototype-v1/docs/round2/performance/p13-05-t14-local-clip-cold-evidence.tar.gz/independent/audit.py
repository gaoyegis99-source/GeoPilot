"""Independent small-file audit of the T14 L local-clip candidate cold evidence."""
from collections import Counter
from io import BytesIO
from itertools import islice
from hashlib import sha256
import json
import math
import re
from pathlib import Path
import re
import shlex
from statistics import median
import subprocess
import tarfile
import sys

REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
RECORDS = REPO / "docs/round2/performance"
PLAN = REPO / "artifacts/test-results/p13-05-vector-l-plan.a2d2e68.C905zE"
ROOT = Path("/mnt/datab/geopilot-p13-05-vector-l-t14.fff225f22356.SIbfWQ")
WORKLOAD = "t14-split_by_area"
SHARD = ROOT / WORKLOAD
COMMITS = {
    "base": "977ab412d9f6e7558d22a5c431fac0ada90b07be",
    "candidate": "fff225f223568921ef2ac56f2b76ee9c4f8cbd29",
}
OLD = "37cb329be04eaddfeb23ac62789926d0fcdb63aa"
TREE_HASHES = {
    "base": "19bf6a3df70aee71ea6bf87f690a7b13b28b2cfc08ad3e79aa01c3e72b6e4277",
    "candidate": "05258667966a75b5695ca10e9835daf9bb36d050fd8254fdfe95eabef18930e7",
}
FROZEN_RUNNER_HASH = "b0b83f6fa51bf097a28b8ae69e828e0ef401e35981e7262f469eca52c95c5af2"
IMAGE = "sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87"
FILESYSTEM = "/dev/sdb1 ext4"
RELATION = {"spatial_relation": "intersects"}
ALLOCATION = {"boundary_assignment": "split_by_area", "boundary_tie": "unassigned", "area_crs": "EPSG:6933"}
OPTIONS = {**RELATION, **ALLOCATION}
STEPS = (
    ("apply_spatial_relation", "python-select-spatial-relation", RELATION),
    ("clip_back_to_analysis_extent", "python-clip-vector-to-extent", {}),
    ("aggregate_by_zone", "python-polygon-zone-statistics", {**ALLOCATION, "area_unit": "square_meter"}),
)
CACHES = ("process_cold", "warm")
PHASES = (("warmup", 2), ("measurement", 5))
PLANNED = [(cache, phase, i) for cache in CACHES for phase, n in PHASES for i in range(1, n + 1)]
RESOURCES = ("cpu_ns", "peak_rss_bytes", "disk_read_bytes", "disk_write_bytes")
METRICS = ("wall_ns", "queue_wall_ns", "execute_steps_wall_ns", "finalize_wall_ns",
           *RESOURCES, "peak_temp_bytes", "input_bytes", "output_bytes")


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def snapshot_digest(snapshot):
    payload = {name: value for name, value in snapshot.items() if name != "sha256"}
    encoded = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return sha256(encoded.encode("ascii")).hexdigest()


def distribution(readings):
    values = sorted(item["value"] for item in readings if item.get("value") is not None)
    return {
        "samples": len(values),
        "coverage": dict(Counter(item["status"] for item in readings)),
        "median": median(values) if len(values) >= 3 else None,
        "p95": values[math.ceil(.95 * len(values)) - 1] if len(values) >= 3 else None,
    }


def reading(value):
    return {"status": "recorded" if value is not None else "unavailable", "value": value}


def measure_columns(row):
    sidecar = row["telemetry"]["document"]
    return {
        "wall_ns": reading(row["wall_ns"]),
        "queue_wall_ns": sidecar["queue_wall_ns"],
        "execute_steps_wall_ns": reading(sidecar["execute_steps_wall_ns"]),
        "finalize_wall_ns": reading(sidecar["finalize_wall_ns"]),
        **sidecar["resources"],
        "peak_temp_bytes": row["peak_temp_bytes"],
        "input_bytes": reading(row["input_bytes"]),
        "output_bytes": reading(row.get("output_bytes")),
    }


def one_run(row, expected):
    assert (row["tier"], row["workload"], row["input_profile"], row["input_manifest_sha256"]) == (
        "L", WORKLOAD, "p13-01", expected["input_manifest_sha256"],
    )
    package = next(file for file in expected["files"] if file["path"] == "t14.gpkg")
    assert row["input"] == package and row["input_bytes"] == package["bytes"]
    assert row["method"] == {"id": "polygon-zone-statistics", "version": 1}
    assert row["critical_options"] == OPTIONS and row["plan_version"] == 1
    assert isinstance(row["wall_ns"], int) and row["wall_ns"] > 0 and row["submission_attempted"]
    assert (row.get("input_preread_ns", 0) > 0) == (row["cache"] == "warm")
    assert row["checks_only_ns"] == {
        "status": "unavailable", "reason": "sidecar_finalization_includes_artifact_registration",
    }
    state = row["run_status"]
    doc = row["telemetry"]["document"]
    assert row["telemetry"]["status"] == "recorded"
    assert doc["schema_version"] == 1 and doc["wall_scope"] == "execution_through_finalization"
    assert state["run_id"] == doc["run_id"] == row["run_id"]
    assert (state["execution_status"], state["check_status"]) == (doc["execution_status"], doc["check_status"])
    assert not state["cancel_requested"]
    assert len(row["steps"]) == len(STEPS)
    events = {event["step_key"]: event for event in doc["steps"]}
    assert len(events) == len(doc["steps"])
    for step, (key, tool, parameters) in zip(row["steps"], STEPS, strict=True):
        assert step["key"] == key
        if step["status"] == "NOT_STARTED":
            assert key not in events and all(step[name] is None for name in ("tool", "parameters", "exit_code", "error"))
            continue
        event = events[key]
        assert step["tool"] == {"id": tool, "version": 1} and step["parameters"] == parameters
        assert event["tool"]["id"] == tool and event["tool"]["version"] == 1
        assert (step["status"], step["exit_code"]) == (event["status"], event["exit_code"])
        assert any(proc["phase"] == "execute" for proc in event["processes"])
    assert row["status"] == "PASS"
    assert (state["execution_status"], state["check_status"], doc["exit_code"]) == ("SUCCEEDED", "PASSED", 0)
    assert state["current_report_id"] and state["error"] is None and not row.get("status_read_errors")
    assert len(events) == 3 and row["checks"]["rules"] == {"output_exists": True}
    assert re.fullmatch(r"[0-9a-f]{64}", row["checks"]["report_sha256"])
    assert all(step["status"] == "SUCCEEDED" and step["exit_code"] == 0 for step in row["steps"])
    for event in events.values():
        process, = [p for p in event["processes"] if p["phase"] == "execute"]
        assert process["exit_code"] == 0 and not process["timed_out"] and not process["cancelled"]
    assert row["correctness"] == expected["correctness"][WORKLOAD]
    assert set(row["artifacts"]) == {"clipped_targets", "original_targets", "allocation_details", "zone_statistics"}
    for role, artifact in row["artifacts"].items():
        assert re.fullmatch(r"[0-9a-f]{64}", artifact["fingerprint"])
        step, output, file = {
            "allocation_details": ("aggregate_by_zone", "allocation_details", "allocation_details.csv"),
            "zone_statistics": ("aggregate_by_zone", "zone_statistics", "zone_statistics.json"),
            "clipped_targets": ("clip_back_to_analysis_extent", "targets", "targets.gpkg"),
            "original_targets": ("clip_back_to_analysis_extent", "original_targets", "original_targets.gpkg"),
        }[role]
        assert artifact["step"] == step and artifact["output"] == output
        assert artifact["uri"] == f"intermediate/{step}/{file}"
    messages = (
        "Selected 131072 of 131072 complete target(s) using intersects",
        "Clipped 114688 of 131072 selected target(s) with nonempty intersections",
        "Summarized 98304 unique target(s), 32768 unassigned",
    )
    assert all(message in row["step_logs"][f"steps/{step}/process.log"]["text"]
               for (step, _, _), message in zip(STEPS, messages, strict=True))
    return {
        "cache": row["cache"], "phase": row["phase"], "repeat": row["repeat"],
        "run_id": row["run_id"], "plan_id": row["plan_id"], "workdir": row["workdir"],
        "status": row["status"], "terminal": [state["execution_status"], state["check_status"]],
        "exit_code": doc["exit_code"], "error": state["error"], "wall_ns": row["wall_ns"],
        "steps": [{"key": step["key"], "status": step["status"], "exit_code": step["exit_code"],
                   "timed_out": any(p["timed_out"] for p in events.get(step["key"], {}).get("processes", []))}
                  for step in row["steps"]],
        "status_read_errors": row.get("status_read_errors", []), "correctness": row.get("correctness"),
        "resources": measure_columns(row),
        "artifacts": row.get("artifacts"), "checks": row.get("checks"),
    }


def timeout_prefix(row, failure_index):
    failure = row["run_status"]["error"]
    failed_key = STEPS[failure_index][0]
    assert (row["status"], row["run_status"]["execution_status"], row["run_status"]["check_status"]) == (
        "FAIL", "FAILED", "NOT_CHECKED",
    )
    assert row["error"] == "ValueError: Run state is FAILED/NOT_CHECKED"
    assert (failure["code"], failure["phase"], failure["step_key"], failure["message"]) == (
        "PROCESS_TIMEOUT", "execute", failed_key, "Process exceeded 60 seconds",
    )
    assert row["run_status"]["current_step"] == failed_key and row["run_status"]["current_report_id"] is None
    assert all(name not in row for name in ("correctness", "checks", "artifacts"))

    steps = row["steps"]
    for completed in steps[:failure_index]:
        assert completed["status"] == "SUCCEEDED" and completed["exit_code"] == 0 and completed["error"] is None
    failed = steps[failure_index]
    assert failed["status"] == "FAILED" and failed["exit_code"] == -15 and failed["error"] == failure
    for unstarted in steps[failure_index + 1:]:
        assert unstarted["status"] == "NOT_STARTED"
        assert all(unstarted[field] is None for field in ("exit_code", "error", "tool", "parameters"))
    sidecar = row["telemetry"]["document"]
    assert sidecar["exit_code"] == -15
    assert [event["step_key"] for event in sidecar["steps"]] == [step[0] for step in STEPS[:failure_index + 1]]
    for index, event in enumerate(sidecar["steps"]):
        process, = [proc for proc in event["processes"] if proc["phase"] == "execute"]
        assert process["cancelled"] is False
        if index == failure_index:
            assert event["exit_code"] == process["exit_code"] == -15 and event["status"] == "FAILED"
            assert process["timed_out"] is True and process["wall_ns"] >= 60_000_000_000
        else:
            assert event["exit_code"] == process["exit_code"] == 0 and event["status"] == "SUCCEEDED"
            assert process["timed_out"] is False
    if failure_index == 1:
        selected = row["step_logs"]["steps/apply_spatial_relation/process.log"]
        assert not selected["truncated"]
        assert "Selected 131072 of 131072 complete target(s) using intersects" in selected["text"]


def audit_runs(rows, expected, *, complete, failure_index):
    keys = [(row["cache"], row["phase"], row["repeat"]) for row in rows]
    assert keys == PLANNED[:len(rows)] and (not complete or keys == PLANNED)
    for field in ("run_id", "workdir"):
        assert len({row[field] for row in rows}) == len(rows)
    records = []
    for row in rows:
        record = one_run(row, expected)
        if failure_index is not None:
            timeout_prefix(row, failure_index)
        records.append(record)

    groups = {}
    for cache in CACHES:
        group = [r for r in rows if r["cache"] == cache]
        plans = {r["plan_id"] for r in group}
        assert len(plans) == (len(group) if cache == "process_cold" else bool(group))
        assert [r["service_reused"] for r in group] == [cache == "warm" and i > 0 for i in range(len(group))]
        measured = [r for r in group if r["phase"] == "measurement"]
        by_status = {}
        for outcome in ("PASS", "FAIL"):
            selected = [r for r in measured if r["status"] == outcome]
            columns = [measure_columns(r) for r in selected]
            by_status[outcome] = {field: distribution([m[field] for m in columns]) for field in METRICS}
            by_status[outcome]["steps"] = {}
            for step_key, _, _ in STEPS:
                events = [event for row in selected for event in row["telemetry"]["document"]["steps"]
                          if event["step_key"] == step_key]
                by_status[outcome]["steps"][step_key] = {
                    "wall_ns": distribution([reading(e["wall_ns"]) for e in events]),
                    **{name: distribution([e["resources"][name] for e in events]) for name in RESOURCES},
                }
        groups[cache] = {
            "counts": {phase: dict(Counter(r["status"] for r in group if r["phase"] == phase))
                       for phase, _ in PHASES},
            "measured_distributions": by_status,
        }
    plans = {cache: {r["plan_id"] for r in rows if r["cache"] == cache} for cache in CACHES}
    assert plans["process_cold"].isdisjoint(plans["warm"])
    return {"rows": records, "groups": groups}


def side_environment(attempt, side):
    command, filesystem = (attempt / "command.log").read_text().splitlines()
    args = shlex.split(command)
    assert IMAGE in args and filesystem == FILESYSTEM
    assert digest(attempt / "source-tree.sha256") == TREE_HASHES[side]
    assert digest(attempt / "frozen-runner.sha256") == FROZEN_RUNNER_HASH
    assert args[args.index("--source-commit") + 1] == COMMITS[side]
    assert args[args.index("--workload") + 1] == WORKLOAD
    assert args[args.index("--tier") + 1] == "L"
    assert [args[i+1] for i, arg in enumerate(args) if arg == "--cache-state"] == list(CACHES)
    environment_path = attempt / "evidence/environment.json"
    if not environment_path.is_file():
        return None
    env = read(environment_path)
    assert env["source_commit"] == COMMITS[side] and env["probe"] is False
    assert (env["planned_warmups"], env["planned_repeats"], env["run_wait_seconds"], env["budget_seconds"]) == (2, 5, 600, None)
    assert env["runner_sha256"] == {
        "run_vector.py": "52b254fcd93b08521ae7347c44e27f9dda3979bcda7fd8b97f1d72a5cd232063",
        "_vector_reference.py": "2aad7d57adba3a9a98cf93e68c40e60d717268b6fd5f229ad54e59bfd46d41f1",
        "_vector_road_profile.py": "31aefb282de59a63882e7b1bcca436fe1f10204bf60e6c07f0f8c6d0d5117232",
    }
    assert env["qgis_version"]["exit_code"] == 0
    return {name: env[name] for name in ("source_commit", "started_utc", "qgis_version", "runner_sha256", "storage_filesystem")}


def id_sets(audit):
    return {field: {row[field] for row in audit["rows"]} for field in ("run_id", "plan_id", "workdir")}


ATTEMPT = SHARD / "candidate/attempt.BdH0Dm"
DOC = "system-prototype-v1/docs/round2/performance"
MANIFEST = "ada61ccadb58accc19039b9f30c24db3d25ac0dc11d09987148105e10dac9c24"
ARTIFACT_SCOPE = "completed cold rows record independent feature/area verification and published artifact fingerprints; worker temporary workspaces removed"


def git(commit, name):
    return subprocess.check_output(["git", "-C", str(REPO), "show", f"{commit}:{DOC}/{name}"])


def archived_pair(commit, name):
    raw = git(commit, f"p13-05-vector-l-{name}-evidence.tar.gz")
    rows = {}
    with tarfile.open(fileobj=BytesIO(raw), mode="r:gz") as archive:
        checksums = dict((path, sha) for sha, path in
                         (line.split(maxsplit=1) for line in archive.extractfile("./SHA256SUMS").read().decode().splitlines()))
        for side in ("base", "candidate"):
            m, = [item for item in archive.getmembers()
                  if f"/{side}/" in item.name and item.name.endswith("/evidence/samples.jsonl")]
            payload = archive.extractfile(m).read()
            assert digest_bytes(payload) == checksums[m.name]
            rows[side] = [json.loads(line) for line in payload.splitlines()]
            assert len(rows[side]) == len({row["run_id"] for row in rows[side]}) == 14
    return rows, digest_bytes(raw)


def digest_bytes(raw):
    return sha256(raw).hexdigest()


def reference(commit):
    raw = git(commit, "p13-03-L-input-manifest.json")
    assert digest_bytes(raw) == MANIFEST
    fixture = json.loads(raw)
    ref = fixture["reference"]
    t14 = ref["t14"]
    tiles = ref["side_tiles"]**2
    split = t14["methods"]["split_by_area"]
    data = {
        "selected": t14["selected_rows"],
        "clipped": sum(t14["clipped_rows_per_id_per_tile"].values()) * tiles,
        "counts": split["counts"], "areas_m2": split["areas_m2"],
        "allocation_rows": len(split["details_per_tile"]) * tiles,
        "zones": ref["layer_counts"]["t14.gpkg"]["zones"],
    }
    assert (data["selected"], data["clipped"], data["allocation_rows"], data["zones"]) == (131072, 114688, 147456, 32768)
    assert data["areas_m2"]["total"] == data["areas_m2"]["assigned"] + data["areas_m2"]["unassigned"]
    return {"files": fixture["files"], "input_manifest_sha256": MANIFEST, "correctness": {WORKLOAD: data}}


def main(commit, output, allow_prefix=False):
    expected = reference(commit)
    frozen_area, archive_sha = archived_pair(commit, "area")
    for side, index in (("base", 0), ("candidate", 1)):
        for row in frozen_area[side]:
            assert row["input_manifest_sha256"] == MANIFEST
            timeout_prefix(row, index)
    frozen_env = read(ATTEMPT / "evidence/environment.json")
    assert frozen_env["workspace_retention"] == "temporary_directory_removed_after_worker_exit"
    assert digest(ATTEMPT / "evidence/input-L/manifest.json") == MANIFEST
    env = side_environment(ATTEMPT, "candidate")
    assert env is not None
    with (ATTEMPT / "evidence/samples.jsonl").open("rb") as stream:
        lines = [line for line in islice(stream, 7) if line.endswith(b"\n")]
    rows = [json.loads(line) for line in lines]
    assert rows and (allow_prefix or len(rows) == 7)
    assert all(row["cache"] == "process_cold" for row in rows)
    cold = audit_runs(rows, expected, complete=False, failure_index=None)
    current_ids = [row["run_id"] for row in rows]

    refs = []
    for name in ("point", "line"):
        pair, _ = archived_pair(commit, name)
        refs.extend(row["run_id"] for side in ("base", "candidate") for row in pair[side])
    refs.extend(row["run_id"] for side in ("base", "candidate") for row in frozen_area[side])
    assert len(refs) == len(set(refs)) == 84
    import gzip
    historical = []
    for suffix in ("formal", "remaining"):
        historical.extend(json.loads(line)["run_id"] for line in
                          gzip.decompress(git(commit, f"p13-03-L-{suffix}-samples.jsonl.gz")).splitlines())
    assert len(historical) == len(set(historical)) == 140
    assert len(set(refs + historical + current_ids)) == len(refs + historical + current_ids)
    base_data = {}
    for side in ("base", "candidate"):
        comparable = [row for row in frozen_area[side] if row["cache"] == "process_cold" and row["phase"] == "measurement"]
        base_data[side] = {"failure_step": comparable[0]["run_status"]["error"]["step_key"],
                           "wall_ns": distribution([reading(row["wall_ns"]) for row in comparable])}
    group = cold["groups"]["process_cold"]
    result = {
        "scope": "T14 local-clip candidate cold only", "attempt": str(ATTEMPT), "candidate_commit": COMMITS["candidate"],
        "container": (ATTEMPT / "container-name").read_text().strip(), "environment": env,
        "cold_prefix_sha256": digest_bytes(b"".join(lines)), "input_manifest_sha256": MANIFEST,
        "frozen_area_archive_sha256": archive_sha, "frozen_area_archive_commit": commit, "reference": expected["correctness"][WORKLOAD],
        "id_counts": {"frozen_vector_l": 84, "p13_03_l": 140, "new_cold": len(rows), "combined_unique": 224 + len(rows)},
        "formal_receipt_verified": False, "artifact_scope": ARTIFACT_SCOPE,
        "samples": cold["rows"], "group": group, "frozen_reference": base_data,
    }
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("cold", len(rows), "/7", group["counts"], "reference", result["reference"])
    for row in cold["rows"]:
        print(row["cache"], row["phase"], row["repeat"], row["run_id"], row["terminal"], "poll errors", len(row["status_read_errors"]))
    print("frozen baseline and prior candidate", base_data)
    d = group["measured_distributions"]["PASS"]
    for field in ("wall_ns", "peak_rss_bytes", "peak_temp_bytes", "queue_wall_ns", *RESOURCES):
        print(field, d[field])
    for key, step in d["steps"].items():
        print(key, "wall ns", step["wall_ns"], "RSS bytes", step["peak_rss_bytes"])
    print("artifact scope", ARTIFACT_SCOPE, "unique ID counts", result["id_counts"])


if __name__ == "__main__":
    main(sys.argv[1], Path(sys.argv[2]), allow_prefix="--allow-prefix" in sys.argv[3:])
