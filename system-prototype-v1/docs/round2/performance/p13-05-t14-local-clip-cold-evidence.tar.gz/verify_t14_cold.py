"""Replay formal T14 cold measurements and reconstruct independent text results."""

import argparse
from collections import Counter, defaultdict
import csv
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
from tempfile import TemporaryDirectory

from geopilot.data.fingerprint import fingerprint_file


STEP_KEYS = ("apply_spatial_relation", "clip_back_to_analysis_extent", "aggregate_by_zone")


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def expected_outputs(reference, output):
    side = reference["side_tiles"]
    oracle = reference["t14"]["methods"]["split_by_area"]
    patterns = sorted(oracle["details_per_tile"],
                      key=lambda entry: (entry["source_feature_id"], entry["zone_id"] is None, entry["zone_id"] or ""))
    zones = defaultdict(list)
    unassigned = set()
    allocation_rows = 0
    details = output / "allocation_details.csv"
    with details.open("x", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(("source_feature_id", "zone_id", "object_status", "area_m2"))
        for row in range(side):
            for column in range(side):
                tile = f"r{row:03d}c{column:03d}/"
                for pattern in patterns:
                    identifier = tile + pattern["source_feature_id"]
                    zone = tile + pattern["zone_id"] if pattern["zone_id"] is not None else None
                    area = float(pattern["area_m2"])
                    writer.writerow((identifier, zone, pattern["object_status"], area))
                    allocation_rows += 1
                    if zone is not None:
                        zones[zone].append((identifier, area))
                    elif pattern["object_status"] == "unassigned":
                        unassigned.add(identifier)
    zone_statistics = output / "zone_statistics.json"
    with zone_statistics.open("x", encoding="utf-8") as stream:
        json.dump({
            "boundary_assignment": "split_by_area", "boundary_tie": "unassigned",
            "area_crs": "EPSG:6933", "area_unit": "square_meter",
            "counts": {key: oracle["counts"][key] for key in ("total", "assigned", "unassigned")},
            "areas_m2": {key: float(oracle["areas_m2"][key]) for key in ("total", "assigned", "unassigned", "uncovered")},
            "zones": [
                {"zone_id": zone, "distinct_count": len(allocations), "area_m2": sum(area for _, area in allocations),
                 "source_feature_ids": sorted(identifier for identifier, _ in allocations)}
                for zone, allocations in sorted(zones.items())
            ],
            "unassigned_source_feature_ids": sorted(unassigned),
        }, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    assert len(unassigned) == oracle["counts"]["unassigned"]
    expected = {
        "selected": reference["t14"]["selected_rows"], "clipped": reference["t14"]["clipped_rows"],
        "counts": oracle["counts"], "areas_m2": oracle["areas_m2"], "allocation_rows": allocation_rows, "zones": len(zones),
    }
    fingerprints = {}
    for path in (details, zone_statistics):
        value = fingerprint_file(path)
        fingerprints[path.stem] = {"fingerprint": value.digest, "bytes": value.size_bytes, "sha256": digest(path)}
    return expected, fingerprints


def verify_sample(row, expected, fingerprints, input_hash):
    state = row["run_status"]
    assert (row["tier"], row["workload"], row["cache"], row["status"]) == ("L", "t14-split_by_area", "process_cold", "PASS")
    assert row["input_manifest_sha256"] == input_hash
    assert (state["run_id"], state["execution_status"], state["check_status"]) == (row["run_id"], "SUCCEEDED", "PASSED")
    assert not state["error"] and row["correctness"] == expected
    assert row["checks"]["rules"] == {"output_exists": True}
    steps = row["steps"]
    assert tuple(step["key"] for step in steps) == STEP_KEYS
    assert all((step["status"], step["exit_code"]) == ("SUCCEEDED", 0) for step in steps)
    for role, expected_file in fingerprints.items():
        record = row["artifacts"][role]
        assert record["fingerprint"] == expected_file["fingerprint"], role
        assert record["layer"] is None and record["step"] == "aggregate_by_zone"
    telemetry = row["telemetry"]["document"]
    assert telemetry["run_id"] == row["run_id"]
    timings = {step["step_key"]: step["wall_ns"] for step in telemetry["steps"]}
    assert tuple(timings) == STEP_KEYS
    return {
        "run_id": row["run_id"], "phase": row["phase"], "repeat": row["repeat"], "wall_ns": row["wall_ns"],
        "step_wall_ns": timings, "peak_rss_bytes": telemetry["resources"]["peak_rss_bytes"],
        "step_peak_rss_bytes": {step["step_key"]: step["resources"]["peak_rss_bytes"] for step in telemetry["steps"]},
        "peak_temp_bytes": row["peak_temp_bytes"], "artifacts": row["artifacts"],
    }


def distribution(values):
    return {"samples": len(values), "median": median(values) if len(values) >= 3 else None,
            "p95_nearest_rank": max(values) if len(values) >= 3 else None}


def verify(root, count):
    inputs = root / "input-manifest.json"
    input_hash = digest(inputs)
    manifest = read(inputs)
    assert (manifest["family"], manifest["tier"], manifest["reference"]["side_tiles"]) == ("vector", "L", 128)
    samples = root / "cold-samples.jsonl"
    rows = [json.loads(line) for line in samples.read_bytes().splitlines()]
    assert len(rows) == count and len({row["run_id"] for row in rows}) == count
    expected_schedule = [("warmup", 1), ("warmup", 2), *(("measurement", index) for index in range(1, 6))]
    assert [(row["phase"], row["repeat"]) for row in rows] == expected_schedule[:count]
    with TemporaryDirectory() as temporary:
        expected, fingerprints = expected_outputs(manifest["reference"], Path(temporary))
    observations = [verify_sample(row, expected, fingerprints, input_hash) for row in rows]
    measured = [row for row in observations if row["phase"] == "measurement"]
    output = {
        "samples_sha256": digest(samples), "input_manifest_sha256": input_hash,
        "independent_reference": expected, "independent_text_artifacts": fingerprints,
        "runs": observations, "measurement_wall_ns": distribution([row["wall_ns"] for row in measured]),
        "measurement_step_wall_ns": {
            key: distribution([row["step_wall_ns"][key] for row in measured]) for key in STEP_KEYS
        },
        "run_rss_coverage": dict(sorted(Counter(row["peak_rss_bytes"]["status"] for row in measured).items())),
        "run_temp_coverage": dict(sorted(Counter(row["peak_temp_bytes"]["status"] for row in measured).items())),
        "run_temp_bytes": distribution([row["peak_temp_bytes"]["value"] for row in measured]),
        "step_rss_coverage": {
            key: dict(sorted(Counter(row["step_peak_rss_bytes"][key]["status"] for row in measured).items()))
            for key in STEP_KEYS
        },
    }
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--count", type=int, choices=range(1, 8), default=7)
    args = parser.parse_args()
    verify(args.root, args.count)
