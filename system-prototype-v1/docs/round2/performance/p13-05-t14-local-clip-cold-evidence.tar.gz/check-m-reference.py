"""Cross-check the independent T14 text output reconstruction against the sealed M pair."""

from hashlib import sha256
import json
from pathlib import Path
import sys
import tarfile
from tempfile import TemporaryDirectory

from verify_t14_cold import expected_outputs


def read_member(archive, name):
    with archive.extractfile(name) as stream:
        return stream.read()


def verify(archive_path):
    report = {}
    with tarfile.open(archive_path, "r:gz") as archive:
        manifests = set()
        for side in ("base", "candidate"):
            role = f"./t14-split_by_area/{side}"
            attempt = read_member(archive, role + "/COMPLETED").decode("ascii").strip()
            evidence = f"{role}/{attempt}/evidence"
            manifest = read_member(archive, evidence + "/input-M/manifest.json")
            manifests.add(sha256(manifest).hexdigest())
            definition = json.loads(manifest)
            assert definition["tier"] == "M" and definition["family"] == "vector"
            with TemporaryDirectory() as output:
                expected, files = expected_outputs(definition["reference"], Path(output))
            rows = [json.loads(line) for line in read_member(archive, evidence + "/samples.jsonl").splitlines()]
            assert len(rows) == 14 and len({row["run_id"] for row in rows}) == 14
            for row in rows:
                assert row["status"] == "PASS" and row["correctness"] == expected
                assert row["input_manifest_sha256"] == sha256(manifest).hexdigest()
                for key, file in files.items():
                    assert row["artifacts"][key]["fingerprint"] == file["fingerprint"]
            report[side] = {"runs": len(rows), "files": files}
        assert len(manifests) == 1
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    verify(Path(sys.argv[1]))
