from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path, PurePosixPath
import json
import sys
import tarfile

directory, report = (Path(arg) for arg in sys.argv[1:])
archives = (
    "vector-m-revised", "vector-l-point", "vector-l-line", "vector-l-area", "raster-s",
    "remote-s-rerun", "dem-l-pair", "remote-l-pair", "t14-local-clip-pair", "dem-m-retry-pair",
)
raw = []
for name in archives:
    with tarfile.open(directory / f"p13-05-{name}-evidence.tar.gz") as archive:
        for member in archive:
            parts = PurePosixPath(member.name).parts
            if name == "raster-s" and parts[0:1] == ("remote-s",):
                continue
            if len(parts) in (3, 5) and parts[-2:] in (("evidence", "trials.jsonl"), ("evidence", "samples.jsonl")):
                with archive.extractfile(member) as stream:
                    raw.extend(json.loads(line) for line in stream)
assert len(raw) == len({row["run_id"] for row in raw}) == 350
rows = [row for row in raw if row.get("kind", row.get("phase")) == "measurement"]
assert len(rows) == 250
totals = json.loads(report.read_bytes())["unique_measurements"]
assert Counter(row["status"] for row in rows) == totals["benchmark_outcomes"]
states = [row["run_status"] if "run_status" in row else row["run_state"] for row in rows]
assert Counter(f'{state["execution_status"]}/{state["check_status"]}' for state in states) == totals["terminal_outcomes"]
assert sum(bool(row.get("correctness")) for row in rows) == totals["independent_verification_recorded"] == 170
observations = [row for row in rows if isinstance(row.get("error"), dict) and row["error"].get("type") == "StatusObservationFailure"]
assert len(observations) == totals["status_observation_failures"] == 9
assert all(row["status"] == "FAIL" and row["correctness"] and row["run_state"]["check_status"] == "PASSED"
           and row["run_state"]["execution_status"] == "SUCCEEDED" and row["status_poll_errors"] for row in observations)
for resource, coverage in totals["resources"].items():
    assert Counter(row["telemetry"].get("document", row["telemetry"])["resources"][resource]["status"] for row in rows) == coverage
print("Independent aggregate reproduced 350 unique raw rows, 250 measurements, and 9 verified observation failures.")

spec = spec_from_file_location("coverage", directory / "p13-05-resource-coverage.py")
coverage = module_from_spec(spec)
spec.loader.exec_module(coverage)
original = coverage.archive_documents
existing = next(row["run_id"] for row in raw if row.get("family") == "remote_sensing")

def reuse_id(path, cases):
    documents = original(path, cases)
    if path.name == "p13-05-dem-m-retry-pair-evidence.tar.gz":
        member, = (key for key in documents if key[:2] == ("dem-m", "base") and key[-1] == "trials.jsonl")
        lines = documents[member].splitlines(keepends=True)
        row = json.loads(lines[0])
        row["run_id"] = existing
        lines[0] = (json.dumps(row) + "\n").encode()
        documents[member] = b"".join(lines)
    return documents

coverage.archive_documents = reuse_id
try:
    coverage.summarize(directory, include_dem_m=True)
except ValueError as error:
    assert str(error) == "Reused run identity in the DEM M retry pair"
    print("Rejected a DEM M record with a run ID from an earlier sealed remote pair.")
else:
    raise AssertionError("Duplicate run ID was counted")
