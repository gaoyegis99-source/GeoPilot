"""Join the stopped DEM M candidate's raw observations to read-only SQLite copies."""

import hashlib
import json
import math
import re
import shutil
import sqlite3
import sys
from collections import Counter
from contextlib import closing
from pathlib import Path


attempt = Path(sys.argv[1]).resolve(strict=True)
frozen = Path(sys.argv[2]).resolve(strict=True)
output = Path(__file__).resolve().parent
source_hashes = {}
copies = {}


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_source(path):
    content = path.read_bytes()
    source_hashes[str(path.relative_to(attempt))] = hashlib.sha256(content).hexdigest()
    return content


def read_json(path):
    return json.loads(read_source(path))


def host_path(path):
    local = attempt / Path(path).relative_to("/scratch")
    assert local.resolve(strict=True) == local
    return local


def no_sidecars(database):
    assert not any(
        database.with_name(database.name + suffix).exists()
        for suffix in ("-wal", "-shm", "-journal")
    ), database


def sqlite_copy(database):
    if database not in copies:
        no_sidecars(database)
        relative = database.relative_to(attempt)
        checksum = sha(database)
        target = output / "sqlite-copies" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            shutil.copyfile(database, target)
        no_sidecars(database)
        assert checksum == sha(target) == sha(database)
        source_hashes[str(relative)] = checksum
        copies[database] = target
    return copies[database]


def compact_steps(steps):
    return [(step["step_key"], step["status"], step["exit_code"]) for step in steps]


trials = [json.loads(line) for line in read_source(attempt / "evidence/trials.jsonl").splitlines()]
report = read_json(attempt / "evidence/report.json")
runtime = read_json(attempt / "evidence/runtime-configuration.json")
comparison = read_json(attempt / "self-comparison.json")
report_exit = int(read_source(attempt / "exit-code"))
comparison_exit = int(read_source(attempt / "self-comparison.exit-code"))
read_source(attempt / "command.log")
read_source(attempt / "container.log")
assert report["environment"]["commit"] == "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
assert (report["status"], report_exit) == ("FAIL", 1)
assert comparison_exit == 0 and comparison["same_source"] and not comparison["candidate_all_measurements_pass"]
assert len(trials) == len({row["run_id"] for row in trials}) == 14

executed_scripts = {}
for filename, expected in sorted(report["implementation_sha256"].items()):
    observed = sha(frozen / "scripts/bench" / filename)
    assert observed == expected
    executed_scripts[filename] = observed

counts = Counter()
rows = []
database_run_ids = {}
for trial in trials:
    cache, index, kind = trial["cache"], trial["index"], trial["kind"]
    sample = attempt / "evidence/samples/M/method" / cache / f"{index:02d}-{kind}"
    exact = read_json(sample / "trial.json")
    assert all(trial.get(field) == exact.get(field) for field in (
        "sample_id", "run_id", "workspace", "status", "exit_code", "error", "run_state",
        "status_poll_errors", "executed_steps", "v1_completed_checks", "correctness",
    )), trial["sample_id"]
    workdir = host_path(trial["workspace"])
    assert workdir.name == trial["run_id"] and workdir.parents[1].name == trial["task_id"]
    database = workdir.parents[4] / "project.sqlite"
    worker_log = host_path(trial["worker_log"])
    assert worker_log.parent == database.parent
    worker_log_bytes = len(read_source(worker_log))
    copied = sqlite_copy(database)
    with closing(sqlite3.connect(copied.as_uri() + "?mode=ro&immutable=1", uri=True)) as db:
        db.row_factory = sqlite3.Row
        if database not in database_run_ids:
            assert db.execute("PRAGMA quick_check").fetchall()[0][0] == "ok", database
            assert not db.execute("PRAGMA foreign_key_check").fetchall(), database
            database_run_ids[database] = {item["id"] for item in db.execute("SELECT id FROM run")}
        run = db.execute("SELECT * FROM run WHERE id = ?", (trial["run_id"],)).fetchone()
        assert (run["id"], run["plan_id"], run["plan_version"], run["workdir"]) == (
            trial["run_id"], trial["plan_id"], trial["plan_version"], trial["workspace"],
        )
        plan = db.execute(
            "SELECT task_id, status FROM analysis_plan WHERE id = ? AND version = ?",
            (run["plan_id"], run["plan_version"]),
        ).fetchone()
        assert (plan["task_id"], plan["status"]) == (trial["task_id"], "confirmed")
        state = {
            "run_id": run["id"], "execution_status": run["execution_status"], "check_status": run["check_status"],
            "current_step": run["current_step"], "cancel_requested": bool(run["cancel_requested"]),
            "error": None if run["error_json"] is None else json.loads(run["error_json"]),
            "current_report_id": run["current_report_id"],
        }
        assert state == trial["run_state"], trial["sample_id"]
        assert (state["execution_status"], state["check_status"], state["cancel_requested"], state["error"]) == (
            "SUCCEEDED", "PASSED", False, None,
        )
        db_steps = db.execute(
            "SELECT step_key, status, result_json, log_path FROM run_step WHERE run_id = ? ORDER BY position",
            (run["id"],),
        ).fetchall()
        saved_steps = []
        for step in db_steps:
            result = json.loads(step["result_json"])
            assert (result["run_id"], result["step_key"], result["status"], result["error"]) == (
                run["id"], step["step_key"], step["status"], None,
            )
            assert step["status"] == "SUCCEEDED" and result["exit_code"] == 0
            saved_steps.append((step["step_key"], step["status"], result["exit_code"]))
            if trial["status"] == "FAIL":
                log = workdir / step["log_path"]
                disk = read_json(log.with_name("result.json"))
                assert (disk["run_id"], disk["step_key"], disk["status"], disk["exit_code"], disk["error"]) == (
                    run["id"], step["step_key"], "SUCCEEDED", 0, None,
                )
                assert re.findall(rb"(?m)^exit_code: (-?[0-9]+)$", read_source(log)) == [b"0"], log
        assert len(saved_steps) == 7 and saved_steps == compact_steps(trial["executed_steps"])
        checked = db.execute(
            "SELECT status, report_json FROM check_report WHERE id = ? AND run_id = ?",
            (run["current_report_id"], run["id"]),
        ).fetchone()
        checks = json.loads(checked["report_json"])
        assert checked["status"] == "PASSED"
        assert read_json(workdir / "checks/report.json") == checks
        assert checks["completed_rules"] == trial["v1_completed_checks"] and len(checks["completed_rules"]) == 3
        assert all(rule["passed"] is True for rule in checks["rules"].values())
        assert checks["interruption"] is None
        disk_manifest = read_json(workdir / "outputs/manifest.json")["artifacts"]
        saved_manifest = {
            item["role"]: {"path": item["uri"], "layer": item["layer"], "type": item["type"],
                           "fingerprint": item["fingerprint"]}
            for item in db.execute("SELECT role, uri, layer, type, fingerprint FROM artifact WHERE run_id = ?", (run["id"],))
        }
        assert len(saved_manifest) == 3 and disk_manifest == saved_manifest

    errors = trial.get("status_poll_errors", [])
    if errors:
        assert trial["status"] == "FAIL" and trial["exit_code"] == 0
        assert trial["error"]["type"] == "StatusObservationFailure"
        assert all(event == {"http_status": 500, "body": {"detail": {
            "code": "STORAGE_FAILED", "message": "Could not read the run record.",
        }}} for event in errors)
    else:
        assert trial["status"] == "PASS" and trial["exit_code"] == 0
    correctness = trial["correctness"]
    raster_max_errors = {
        name: value["maximum_absolute_error"]
        for name, value in correctness.items() if "maximum_absolute_error" in value
    }
    assert set(raster_max_errors) == {"terrain_raster", "threshold_regions"} and all(value == 0 for value in raster_max_errors.values())
    area = correctness["area_statistics"]
    classes = area["observed"]["classes"]
    assert [(item["class_id"], item["pixel_count"]) for item in classes] == [(7, 4_183_812)]
    assert area["observed"]["nodata_pixel_count"] == 2_304
    class_area_errors = {
        str(item["class_id"]): abs(item["area_m2"] - area["expected_area_by_class_m2"][str(item["class_id"])])
        for item in classes
    }
    assert all(value < area["absolute_tolerance_m2"] for value in class_area_errors.values())
    expected_total = math.fsum(area["expected_area_by_class_m2"].values())
    counts[(cache, kind, trial["status"])] += 1
    rows.append({
        "sample": trial["sample_id"], "raw_status": trial["status"], "status_poll_errors": errors,
        "trial_error": trial.get("error"), "trial_exit_code": trial["exit_code"],
        "worker_exit_code": trial.get("worker_exit_code"), "worker_log_bytes": worker_log_bytes,
        "wall_ns_as_recorded_not_reclassified": trial["wall_ns"], "sqlite_state": state,
        "database": str(database.relative_to(attempt)), "saved_steps": saved_steps,
        "formal_artifacts": len(saved_manifest), "v1_checks": checks["completed_rules"],
        "saved_independent_validation": {
            "pixel_counts": [item["pixel_count"] for item in classes],
            "nodata_pixel_count": area["observed"]["nodata_pixel_count"],
            "raster_max_errors": raster_max_errors,
            "class_area_absolute_errors_m2": class_area_errors,
            "total_area_absolute_error_m2": abs(area["observed"]["total_area_m2"] - expected_total),
        },
    })

assert len(copies) == 8
assert {item["sqlite_state"]["run_id"] for item in rows} == set().union(*database_run_ids.values())
assert sum(len(item["status_poll_errors"]) for item in rows) == 6
assert {item["sample"] for item in rows if item["raw_status"] == "FAIL"} == {
    "raster/M/method/warm/01", "raster/M/method/warm/02", "raster/M/method/warm/07",
}
assert all(sha(attempt / path) == expected for path, expected in source_hashes.items())
print(json.dumps({
    "attempt": str(attempt),
    "executed_source": report["environment"]["commit"],
    "checked_frozen_bench_scripts": executed_scripts,
    "runtime_configuration_keys": sorted(runtime),
    "sqlite_version": sqlite3.sqlite_version,
    "report": {"status": report["status"], "exit_code": report_exit},
    "self_comparison": {"status": comparison["status"], "exit_code": comparison_exit,
                        "candidate_all_measurements_pass": comparison["candidate_all_measurements_pass"]},
    "counts": [{"cache": cache, "kind": kind, "raw_status": status, "count": count}
               for (cache, kind, status), count in sorted(counts.items())],
    "sqlite_databases": len(copies),
    "sqlite_run_count": sum(len(ids) for ids in database_run_ids.values()),
    "source_sha256_before_and_after": dict(sorted(source_hashes.items())),
    "trials": rows,
}, ensure_ascii=False, indent=2, sort_keys=True))
