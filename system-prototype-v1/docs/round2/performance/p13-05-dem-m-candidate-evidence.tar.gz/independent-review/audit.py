"""Read-only independent completed DEM M candidate audit."""

from collections import Counter
from hashlib import sha256
import json
import math
import re
from pathlib import Path
import shlex
from statistics import median
import sys


REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
ROOT = REPO / "artifacts/test-results/p13-05-raster-pairs.a2d2e68.after-vector-l"
ARCHIVE = REPO / "docs/round2/performance"
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
CANDIDATE = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
TIER = "M"
CASES = {"dem-m": ("raster", "raster-method-m", {"7": 4183812}, 2304, 7)}
CACHES = ("process_cold", "warm")
METRICS = ("wall_ns", "peak_rss_bytes", "peak_temp_bytes")
PASS = {"PASS": 5, "FAIL": 0, "NOT_RUN": 0}
RUNNER = {
    "run_raster.py": "9a4a9bc061d770c1fce631895bff25f819751e5a98291440f231e5ed267a3729",
    "_raster_metrics.py": "d23eb107cd1ec19eb040ca391831d8028c4523ff783f09314fdc22e05057722e",
    "_raster_reference.py": "eb54e29bbee34e05952e699e4c9b4bc99f3f342ece30773280836eec02cb19a3",
    "_raster_workloads.py": "fa6bc12a43c93487c8159feb7fdf3529ac21b0bc0acaf436fe7a73591b54dd8d",
}
IMAGE = "sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87"


def read(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream]


def digest(raw):
    return sha256(raw).hexdigest()


def stats(values):
    ordered = sorted(values)
    return {"median": median(ordered), "p95_nearest_rank": ordered[math.ceil(.95 * len(ordered)) - 1]} if len(ordered) >= 3 else None


def dist(items):
    values = [i["value"] for i in items if i.get("value") is not None]
    return {
        "samples": len(values), "partial": sum(i.get("status") == "partial" and i.get("value") is not None for i in items),
        **(stats(values) or {"median": None, "p95_nearest_rank": None}),
    }


def independent_reference():
    frozen = read(ARCHIVE / "p13-04-dem-m-classification-source.json")
    area_report = (ARCHIVE / "p13-04.md").read_text()
    match = re.search(r"类别 7 的 EPSG:6933 面积参考值为 ([0-9,.]+) m²", area_report)
    assert match
    area = float(match[1].replace(",", ""))
    assert (frozen["shape"], frozen["valid_class_counts"], frozen["masked_pixels"]) == ([2046, 2046], {"7": 4183812}, 2304)
    return frozen, area


def area_check(observed, fixture, frozen, independent_area):
    assert set(observed) == {"terrain_raster", "threshold_regions", "area_statistics"}
    assert fixture["shape"] == [2048, 2048] and fixture["pixels"] == 2048**2
    assert fixture["slope_degrees"] == 45 and fixture["input_nodata_pixels"] == 256
    assert fixture["analysis_extent"]["shape"] == frozen["shape"]
    assert fixture["analysis_extent"]["transform"] == frozen["transform"]
    masked = fixture["input_nodata_pixels"] * 9
    valid = math.prod(frozen["shape"]) - masked
    assert (valid, masked) == (frozen["valid_class_counts"]["7"], frozen["masked_pixels"])
    assert (fixture["valid_terrain_pixels"], fixture["terrain_nodata_pixels"]) == (valid, masked)

    for name, dtype, band_name, unit, nodata, tolerance in (
        ("terrain_raster", "float32", "terrain", "degree", -9999.0, 1e-5),
        ("threshold_regions", "uint8", "threshold_class", "class", 255.0, 0),
    ):
        artifact = observed[name]
        assert (artifact["height"], artifact["width"]) == tuple(frozen["shape"])
        assert artifact["bands"] == 1 and artifact["crs"] == frozen["crs"]
        assert artifact["transform"] == frozen["transform"] and artifact["block_shapes"] == frozen["blocks"]
        assert (artifact["dtypes"], artifact["band_names"], artifact["band_units"], artifact["nodata"]) == (
            [dtype], [band_name], [unit], [nodata],
        )
        assert artifact["valid_pixels_by_band"] == [valid] and artifact["masked_pixels_by_band"] == [masked]
        assert artifact["maximum_absolute_error"] == 0 and artifact["absolute_tolerance"] == tolerance

    area = observed["area_statistics"]
    actual = area["observed"]
    assert (actual["source_crs"], actual["area_crs"], actual["area_method"], actual["area_unit"],
            actual["cell_area_method"], actual["resampling"]) == (
        frozen["crs"], "EPSG:6933", "equal_area", "square_meter", "projected_cell_boundary", "none",
    )
    assert (actual["valid_pixel_count"], actual["selected_pixel_count"], actual["unselected_pixel_count"],
            actual["nodata_pixel_count"]) == (valid, valid, 0, masked)
    class_record, = actual["classes"]
    assert class_record["class_id"] == 7 and class_record["pixel_count"] == valid
    observed_area = class_record["area_m2"]
    assert observed_area == actual["total_area_m2"]
    rel, abs_ = area["relative_tolerance"], area["absolute_tolerance_m2"]
    assert (rel, abs_) == (2e-7, .02)
    runner_reference = area["expected_area_by_class_m2"]["7"]
    assert math.isclose(runner_reference, independent_area, rel_tol=0, abs_tol=2e-6)
    assert math.isclose(observed_area, independent_area, rel_tol=rel, abs_tol=abs_)
    convergence = actual["boundary_convergence"]
    assert convergence == {"absolute_tolerance_m2": 1e-6, "relative_tolerance": 1e-8, "max_segments_per_edge_used": 8}
    return {
        "source_grid": fixture["shape"], "classified_grid": frozen["shape"], "valid_class_counts": {"7": valid},
        "masked_pixels": masked, "maximum_terrain_pixel_error": observed["terrain_raster"]["maximum_absolute_error"],
        "maximum_class_error": observed["threshold_regions"]["maximum_absolute_error"],
        "observed_area_m2": observed_area, "independent_area_m2": independent_area,
        "absolute_area_difference_m2": abs(observed_area - independent_area),
        "runner_reference_area_m2": runner_reference, "tolerances": {"relative": rel, "absolute_m2": abs_},
        "area_boundary_convergence": convergence,
    }


def historic_evidence(case):
    _, historic_name, _, _, _ = CASES[case]
    archive_report = read(ARCHIVE / f"p13-04-{historic_name}-report.json")
    archive_trials = ARCHIVE / f"p13-04-{historic_name}-trials.jsonl"
    return archive_report, next(row for row in jsonl(archive_trials) if row["tier"] == TIER)


def trial_identity(row, case, manifest, historic):
    family = CASES[case][0]
    index = row["index"]
    assert row["sample_id"] == f"{family}/{TIER}/method/{row['cache']}/{index:02d}"
    assert (row["family"], row["tier"], row["workload"], row["kind"], row["manifest_sha256"]) == (
        family, TIER, "method", "warmup" if index <= 2 else "measurement", manifest,
    )
    assert row["method"] == historic["method"] and row["critical_options"] == historic["critical_options"]
    assert row["parameters_sha256"] == digest(json.dumps(
        row["confirmed_parameters"], sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode())
    assert row["run_state"]["run_id"] == row["run_id"]


def completed_output(row, historic, case, fixture, frozen, independent_area):
    family, _, class_counts, nodata, nsteps = CASES[case]
    state, sidecar = row["run_state"], row["telemetry"]
    assert row["exit_code"] == 0
    assert (state["execution_status"], state["check_status"]) == ("SUCCEEDED", "PASSED")
    assert state["current_report_id"] and not state["error"] and not state["cancel_requested"]
    assert (sidecar["run_id"], sidecar["execution_status"], sidecar["check_status"], sidecar["exit_code"]) == (
        row["run_id"], "SUCCEEDED", "PASSED", 0,
    )
    steps = row["executed_steps"]
    assert len(steps) == len(sidecar["steps"]) == nsteps and len({s["step_key"] for s in steps}) == nsteps
    for raw, event in zip(steps, sidecar["steps"]):
        assert raw["status"] == event["status"] == "SUCCEEDED" and raw["exit_code"] == event["exit_code"] == 0
        assert raw["step_key"] == event["step_key"]
        assert raw["tool"] == {key: event["tool"][key] for key in ("id", "version")}
        assert isinstance(raw["parameters"], dict)
    assert [s["step_key"] for s in steps] == [s["step_key"] for s in historic["telemetry"]["steps"]]
    assert [(s["tool"]["id"], s["tool"]["version"]) for s in steps] == [
        (s["tool"]["id"], s["tool"]["version"]) for s in historic["telemetry"]["steps"]
    ]
    assert row["v1_completed_checks"] == ["dem_covers_expanded_extent", "units_resolved", "border_pixels_match_reference"]
    threshold = {"intervals": [{"class_id": 7, "lower": 45, "upper": 45, "include_lower": True, "include_upper": True}]}
    assert row["confirmed_parameters"] == {
        "terrain_output": "slope", "slope_unit": "degree", "area_crs": "EPSG:6933", "threshold": threshold,
        "band": 1, "vertical_unit": "metadata", "z_factor": 1.0,
    } == historic["confirmed_parameters"]
    assert [s["parameters"] for s in steps] == [
        {"radius_pixels": 1}, {}, {"band": 1, "vertical_unit": "metadata", "z_factor": 1.0},
        {"band": 1, "z_factor": 1.0, "terrain_output": "slope", "slope_unit": "degree"},
        {}, {"threshold": threshold}, {"area_crs": "EPSG:6933"},
    ]
    settings = {key: row[key] for key in ("method", "critical_options", "confirmed_parameters", "executed_steps")}
    area = area_check(row["correctness"], fixture, frozen, independent_area)
    return settings, area


def environment_check(path, report):
    assert report["implementation_sha256"] == RUNNER
    storage = report["environment"]["storage"]["mount_source_and_filesystem"]
    assert re.sub(r"\[.*\]", "", storage) == "/dev/sda2 ext4"
    command = path.parent / "command.log"
    assert IMAGE in shlex.split(command.read_text().splitlines()[1])


CASE = "dem-m"
ATTEMPT = ROOT / CASE / "candidate/attempt.f0puyhqd"
SELF = ATTEMPT / "self-comparison.json"
PRIOR = Path("/tmp/geopilot-p13-05-raster-s-audit.rJKuNw/independent.json")
PRIOR_SHA = "f6c4e2d81e0d269b154a5640c7aa71a4636472174bb841e86290c59c630c437b"
RESOURCES = ("cpu_ns", "peak_rss_bytes", "disk_read_bytes", "disk_write_bytes")
STATUS_READ_ERROR = {
    "http_status": 500, "body": {"detail": {"code": "STORAGE_FAILED", "message": "Could not read the run record."}},
}


def observation(value):
    return {"status": "recorded" if value is not None else "unavailable", "value": value}


def summary(items):
    return {
        **dist(items), "coverage": dict(Counter(item["status"] for item in items)),
        "observed_values": [item["value"] for item in items],
    }


def columns(row):
    sidecar = row["telemetry"]
    return {
        "wall_ns": observation(row["wall_ns"]), "queue_wall_ns": sidecar["queue_wall_ns"],
        "execute_steps_wall_ns": observation(sidecar["execute_steps_wall_ns"]),
        "finalize_wall_ns": observation(sidecar["finalize_wall_ns"]),
        **sidecar["resources"], "peak_temp_bytes": row["workspace_size"]["peak_temp_bytes"],
    }


def validate_side(path, commit):
    archive_report, historic = historic_evidence(CASE)
    report_file = path / "report.json"
    report = read(report_file)
    environment_check(path, report)
    receipt = read(path / "runtime-configuration.json")
    assert report["mode"] == "formal" and not report.get("error")
    assert report["environment"]["commit"] == commit and report["family"] == "raster"
    assert (path.parent / "self-comparison.exit-code").read_text().strip() == "0"
    assert (path.parent.parent / "COMPLETED").read_text().strip() == path.parent.name
    container_exit = int((path.parent / "exit-code").read_text())
    assert receipt["schema_version"] == 1 and receipt["report_files"] == {"report.json": digest(report_file.read_bytes())}
    snapshot = receipt["before"]
    assert snapshot == receipt["after"]
    assert snapshot["sha256"] == digest(json.dumps(
        {key: value for key, value in snapshot.items() if key != "sha256"}, ensure_ascii=True,
        sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode("ascii"))
    current, old = report["inputs"][TIER], archive_report["inputs"][TIER]
    assert set(report["inputs"]) == {TIER} and current["directory"] == f"/inputs/{TIER}" and current["generation_ns"] is None
    assert current["manifest_sha256"] == old["manifest_sha256"]
    assert current["first_fingerprints"] == current["last_fingerprints"] == old["first_fingerprints"] == old["last_fingerprints"]

    frozen, independent_area = independent_reference()
    assert current["manifest_sha256"] == frozen["fixture_manifest_sha256"]
    assert current["reference"] == old["reference"]
    trials_file = path / "trials.jsonl"
    rows = jsonl(trials_file)
    assert len(rows) == len({row["run_id"] for row in rows}) == 14
    assert [(row["cache"], row["index"]) for row in rows] == [(cache, i) for cache in CACHES for i in range(1, 8)]
    for key in ("task_id", "plan_id", "workspace"):
        assert len({row[key] for row in rows}) == 14
    assert container_exit == int(any(row["status"] == "FAIL" for row in rows))
    assert report["status"] == ("FAIL" if container_exit else "PASS")
    areas, settings, evidence = [], [], []
    for row in rows:
        trial_identity(row, CASE, current["manifest_sha256"], historic)
        assert row.get("worker_exit_code") == (0 if row["cache"] == "process_cold" else None)
        errors = row.get("status_poll_errors", [])
        assert all(error == STATUS_READ_ERROR for error in errors)
        assert row["status"] == ("FAIL" if errors else "PASS")
        if errors:
            assert row["error"] == {
                "type": "StatusObservationFailure",
                "message": "Execution reached terminal state after an HTTP status-read error",
            }
        else:
            assert not row.get("error")
        options, area = completed_output(row, historic, CASE, current["reference"], frozen, independent_area)
        settings.append(options)
        areas.append(area)
        assert row["pixels"] == 2048**2
        assert math.isclose(row["pixels_per_second"], row["pixels"] * 1e9 / row["wall_ns"], rel_tol=1e-14)
        evidence.append({
            "sample_id": row["sample_id"], "cache": row["cache"], "kind": row["kind"], "run_id": row["run_id"],
            "task_id": row["task_id"], "plan_id": row["plan_id"], "status": row["status"],
            "status_poll_errors": errors, "worker_pid": row["worker_pid"],
            "run_status": row["run_state"], "step_exit_codes": [step["exit_code"] for step in row["executed_steps"]],
            "parameters_sha256": row["parameters_sha256"], "correctness": area, "readings": columns(row),
        })
    assert all(item == settings[0] for item in settings)
    assert all(item == areas[0] for item in areas)

    groups = {}
    planned = [{"tier": TIER, "workload": "method", "cache": cache} for cache in CACHES]
    assert report["expected_groups"] == planned and len(report["groups"]) == 2
    for cache in CACHES:
        raw = [row for row in rows if row["cache"] == cache]
        assert len({row["worker_pid"] for row in raw}) == (7 if cache == "process_cold" else 1)
        measured = [row for row in raw if row["kind"] == "measurement"]
        warmups = [row for row in raw if row["kind"] == "warmup"]
        assert len(measured) == 5 and len(warmups) == 2
        group = next(group for group in report["groups"] if group["cache"] == cache)
        assert (group["tier"], group["workload"], group["expected_trials"], group["observed_trials"]) == (TIER, "method", 7, 7)
        assert group["trial_failures"] == sum(row["status"] == "FAIL" for row in raw)
        assert not group["interrupted"] and group["warm_worker_exit"] == (0 if cache == "warm" else None)
        assert group["input_fingerprints_before"] == group["input_fingerprints_after"] == current["first_fingerprints"]
        counts = Counter(row["status"] for row in measured)
        failures = Counter(row["error"]["type"] for row in measured if row["status"] == "FAIL")
        aggregate = group["operations"]["method"]
        assert (aggregate["passed"], aggregate["failed"], aggregate["missing"]) == (counts["PASS"], counts["FAIL"], 0)
        passing = [row for row in measured if row["status"] == "PASS"]
        assert aggregate.get("wall_ns") == stats([row["wall_ns"] for row in passing])
        assert aggregate.get("pixels_per_second") == stats([row["pixels_per_second"] for row in passing])
        sampled = [row["telemetry"]["resources"]["peak_rss_bytes"]["value"] for row in passing
                   if row["telemetry"]["resources"]["peak_rss_bytes"]["status"] == "sampled"]
        assert aggregate.get("sampled_peak_rss_count") == len(sampled)
        assert aggregate.get("peak_rss_bytes") == stats(sampled)

        by_status = {}
        for status in ("PASS", "FAIL"):
            subset = [row for row in measured if row["status"] == status]
            records = [columns(row) for row in subset]
            metrics = ("wall_ns", "queue_wall_ns", "execute_steps_wall_ns", "finalize_wall_ns", *RESOURCES, "peak_temp_bytes")
            result = {field: summary([record[field] for record in records]) for field in metrics}
            result["steps"] = {}
            for i, step in enumerate(settings[0]["executed_steps"]):
                events = [row["telemetry"]["steps"][i] for row in subset]
                result["steps"][step["step_key"]] = {
                    "wall_ns": summary([observation(event["wall_ns"]) for event in events]),
                    "peak_rss_bytes": summary([event["resources"]["peak_rss_bytes"] for event in events]),
                }
            by_status[status] = result
        groups[cache] = {
            "warmup_counts": dict(Counter(row["status"] for row in warmups)),
            "measurement_counts": {status: counts[status] for status in ("PASS", "FAIL", "NOT_RUN")},
            "measurement_failure_types": dict(failures), "distribution": by_status,
        }
    return {
        "evidence": str(path), "container_exit": container_exit, "report_status": report["status"], "receipt": snapshot["sha256"],
        "input_manifest_sha256": current["manifest_sha256"], "settings": settings[0], "area": areas[0],
        "files": {item.name: digest(item.read_bytes()) for item in (report_file, trials_file, path / "runtime-configuration.json")},
        "groups": groups, "observations": evidence, "status_poll_errors": sum(len(item["status_poll_errors"]) for item in evidence),
    }


REMOTE = Path("/tmp/geopilot-p13-05-remote-s-after-vector-l-audit.Gbk18m/independent.json")
REMOTE_SHA = "cbb29456d9657978bdd4a59d60f0debdedc7bcb91a38efc5b6a0f08f85c2892b"


def check_self(report, side):
    assert (report["status"], report["before_source"], report["after_source"],
            report["same_source"], report["candidate_all_measurements_pass"]) == (
        "MATCHED_EVIDENCE", CANDIDATE, CANDIDATE, True, False,
    )
    assert report["runtime_configuration"] == {
        "level": "application_config_and_python_proj", "schema_version": 1, "sha256": side["receipt"],
    }
    assert len(report["groups"]) == 2 and {group["group"][2] for group in report["groups"]} == set(CACHES)
    fields = ("samples", "partial", "median", "p95_nearest_rank")
    for group in report["groups"]:
        cache = group["group"][2]
        assert group["group"] == [TIER, "method", cache, "p13-01", "method"]
        assert group["step_parameter_evidence"] == "normalized_step_requests"
        observed = group["before"]
        expected = side["groups"][cache]
        assert observed == group["after"] and observed["counts"] == expected["measurement_counts"]
        nfail = expected["measurement_counts"]["FAIL"]
        assert observed["failure_codes"] == ({"unspecified": nfail} if nfail else {})
        for metric in METRICS:
            for status in ("PASS", "FAIL"):
                assert observed[metric][status] == {f: expected["distribution"][status][metric][f] for f in fields}
        delta = {}
        for metric in METRICS:
            reading = observed[metric]["PASS"]
            if reading["samples"] == expected["measurement_counts"]["PASS"] >= 3 and reading["partial"] == 0:
                delta[metric] = {"median": 0, "p95_nearest_rank": 0}
        assert group["successful_sample_deltas"] == delta


def check_previous_ids(current):
    assert digest(PRIOR.read_bytes()) == PRIOR_SHA and digest(REMOTE.read_bytes()) == REMOTE_SHA
    first = [rid for case in read(PRIOR).values() for side in ("base", "candidate") for rid in case[side]["run_ids"]]
    remote_report = read(REMOTE)
    later = [row["run_id"] for side in ("base", "candidate") for row in remote_report[side]["observations"]]
    files = [ARCHIVE / f"p13-04-{kind}-method-{size}-trials.jsonl"
             for kind, size in (("raster", "s"), ("raster", "m"), ("raster", "l"), ("remote", "sm"), ("remote", "l"))]
    historical = [row["run_id"] for file in files for row in jsonl(file)]
    assert (len(first), len(later), len(historical)) == (47, 28, 84)
    all_ids = first + later + historical + current
    assert len(all_ids) == len(set(all_ids)) == 173
    return {"first_raster_round": 47, "remote_s_rerun": 28, "historical_p13_04_methods": 84,
            "current": len(current), "combined_unique": len(all_ids)}


def main(output):
    assert ATTEMPT.parent.joinpath("COMPLETED").read_text().strip() == ATTEMPT.name
    assert SELF.with_name("self-comparison.stderr").read_bytes() == b""
    command = shlex.split(SELF.with_name("self-comparison.command").read_text())
    assert "--require-runtime-configuration" in command
    assert all(Path(command[command.index(f"--{side}") + 1]) == ATTEMPT / "evidence" for side in ("before", "after"))
    result = validate_side(ATTEMPT / "evidence", CANDIDATE)
    assert result["container_exit"] == 1 and result["status_poll_errors"] == 6
    assert result["groups"]["process_cold"]["measurement_counts"] == {"PASS": 5, "FAIL": 0, "NOT_RUN": 0}
    assert result["groups"]["warm"]["measurement_counts"] == {"PASS": 4, "FAIL": 1, "NOT_RUN": 0}
    assert result["groups"]["process_cold"]["warmup_counts"] == {"PASS": 2}
    assert result["groups"]["warm"]["warmup_counts"] == {"FAIL": 2}
    plan = read(ROOT / "plan.json")
    assert plan["commits"]["candidate"] == CANDIDATE
    assert plan["image"] == IMAGE and plan["disk"][:2] == ["/dev/sda2", "ext4"]
    assert result["input_manifest_sha256"] == plan["input_manifest_sha256"][CASE]
    self_result = read(SELF)
    check_self(self_result, result)
    id_counts = check_previous_ids([row["run_id"] for row in result["observations"]])
    output.write_text(json.dumps({
        "scope": "candidate only", "self_comparison": str(SELF), "self_comparison_sha256": digest(SELF.read_bytes()),
        "self_comparison_status": self_result["status"], "run_identity_checks": id_counts, "candidate": result,
    }, indent=2) + "\n", encoding="utf-8")
    print("candidate container exit", result["container_exit"], "self-comparison exit 0", result["receipt"])
    for row in result["observations"]:
        if row["status_poll_errors"]:
            print("observation failure", row["sample_id"], row["run_id"], len(row["status_poll_errors"]),
                  row["run_status"]["execution_status"], row["run_status"]["check_status"], row["step_exit_codes"])
    for cache, group in result["groups"].items():
        print(cache, "warmups", group["warmup_counts"], "formal", group["measurement_counts"])
        for status in ("PASS", "FAIL"):
            d = group["distribution"][status]
            print(status, "wall ns", d["wall_ns"], "RSS bytes", d["peak_rss_bytes"], "temp bytes", d["peak_temp_bytes"])
        d = group["distribution"]["PASS"]["steps"]["calculate_area_with_equal_area_projection"]
        print(cache, "successful area step", d)
    print("independent classification and area", result["area"])
    print("run identity disjoint", id_counts)


if __name__ == "__main__":
    main(Path(sys.argv[1]))
