import errno
import json
import os
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

import pytest

from geopilot.domain.step_io import ExecutionStatus, StepRequest
from geopilot.execution import output_staging as staging
from geopilot.execution.process_manager import capture_process
from geopilot.execution.step_support import output_staging_receipt_path
from geopilot.execution.worker_lease import exclusive_local_lock, managed_workers_stopped, worker_lease
from geopilot.persistence.run_repository import get_run, get_run_step, insert_run, save_run_step
from geopilot.persistence.schema import initialize_database, open_database
from geopilot.runs.models import Run, RunStep
from geopilot.scheduler import loop


WORKER = "from pathlib import Path; Path('worker-launched').touch()"
TARGETS = ("outputs", "intermediate")
LOOKALIKE = ".python-output-" + "f" * 32


@pytest.fixture
def fixture(tmp_path):
    work = tmp_path / "run"
    for folder in (*TARGETS, "steps/example", f"intermediate/{LOOKALIKE}"):
        (work / folder).mkdir(parents=True, exist_ok=True)
    (work / "outputs/published.json").write_bytes(b"published")
    (work / f"intermediate/{LOOKALIKE}/marker").write_bytes(b"unowned")
    request = StepRequest(
        run_id="run", step_key="example", tool={"id": "python-probe", "version": 1}, workdir_ref="run",
        inputs={}, parameters={}, output_targets={"first": {"path": "outputs/one.json"},
                                                  "second": {"path": "intermediate/two.json"}},
        log_path="steps/example/process.log", cancel_path="cancel.flag",
    )
    request = request.model_dump(mode="json")
    receipt = output_staging_receipt_path(work, request)
    return work, request, receipt


def execute(work, request):
    return capture_process([sys.executable, "-c", WORKER], cwd=work, timeout=3,
                           env_context=staging.owned_output_staging(work, request, os.environ))


def test_control_child_launches_and_leased_staging_is_removed(fixture):
    work, request, receipt = fixture
    assert execute(work, request).exit_code == 0
    assert (work / "worker-launched").is_file() and managed_workers_stopped(work)
    assert not directory_records(work) and not receipt.exists()
    assert_sentinels(work)


def directory_records(work):
    return {path.relative_to(work).as_posix(): [path.stat().st_dev, path.stat().st_ino, sorted(p.name for p in path.iterdir())]
            for folder in TARGETS for path in (work / folder).glob(".python-output-*") if path.name != LOOKALIKE}


def assert_sentinels(work):
    assert (work / "outputs/published.json").read_bytes() == b"published"
    assert (work / f"intermediate/{LOOKALIKE}/marker").read_bytes() == b"unowned"
    assert not (work / "outputs/one.json").exists()
    assert not (work / "intermediate/two.json").exists()


def check_prelaunch(work, request):
    assert not (work / "worker-launched").exists()
    assert not managed_workers_stopped(work)
    assert len(directory_records(work)) == len(TARGETS)
    assert_sentinels(work)


def fail_receipt(monkeypatch, fixture, fault):
    work, request, receipt = fixture
    original_open = staging.os.open

    def open_receipt(path, flags, *args, **kwargs):
        if path == receipt.name and flags & os.O_EXCL:
            check_prelaunch(work, request)
            raise OSError(errno.ENOSPC, "injected receipt open failure")
        return original_open(path, flags, *args, **kwargs)

    def write_partial(records, stream):
        check_prelaunch(work, request)
        assert len(records) == len(TARGETS)
        stream.write("[")
        stream.flush()
        raise OSError(errno.ENOSPC, "injected partial receipt write")

    def fail_fsync(fd):
        check_prelaunch(work, request)
        assert len(json.loads(receipt.read_bytes())) == len(TARGETS)
        raise OSError(errno.EIO, "injected receipt fsync failure")

    if fault == "open":
        monkeypatch.setattr(staging.os, "open", open_receipt)
    elif fault == "partial":
        monkeypatch.setattr(staging.json, "dump", write_partial)
    else:
        assert fault == "fsync"
        monkeypatch.setattr(staging.os, "fsync", fail_fsync)


@pytest.mark.parametrize("fault", ["open", "partial", "fsync"])
def test_receipt_failure_before_spawn_cleans_owned_directories(fixture, monkeypatch, fault):
    work, request, receipt = fixture
    with monkeypatch.context() as patched:
        fail_receipt(patched, fixture, fault)
        with pytest.raises(OSError, match="injected"):
            execute(work, request)
    assert not directory_records(work) and not receipt.exists()
    assert not (work / "worker-launched").exists() and managed_workers_stopped(work)
    assert_sentinels(work)
    print(json.dumps({"fault": fault, "remaining_directories": [], "receipt": False, "child": False}))


@pytest.mark.parametrize("fault,can_recover", [("open", False), ("partial", False), ("fsync", True)])
def test_receipt_fault_and_busy_cleanup(fixture, monkeypatch, fault, can_recover):
    work, request, receipt = fixture

    def busy(*args, **kwargs):
        raise OSError(errno.EBUSY, "injected persistent cleanup refusal")

    with monkeypatch.context() as patched:
        patched.setattr(staging, "rmtree", busy)
        fail_receipt(patched, fixture, fault)
        with pytest.raises(OSError, match="injected"):
            execute(work, request)
    remaining = directory_records(work)
    assert len(remaining) == 2 and all(not v[-1] for v in remaining.values())
    assert not (work / "worker-launched").exists() and managed_workers_stopped(work)
    receipt_text = receipt.read_text() if receipt.exists() else None
    if fault == "partial":
        assert receipt_text == "["
        with worker_lease(work), pytest.raises(json.JSONDecodeError):
            staging.recover_output_staging(work, request)
    elif fault == "open":
        assert receipt_text is None
        with worker_lease(work):
            staging.recover_output_staging(work, request)
    else:
        assert len(json.loads(receipt_text)) == 2
        with monkeypatch.context() as patched, worker_lease(work):
            patched.setattr(staging, "rmtree", busy)
            staging.recover_output_staging(work, request)
            assert directory_records(work) == remaining and receipt.read_text() == receipt_text
        with worker_lease(work):
            staging.recover_output_staging(work, request)
    assert directory_records(work) == ({} if can_recover else remaining)
    assert receipt.exists() == (fault == "partial")
    assert_sentinels(work)
    print(json.dumps({"fault": fault, "cleanup": "EBUSY", "before": remaining, "receipt": receipt_text,
                      "after_explicit_retry": directory_records(work), "child": False}))


def test_identity_capture_failure_leaves_one_untracked_empty_directory(fixture, monkeypatch):
    work, request, receipt = fixture
    original_stat = staging.os.stat

    def fail_stat(path, *args, **kwargs):
        if isinstance(path, str) and path.startswith(".python-output-") and kwargs.get("dir_fd") is not None:
            raise OSError(errno.EIO, "injected staging identity stat failure")
        return original_stat(path, *args, **kwargs)

    with monkeypatch.context() as patched:
        patched.setattr(staging.os, "stat", fail_stat)
        with pytest.raises(OSError, match="identity stat"):
            execute(work, request)
    remaining = directory_records(work)
    assert len(remaining) == 1 and all(not v[-1] for v in remaining.values())
    assert not receipt.exists() and not (work / "worker-launched").exists()
    with worker_lease(work):
        staging.recover_output_staging(work, request)
    assert directory_records(work) == remaining
    assert_sentinels(work)
    print(json.dumps({"fault": "stat_after_mkdir", "after_explicit_retry": remaining, "receipt": False, "child": False}))


def seed_run(database, work, request, *, terminal_count=0):
    initialize_database(database)
    now = datetime.now(UTC)
    with open_database(database) as connection, connection:
        connection.execute("INSERT INTO task VALUES ('task', '{}', NULL, ?)", (now.isoformat(),))
        connection.execute("INSERT INTO analysis_plan VALUES ('plan', 1, 'task', 'confirmed', '{}', ?)", (now.isoformat(),))
        if terminal_count:
            connection.executemany("""INSERT INTO run(id, plan_id, plan_version, execution_status, check_status,
                                   workdir, created_at) VALUES (?, 'plan', 1, 'SUCCEEDED', 'PASSED', ?, ?)""",
                                   [(f"history-{i}", f"{work}/history-{i}", now.isoformat()) for i in range(terminal_count)])
            return
        insert_run(connection, Run(id="run", plan_id="plan", plan_version=1, workdir=str(work), created_at=now,
                                   execution_status=ExecutionStatus.RUNNING, current_step="example"))
        save_run_step(connection, RunStep(run_id="run", step_key="example", position=0, started_at=now,
                                          status=ExecutionStatus.RUNNING, request=StepRequest.model_validate(request)))


@pytest.mark.parametrize("fault", ["before_open", "during_partial_write"])
def test_crash_before_complete_receipt_leaves_empty_directories_after_active_recovery(fixture, tmp_path, fault, caplog):
    work, request, receipt = fixture
    database = tmp_path / "project.sqlite"
    seed_run(database, work, request)
    process = subprocess.run([sys.executable, __file__, fault, str(work), json.dumps(request)],
                             capture_output=True, timeout=8, check=False)
    assert process.returncode == 86, process.stderr.decode()
    before = directory_records(work)
    assert len(before) == len(TARGETS) and all(not value[-1] for value in before.values())
    assert not (work / "worker-launched").exists() and managed_workers_stopped(work)
    assert (receipt.read_text() if receipt.exists() else None) == ("[" if fault == "during_partial_write" else None)
    with exclusive_local_lock(database.with_name(f"{database.name}.scheduler.lock")):
        verify = lambda run: managed_workers_stopped(Path(run.workdir))
        assert loop.recover_interrupted_runs(database, processes_stopped=verify) == ("run",)
        assert loop.recover_interrupted_runs(database, processes_stopped=verify) == ()
    with open_database(database, read_only=True) as connection:
        run = get_run(connection, "run")
        step = get_run_step(connection, "run", "example")
        assert run.execution_status is ExecutionStatus.FAILED and run.error.code == "RUN_INTERRUPTED"
        assert step.status is ExecutionStatus.FAILED and step.result.error.code == "RUN_INTERRUPTED"
        assert connection.execute("SELECT count(*) FROM artifact").fetchone()[0] == 0
    assert directory_records(work) == before
    assert ("Could not recover output staging" in caplog.text) == (fault == "during_partial_write")
    assert_sentinels(work)
    print(json.dumps({"crash_point": fault, "supervisor_exit": process.returncode, "run_after": run.error.code,
                      "empty_directories_after_startup": before, "invalid_receipt_logged": bool(caplog.text)}))


def test_history_query_scans_database_but_never_visits_terminal_run_directories(fixture, tmp_path, monkeypatch):
    work, request, _ = fixture
    database = tmp_path / "history.sqlite"
    seed_run(database, work, request, terminal_count=4096)
    with open_database(database, read_only=True) as connection:
        traced = []
        connection.set_trace_callback(traced.append)
        assert loop._executing_ids(connection) == ()
        query, = traced
        plan = [row["detail"] for row in connection.execute(f"EXPLAIN QUERY PLAN {query}")]
        assert "SCAN run" in plan

    def unexpected(*args):
        pytest.fail("Terminal history reached worker or staging check")

    monkeypatch.setattr(loop, "recover_output_staging", unexpected)
    assert loop.recover_interrupted_runs(database, processes_stopped=unexpected) == ()
    print(json.dumps({"terminal_rows": 4096, "query_plan": plan, "workdir_visits": 0}))


if __name__ == "__main__":
    fault, work, request_json = sys.argv[1:]
    work, request = Path(work), json.loads(request_json)
    receipt = output_staging_receipt_path(work, request)
    if fault == "before_open":
        original_open = staging.os.open

        def exit_before_open(path, flags, *args, **kwargs):
            if path == receipt.name and flags & os.O_EXCL:
                check_prelaunch(work, request)
                os._exit(86)
            return original_open(path, flags, *args, **kwargs)

        staging.os.open = exit_before_open
    else:
        assert fault == "during_partial_write"

        def exit_after_partial(records, stream):
            check_prelaunch(work, request)
            stream.write("[")
            stream.flush()
            os._exit(86)

        staging.json.dump = exit_after_partial
    execute(work, request)
