#!/usr/bin/env bash
set -o pipefail
probe=/dev/shm/geopilot-p13-staging-receipt.lYtHBTqn
status=0
for label in frozen preview; do
  cd "$probe/$label/system-prototype-v1" || exit 1
  PYTHONPATH="$PWD/src" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 TMPDIR=/dev/shm \
    /home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/.venv/bin/python -m pytest \
    -q -s -p no:cacheprovider --basetemp="$probe/$label-pytest" --junitxml="$probe/$label.junit.xml" \
    "$probe/test_receipt_faults.py" 2>&1 | tee "$probe/$label.log"
  result=$?
  printf '%s\n' "$result" > "$probe/$label.exit-code"
  if ((result)); then status=$result; fi
done
exit "$status"
