#!/usr/bin/env bash
set -euo pipefail
evidence=$(cd "$(dirname "$0")" && pwd)
python_bin=$(realpath "$1")
replay=$(mktemp -d)
mkdir "$replay/a2d2e68"
tar -xf "$evidence/source/a2d2e68.tar" -C "$replay/a2d2e68"
cp -a "$replay/a2d2e68" "$replay/c001411"
(cd "$replay/c001411" && git apply --binary -p2 "$evidence/source/c001411.patch")
for revision in a2d2e68 c001411; do
  (
    cd "$replay/$revision"
    sha256sum -c "$evidence/source/$revision.files" > "$replay/$revision.source-check.log"
    env PYTHONPATH="$PWD/src" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
      "$python_bin" -m pytest -q -s -p no:cacheprovider \
      --basetemp="$replay/$revision-pytest" --junitxml="$replay/$revision.junit.xml" \
      "$evidence/test_receipt_faults.py"
  ) 2>&1 | tee "$replay/$revision.log"
done
printf 'Replay evidence directory %s\n' "$replay"
