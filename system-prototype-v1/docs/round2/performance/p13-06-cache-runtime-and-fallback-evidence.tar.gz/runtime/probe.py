import hashlib
import json
import math
import os
import platform
from pathlib import Path
import sys

import numpy as np
import pyproj
import rasterio
from rasterio.transform import Affine
import yaml

from geopilot.artifacts.models import ArtifactSource
from geopilot.artifacts.service import _reopen_artifact
from geopilot.checks.input_checks import preflight_step_inputs
from geopilot.data.fingerprint import copy_file_group, fingerprint_file
from geopilot.domain.step_io import StepRequest
from geopilot.domain.tool_contract import ToolContract
from geopilot.execution.runner import run_step
from geopilot.gis.raster.threshold import classify_raster
from geopilot.persistence.workspace import create_run_workspace
from geopilot.tools.registry import ToolRegistry

root = Path(sys.argv[1])
source = root / "source"
run_id = "cache-key-counterexample"
step = "calculate_area_with_equal_area_projection"
input_uri = "inputs/threshold-regions.tif"
output_uri = "outputs/area-statistics.json"
equal_area = "EPSG:6933"
contract_path = source / "config/tools/python-dem-area-stats.yaml"
method_path = source / "config/methods/dem-terrain-analysis.v1.yaml"
worker = source / "src/geopilot/gis/tools/summarize_dem_area.py"
contract = ToolContract.model_validate(yaml.safe_load(contract_path.read_text()))
implementations = {contract.implementation: worker}
registry = ToolRegistry(python_implementations=implementations)
registry.register(contract, required_modules=("rasterio", "pyproj"))

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def make_workspace(case):
    workspace = create_run_workspace(root / case, "dem-terrain-analysis", run_id)
    workspace.create_step(step)
    return workspace.path

def write_tiff(path, values, *, grid, crs, nodata, point=False, valid=None):
    with rasterio.Env(GDAL_TIFF_INTERNAL_MASK=False, GTIFF_POINT_GEO_IGNORE="FALSE"):
        with rasterio.open(
            path, "w", driver="GTiff", width=values.shape[1], height=values.shape[0], count=1,
            dtype=values.dtype, crs=crs, transform=grid, nodata=nodata,
        ) as dataset:
            dataset.write(values, 1)
            if point:
                dataset.update_tags(AREA_OR_POINT="Point")
            if valid is not None:
                dataset.write_mask(valid)

def exercise(case, fixture, environment):
    workdir = make_workspace(case)
    input_path = workdir / input_uri
    output_path = workdir / output_uri
    expected = fingerprint_file(fixture).digest
    copy_file_group(fixture, input_path, expected_digest=expected)
    assert expected == fingerprint_file(input_path).digest
    request = StepRequest(
        run_id=run_id, step_key=step, workdir_ref=run_id, tool=contract.ref,
        inputs={"threshold_regions": {"path": input_uri}},
        parameters={"area_crs": equal_area},
        output_targets={"area_statistics": {"path": output_uri}},
        log_path=f"steps/{step}/process.log", cancel_path="cancel.flag",
    )
    os.environ.update(environment)
    try:
        result = run_step(
            request, registry=registry, workdir=workdir, python_implementations=implementations,
            input_preflight=preflight_step_inputs,
        )
        assert result.status == "SUCCEEDED" and result.exit_code == 0, result
        with rasterio.Env(**environment), rasterio.open(input_path) as opened:
            observed = {
                "transform": list(opened.transform)[:6],
                "files": [Path(name).name for name in opened.files],
                "band_mask": opened.read_masks(1).tolist(),
                "area_or_point": opened.tags().get("AREA_OR_POINT"),
            }
    finally:
        for name in environment:
            del os.environ[name]
    assert expected == fingerprint_file(input_path).digest
    return workdir, result, {
        "worker_configuration": environment,
        "step_result_environment": result.environment,
        "request_sha256": sha(workdir / "steps" / step / "request.json"),
        "input_main_sha256": sha(input_path),
        "input_file_group_digest": expected,
        "physical_input_files": sorted(path.name for path in input_path.parent.iterdir() if path.is_file()),
        "opened_input": observed,
        "output_file_group_digest": fingerprint_file(output_path).digest,
        "output_report": json.loads(output_path.read_text()),
    }

assert os.sched_getaffinity(0) == {29}
assert os.getpriority(os.PRIO_PROCESS, 0) == 19
assert all(name not in os.environ for name in ("GDAL_DISABLE_READDIR_ON_OPEN", "GTIFF_POINT_GEO_IGNORE"))
external = root / "fixture" / "external-mask.tif"
write_tiff(
    external, np.array([[1, 2, 0], [255, 1, 2]], dtype="uint8"),
    grid=Affine(20, 3, 0, 4, -10, 0), crs=equal_area, nodata=255,
    valid=np.array([[255, 255, 255], [255, 255, 0]], dtype="uint8"),
)
assert external.with_suffix(".tif.msk").is_file()
terrain = root / "fixture" / "point-terrain.tif"
classification = root / "fixture" / "point-classification.tif"
write_tiff(
    terrain, np.array([[5, 5, 0], [0, 5, 5]], dtype="float32"),
    grid=Affine(30_000, 0, 500_000, 0, -20_000, 4_400_000), crs="EPSG:32650", nodata=-9999, point=True,
)
with rasterio.Env(GTIFF_POINT_GEO_IGNORE="FALSE"):
    classify_raster(terrain, classification, threshold={"intervals": [
        {"class_id": 7, "lower": 4, "upper": 6, "include_lower": True, "include_upper": True},
    ]})
assert [path.name for path in classification.parent.glob("point-classification*")] == [classification.name]

cases = {
    "external_mask_opened": (external, {"GDAL_DISABLE_READDIR_ON_OPEN": "FALSE"}),
    "external_mask_hidden": (external, {"GDAL_DISABLE_READDIR_ON_OPEN": "EMPTY_DIR"}),
    "point_center_honored": (classification, {"GTIFF_POINT_GEO_IGNORE": "FALSE"}),
    "point_center_ignored": (classification, {"GTIFF_POINT_GEO_IGNORE": "TRUE"}),
}
runs = {name: exercise(name, *arguments) for name, arguments in cases.items()}
evidence = {name: outcome[2] for name, outcome in runs.items()}
for a, b in [("external_mask_opened", "external_mask_hidden"), ("point_center_honored", "point_center_ignored")]:
    left, right = evidence[a], evidence[b]
    for field in ("request_sha256", "input_main_sha256", "input_file_group_digest", "physical_input_files", "step_result_environment"):
        assert left[field] == right[field], (a, b, field)
    assert left["output_file_group_digest"] != right["output_file_group_digest"], (a, b)
    assert left["output_report"] != right["output_report"], (a, b)
a, b = evidence["external_mask_opened"], evidence["external_mask_hidden"]
assert a["opened_input"]["band_mask"][-1][-1] == 0
assert b["opened_input"]["band_mask"][-1][-1] == 255
for case, selected, nodata, total in [(a, 3, 2, 636.0), (b, 4, 1, 848.0)]:
    report = case["output_report"]
    assert report["selected_pixel_count"] == selected and report["nodata_pixel_count"] == nodata
    assert report["total_area_m2"] == total == selected * abs(20 * -10 - 3 * 4)
a, b = evidence["point_center_honored"], evidence["point_center_ignored"]
assert a["opened_input"]["area_or_point"] == b["opened_input"]["area_or_point"] == "Point"
assert a["opened_input"]["transform"] == [30_000.0, 0.0, 500_000.0, 0.0, -20_000.0, 4_400_000.0]
assert b["opened_input"]["transform"] == [30_000.0, 0.0, 515_000.0, 0.0, -20_000.0, 4_390_000.0]
assert a["output_report"]["selected_pixel_count"] == b["output_report"]["selected_pixel_count"] == 4
assert math.isfinite(a["output_report"]["total_area_m2"]) and math.isfinite(b["output_report"]["total_area_m2"])
assert abs(a["output_report"]["total_area_m2"] - b["output_report"]["total_area_m2"]) > 1

old_workdir, old_result, old = runs["point_center_honored"]
current_workdir, current_result, current = runs["point_center_ignored"]
stale_workdir = make_workspace("stale_copy")
cached = old_workdir / output_uri
stale = stale_workdir / output_uri
copy_file_group(cached, stale, expected_digest=old["output_file_group_digest"])
lineage = ArtifactSource(
    plan_id="cache-key-probe", plan_version=1, step_key=step, output_name="area_statistics",
    tool=contract.ref, inputs={},
)
registered = _reopen_artifact(stale_workdir, "area_statistics", old_result.outputs["area_statistics"], lineage, run_id).record
fresh = _reopen_artifact(
    current_workdir, "area_statistics", current_result.outputs["area_statistics"], lineage, run_id,
).record
assert registered.metadata == fresh.metadata
assert registered.fingerprint == old["output_file_group_digest"] != fresh.fingerprint
assert fresh.fingerprint == current["output_file_group_digest"]

print(json.dumps({
    "source_commit": (root / "source-commit").read_text().strip(),
    "method_sha256": sha(method_path),
    "tool_contract_sha256": sha(contract_path),
    "worker_sha256": sha(worker),
    "versions": {
        "python": platform.python_version(), "rasterio": rasterio.__version__, "gdal": rasterio.__gdal_version__,
        "pyproj": pyproj.__version__, "proj": pyproj.proj_version_str, "numpy": np.__version__,
    },
    "affinity": sorted(os.sched_getaffinity(0)),
    "nice": os.getpriority(os.PRIO_PROCESS, 0),
    "cases": evidence,
    "copied_stale_json_passed_artifact_reopen": {
        "metadata": registered.metadata,
        "copied_fingerprint": registered.fingerprint,
        "fresh_fingerprint": fresh.fingerprint,
    },
}, indent=2, sort_keys=True))
