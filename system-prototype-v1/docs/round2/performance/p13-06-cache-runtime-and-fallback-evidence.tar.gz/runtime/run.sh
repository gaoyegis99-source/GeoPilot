#!/bin/bash
set -o pipefail
probe=$(cd "$(dirname "$0")" && pwd)
project=/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1
cd "$probe"
env -u GDAL_DISABLE_READDIR_ON_OPEN -u GTIFF_POINT_GEO_IGNORE \
  PYTHONPATH="$probe/source/src" PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 \
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1 PROJ_NETWORK=OFF TMPDIR="$probe/tmp" \
  nice -n 19 ionice -c3 taskset -c 29 "$project/.venv/bin/python" -B "$probe/probe.py" "$probe"
