# P13-06 first cache candidate and runtime counterexamples

Source `32c5a9476b253d38c0ad89aa096333eb9e321847`, exact Git export of Python source and the two YAML contracts. The probe uses the registered Python runner and input preflight for four 3×2 fixtures. Both executions of the probe exited 0 and yielded byte-identical result JSON. No production edits, formal samples or database services are involved.

## Smallest first scope

Allow only the fixed `dem-terrain-analysis@1` method's `calculate_area_with_equal_area_projection` step bound to `python-dem-area-stats@1`. It consumes one typed local classification TIFF, has no layer, takes one explicit `area_crs` string, and emits one path-free JSON document. Initially restrict eligibility to an output of the same plan's successful `python-dem-threshold@1` and require the expected single-file group. The step's own log contains path references. The JSON payload contains the measured result.

Hash a versioned canonical serialization of the method identity and effective definition, fixed step/tool reference, tool contract and actual resolved implementation binding, fully normalized effective parameters, and the ordered input role, type, layer and verified content-file-group digest. Bind that key to a trusted immutable build and effective runtime configuration. The build needs to identify the execution code/import closure, interpreter and Python/native dependencies, and effective GDAL/PROJ binaries and data. Fixed installation manifests are a starting point. The recorded package versions and current release source/config digests alone do not prove the effective runtime configuration. Permit hits only when the actual worker is launched under a verified controlled configuration. Inherited options like `GTIFF_POINT_GEO_IGNORE`, config files, plugin/search paths and PROJ data can matter. Verify the controlled deployment and effective configuration instead of assuming a complete list of ambient variables. A missing or changed trusted identity should take the normal execution path. Scope reuse to the same trusted local project/catalog.

The cache receipt should bind the key to the exact source run and step, result role/type, and artifact group fingerprint. Use an owned immutable receipt/payload and verify it on read. Copy into a fresh current-run destination with `copy_file_group`, check the copied digest and current input's stability, reopen and validate the JSON schema and requested CRS, and retain current lineage and checks. A typed cache-reuse receipt needs its own process-check path because there is no new worker invocation on a hit. Resolve malformed or missing entries via normal execution. Generic JSON reopening verifies structure/physical identity, as the stale-copy probe illustrates. Key correctness remains a separate condition.

## Measured differences

- `GDAL_DISABLE_READDIR_ON_OPEN=FALSE` versus `EMPTY_DIR`. The main TIFF and its external mask had the same file-group digest in both workspaces. GDAL opened the mask in the first run and omitted it in the second. The analytical cell area is 212 m² from the affine determinant. The real runner reported 3 selected cells and 636 m² with the mask, then 4 cells and 848 m² with it hidden.
- `GTIFF_POINT_GEO_IGNORE=FALSE` versus `TRUE`. Production `classify_raster` wrote a single PixelIsPoint TIFF. Both workspaces had the same file-group digest and there was no sidecar. Ignoring the pixel-center convention shifted the opened transform by +15,000 m easting and −10,000 m northing. The class count stayed four. The real runner reported 2,401,770,286.741895 m² and 2,401,677,107.9217362 m² respectively.
- Both comparisons held request bytes, tool and method contracts, implementation, worker package versions recorded by the runner and copied input bytes constant. The only deliberate worker difference was the named option. Copying the first PixelIsPoint JSON with its expected group digest into a new workspace succeeded. The actual artifact reopening helper also accepted it and returned the same generic metadata as the correct second result. Its digest and the correct result's digest were distinct.

The probe demonstrates invalidation requirements and why a semantic error can survive successful JSON reopen. It does not implement cache lookup, provenance receipts or a production runtime manifest. The external-mask input tests the general tool behavior. The PixelIsPoint case applies even when eligibility is restricted to the production threshold's single-file output.

## Reproduction

Run from the project directory with the current host test environment. Extract the evidence into an empty tmpfs directory. The scripts can be placed in a new sibling for a rerun because the existing evidence already contains the first workspaces.

```bash
p13_probe=$(mktemp -d /dev/shm/geopilot-p13-06-cache-replay.XXXXXXXX)
cp /path/to/unpacked-evidence/{probe.py,run.sh,source-commit} "$p13_probe/"
mkdir "$p13_probe"/{source,fixture,tmp}
nice -n 19 ionice -c3 taskset -c 29 git -C .. archive "$(cat "$p13_probe/source-commit")" \
  system-prototype-v1/src system-prototype-v1/config/tools/python-dem-area-stats.yaml \
  system-prototype-v1/config/methods/dem-terrain-analysis.v1.yaml |
  nice -n 19 ionice -c3 taskset -c 29 tar -x --strip-components=1 -C "$p13_probe/source"
"$p13_probe/run.sh" > "$p13_probe/result.json" 2> "$p13_probe/stderr.log"
cmp /path/to/unpacked-evidence/result.json "$p13_probe/result.json"
```
