import errno
import json
import os
import sys
from datetime import UTC, datetime
from pathlib import Path

from pydantic import ValidationError

from geopilot.data.fingerprint import copy_file_group, fingerprint_file
from geopilot.domain.step_io import StepRequest, StepResult
from geopilot.domain.tool_contract import ToolContract
from geopilot.execution.step_support import AdapterError, prepare_step
from geopilot.execution.worker_lease import managed_workers_stopped, worker_lease
from geopilot.tools.registry import ToolRegistry


root = Path(sys.argv[1]).resolve()
cache = root / "cache"
workdir = root / "run"
for directory in (cache, workdir / "intermediate/first", workdir / "intermediate/second", workdir / "steps/reuse"):
    directory.mkdir(parents=True)

first_source = cache / "first.tif"
first_source.write_bytes(b"opaque first output for file-group copying")
first_source.with_suffix(".tif.aux.xml").write_bytes(b"<PAMDataset />")
second_source = cache / "second.json"
second_source.write_bytes(b'{"value":1}')
first_digest, second_digest = (fingerprint_file(source).digest for source in (first_source, second_source))
second_source.write_bytes(b'{"value":2}')
first = workdir / "intermediate/first/current.tif"
second = workdir / "intermediate/second/current.json"

contract = ToolContract.model_validate({
    "id": "python-cache-fallback-probe", "version": 1, "runner": "python", "implementation": "probe.cache_fallback",
    "inputs": {}, "outputs": {"first": "raster_terrain", "second": "json"}, "parameters": {}, "preconditions": [],
    "check_rules": ["output_exists"], "measurement_policy": {"distance": "not_applicable", "area": "not_applicable"},
})
registry = ToolRegistry(python_implementations=(contract.implementation,))
registry.register(contract)
request = StepRequest(
    run_id="run", step_key="reuse", tool=contract.ref, workdir_ref="run", inputs={}, parameters={},
    output_targets={"first": {"path": first.relative_to(workdir).as_posix()},
                    "second": {"path": second.relative_to(workdir).as_posix()}},
    log_path="steps/reuse/process.log", cancel_path="cancel.flag",
).model_dump(mode="json")


def prepare():
    return prepare_step(request, registry=registry, workdir=workdir, runner="python")


prepare()
sidecar = first.with_suffix(".tif.aux.xml")
with worker_lease(workdir):
    assert not managed_workers_stopped(workdir)
    copy_file_group(first_source, first, expected_digest=first_digest)
    assert first.is_file() and sidecar.is_file() and fingerprint_file(first).digest == first_digest
    try:
        copy_file_group(second_source, second, expected_digest=second_digest)
    except OSError as error:
        assert error.errno == errno.EAGAIN
        copy_error = {"errno": error.errno, "message": error.strerror}
    else:
        raise AssertionError("The later corrupt file group was accepted")
    assert not second.exists()
    remaining = [str(path.relative_to(workdir)) for path in (first, sidecar) if path.is_file()]
    assert len(remaining) == 2
    try:
        prepare()
    except AdapterError as error:
        assert error.field == "output_targets.first.path"
        fallback_error = {"code": error.code, "phase": error.phase, "field": error.field, "message": error.message}
    else:
        raise AssertionError("Normal execution unexpectedly accepted an occupied output")
    try:
        with worker_lease(workdir):
            raise AssertionError("A nested independent worker lease was granted")
    except BlockingIOError as error:
        assert error.errno == errno.EAGAIN
        nested_lease_errno = error.errno
    # The fixture itself owns both files; this is compensation for the test, not new production behavior.
    sidecar.unlink()
    first.unlink()

assert managed_workers_stopped(workdir)
with worker_lease(workdir):
    assert not managed_workers_stopped(workdir)
assert prepare().workdir == workdir
assert not any(path.exists() for path in (first, sidecar, second, workdir / request["log_path"]))

timestamp = datetime.now(UTC)
non_process_result = {"run_id": "run", "step_key": "reuse", "status": "SUCCEEDED", "exit_code": None,
                      "outputs": {}, "log_path": "steps/reuse/process.log", "warnings": [], "error": None,
                      "started_at": timestamp, "finished_at": timestamp, "environment": {}}
try:
    StepResult.model_validate(non_process_result)
except ValidationError as error:
    validation = error.errors(include_input=False, include_context=False, include_url=False)
    assert validation[0]["msg"] == "Value error, A successful step requires exit code 0, a log path and no error"
else:
    raise AssertionError("Current StepResult unexpectedly accepted non-process success")

observation = {
    "source_revision": (root / "source/REVISION").read_text().strip(),
    "affinity": sorted(os.sched_getaffinity(0)),
    "later_copy_failure": copy_error,
    "first_group_remaining": remaining,
    "later_group_remains": False,
    "production_fallback_preflight_error": fallback_error,
    "prepare_after_compensation": "OK",
    "nested_worker_lease_errno": nested_lease_errno,
    "lease_after_release": "acquired",
    "success_without_process_exit_validation": validation,
}
assert observation["affinity"] == [8]
(root / "observation.json").write_text(json.dumps(observation, indent=2) + "\n")
print(json.dumps(observation, indent=2))
