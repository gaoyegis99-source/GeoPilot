#!/usr/bin/env bash
set -o pipefail
probe=/dev/shm/geopilot-p13-cache-preflight.jwcn72U4
python_bin=/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/.venv/bin/python
PYTHONPATH="$probe/source/system-prototype-v1/src" PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm \
  taskset -c 8 "$python_bin" "$probe/probe.py" "$probe" 2>&1 | tee "$probe/probe.log"
result=$?
printf '%s\n' "$result" > "$probe/exit-code"
exit "$result"
