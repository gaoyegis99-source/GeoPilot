#!/usr/bin/env bash
set -o pipefail
probe=/dev/shm/geopilot-p13-normal-locks.O5nD9vXs
cd "$probe/source/system-prototype-v1" || exit 1
export PYTHONPATH="$PWD/src" PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm
python_bin=/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/.venv/bin/python
status=0

measure() {
  label=$1
  shift
  "$@" 2>&1 | tee "$probe/$label.log"
  result=$?
  printf '%s\n' "$result" > "$probe/$label.exit-code"
  if ((result)); then status=$result; fi
}

measure standard "$python_bin" "$probe/normal_probe.py" "$probe/standard" --runs 10 --readers 1 --interval 0.2
measure concurrent "$python_bin" "$probe/normal_probe.py" "$probe/concurrent" --runs 10 --readers 6 --interval 0.01 --auxiliary
mkdir "$probe/strace"
measure traced strace -ff -ttt -T -yy -e trace=fcntl,fdatasync,fsync,mkdir,mkdirat,link,linkat,unlink,unlinkat \
  -o "$probe/strace/syscall" "$python_bin" "$probe/normal_probe.py" "$probe/traced" \
  --runs 2 --readers 2 --interval 0.02 --auxiliary
exit "$status"
