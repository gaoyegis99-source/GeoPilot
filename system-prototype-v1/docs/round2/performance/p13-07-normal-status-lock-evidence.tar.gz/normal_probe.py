import argparse
import json
import logging
import math
import socket
import sqlite3
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from datetime import UTC, datetime
from functools import partial
from pathlib import Path
from threading import Thread
from time import monotonic, monotonic_ns, sleep, time_ns

import httpx2 as httpx
import uvicorn

from geopilot.api.app import create_app
from geopilot.application.plan_runner import execute_claimed_run
from geopilot.domain.tool_contract import ToolContract
from geopilot.persistence.run_repository import get_run, list_run_steps
from geopilot.persistence.schema import initialize_database, open_database
from geopilot.plans.models import AnalysisPlan
from geopilot.tools.registry import ToolRegistry


TOOL = """
import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--request', required=True)
parser.add_argument('--result', required=True)
args = parser.parse_args()
request = json.loads(Path(args.request).read_text())
source = request['inputs'].get('source')
counter = json.loads(Path(source['path']).read_text())['value'] if source else 0
for target in request['output_targets'].values():
    Path(target['path']).write_text(json.dumps({'value': counter + 1}))
Path(args.result).write_text(json.dumps({'outputs': request['output_targets'], 'environment': {}}))
"""


def setup(directory):
    database = directory / "project.sqlite"
    workspace = directory / "workspace"
    worker = directory / "json-worker.py"
    worker.write_text(TOOL)
    registry = ToolRegistry(python_implementations=("probe.json_write",))
    contracts = [ToolContract.model_validate({
        "id": f"python-json-{name}", "version": 1, "runner": "python", "implementation": "probe.json_write",
        "inputs": {"source": "json"} if source else {}, "outputs": {"output": "json"},
        "parameters": {}, "preconditions": [], "check_rules": ["output_exists"],
        "measurement_policy": {"area": "not_applicable", "distance": "not_applicable"},
    }) for name, source in (("generate", False), ("advance", True))]
    for contract in contracts:
        registry.register(contract)
    plan = AnalysisPlan.model_validate({
        "id": "plan", "task_id": "task", "version": 1, "status": "confirmed",
        "goal": {"summary": "Run a small three-step JSON workflow"}, "inputs": {}, "critical_options": {},
        "method": {"id": "probe-method", "version": 1},
        "steps": [
            {"key": key, "tool": contracts[int(previous is not None)].ref,
             "inputs": {"source": {"step": previous, "output": "output"}} if previous else {}, "parameters": {},
             "outputs": {"output": {"type": "json", "target": f"{parent}/{key}/result.json"}}}
            for key, previous, parent in (("first", None, "intermediate"), ("second", "first", "intermediate"),
                                          ("final", "second", "outputs"))
        ],
        "expected_artifacts": [{"role": "result", "step": "final", "output": "output", "type": "json"}],
        "check_rules": ["output_exists"], "issues": [],
    })
    initialize_database(database)
    with open_database(database) as connection, connection:
        pragmas = {name: connection.execute(f"PRAGMA {name}").fetchone()[0] for name in (
            "journal_mode", "busy_timeout", "synchronous", "cache_spill", "cache_size", "page_size",
        )}
        assert pragmas["journal_mode"] == "delete" and pragmas["busy_timeout"] == 5000
        now = datetime.now(UTC).isoformat()
        connection.execute("INSERT INTO task VALUES ('task', ?, NULL, ?)", (plan.goal.model_dump_json(), now))
        connection.execute("INSERT INTO analysis_plan VALUES ('plan', 1, 'task', 'confirmed', ?, ?)",
                           (plan.model_dump_json(), now))
    execute = partial(execute_claimed_run, database, workspace_root=workspace, registry=registry,
                      python_implementations={"probe.json_write": worker})
    return database, create_app(database, workspace_root=workspace, registry=registry, execute_run=execute), pragmas


class DiagnosticCapture(logging.Handler):
    def __init__(self):
        super().__init__(logging.WARNING)
        self.events = []

    def emit(self, record):
        self.events.append({"logger": record.name, "created_ns": int(record.created * 1_000_000_000),
                            "message": record.getMessage()})


@contextmanager
def service(app):
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        server = uvicorn.Server(uvicorn.Config(app, lifespan="on", access_log=False, log_config=None))
        thread = Thread(target=server.run, kwargs={"sockets": [listener]}, daemon=True)
        thread.start()
        try:
            deadline = monotonic() + 8
            while not server.started:
                assert thread.is_alive() and monotonic() < deadline, "Production ASGI service failed to start"
                sleep(0.01)
            yield f"http://127.0.0.1:{listener.getsockname()[1]}"
        finally:
            server.should_exit = True
            thread.join(timeout=8)
            assert not thread.is_alive()


def request(client, method, path, *, kind, reader=None, data=None):
    start_utc = time_ns()
    start = monotonic_ns()
    response = client.request(method, path, json=data)
    elapsed = monotonic_ns() - start
    body = response.json()
    observation = {"kind": kind, "reader": reader, "started_utc_ns": start_utc,
                   "finished_utc_ns": time_ns(), "wall_ns": elapsed, "http": response.status_code}
    if response.is_error:
        observation["error"] = body
    if kind == "status" and response.is_success:
        observation.update(execution_status=body["execution_status"], check_status=body["check_status"],
                           current_step=body["current_step"], run_id=body["run_id"])
    return body, observation


def read_until_terminal(url, run_id, reader, interval, auxiliary):
    rows = []
    path = f"/api/runs/{run_id}"
    with httpx.Client(base_url=url, trust_env=False, timeout=8) as client:
        deadline = monotonic() + 18
        while monotonic() < deadline:
            body, sample = request(client, "GET", path, kind="status", reader=reader)
            rows.append(sample)
            if sample["http"] == 200:
                if body["execution_status"] in ("FAILED", "CANCELLED"):
                    return rows, body
                if body["execution_status"] == "SUCCEEDED" and body["check_status"] != "CHECKING":
                    return rows, body
                if auxiliary and reader == 0:
                    kind = "steps" if len(rows) % 4 == 1 else "artifacts"
                    _, auxiliary_sample = request(client, "GET", f"{path}/{kind}", kind=kind, reader=reader)
                    rows.append(auxiliary_sample)
            sleep(interval)
    return rows, None


def latency(rows):
    values = sorted(row["wall_ns"] for row in rows)
    return {f"p{percentile}_ms": round(values[math.ceil(percentile * len(values) / 100) - 1] / 1_000_000, 3)
            for percentile in (50, 95, 99, 100)} if values else {}


def main(args):
    args.directory.mkdir()
    database, app, pragmas = setup(args.directory)
    capture = DiagnosticCapture()
    loggers = [logging.getLogger(name) for name in ("geopilot.api.app", "geopilot.scheduler.loop")]
    for logger in loggers:
        logger.addHandler(capture)
    observations = []
    finished = []
    started = monotonic_ns()
    try:
        with service(app) as url, ThreadPoolExecutor(max_workers=args.readers) as readers:
            with httpx.Client(base_url=url, trust_env=False, timeout=8) as coordinator:
                for _ in range(args.runs):
                    accepted, sample = request(coordinator, "POST", "/api/plans/plan/runs", kind="submission",
                                               data={"plan_version": 1})
                    observations.append(sample)
                    if sample["http"] != 202:
                        break
                    run_id = accepted["run_id"]
                    futures = [readers.submit(read_until_terminal, url, run_id, index, args.interval, args.auxiliary)
                               for index in range(args.readers)]
                    finals = []
                    for future in futures:
                        rows, final = future.result(timeout=22)
                        observations.extend(rows)
                        finals.append(final)
                    finished.append({"run_id": run_id, "terminal_observations": finals})
                    if any(final is None or final["check_status"] != "PASSED" for final in finals):
                        break
    finally:
        for logger in loggers:
            logger.removeHandler(capture)

    with open_database(database, read_only=True) as connection:
        integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
        for report in finished:
            run = get_run(connection, report["run_id"])
            report["db_execution"] = run.execution_status.value
            report["db_check"] = run.check_status.value
            report["steps"] = [{"status": step.status.value, "exit_code": step.result.exit_code if step.result else None}
                               for step in list_run_steps(connection, run.id)]
            report["manifest"] = (Path(run.workdir) / "outputs/manifest.json").is_file()
            report["compatibility_report"] = (Path(run.workdir) / "checks/report.json").is_file()
            report["output_value"] = json.loads((Path(run.workdir) / "outputs/final/result.json").read_bytes())["value"] if report["manifest"] else None
        artifacts = connection.execute("SELECT count(*) FROM artifact").fetchone()[0]
        reports = connection.execute("SELECT count(*) FROM check_report WHERE status = 'PASSED'").fetchone()[0]
    observations.sort(key=lambda row: row["started_utc_ns"])
    with (args.directory / "http.jsonl").open("w") as stream:
        for row in observations:
            stream.write(json.dumps(row) + "\n")
    kinds = {row["kind"] for row in observations}
    summary = {"source_revision": (Path.cwd().parent / "REVISION").read_text().strip(),
               "sqlite": sqlite3.sqlite_version, "pragmas": pragmas,
               "runs_requested": args.runs, "readers_per_run": args.readers, "reader_interval_s": args.interval,
               "auxiliary_read_routes": args.auxiliary, "elapsed_s": round((monotonic_ns() - started) / 1e9, 3),
               "requests": {kind: {"codes": dict(Counter(row["http"] for row in observations if row["kind"] == kind)),
                                   "latency": latency([row for row in observations if row["kind"] == kind])}
                            for kind in sorted(kinds)},
               "run_status_states": dict(Counter(f"{row['execution_status']}/{row['check_status']}"
                                                 for row in observations if "execution_status" in row)),
               "diagnostics": capture.events, "integrity_check": integrity, "artifacts": artifacts,
               "passed_reports": reports, "journal_left_after_stop": database.with_name("project.sqlite-journal").exists(),
               "runs": finished}
    (args.directory / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "runs"}, indent=2), flush=True)
    assert integrity == "ok"
    assert len(finished) == args.runs and artifacts == reports == args.runs
    assert all(run["db_execution"] == "SUCCEEDED" and run["db_check"] == "PASSED" and run["output_value"] == 3
               and run["compatibility_report"] and run["steps"] == [{"status": "SUCCEEDED", "exit_code": 0}] * 3
               for run in finished)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--runs", type=int, required=True)
    parser.add_argument("--readers", type=int, required=True)
    parser.add_argument("--interval", type=float, required=True)
    parser.add_argument("--auxiliary", action="store_true")
    main(parser.parse_args())
