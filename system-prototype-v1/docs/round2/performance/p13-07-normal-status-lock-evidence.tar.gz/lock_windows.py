import json
import re
import sys
from decimal import Decimal
from pathlib import Path
from statistics import median


PENDING = 1_073_741_824
RESERVED = PENDING + 1
SHARED = PENDING + 2
LOCK = re.compile(r"fcntl\(\d+<[^>]+/traced/project\.sqlite>, F_SETLK, "
                  r"\{l_type=(\w+), l_whence=SEEK_SET, l_start=(\d+), l_len=(\d+)\}\) = (.*)")
LINE = re.compile(r"^(\d+\.\d+) (.*?) <(\d+\.\d+)>$")


def us(value):
    return int(Decimal(value) * 1_000_000)


def time_details(durations):
    return {"n": len(durations), "min_ms": min(durations) / 1000,
            "median_ms": median(durations) / 1000, "max_ms": max(durations) / 1000}


def role(body):
    if body.startswith("mkdirat(") and "/steps>," in body:
        return "step_directory"
    if body.startswith('mkdir("') and "/workspace/" in body and any(f"/{folder}/" in body for folder in ("intermediate", "outputs")):
        return "artifact_temp_directory" if "/.manifest-" in body else "output_directory"
    if body.startswith('mkdir("') and "/checks/.report-" in body:
        return "report_temp_directory"
    if body.startswith(("link(", "linkat(")) and '/outputs/manifest.json"' in body:
        return "manifest_link"
    if body.startswith(("link(", "linkat(")) and '/checks/report.json"' in body:
        return "report_link"
    if body.startswith(("fsync(", "fdatasync(")):
        if "/traced/project.sqlite-journal>" in body:
            return "journal_sync"
        if "/traced/project.sqlite>" in body:
            return "database_sync"
    if body.startswith('unlink("') and '/traced/project.sqlite-journal"' in body:
        return "journal_unlink"
    return None


def parse(path):
    current = None
    windows = []
    outside_file_ops = []
    failures = []
    for number, line in enumerate(path.read_text().splitlines(), 1):
        parsed = LINE.match(line)
        if not parsed:
            continue
        start, body, elapsed = parsed.groups()
        start, elapsed = us(start), us(elapsed)
        event = role(body)
        if event:
            record = {"event": event, "trace_line": number, "start_utc_us": start, "syscall_us": elapsed}
            if current is not None:
                record["lock"] = ("EXCLUSIVE" if current.get("exclusive_at_us") and not current.get("exclusive_release_us")
                                  else "PENDING" if current.get("pending_at_us") else "RESERVED")
                current["file_ops"].append(record)
            else:
                outside_file_ops.append(record)

        match = LOCK.match(body)
        if not match:
            continue
        lock, offset, length, result = match.groups()
        offset, length = int(offset), int(length)
        if result != "0":
            failures.append({"trace_line": number, "lock": lock, "offset": offset, "result": result})
            continue
        done = start + elapsed
        if lock == "F_WRLCK" and offset == RESERVED:
            assert current is None
            current = {"reserved_at_us": done, "trace_line_start": number, "file_ops": []}
        if current is None:
            continue
        if lock == "F_WRLCK" and offset == PENDING:
            current["pending_at_us"] = done
        if lock == "F_WRLCK" and offset == SHARED:
            current["exclusive_at_us"] = done
        if lock == "F_RDLCK" and offset == SHARED and current.get("exclusive_at_us"):
            current["exclusive_release_us"] = done
        if lock == "F_UNLCK" and offset <= RESERVED and (length == 0 or offset + length > RESERVED):
            current["reserved_release_us"] = done
            current["trace_line_end"] = number
            current["reserved_us"] = done - current["reserved_at_us"]
            if current.get("pending_at_us"):
                current["read_blocking_us"] = done - current["pending_at_us"]
            if current.get("exclusive_at_us"):
                current["exclusive_us"] = current.get("exclusive_release_us", done) - current["exclusive_at_us"]
            windows.append(current)
            current = None
    assert current is None, path
    return windows, outside_file_ops, failures


root = Path(sys.argv[1])
traces = sorted((root / "strace").glob("syscall.*"))
parsed = {path.name: parse(path) for path in traces}
scheduler, = [file for file, (windows, _, _) in parsed.items()
              if any(op["event"] == "step_directory" for window in windows for op in window["file_ops"])]
windows, outside_ops, _ = parsed[scheduler]
commits = [window for window in windows if any(op["event"] == "journal_unlink" for op in window["file_ops"])]
no_mutation = [window for window in windows if not window["file_ops"] and "exclusive_us" in window]
sequence = ["claim", "seed_steps", "start_first", "result_first", "start_second", "result_second",
            "start_final", "result_final", "register_artifacts", "publish_check"]
assert len(commits) == len(sequence) * 2
for index, window in enumerate(commits):
    window["production_stage"] = sequence[index % len(sequence)]
    window["run_index"] = index // len(sequence) + 1
    labels = {op["event"] for op in window["file_ops"]}
    stage = window["production_stage"]
    assert ("step_directory" in labels) == stage.startswith("start_")
    assert ("manifest_link" in labels) == (stage == "register_artifacts")
    assert ("report_link" in labels) == (stage == "publish_check")
    if stage.startswith("result_"):
        assert labels == {"database_sync", "journal_sync", "journal_unlink"}


def metric(label, selected):
    return {"stage": label, **{key: time_details([window[key] for window in selected])
                               for key in ("reserved_us", "read_blocking_us", "exclusive_us")}}


summary = [metric("all_commits", commits),
           metric("all_scheduler_lock_upgrades", [w for w in windows if "exclusive_us" in w]),
           metric("no_observed_journal_write", no_mutation),
           metric("start_steps", [w for w in commits if w["production_stage"].startswith("start_")]),
           metric("save_step_results", [w for w in commits if w["production_stage"].startswith("result_")]),
           metric("register_artifacts", [w for w in commits if w["production_stage"] == "register_artifacts"]),
           metric("publish_check", [w for w in commits if w["production_stage"] == "publish_check"])]
failures = {name: entries for name, (_, _, entries) in parsed.items() if entries}
evidence = {"scheduler_trace": scheduler, "scheduler_write_windows": windows, "scheduler_commit_stats": summary,
            "scheduler_observed_file_ops_outside_sqlite_reserved": outside_ops, "failed_sqlite_kernel_lock_calls": failures}
(root / "lock-windows.json").write_text(json.dumps(evidence, indent=2) + "\n")
for row in summary:
    print(json.dumps(row))
print("scheduler_trace", scheduler, "failed_sqlite_kernel_lock_calls", sum(map(len, failures.values())))
