import base64
import hashlib
import importlib.metadata as metadata
from pathlib import Path
import shutil
import sys

destination = Path(sys.argv[1])
for name in ("psycopg", "psycopg-binary"):
    dist = metadata.distribution(name)
    assert dist.version == "3.3.4", (name, dist.version)
    copied = verified = 0
    for entry in dist.files:
        if "__pycache__" in entry.parts:
            continue
        assert not entry.is_absolute() and ".." not in entry.parts, entry
        source = dist.locate_file(entry)
        target = destination / entry
        assert source.is_file() and not target.exists(), source
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        copied += 1
        if entry.hash is None:
            assert entry.name == "RECORD", entry
            continue
        actual = hashlib.new(entry.hash.mode, target.read_bytes()).digest()
        assert base64.urlsafe_b64encode(actual).rstrip(b"=").decode() == entry.hash.value, entry
        assert entry.size is None or target.stat().st_size == entry.size, entry
        verified += 1
    print(f"{name} {dist.version} source={dist.locate_file('')} copied={copied} RECORD_verified={verified}")
