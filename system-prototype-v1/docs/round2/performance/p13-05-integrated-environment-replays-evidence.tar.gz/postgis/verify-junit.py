from collections import Counter
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

def cases(path):
    suite = ET.parse(path).find("testsuite")
    nodes = {}
    for case in suite.findall("testcase"):
        node = case.get("classname").replace(".", "/") + ".py::" + case.get("name")
        assert node not in nodes, node
        nodes[node] = case
    return suite.attrib, nodes

root = Path(sys.argv[1])
original_summary, original = cases(root / "original-regression.xml")
replay_summary, replay = cases(root / "attempt-1" / "regression.xml")
expected = [
    node for node, case in original.items()
    if (skip := case.find("skipped")) is not None and "could not import 'psycopg'" in skip.get("message", "")
]
assert expected == (root / "node-ids.txt").read_text().splitlines()
assert expected == list(replay) and len(replay) == 13
assert all(len(case) == 0 for case in replay.values())
assert replay_summary["tests"] == "13"
assert {replay_summary[k] for k in ("errors", "failures", "skipped")} == {"0"}
assert (root / "attempt-1" / "exit-code").read_text().strip() == "0"
assert len((root / "attempt-1" / "docker-runs.log").read_text().splitlines()) == 4
assert not (root / "attempt-1" / "postgis-after.log").read_text().strip()
other = Counter(
    skip.get("message") for node, case in original.items()
    if node not in expected and (skip := case.find("skipped")) is not None
)
assert sum(other.values()) == 9
print(json.dumps({
    "original": original_summary,
    "replay": replay_summary,
    "exact_selected_ids": expected,
    "replayed_exit_code": 0,
    "replayed_skips": 0,
    "unselected_original_skips": dict(other),
    "postgis_fixtures_launched": 4,
    "postgis_fixtures_remaining": 0,
}, indent=2, ensure_ascii=False))
