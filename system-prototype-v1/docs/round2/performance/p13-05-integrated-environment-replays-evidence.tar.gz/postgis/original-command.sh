#!/bin/bash
set -o pipefail
geo_p13_evidence="$1"
export PYTHONPATH="$PWD/src" PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1 PROJ_NETWORK=OFF TMPDIR=/dev/shm
nice -n 19 ionice -c3 taskset -c 31 .venv/bin/python -B -m pytest -q -p no:cacheprovider \
  -W error::pytest.PytestUnhandledThreadExceptionWarning --basetemp="$geo_p13_evidence/pytest" \
  --junitxml="$geo_p13_evidence/regression.xml" tests/data_adapters tests/gis tests/runners \
  tests/scheduler/test_cancellation.py tests/api/test_run_status.py
