#!/bin/bash
set -euo pipefail
scratch=$(cd "$(dirname "$0")" && pwd)
project=/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1
attempt="$1"
[[ "$attempt" =~ ^attempt-[0-9]+$ ]]
out="$scratch/$attempt"
mkdir "$out"
cd "$scratch/source"
export PYTHONPATH="$PWD/src:$scratch/deps"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1 PROJ_NETWORK=OFF
export TMPDIR="$scratch/tmp"
export PATH="$scratch/bin:$PATH"
export GEOPILOT_POSTGIS_REPLAY_DOCKER_LOG="$out/docker-runs.log"
readarray -t nodes < "$scratch/node-ids.txt"
[[ "${#nodes[@]}" == 13 ]]
cmd=(nice -n 19 ionice -c3 taskset -c 29 "$project/.venv/bin/python" -B -m pytest -q -p no:cacheprovider
  -W error::pytest.PytestUnhandledThreadExceptionWarning --basetemp="$out/pytest"
  --junitxml="$out/regression.xml" "${nodes[@]}")
printf '%q ' "${cmd[@]}" > "$out/pytest-command.sh"
printf '\n' >> "$out/pytest-command.sh"
set +e
"${cmd[@]}" 2>&1 | tee "$out/regression.log"
status="${PIPESTATUS[0]}"
set -e
printf '%s\n' "$status" > "$out/exit-code"
docker ps -a --format '{{.Names}} {{.State}}' --filter 'name=geopilot-postgis-' > "$out/postgis-after.log"
exit "$status"
