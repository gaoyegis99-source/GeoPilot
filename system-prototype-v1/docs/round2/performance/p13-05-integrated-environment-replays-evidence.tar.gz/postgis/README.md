# P13-05 PostGIS host skip replay

The archived integrated host JUnit records 500 nodes and 22 skips. The archived run used production source `217320baec299e4a66a34042fb353bad0d703749`. This replay exported the exact project subtree of `cf53e827a93ff4f56cca8541827b26ff858ed736`. Production `src`, both selected test modules, and the dependency specs are unchanged across those refs. The only changed test file is the unrelated raster benchmark test.

All 13 matching JUnit node IDs are in `node-ids.txt`. Five are snapshot tests and eight are versioning tests, with the rollback action exercised as two separate nodes. Eleven receive the module-scoped `postgis` fixture across two modules. The filtered-snapshot/offline and changed-data/offline tests call `isolated_postgis()` directly and also verify operation after the database stops. Every selected node requires a real PostgreSQL/PostGIS instance, including those asserting SQLite rollback and publication cleanup. The two fixture instances and two direct instances used the project's cached, pinned image with pull disabled, no network, no published port and tmpfs database storage.

Python 3.13.13 and pytest 8.3.4 came from the existing host test interpreter. A tmpfs target supplied `psycopg[binary]==3.3.4` from the locally installed distributions, verified against their installed RECORD digests. The project environment received no installations. The test process used CPU29, nice 19, idle I/O priority and a tmpfs pytest base directory. The fixture's source retains its private Unix socket and generated password-file directory under `/tmp` and removes that directory on teardown. The PATH wrapper adds CPU29 affinity to the four test containers. CPU29 was assigned because the capacity probe used CPU31.

From the project directory, reconstruct the source, package target and test working directories and then use the exact replay command recorded below. No downloads are necessary when the same local distributions and pinned Docker image are present. An initial archive command from the project subdirectory failed before any tests ran. The corrected command runs Git from the repository root.

```sh
scratch=$(mktemp -d /dev/shm/geopilot-p13-05-psycopg-replay.XXXXXXXX)
# Extract this evidence archive into "$scratch" first.
mkdir "$scratch"/{source,deps,tmp}
nice -n 19 ionice -c3 taskset -c 29 git -C .. archive cf53e827a93ff4f56cca8541827b26ff858ed736:system-prototype-v1 |
  nice -n 19 ionice -c3 taskset -c 29 tar -x -C "$scratch/source"
nice -n 19 ionice -c3 taskset -c 29 /home/mtd/miniconda3/bin/python -B "$scratch/copy-deps.py" "$scratch/deps"
"$scratch/replay.sh" attempt-2
```

The first replay exited 0 with 13 passed, zero skipped, and one Pyogrio warning from the deliberate unknown-CRS test. JUnit node IDs match the original 13 one for one. The nine original QGIS skips remain outside this replay.
