"""Check every host skip was executed successfully in the two environment replays."""
from pathlib import Path
import json
import sys
import tarfile
import xml.etree.ElementTree as ET


def nodes(xml):
    result = {}
    for case in ET.fromstring(xml).iter("testcase"):
        name = case.attrib["classname"], case.attrib["name"]
        assert name not in result, name
        result[name] = case
    return result


root = Path(sys.argv[1])
with tarfile.open(root / "qgis/host-evidence.tar.gz") as archive:
    member, = [path for path in archive.getnames() if path.endswith("/regression.xml") or path == "regression.xml"]
    host_xml = archive.extractfile(member).read()
assert host_xml == (root / "postgis/original-regression.xml").read_bytes()
host = nodes(host_xml)
qgis = nodes((root / "qgis/out/native-junit.xml").read_bytes())
postgis = nodes((root / "postgis/attempt-1/regression.xml").read_bytes())
assert len(host) == 500 and len(qgis) == 9 and len(postgis) == 13
host_skips = {name: case.find("skipped").get("message") for name, case in host.items() if case.find("skipped") is not None}
assert len(host_skips) == 22
assert set(postgis) == {name for name, reason in host_skips.items() if "psycopg" in reason}
assert set(qgis) == set(host_skips) - set(postgis)
assert all(case.find(tag) is None for case in host.values() for tag in ("failure", "error"))
assert all(case.find(tag) is None for suite in (qgis, postgis) for case in suite.values() for tag in ("failure", "error", "skipped"))
assert (root / "qgis/out/pytest.exit-code").read_text().strip() == (root / "postgis/attempt-1/exit-code").read_text().strip() == "0"
source = (root / "qgis/out/source-commit").read_text().strip()
assert source == (root / "postgis/source-commit").read_text().strip() == "cf53e827a93ff4f56cca8541827b26ff858ed736"
print(json.dumps({"original_nodes": len(host), "host_passed": len(host) - len(host_skips),
                  "native_qgis_passed": len(qgis), "native_postgis_passed": len(postgis),
                  "all_original_nodes_covered_across_runs": True, "replay_source": source}, indent=2))
