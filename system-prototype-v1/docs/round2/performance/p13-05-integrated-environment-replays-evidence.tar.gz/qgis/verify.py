from hashlib import sha256
import json
from pathlib import Path
import re
import shlex
import sys
import tarfile
import xml.etree.ElementTree as ET

root = Path(sys.argv[1])
out = root / "out"
raw = root / "host-evidence.tar.gz"
with tarfile.open(raw, "r:gz") as tar:
    suite = ET.parse(tar.extractfile("./regression.xml")).find("testsuite")
    source = tar.extractfile("./source-commit").read().decode().strip()
expected = []
for case in suite.findall("testcase"):
    skip = case.find("skipped")
    if skip is not None and "GEOPILOT_QGIS_PROCESS" in skip.attrib["message"]:
        path = re.search(r"(tests/runners/\w+\.py):\d+", skip.text).group(1)
        expected.append(f"{path}::{case.attrib['name']}")
assert len(set(expected)) == len(expected) == 9
assert expected == (out / "nodes.txt").read_text().splitlines()
assert not (out / "source-equivalence.diff").read_bytes()
pytest_args = shlex.split((out / "pytest.command").read_text())
assert pytest_args[-9:] == expected
docker_args = shlex.split((out / "docker.command").read_text())
assert docker_args[docker_args.index("--cpuset-cpus") + 1] == "30"
assert docker_args[docker_args.index("--network") + 1] == "none"
assert "--read-only" in docker_args
assert docker_args[-6:] == ["-n", "19", "/usr/bin/ionice", "-c3", "/bin/bash", "/scratch/container.sh"]
native = ET.parse(out / "native-junit.xml").find("testsuite")
assert native is not None
assert {k: native.attrib[k] for k in ("tests", "errors", "failures", "skipped")} == {
    "tests": "9", "errors": "0", "failures": "0", "skipped": "0",
}
cases = native.findall("testcase")
assert all(len(case) == 0 for case in cases)
actual = [f"{case.attrib['classname'].replace('.', '/')}.py::{case.attrib['name']}" for case in cases]
assert actual == expected
assert (out / "pytest.exit-code").read_text().strip() == (out / "docker.exit-code").read_text().strip() == "0"
assert (out / "source-commit").read_text().strip() == "cf53e827a93ff4f56cca8541827b26ff858ed736"
versions = json.loads((out / "native-versions.json").read_text())
assert versions["affinity"] == [30] and versions["nice"] == 19 and versions["source"] == (out / "source-commit").read_text().strip()
assert versions["image"] in docker_args
assert (out / "ionice.log").read_text().strip() == "idle"
assert "cpuset=31 status=running" in (out / "capacity-before.log").read_text()
assert "QGIS 3.44.15-Solothurn" in (out / "qgis-process-version.log").read_text()
summary = {
    "host_original_source": source, "native_replay_source": versions["source"],
    "host_archive_sha256": sha256(raw.read_bytes()).hexdigest(),
    "native_junit_sha256": sha256((out / "native-junit.xml").read_bytes()).hexdigest(),
    "totals": {k: native.attrib[k] for k in ("tests", "errors", "failures", "skipped", "time")},
    "nodes": [{"nodeid": item, "duration_s": float(case.attrib["time"])} for item, case in zip(actual, cases, strict=True)],
    "replay_cpu": versions["affinity"], "replay_nice": versions["nice"], "replay_io": "idle",
    "capacity_before": (out / "capacity-before.log").read_text().strip(),
    "capacity_after": (out / "capacity-after.log").read_text().strip(),
    "first_preflight_exit": int((root / "first-preflight/docker.exit-code").read_text()),
}
(out / "verification.json").write_text(json.dumps(summary, indent=2) + "\n")
print(f"Verified 9 exact native QGIS node IDs, 0 skips/failures, CLI and pytest exit 0, CPU {versions['affinity']}")
