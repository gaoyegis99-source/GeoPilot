#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "$0")" && pwd)
git_root=/home/mtd/liweigis/GeoPilot-round2
project="$git_root/system-prototype-v1"
image=sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87
commit=$(git -C "$git_root" rev-parse 'cf53e82^{commit}')
source="$root/source/system-prototype-v1"
runtime="$project/.environments/p13-native"
qgis="$project/.environments/qgis-deb/usr/bin"
name="geopilot-p13-05-nine-native-${root##*.}"
uid_gid="$(id -u):$(id -g)"
cpu="${1:-31}"
[[ "$cpu" =~ ^[0-9]+$ ]]
printf '%s\n' "$commit" > "$root/out/source-commit"
git -C "$git_root" diff --exit-code 217320b "$commit" -- system-prototype-v1/src system-prototype-v1/configs \
    system-prototype-v1/tests/runners/{test_attribute_filter,test_measurement_steps,test_qgis_runner,test_road_selection}.py \
    > "$root/out/source-equivalence.diff"
git -C "$git_root" archive "$commit" system-prototype-v1 | tar -x -C "$root/source"
test -f "$source/pyproject.toml"
test -r "$runtime/venv/bin/python" -a -x "$qgis/qgis_process" -a -x "$qgis/qgis_process.bin"
sha256sum "$qgis/qgis_process" "$qgis/qgis_process.bin" > "$root/out/qgis-executable.sha256"
cmd=(docker run --rm --network none --cpuset-cpus "$cpu" --name "$name" --user "$uid_gid"
  --read-only --tmpfs /tmp:rw,nosuid,nodev,size=128m,mode=1777
  --entrypoint /usr/bin/nice --workdir /project
  -e HOME=/scratch/home -e XDG_RUNTIME_DIR=/scratch/xdg -e QGIS_CUSTOM_CONFIG_PATH=/scratch/qgis-profile
  -e QT_QPA_PLATFORM=offscreen -e GEOPILOT_QGIS_PROCESS=/usr/bin/qgis_process -e PROJ_NETWORK=OFF
  -e PYTHONDONTWRITEBYTECODE=1 -e PYTHONNOUSERSITE=1 -e PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
  -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -e GDAL_NUM_THREADS=1 -e MKL_NUM_THREADS=1
  -e "GEOPILOT_NATIVE_IMAGE=$image" -e "GEOPILOT_REPLAY_SOURCE=$commit"
  --mount "type=bind,src=$source,dst=/project,readonly"
  --mount "type=bind,src=$root/out,dst=/scratch"
  --mount "type=bind,src=$runtime,dst=/runtime,readonly"
  --mount "type=bind,src=$qgis/qgis_process,dst=/usr/bin/qgis_process,readonly"
  --mount "type=bind,src=$qgis/qgis_process.bin,dst=/usr/bin/qgis_process.bin,readonly"
  "$image" -n 19 /usr/bin/ionice -c3 /bin/bash /scratch/container.sh)
printf '%q ' "${cmd[@]}" > "$root/out/docker.command"
printf '\n' >> "$root/out/docker.command"
printf '%s\n' "$name" > "$root/out/container-name"
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$root/out/started-utc"
set +e
"${cmd[@]}" > "$root/out/docker.log" 2>&1
status=$?
set -e
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$root/out/finished-utc"
printf '%s\n' "$status" > "$root/out/docker.exit-code"
cat "$root/out/docker.log"
exit "$status"
