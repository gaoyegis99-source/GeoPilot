import json
import os
from pathlib import Path
import sqlite3
import sys

from osgeo import gdal
import geopandas
import numpy
import pyogrio
import pyproj
import pytest
from qgis.core import Qgis
import rasterio
import shapely

record = {
    "python": sys.version,
    "executable": sys.executable,
    "qgis_bindings": Qgis.QGIS_VERSION,
    "qgis_process": os.environ["GEOPILOT_QGIS_PROCESS"],
    "gdal_bindings": gdal.VersionInfo("RELEASE_NAME"),
    "pyogrio": pyogrio.__version__,
    "pyogrio_gdal": pyogrio.__gdal_version__,
    "rasterio": rasterio.__version__,
    "rasterio_gdal": rasterio.__gdal_version__,
    "proj": pyproj.proj_version_str,
    "shapely": shapely.__version__,
    "geos": shapely.geos_version_string,
    "geopandas": geopandas.__version__,
    "sqlite": sqlite3.sqlite_version,
    "pytest": pytest.__version__,
    "numpy": numpy.__version__,
    "affinity": sorted(os.sched_getaffinity(0)),
    "nice": os.getpriority(os.PRIO_PROCESS, 0),
    "image": os.environ["GEOPILOT_NATIVE_IMAGE"],
    "source": os.environ["GEOPILOT_REPLAY_SOURCE"],
    "os_release": Path("/etc/os-release").read_text(),
}
print(json.dumps(record, indent=2))
