#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
limited() { nice -n 19 taskset -c 31 "$@"; }
record() {
  local label="$1" code=0
  shift
  printf '%q ' nice -n 19 taskset -c 31 "$@" > "proof/$label.command"
  printf '\n' >> "proof/$label.command"
  limited "$@" > "proof/$label.log" 2>&1 || code=$?
  printf '%s\n' "$code" > "proof/$label.exit-code"
  return "$code"
}
record syntax python3 -B -c 'import ast, pathlib; [ast.parse(pathlib.Path(name).read_text(), filename=name) for name in ("run-raster-pairs.py", "test_launcher.py")]; print("Python AST syntax OK")'
record dry-run python3 -B ./run-raster-pairs.py --dry-run
record dry-run-single python3 -B ./run-raster-pairs.py --dry-run --case remote-l
record fixture-tests python3 -B -m unittest -v test_launcher
record archived-inputs python3 -B ./archive_proof.py
