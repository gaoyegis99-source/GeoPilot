# P13-05 栅格完整方法配对启动器

此目录是正式测量前的隔离准备。证明文件只来自只读元数据、已归档的 P13-04 JSON/JSONL 和明确标记的合成测试。尚未启动真实容器或生成栅格数据。

## 启动

正式计时窗口由主控串行交接。首次可选择两个短场景，随后使用同一启动器和输出根按档续批。

```bash
python3 -B /dev/shm/geopilot-p13-05-raster-pairs-a2d2e68.TONYtP/run-raster-pairs.py --dry-run
python3 -B /dev/shm/geopilot-p13-05-raster-pairs-a2d2e68.TONYtP/run-raster-pairs.py --run --case dem-s --case remote-s
python3 -B /dev/shm/geopilot-p13-05-raster-pairs-a2d2e68.TONYtP/run-raster-pairs.py --run --case dem-m --case dem-l --case remote-l
```

不传 `--case` 会依次跑 DEM S/M/L 和遥感 S/L。默认结果目录为 `/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/artifacts/test-results/p13-05-raster-pairs.a2d2e68.TONYtP`。使用 `--output-root` 时，选择同一设备上的新目录或同一启动器此前创建的目录。以同样参数重启可复用完成的单侧记录并继续未完成部分。启动器先检查看板、获取栅格与修正版矢量共用的历史 M 只读租约和结果目录租约，再验证冻结全树。其他 GIS 进程由主控排程。

每侧每场景分别完成进程冷和服务暖两组，每组两次预热和五次正式样本。全量为 40 次预热和 100 次正式样本。场景间交替哪一侧先跑，比较始终从 base 到 candidate。每个 side 的容器名、命令、stdout/stderr 和原始退出码保存在对应 `attempt.*` 下。取得 14 个不同的持久终态、完整指纹、已执行步骤的归一化请求及配置回执后，用密封比较器自检。正式业务失败且证据完整的 side 会被标记完成，原退出码 1 原样保留。部分失败保留原目录；重启在新的 attempt 运行未完成 side。每次前后比较各存一份 `pair.*/before-after.json`、命令、stderr 和退出码。比较器对前测没有成功样本的组只分别报告失败与成功结果。

## 冻结边界

源码使用持久修正版计划的两个完整只读导出，提交为 `977ab412d9f6e7558d22a5c431fac0ada90b07be` 和 `a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc`。候选导出已包含父进程依赖的延迟导入修复，启动器核对该模块及整树清单指纹。使用同一冻结配置包装器和比较器、相同固定镜像、Python/QGIS 挂载以及相同线程与缓存设置。配置包装器针对实际执行记录配置和 Python PROJ 前后指纹。1800 秒只限于端到端观察，生产步骤原 60 秒时限从冻结配置调用链继承。

每个配对都将同一个 P13-04 原始输入根挂载为只读 `/inputs`。五组输入及输出位于历史物理盘 `/dev/sda2`、ext4、UUID `c826a6ab-37ec-4c81-a661-7a83882273fb`。dry-run 只读取小型 manifest、历史报告和冻结脚本以及文件元数据。正式运行会由现有栅格 runner 校验实际文件字节，输出阶段再核对与 P13-04 的指纹。每一侧都以同样的只读输入、设备及完整 runner 规则执行。

P13-04 的记录耗时单侧合计约 79.07 分钟。其中 DEM S/M/L 分别约 2.69、16.72、23.84 分钟，遥感 S/L 分别约 2.11、33.72 分钟。这些时长是已记录 run、初始化、登记和设置的累计值，另有包装器、读取校验和组级开销。若两侧与历史单侧等耗，总计约 158.15 分钟。候选耗时仍需实测。

## 本次校验

```bash
bash -n /dev/shm/geopilot-p13-05-raster-pairs-a2d2e68.TONYtP/check.sh
bash /dev/shm/geopilot-p13-05-raster-pairs-a2d2e68.TONYtP/check.sh
```

`proof/` 保存语法、全量/单档 dry-run、八个小夹具测试、历史输入与时长的命令、原始输出及退出码。夹具的 Docker 行为被替换，前后证据仍由真实密封比较器读取。验证了旧候选输出根的拒绝路径和修正版双侧挂载，八项测试通过。正式计时由主控调度。启动器及证据目前在 tmpfs，重启前需单独保存方可留存。
