"""Small orchestration and evidence fixtures. No Docker, native GIS or large fixture reads."""
import hashlib
import importlib.util
import json
import os
import shlex
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("raster_pairs", HERE / "run-raster-pairs.py")
launcher = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(launcher)


def write_json(path, value):
    path.write_text(json.dumps(value) + "\n", encoding="utf-8")


class PlanTest(unittest.TestCase):
    def test_real_metadata_dry_run_is_read_only_and_selectable(self):
        with tempfile.TemporaryDirectory(dir=HERE) as scratch:
            dummy = Path(scratch) / "docker"
            dummy.write_text("#!/bin/sh\nprintf unexpected > \"$0.called\"\nexit 91\n")
            dummy.chmod(0o700)
            environment = dict(os.environ, PATH=f"{scratch}:{os.environ['PATH']}", PYTHONDONTWRITEBYTECODE="1")
            for selection in ([], ["--case", "remote-l"]):
                result = subprocess.run([sys.executable, "-B", SPEC.origin, "--dry-run", *selection],
                                        env=environment, check=True, text=True, capture_output=True)
                self.assertFalse(dummy.with_suffix(".called").exists())
                self.assertFalse(launcher.DEFAULT_OUTPUT.exists())
                lines = result.stdout.splitlines()
                commands = [shlex.split(line) for line in lines if line.startswith("docker ")]
                selected = list(launcher.CASES) if not selection else [selection[-1]]
                self.assertEqual(len(commands), len(selected) * 2)
                self.assertEqual(sum("--require-runtime-configuration" in line for line in lines), len(selected))
                for case, (a, b) in zip(selected, zip(commands[::2], commands[1::2]), strict=True):
                    profile, tier, *_ = launcher.CASES[case]
                    for cmd in (a, b):
                        self.assertIn(launcher.IMAGE, cmd)
                        self.assertIn("PROJ_NETWORK=OFF", cmd)
                        self.assertIn(f"type=bind,src={launcher.HISTORY}/{profile}/inputs,dst=/inputs,readonly", cmd)
                        self.assertIn(f"benchmarks/datasets/{profile}.yaml", cmd)
                        self.assertIn("--pull=never", cmd)
                        self.assertNotIn("--pilot", cmd)
                        self.assertEqual(cmd[cmd.index("--tiers") + 1], tier)
                        self.assertEqual(cmd[cmd.index("--cache") + 1:cmd.index("--cache") + 3], list(launcher.CACHE))
                        self.assertEqual(cmd[cmd.index("--timeout") + 1], "1800")
                    self.assertEqual({a[-1], b[-1]}, set(launcher.COMMITS.values()))
                    for cmd, side in zip((a, b), launcher.sides(case), strict=True):
                        self.assertIn(f"type=bind,src={launcher.PLAN}/{side},dst=/project,readonly", cmd)
                        self.assertEqual(cmd[-1], launcher.COMMITS[side])
                self.assertNotIn("p13-05-vector-m-plan.8IVSI6/", result.stdout)
                self.assertIn("p13-05-raster-pairs.a2d2e68.", str(launcher.DEFAULT_OUTPUT))
            bad = subprocess.run([sys.executable, "-B", SPEC.origin, "--case", "dem-s", "--case", "dem-s"],
                                 env=environment, check=False, text=True, capture_output=True)
            self.assertEqual(bad.returncode, 2)
            self.assertIn("Duplicate cases", bad.stderr)
            self.assertFalse(dummy.with_suffix(".called").exists())

    def test_readonly_lease_rejects_contention_without_changing_file(self):
        with tempfile.TemporaryDirectory(dir=HERE) as scratch:
            lock = Path(scratch) / "lock"
            lock.write_text("fixture lock")
            with launcher.lease(lock, read_only=True):
                with self.assertRaisesRegex(ValueError, "formal measurement already holds"):
                    with launcher.lease(lock, read_only=True):
                        self.fail("another launch acquired the same lease")
            self.assertEqual(lock.read_text(), "fixture lock")


class EvidenceTest(unittest.TestCase):
    def setUp(self):
        scratch = tempfile.TemporaryDirectory(dir=HERE)
        self.addCleanup(scratch.cleanup)
        self.root = Path(scratch.name)
        self.contract = launcher.input_contract("dem-s")

    def fixture(self, side, passes, attempt=None):
        _, family, tier, sha, files = self.contract
        is_mock_docker = attempt is not None
        attempt = attempt or self.root / side / "attempt.sample"
        evidence = attempt / "evidence"
        evidence.mkdir(parents=True)
        raw = launcher.read_json(launcher.PLAN / "base/docs/round2/performance/p13-04-raster-method-s-report.json")
        environment = raw["environment"]
        environment["commit"] = launcher.COMMITS[side]
        environment["storage"]["mount_source_and_filesystem"] = "/dev/sda2[/fixture] ext4"
        expected = [{"tier": tier, "workload": "method", "cache": cache} for cache in launcher.CACHE]
        report = {
            "mode": "formal", "family": family, "status": "PASS" if passes else "FAIL",
            "implementation_sha256": launcher.RUNNER, "environment": environment, "expected_groups": expected,
            "benchmark_manifest_sha256": raw["benchmark_manifest_sha256"], "profile_sha256": raw["profile_sha256"],
            "inputs": {tier: {"directory": f"/inputs/{tier}", "generation_ns": None, "manifest_sha256": sha,
                              "first_fingerprints": files, "last_fingerprints": files}},
            "groups": [{**group, "interrupted": False, "expected_trials": 7, "observed_trials": 7,
                        "input_fingerprints_before": files, "input_fingerprints_after": files,
                        "trial_failures": 0 if passes else 7,
                        "operations": {"method": {"passed": 5 if passes else 0,
                                                  "failed": 0 if passes else 5, "missing": 0}}}
                       for group in expected],
        }
        write_json(evidence / "report.json", report)
        snapshot = {"schema_version": 1, "config": {"methods": {}, "tools": {}, "runner_bindings": {}, "sensors": {}},
                    "python_proj": {"version": "fixture", "epsg_version": "fixture", "network_enabled": False,
                                    "search_roots": [{"proj.db": "0" * 64}], "user_files": None,
                                    "auxiliary_databases": []}}
        payload = json.dumps(snapshot, sort_keys=True, separators=(",", ":"))
        snapshot["sha256"] = hashlib.sha256(payload.encode()).hexdigest()
        write_json(evidence / "runtime-configuration.json",
                   {"schema_version": 1, "before": snapshot, "after": snapshot,
                    "report_files": {"report.json": launcher.digest(evidence / "report.json")}})
        if not is_mock_docker:
            (attempt / "exit-code").write_text("0\n" if passes else "1\n")
        tool = {"id": "synthetic_fixture", "version": "v1"}
        step = {"step_key": "fixture", "tool": tool, "parameters": {"value": 7},
                "status": "SUCCEEDED", "exit_code": 0}
        rows = []
        for cache in launcher.CACHE:
            for index in range(1, 8):
                run_id = f"fixture-{side}-{cache}-{index}"
                rows.append({
                    "family": family, "tier": tier, "workload": "method", "cache": cache, "index": index,
                    "kind": "warmup" if index <= 2 else "measurement",
                    "manifest_sha256": sha, "sample_id": f"{family}/{tier}/method/{cache}/{index:02d}",
                    "run_id": run_id, "executed_steps": [step], "status": report["status"], "wall_ns": 1,
                    "method": "synthetic_fixture", "confirmed_parameters": {},
                    "parameters_sha256": hashlib.sha256(b"{}").hexdigest(),
                    "run_state": {"run_id": run_id, "execution_status": "SUCCEEDED" if passes else "FAILED",
                                  "check_status": "PASSED" if passes else "NOT_CHECKED",
                                  "error": None if passes else {"code": "PROCESS_TIMEOUT"}},
                    "correctness": {"fixture": True} if passes else None,
                    "telemetry": {"steps": [{**step, "processes": [{"phase": "execute", "exit_code": 0}]}]},
                })
        (evidence / "trials.jsonl").write_text("".join(json.dumps(row) + "\n" for row in rows))
        return attempt

    def test_timeout_to_success_comparison_has_no_success_speedup(self):
        before = self.fixture("base", passes=False)
        after = self.fixture("candidate", passes=True)
        a = launcher.verify_attempt(before, "base", self.contract)
        b = launcher.verify_attempt(after, "candidate", self.contract)
        launcher.compare(a, b, self.root, "paired")
        result = launcher.read_json(self.root / "paired.json")
        self.assertTrue(result["candidate_all_measurements_pass"])
        for group in result["groups"]:
            self.assertEqual(group["before"]["failure_codes"], {"PROCESS_TIMEOUT": 5})
            self.assertEqual(group["after"]["counts"]["PASS"], 5)
            self.assertEqual(group["successful_sample_deltas"], {})
            self.assertEqual(group["step_parameter_evidence"], "normalized_step_requests")

    def test_report_requires_receipt_and_original_exit_code(self):
        attempt = self.fixture("base", passes=False)
        (attempt / "exit-code").write_text("0\n")
        with self.assertRaisesRegex(ValueError, "exit mismatch"):
            launcher.verify_attempt(attempt, "base", self.contract)
        (attempt / "exit-code").write_text("1\n")
        (attempt / "evidence/runtime-configuration.json").unlink()
        with self.assertRaises(FileNotFoundError):
            launcher.verify_attempt(attempt, "base", self.contract)

    def test_rejects_different_input_and_missing_step_evidence(self):
        attempt = self.fixture("base", passes=False)
        _, family, tier, sha, _ = self.contract
        with self.assertRaisesRegex(ValueError, "Unexpected report input"):
            launcher.verify_attempt(attempt, "base", (None, family, tier, sha, {}))
        path = attempt / "evidence/trials.jsonl"
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        del rows[0]["executed_steps"]
        path.write_text("".join(json.dumps(row) + "\n" for row in rows))
        with self.assertRaisesRegex(ValueError, "missing normalized step"):
            launcher.verify_attempt(attempt, "base", self.contract)

    def test_mock_live_path_pairs_and_resumes_with_actual_comparator(self):
        output = self.root / "output"
        lock = self.root / "held"
        lock.touch()
        board = self.root / "board"
        board.write_text("| P13-03 | | | | | ACCEPTED |\n"
                         "| P13-04 | | | | | ACCEPTED |\n"
                         "| P13-05 | | | | | DOING |\n")
        actual_run = subprocess.run
        calls = []

        def process(cmd, **kwargs):
            if cmd[:2] != ["docker", "run"]:
                return actual_run(cmd, **kwargs)
            side = next(side for side, commit in launcher.COMMITS.items() if cmd[-1] == commit)
            bind = next(arg for arg in cmd if arg.startswith("type=bind,src=") and arg.endswith(",dst=/scratch"))
            scratch = Path(bind.removeprefix("type=bind,src=").removesuffix(",dst=/scratch"))
            calls.append(side)
            passes = side == "candidate"
            self.fixture(side, passes, scratch)
            return subprocess.CompletedProcess(cmd, int(not passes))

        with (patch.object(launcher, "VECTOR_LOCK", lock), patch.object(launcher, "BOARD", board),
              patch.object(launcher, "check_disk"), patch.object(launcher, "check_seals"),
              patch.object(subprocess, "check_output", return_value=""),
              patch.object(subprocess, "run", side_effect=process)):
            contracts = {"dem-s": self.contract}
            for _ in range(2):
                launcher.run_live(output, ["dem-s"], contracts, {"synthetic": True})
        self.assertEqual(calls, ["base", "candidate"])
        comparisons = list((output / "dem-s").glob("pair.*/before-after.json"))
        self.assertEqual(len(comparisons), 2)
        for result in comparisons:
            self.assertTrue(launcher.read_json(result)["candidate_all_measurements_pass"])

    def test_old_plan_output_is_rejected_before_docker(self):
        old = self.root / "old-output"
        old.mkdir()
        write_json(old / "plan.json", {
            "commits": {**launcher.COMMITS, "candidate": "e874a0f7510ad7d99e0e623f211e0f5afeb411cd"},
        })
        lock = self.root / "existing-vector.lock"
        lock.touch()
        board = self.root / "board"
        board.write_text("| P13-03 | | | | | ACCEPTED |\n"
                         "| P13-04 | | | | | ACCEPTED |\n"
                         "| P13-05 | | | | | DOING |\n")
        with (patch.object(launcher, "VECTOR_LOCK", lock), patch.object(launcher, "BOARD", board),
              patch.object(subprocess, "check_output", side_effect=AssertionError("unexpected Docker call"))):
            contracts = {"dem-s": self.contract}
            with self.assertRaisesRegex(ValueError, "Output is not owned"):
                launcher.run_live(old, ["dem-s"], contracts, launcher.session_identity(contracts))
        self.assertEqual([item.name for item in old.iterdir()], ["plan.json"])

    def test_resume_uses_existing_attempt_without_container(self):
        attempt = self.fixture("base", passes=False)
        case = self.root / "dem-s"
        case.mkdir()
        (self.root / "base").rename(case / "base")
        (case / "base/COMPLETED").write_text(attempt.name + "\n")
        with patch.object(launcher, "command", side_effect=AssertionError("resume attempted to run Docker")):
            reused = launcher.measure("dem-s", "base", self.root, self.contract)
        self.assertEqual(reused, case / "base" / attempt.name / "evidence")


if __name__ == "__main__":
    unittest.main(verbosity=2)
