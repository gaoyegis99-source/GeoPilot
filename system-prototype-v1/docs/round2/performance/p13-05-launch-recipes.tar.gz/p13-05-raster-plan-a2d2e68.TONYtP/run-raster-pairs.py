#!/usr/bin/env python3
"""Start, resume, or print the sealed P13-05 raster method pairs."""
import argparse
import contextlib
import fcntl
import hashlib
import json
import os
import re
import shlex
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
RESULTS = REPO / "artifacts/test-results"
PLAN = RESULTS / "p13-05-revised-pair-source.a2d2e68"
HISTORY = RESULTS / "p13-04-formal-tools.pN5DMz"
VECTOR_LOCK = Path("/mnt/datab/geopilot-p13-05-vector-m.8IVSI6/.orchestrator.lock")
DEFAULT_OUTPUT = RESULTS / f"p13-05-raster-pairs.a2d2e68.{HERE.name.rsplit('.', 1)[-1]}"
BOARD = REPO / "plans-round2/06_PROGRESS/TASK_BOARD.md"
DISK = ("/dev/sda2", "ext4", "8:2", "c826a6ab-37ec-4c81-a661-7a83882273fb")
IMAGE = "sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87"
RUNTIME = REPO / ".environments/p13-native"
QGIS = REPO / ".environments/qgis-deb/usr/bin"
CACHE = ("process_cold", "warm")
COMMITS = {
    "base": "977ab412d9f6e7558d22a5c431fac0ada90b07be",
    "candidate": "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc",
}
TREE_PROOFS = {
    "base": "19bf6a3df70aee71ea6bf87f690a7b13b28b2cfc08ad3e79aa01c3e72b6e4277",
    "candidate": "ff853a59c4dea94bd0cf1046c34d1980904a3661744ee3827e7911303b51fac7",
}
REVISED_STAGING = (
    "src/geopilot/execution/output_staging.py",
    "7b761ec727568d77a6f9a56e903df2f45d1b5154b80fc0d21118b59e56180b88",
)
RUNNER = {
    "run_raster.py": "9a4a9bc061d770c1fce631895bff25f819751e5a98291440f231e5ed267a3729",
    "_raster_metrics.py": "d23eb107cd1ec19eb040ca391831d8028c4523ff783f09314fdc22e05057722e",
    "_raster_reference.py": "eb54e29bbee34e05952e699e4c9b4bc99f3f342ece30773280836eec02cb19a3",
    "_raster_workloads.py": "fa6bc12a43c93487c8159feb7fdf3529ac21b0bc0acaf436fe7a73591b54dd8d",
}
WRAPPER = {
    "run_with_runtime_configuration.py": "5a9a838b955f88aeddc5ec44e8627247bf5e0eb1289f55bd1a525012cee35d98",
    "_runtime_config.py": "70df5d4dd1eca53f43b229851b24a3d83f098dd07c6a54c49566529350d7e00d",
}
COMPARATOR = "efb1bb22c92ffd42eab53292dc41868b30f61cf4b9f7473fba82efaa25e2804c"
QGIS_FILES = {
    "qgis_process": "4d3593bac0500aaf4097b739052728aec92545c5a939e53d7b3cf0a63950c663",
    "qgis_process.bin": "7f5e51331df13a1b7ba2ff74002d4646a2f5b697beb8f6157b0bfa13b9f60b73",
}
CASES = {
    "dem-s": ("raster", "S", "raster-method-s", "cf05c1d2cd21f27c66a97cf22d6a66c1e3889efc89bf7b984f0505cd5983d80a"),
    "dem-m": ("raster", "M", "raster-method-m", "24e15649d2777503ff2c3ca7544de9b6ca038d4ffaf04f6fa16b01ba271169f7"),
    "dem-l": ("raster", "L", "raster-method-l", "a9c670131aa9d4feab76b63e9ad38c75a1822ac0bd8a8bb1808fadc7fa5771ff"),
    "remote-s": ("remote-sensing", "S", "remote-method-sm", "2f22bce7d22a44f21f142bf5d2735d711a9dec4e3c6e1024ef0ae94436f3b4a3"),
    "remote-l": ("remote-sensing", "L", "remote-method-l", "7ca5d30de46b40955845aadb312ff02b6653a11fc708d8aeaaf8d404fb769e04"),
}
RUNTIME_ENV = (
    "HOME=/tmp", "QT_QPA_PLATFORM=offscreen", "QGIS_CUSTOM_CONFIG_PATH=/tmp/geopilot-qgis",
    "PYTHONDONTWRITEBYTECODE=1", "OPENBLAS_NUM_THREADS=1", "OMP_NUM_THREADS=1",
    "GDAL_NUM_THREADS=1", "MKL_NUM_THREADS=1", "PROJ_NETWORK=OFF", "GDAL_CACHEMAX=64",
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def check_digest(path, expected):
    require(digest(path) == expected, f"Changed SHA-256: {path}")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def mount(path):
    return tuple(subprocess.check_output(
        ["findmnt", "-n", "-o", "SOURCE,FSTYPE,MAJ:MIN,UUID", "--target", path],
        text=True,
    ).split())


def check_disk(path):
    require(mount(path) == DISK, f"Expected historical {DISK} at {path}")


def input_contract(case):
    profile, tier, report_name, expected_sha = CASES[case]
    root = HISTORY / profile / "inputs"
    folder = root / tier
    path = folder / "manifest.json"
    require(folder.resolve(strict=True) == folder, f"Unexpected input alias: {folder}")
    check_disk(folder)
    require(stat.S_ISREG(path.lstat().st_mode), f"Expected original manifest: {path}")
    check_digest(path, expected_sha)
    manifest = read_json(path)
    family = profile.replace("-", "_")
    require((manifest["family"], manifest["tier"]) == (family, tier), f"Invalid fixture identity: {path}")
    files = {}
    for record in manifest["files"]:
        relative = Path(record["path"])
        require(not relative.is_absolute() and ".." not in relative.parts, f"Unsafe fixture path: {relative}")
        target = folder / relative
        metadata = target.lstat()
        require(target.resolve(strict=True) == target and stat.S_ISREG(metadata.st_mode)
                and metadata.st_dev == folder.stat().st_dev and metadata.st_size == record["bytes"],
                f"Fixture metadata changed: {target}")
        role = record["role"]
        require(role not in files, f"Duplicate fixture role: {role}")
        files[role] = {key: record[key] for key in ("path", "bytes", "sha256")}
    history_file = PLAN / "base/docs/round2/performance" / f"p13-04-{report_name}-report.json"
    old = read_json(history_file)["inputs"][tier]
    require(expected_sha == old["manifest_sha256"]
            and files == old["first_fingerprints"] == old["last_fingerprints"],
            f"Fixture differs from P13-04 archived fingerprint: {folder}")
    return root, family, tier, expected_sha, files


def command(case, side, attempt, name):
    profile, tier, _, _ = CASES[case]
    cmd = ["docker", "run", "--rm", "--pull=never", "--name", name, "--network", "none",
           "--user", f"{os.getuid()}:{os.getgid()}", "--entrypoint", "/runtime/venv/bin/python",
           "--workdir", "/project"]
    for item in RUNTIME_ENV:
        cmd.extend(("-e", item))
    for source, target, readonly in (
        (PLAN / side, "/project", True),
        (RUNTIME, "/runtime", True),
        (QGIS / "qgis_process", "/usr/bin/qgis_process", True),
        (QGIS / "qgis_process.bin", "/usr/bin/qgis_process.bin", True),
        (HISTORY / profile / "inputs", "/inputs", True),
        (attempt, "/scratch", False),
    ):
        cmd.extend(("--mount", f"type=bind,src={source},dst={target}" + (",readonly" if readonly else "")))
    cmd.extend((IMAGE, "scripts/bench/run_with_runtime_configuration.py",
                "--kind", "raster", "--config", "/project/config", "--output", "/scratch/evidence", "--",
                "--profile", f"benchmarks/datasets/{profile}.yaml", "--tiers", tier, "--workload", "method",
                "--cache", *CACHE, "--input-root", "/inputs", "--timeout", "1800", "--source-commit", COMMITS[side]))
    return cmd


def verify_attempt(attempt, side, contract):
    _, family, tier, manifest_sha, files = contract
    evidence = attempt / "evidence"
    report_path = evidence / "report.json"
    report = read_json(report_path)
    code = int((attempt / "exit-code").read_text())
    require(code in (0, 1) and report["status"] == ("FAIL" if code else "PASS")
            and report["mode"] == "formal" and not report.get("error"),
            f"Attempt incomplete or container/report exit mismatch: {attempt}")
    receipt = read_json(evidence / "runtime-configuration.json")
    require(receipt["schema_version"] == 1 and receipt["before"] == receipt["after"]
            and receipt["report_files"] == {"report.json": digest(report_path)},
            f"Unsealed report: {attempt}")
    environment = report["environment"]
    require(report["family"] == family and environment["commit"] == COMMITS[side]
            and report["implementation_sha256"] == RUNNER,
            f"Unexpected method runner identity: {attempt}")
    storage = environment["storage"]["mount_source_and_filesystem"]
    require(re.sub(r"\[.*\]", "", storage) == f"{DISK[0]} {DISK[1]}",
            f"Unexpected report storage: {storage}")
    require(set(report["inputs"]) == {tier}, f"Unexpected input tiers: {attempt}")
    fixture = report["inputs"][tier]
    require(fixture["directory"] == f"/inputs/{tier}" and fixture["generation_ns"] is None
            and fixture["manifest_sha256"] == manifest_sha
            and fixture["first_fingerprints"] == fixture["last_fingerprints"] == files,
            f"Unexpected report input identity: {attempt}")
    expected = [{"tier": tier, "workload": "method", "cache": cache} for cache in CACHE]
    groups = report["groups"]
    require(report["expected_groups"] == expected and len(groups) == 2,
            f"Unexpected formal group plan: {attempt}")
    for group, identity in zip(groups, expected, strict=True):
        require(all(group[key] == value for key, value in identity.items()) and not group["interrupted"]
                and group["expected_trials"] == group["observed_trials"] == 7
                and group["input_fingerprints_before"] == group["input_fingerprints_after"] == files,
                f"Incomplete group or different input: {attempt}")
    rows = [json.loads(line) for line in (evidence / "trials.jsonl").read_text().splitlines()]
    require(len(rows) == 14, f"Expected 14 raw trials: {attempt}")
    run_ids = set()
    for row, (cache, index) in zip(rows, ((cache, n) for cache in CACHE for n in range(1, 8)), strict=True):
        run = row.get("run_state") or {}
        run_id = row.get("run_id")
        terminal = run.get("execution_status") in {"FAILED", "CANCELLED"} or run.get("check_status") in {
            "PASSED", "WARNING", "FAILED",
        }
        require((row["family"], row["tier"], row["workload"], row["cache"], row["index"], row["kind"],
                 row["manifest_sha256"], row["sample_id"])
                == (family, tier, "method", cache, index, "warmup" if index <= 2 else "measurement",
                    manifest_sha, f"{family}/{tier}/method/{cache}/{index:02d}")
                and row["status"] in ("PASS", "FAIL") and run_id and run_id not in run_ids
                and run_id == run.get("run_id") and terminal and isinstance(row.get("executed_steps"), list),
                f"Unexpected trial identity, missing terminal run, or missing normalized step evidence: {attempt}")
        run_ids.add(run_id)
    return evidence


def compare(before, after, log_dir, label):
    cmd = [sys.executable, PLAN / "runner/run_memory_profile.py", "--kind", "raster",
           "--require-runtime-configuration", "--before", before, "--after", after]
    (log_dir / f"{label}.command").write_text(shlex.join(map(str, cmd)) + "\n")
    with (log_dir / f"{label}.json").open("wb") as out, (log_dir / f"{label}.stderr").open("wb") as err:
        code = subprocess.run(cmd, stdout=out, stderr=err, check=False).returncode
    (log_dir / f"{label}.exit-code").write_text(f"{code}\n")
    require(code == 0, f"Frozen comparator rejected evidence: {log_dir}/{label}.stderr")


@contextlib.contextmanager
def lease(path, read_only=False):
    with path.open("rb" if read_only else "a+b") as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError(f"A formal measurement already holds {path}") from error
        yield


def check_seals(live=False):
    commit_record = PLAN / "proof/candidate-commit"
    require(commit_record.read_text().strip() == COMMITS["candidate"], f"Changed candidate commit: {commit_record}")
    name, sha = REVISED_STAGING
    check_digest(PLAN / "candidate" / name, sha)
    for side, expected in TREE_PROOFS.items():
        manifest = PLAN / "proof" / f"{side}-tree.sha256"
        check_digest(manifest, expected)
        for name, sha in (RUNNER | WRAPPER).items():
            check_digest(PLAN / side / "scripts/bench" / name, sha)
        if live:
            subprocess.run(["sha256sum", "--quiet", "-c", manifest], cwd=PLAN / side, check=True)
    for name, sha in (WRAPPER | {"run_memory_profile.py": COMPARATOR}).items():
        check_digest(PLAN / "runner" / name, sha)
    if live:
        require((RUNTIME / "venv/bin/python").is_file(), f"Missing frozen runtime: {RUNTIME}")
        for name, sha in QGIS_FILES.items():
            check_digest(QGIS / name, sha)


def session_identity(contracts):
    return {"script_sha256": digest(Path(__file__)), "plan": str(PLAN), "commits": COMMITS,
            "tree_proofs": TREE_PROOFS, "wrapper": WRAPPER, "comparator": COMPARATOR,
            "image": IMAGE, "disk": list(DISK),
            "input_manifest_sha256": {case: contract[3] for case, contract in contracts.items()}}


def measure(case, side, root, contract):
    folder = root / case / side
    folder.mkdir(parents=True, exist_ok=True)
    completion = folder / "COMPLETED"
    if completion.exists():
        name = completion.read_text().strip()
        require(re.fullmatch(r"attempt\.[a-z0-9_]+", name), f"Invalid completion pointer: {completion}")
        evidence = verify_attempt(folder / name, side, contract)
        print(f"reuse {case} {side} {evidence}", flush=True)
        return evidence
    attempt = Path(tempfile.mkdtemp(prefix="attempt.", dir=folder))
    name = f"geopilot-p1305-{case}-{side}-{attempt.name.split('.', 1)[1]}"
    cmd = command(case, side, attempt, name)
    (attempt / "container-name").write_text(name + "\n")
    (attempt / "command.log").write_text(f"storage={DISK[0]} {DISK[1]} {DISK[2]} {DISK[3]}\n"
                                         + shlex.join(cmd) + "\n")
    print(f"start {case} {side} container={name} log={attempt / 'container.log'}", flush=True)
    with (attempt / "container.log").open("xb") as log:
        code = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=False).returncode
    (attempt / "exit-code").write_text(f"{code}\n")
    print(f"end {case} {side} container={name} exit={code}", flush=True)
    evidence = verify_attempt(attempt, side, contract)
    compare(evidence, evidence, attempt, "self-comparison")
    with completion.open("x") as marker:
        marker.write(attempt.name + "\n")
    return evidence


def run_live(output, selected, contracts, identity):
    status = {}
    for line in BOARD.read_text().splitlines():
        fields = line.split("|")
        if len(fields) >= 8 and fields[1].strip() in ("P13-03", "P13-04", "P13-05"):
            status[fields[1].strip()] = fields[6].strip()
    require(status.get("P13-03") == status.get("P13-04") == "ACCEPTED" and status.get("P13-05") == "DOING",
            f"Formal raster prerequisites unavailable: {status}")
    with lease(VECTOR_LOCK, read_only=True):
        if not output.exists():
            output.mkdir(mode=0o700)
            (output / "plan.json").write_text(json.dumps(identity, indent=2) + "\n")
        else:
            require(read_json(output / "plan.json") == identity, f"Output is not owned by this plan: {output}")
        check_disk(output)
        with lease(output / ".orchestrator.lock"):
            check_seals(live=True)
            listed = subprocess.check_output(
                ["docker", "ps", "--format", "{{.Names}}"], text=True).splitlines()
            for marker in output.glob("*/*/attempt.*/container-name"):
                require(marker.read_text().strip() not in listed, f"Earlier container remains active: {marker}")
            for case in selected:
                results = {side: measure(case, side, output, contracts[case]) for side in sides(case)}
                paired = Path(tempfile.mkdtemp(prefix="pair.", dir=output / case))
                compare(results["base"], results["candidate"], paired, "before-after")
                print(f"paired {case} {paired / 'before-after.json'}", flush=True)


def sides(case):
    if list(CASES).index(case) % 2:
        return ("candidate", "base")
    return ("base", "candidate")


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--dry-run", action="store_true", help="check sealed metadata and print commands (default)")
    modes.add_argument("--run", action="store_true", help="execute formal pairs under the measurement leases")
    parser.add_argument("--case", choices=CASES, action="append", help="repeat to select specific pairs")
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    selected = args.case or list(CASES)
    require(len(set(selected)) == len(selected), "Duplicate cases")
    output = args.output_root
    require(output.is_absolute() and "," not in str(output) and output.resolve() == output
            and output.parent.is_dir(), "Expected an absolute output directory with an existing canonical parent")
    check_disk(output.parent)
    check_seals()
    contracts = {case: input_contract(case) for case in CASES}
    identity = session_identity(contracts)
    if args.run:
        run_live(output, selected, contracts, identity)
    else:
        print(f"dry-run disk={DISK} output={output} scenarios={len(selected)} planned_trials={28 * len(selected)} "
              "warmup_per_group=2 measurements_per_group=5")
        for case in selected:
            print(f"input {case} manifest={contracts[case][3]} bytes={sum(item['bytes'] for item in contracts[case][4].values())}")
            for side in sides(case):
                attempt = output / case / side / "attempt.NEW"
                print(shlex.join(command(case, side, attempt, f"geopilot-p1305-{case}-{side}-NEW")))
            print(shlex.join([sys.executable, str(PLAN / "runner/run_memory_profile.py"), "--kind", "raster",
                             "--require-runtime-configuration", "--before",
                             str(output / case / "base/attempt.NEW/evidence"), "--after",
                             str(output / case / "candidate/attempt.NEW/evidence")]))


if __name__ == "__main__":
    try:
        main()
    except (KeyError, OSError, TypeError, ValueError, subprocess.CalledProcessError) as error:
        print(f"raster pairs: {error}", file=sys.stderr)
        sys.exit(2)
