nice -n 19 taskset -c 31 python3 -B -m unittest -v test_launcher 
