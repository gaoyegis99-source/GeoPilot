nice -n 19 taskset -c 31 python3 -B ./run-raster-pairs.py --dry-run --case remote-l 
