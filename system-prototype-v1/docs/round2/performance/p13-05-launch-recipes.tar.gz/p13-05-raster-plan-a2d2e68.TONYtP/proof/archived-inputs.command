nice -n 19 taskset -c 31 python3 -B ./archive_proof.py 
