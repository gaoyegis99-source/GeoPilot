"""Print only frozen manifest and historical small JSONL metadata for the test record."""
import json
from collections import Counter

from test_launcher import launcher

archive = launcher.PLAN / "base/docs/round2/performance"
phases = "wall_ns", "service_initialization_ns", "asset_registration_ns", "setup_ns"
total = 0
for case, (_, tier, stem, _) in launcher.CASES.items():
    root, family, tier, digest, files = launcher.input_contract(case)
    with (archive / f"p13-04-{stem}-trials.jsonl").open() as stream:
        rows = [row for row in map(json.loads, stream) if row["tier"] == tier]
    counts = Counter(row["status"] for row in rows)
    duration = sum(row.get(field, 0) or 0 for row in rows for field in phases) / 1e9
    total += duration
    print(json.dumps({"case": case, "family": family, "tier": tier, "input_root": str(root),
                      "storage": launcher.mount(root), "manifest_sha256": digest, "files": files,
                      "historical_trials": len(rows), "historical_counts": counts,
                      "historical_recorded_run_and_setup_minutes": round(duration / 60, 2)}))
print(f"historic_equivalent_one_side_minutes={total/60:.2f} two_sides_minutes={total/30:.2f}")
print("sums exclude runner group setup, rehashes and wrapper; candidate duration is unknown")
