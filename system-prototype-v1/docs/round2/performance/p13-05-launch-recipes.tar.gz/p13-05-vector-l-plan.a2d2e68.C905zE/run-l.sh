#!/usr/bin/env bash
set -euo pipefail
umask 077

plan="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
repo=/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1
board="$repo/plans-round2/06_PROGRESS/TASK_BOARD.md"
snapshot="$repo/artifacts/test-results/p13-05-revised-pair-source.a2d2e68"
m_output=/mnt/datab/geopilot-p13-05-vector-m.8IVSI6
image=sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87
runtime="$repo/.environments/p13-native"
qgis="$repo/.environments/qgis-deb/usr/bin"
disk_uuid=41500e8e-5be7-438f-b5ff-9caeebd11411
output_root="/mnt/datab/geopilot-p13-05-vector-l.a2d2e68.${plan##*.}"
mode=dry-run
declare -A commits=(
  [base]=977ab412d9f6e7558d22a5c431fac0ada90b07be
  [candidate]=a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc
)
all=(t13-points-intersects t13-lines-intersects t14-split_by_area)
selected=()
command=()

die() {
  printf '%s\n' "$*" >&2
  exit 2
}

usage() {
  printf '%s\n' 'Usage: bash run-l.sh [--dry-run | --run] [--workload NAME ...] [--output-root NEW_OR_OWN_DIRECTORY]' \
    "Workloads: ${all[*]}"
}

while (( $# )); do
  case "$1" in
    --dry-run) mode=dry-run; shift ;;
    --run) mode=run; shift ;;
    --workload)
      (( $# >= 2 )) || die '--workload requires a name'
      case "$2" in
        t13-points-intersects|t13-lines-intersects|t14-split_by_area) ;;
        *) die "Unknown workload: $2" ;;
      esac
      for previous in "${selected[@]}"; do
        [[ "$previous" != "$2" ]] || die "Duplicate workload: $2"
      done
      selected+=("$2"); shift 2 ;;
    --output-root)
      (( $# >= 2 )) || die '--output-root requires a directory'
      output_root="$2"; shift 2 ;;
    --help|-h) usage; exit 0 ;;
    *) usage >&2; die "Unexpected argument: $1" ;;
  esac
done
if (( ${#selected[@]} == 0 )); then selected=("${all[@]}"); fi

[[ "$output_root" = /* && "$output_root" != *,* && ! -L "$output_root" ]] ||
  die 'Output must be an absolute local directory without Docker mount separators or a final symlink'
output_root="$(realpath -m -- "$output_root")"
parent="$(dirname "$output_root")"
[[ -d "$parent" ]] || die "Output parent is missing: $parent"
read -r device filesystem uuid device_number < <(findmnt -n -o SOURCE,FSTYPE,UUID,MAJ:MIN --target "$parent")
[[ "$device $filesystem $uuid $device_number" == "/dev/sdb1 ext4 $disk_uuid 8:17" ]] ||
  die "Expected the frozen /dev/sdb1 ext4 workspace, got $device $filesystem $uuid $device_number"

task_status() {
  awk -F'|' -v task="$1" '
    { id=$2; gsub(/[[:space:]]/, "", id) }
    id == task { gsub(/[[:space:]]/, "", $7); print $7 }
  ' "$board"
}
vector_status="$(task_status P13-03)"
raster_status="$(task_status P13-04)"
if [[ "$mode" == run && ( "$vector_status" != ACCEPTED || "$raster_status" != ACCEPTED ) ]]; then
  die "P13-05 dependencies: P13-03=$vector_status P13-04=$raster_status"
fi

check_source() {
  local side="$1"
  (cd "$snapshot/$side" && sha256sum --quiet -c "$snapshot/proof/$side-tree.sha256")
}

(
  cd "$snapshot"
  sha256sum --quiet -c "$plan/proof/revised-source-identity.sha256"
)
[[ "$(<"$snapshot/proof/candidate-commit")" == "${commits[candidate]}" ]] ||
  die 'Revised candidate commit marker differs'
(cd "$snapshot/runner" && sha256sum --quiet -c "$snapshot/proof/frozen-runner.sha256")
session_identity="$(
  cd "$plan"
  sha256sum run-l.sh proof/{check-side.py,expected-inputs.json,revised-source-identity.sha256} | sha256sum | cut -d ' ' -f 1
)"
printf 'mode=%s P13-03=%s P13-04=%s storage=%s/%s/%s output=%s wait_seconds=600 budget_seconds=null\n' \
  "$mode" "$vector_status" "$raster_status" "$device" "$filesystem" "$uuid" "$output_root"

build_command() {
  local workload="$1" side="$2" attempt="$3" container="$4"
  command=(
    docker run --rm --pull=never --name "$container" --network none --user "$(id -u):$(id -g)"
    --entrypoint /runtime/venv/bin/python --workdir /project
    -e HOME=/tmp -e QT_QPA_PLATFORM=offscreen -e QGIS_CUSTOM_CONFIG_PATH=/tmp/geopilot-qgis
    -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1
    -e GDAL_NUM_THREADS=1 -e MKL_NUM_THREADS=1 -e PROJ_NETWORK=OFF
    --mount "type=bind,src=$snapshot/$side,dst=/project,readonly"
    --mount "type=bind,src=$runtime,dst=/runtime,readonly"
    --mount "type=bind,src=$qgis/qgis_process,dst=/usr/bin/qgis_process,readonly"
    --mount "type=bind,src=$qgis/qgis_process.bin,dst=/usr/bin/qgis_process.bin,readonly"
    --mount "type=bind,src=$attempt,dst=/scratch"
    "$image" scripts/bench/run_with_runtime_configuration.py
    --kind vector --config /project/config --output /scratch/evidence --
    --tier L --workload "$workload" --cache-state process_cold --cache-state warm
    --profile benchmarks/datasets/vector.yaml --wait-seconds 600
    --qgis-process /usr/bin/qgis_process --source-commit "${commits[$side]}"
  )
}

print_command() {
  printf '%q ' "${command[@]}"
  printf '\n'
}

side_order() {
  case "$1" in
    t13-lines-intersects) sides=(candidate base) ;;
    *) sides=(base candidate) ;;
  esac
}

if [[ "$mode" == dry-run ]]; then
  for workload in "${selected[@]}"; do
    side_order "$workload"
    for side in "${sides[@]}"; do
      build_command "$workload" "$side" "$output_root/$workload/$side/attempt.NEW" "geopilot-p1305-L-a2d2e68-${plan##*.}-$workload-$side-NEW"
      print_command
    done
  done
  exit 0
fi

if [[ -f "$m_output/.orchestrator.lock" ]]; then
  exec 8<"$m_output/.orchestrator.lock"
  flock -n 8 || die 'The current M paired batch still owns its measurement window'
fi
check_source base
check_source candidate
[[ -d "$runtime" && -x "$qgis/qgis_process" && -x "$qgis/qgis_process.bin" ]] ||
  die 'The verified original Python/QGIS bindings are unavailable'
(
  cd "$qgis"
  printf '%s\n' \
    '4d3593bac0500aaf4097b739052728aec92545c5a939e53d7b3cf0a63950c663  qgis_process' \
    '7f5e51331df13a1b7ba2ff74002d4646a2f5b697beb8f6157b0bfa13b9f60b73  qgis_process.bin' |
    sha256sum --quiet -c -
)
if [[ ! -e "$output_root" ]]; then
  mkdir -- "$output_root"
  printf '%s\n' "$session_identity" > "$output_root/.p13-05-plan"
else
  [[ -f "$output_root/.p13-05-plan" && "$(<"$output_root/.p13-05-plan")" == "$session_identity" ]] ||
    die "Refusing an existing output directory without this plan's identity: $output_root"
fi
[[ "$(findmnt -n -o SOURCE,UUID --target "$output_root" | xargs)" == "/dev/sdb1 $disk_uuid" ]] ||
  die 'The output directory is on a different physical mount'
exec 9>"$output_root/.orchestrator.lock"
flock -n 9 || die "A paired batch already owns $output_root"
shopt -s nullglob
for marker in "$output_root"/*/*/attempt.*/container-name; do
  name="$(<"$marker")"
  if docker container inspect "$name" >/dev/null 2>&1; then
    die "An earlier container is still active: $name"
  fi
done

verify_side() {
  local evidence="$1" side="$2" workload="$3"
  python3 "$plan/proof/check-side.py" "$evidence" "${commits[$side]}" "$workload"
}

compare() {
  python3 "$snapshot/runner/run_memory_profile.py" --kind vector --require-runtime-configuration \
    --before "$1" --after "$2"
}

declare -A completed
measure_side() {
  local workload="$1" side="$2" side_root="$output_root/$1/$2"
  local attempt name entry
  local -a result
  mkdir -p -- "$side_root"
  if [[ -f "$side_root/COMPLETED" ]]; then
    entry="$(<"$side_root/COMPLETED")"
    [[ "$entry" =~ ^attempt\.[A-Za-z0-9]+$ ]] || die "Invalid completion pointer in $side_root"
    attempt="$side_root/$entry"
    verify_side "$attempt/evidence" "$side" "$workload" >/dev/null
    compare "$attempt/evidence" "$attempt/evidence" >/dev/null
    completed[$side]="$attempt/evidence"
    printf 'resume complete %s %s %s\n' "$workload" "$side" "$attempt"
    return
  fi

  check_source "$side"
  attempt="$(mktemp -d "$side_root/attempt.XXXXXX")"
  name="geopilot-p1305-L-a2d2e68-${plan##*.}-$workload-$side-${attempt##*.}"
  printf '%s\n' "$name" > "$attempt/container-name"
  cp "$snapshot/proof/$side-tree.sha256" "$attempt/source-tree.sha256"
  cp "$snapshot/proof/frozen-runner.sha256" "$attempt/frozen-runner.sha256"
  build_command "$workload" "$side" "$attempt" "$name"
  {
    print_command
    printf '%s %s\n' "$device" "$filesystem"
  } > "$attempt/command.log"
  {
    findmnt -n -o SOURCE,FSTYPE,UUID,MAJ:MIN --target "$attempt"
    cat /proc/loadavg /proc/pressure/io
  } > "$attempt/storage-and-start-load.log"
  date -u +%FT%TZ > "$attempt/started-utc"
  cat "$attempt/command.log"
  set +e
  "${command[@]}" 2>&1 | tee "$attempt/run.log"
  result=("${PIPESTATUS[@]}")
  set -e
  printf '%s\n' "${result[0]}" > "$attempt/container-exit"
  printf '%s\n' "${result[1]}" > "$attempt/logging-exit"
  date -u +%FT%TZ > "$attempt/finished-utc"
  printf 'container exit=%s logging exit=%s %s\n' "${result[@]}" "$attempt"
  check_source "$side"
  if [[ -d "$attempt/evidence" ]]; then
    cp "$attempt/command.log" "$attempt/evidence/command.log"
  fi
  (( result[1] == 0 && result[0] <= 1 )) || die "Attempt incomplete, retained at $attempt"
  verify_side "$attempt/evidence" "$side" "$workload" > "$attempt/shard-verification.json"
  compare "$attempt/evidence" "$attempt/evidence" > "$attempt/self-comparison.json"
  printf '%s\n' "${attempt##*/}" > "$attempt/completed-pointer"
  ln "$attempt/completed-pointer" "$side_root/COMPLETED"
  completed[$side]="$attempt/evidence"
}

for workload in "${selected[@]}"; do
  side_order "$workload"
  for side in "${sides[@]}"; do
    measure_side "$workload" "$side"
  done
  comparison="$(mktemp -d "$output_root/$workload/comparison.XXXXXX")"
  printf '%s\n' "${completed[base]}" "${completed[candidate]}" > "$comparison/evidence-paths"
  compare "${completed[base]}" "${completed[candidate]}" \
    > "$comparison/result.json" 2> "$comparison/stderr.log" ||
    die "Paired comparison failed, see $comparison/stderr.log"
  printf 'paired evidence %s %s/result.json\n' "$workload" "$comparison"
done
