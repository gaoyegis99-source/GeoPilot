"""Exercise shard and paired comparison contracts using small evidence-only fixtures."""

from collections import Counter
from copy import deepcopy
import gzip
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory


proof = Path(__file__).resolve().parent
repo = proof.parents[3]
archive = repo / "docs/round2/performance"
snapshot = repo / "artifacts/test-results/p13-05-revised-pair-source.a2d2e68"
comparator = snapshot / "runner/run_memory_profile.py"
spec = importlib.util.spec_from_file_location("check_side", proof / "check-side.py")
check_side = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check_side)
base_commit = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
candidate_commit = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
image = "sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87"


def rows(path):
    with gzip.open(path, "rt") as stream:
        return [json.loads(line) for line in stream]


def store(path, value):
    path.write_text(json.dumps(value) + "\n")


def write_shard(root, rows, expected, commit, workload):
    root.mkdir(parents=True)
    (root / "input-L").mkdir()
    (root / "input-L/manifest.json").write_bytes(b'{"fixture":"lightweight input, not a GeoPackage"}\n')
    for item in expected["files"]:
        (root / "input-L" / item["path"]).write_bytes(item["path"].encode())
    env = json.loads((archive / "p13-03-L-formal-environment.json").read_text())
    env["source_commit"] = commit
    store(root / "environment.json", env)
    store(root / "inputs.json", {"L": {
        "files_before": expected["files"], "files_after": expected["files"],
        "input_manifest_sha256": expected["input_manifest_sha256"],
    }})
    (root / "command.log").write_text(f"docker run --rm {image}\n/dev/sdb1 ext4\n")
    package = "t14.gpkg" if workload == "t14-split_by_area" else "relations.gpkg"
    fingerprint = next(item for item in expected["files"] if item["path"] == package)
    with (root / "samples.jsonl").open("w") as stream:
        for row in rows:
            row.update(input_manifest_sha256=expected["input_manifest_sha256"],
                       input=fingerprint, input_bytes=fingerprint["bytes"])
            stream.write(json.dumps(row) + "\n")
    counts = Counter((r["cache"], r["phase"], r["status"]) for r in rows)
    groups = [
        {"tier": "L", "workload": workload, "cache": cache, "input_profile": "p13-01",
         **{f"{prefix}_{status.lower()}": counts[cache, phase, status]
            for phase, prefix in (("warmup", "warmup"), ("measurement", "measured"))
            for status in ("PASS", "FAIL", "NOT_RUN")}}
        for cache in check_side.CACHES
    ]
    totals = Counter(r["status"] for r in rows)
    store(root / "summary.json", {
        "probe": False, "finished_utc": "synthetic fixture", "status": "INCOMPLETE" if totals["FAIL"] else "PASS",
        "sample_counts": {status: totals[status] for status in ("PASS", "FAIL", "NOT_RUN")}, "groups": groups,
    })
    snapshot = {"schema_version": 1,
                "config": {key: {"fixture.yaml": "a" * 64} for key in ("methods", "tools", "runner_bindings", "sensors")},
                "python_proj": {"version": "fixture", "epsg_version": "fixture", "network_enabled": False,
                                "search_roots": [{"proj.db": "b" * 64}], "user_files": None, "auxiliary_databases": []}}
    snapshot["sha256"] = sha256(json.dumps(snapshot, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    store(root / "runtime-configuration.json", {
        "schema_version": 1,
        "report_files": {name: check_side.digest(root / name) for name in ("environment.json", "summary.json")},
        "before": snapshot, "after": snapshot,
    })
    (root.parent / "container-exit").write_text("1\n" if totals["FAIL"] else "0\n")
    (root.parent / "logging-exit").write_text("0\n")


def compare(before, after):
    return subprocess.run([sys.executable, "-B", str(comparator), "--kind", "vector",
                           "--require-runtime-configuration", "--before", str(before), "--after", str(after)],
                          text=True, capture_output=True)


expected = json.loads((proof / "expected-inputs.json").read_text())
historical = rows(archive / "p13-03-L-formal-samples.jsonl.gz") + rows(archive / "p13-03-L-remaining-samples.jsonl.gz")
successful = rows(archive / "p13-03-M-samples.jsonl.gz")
expected["input_manifest_sha256"] = sha256(b'{"fixture":"lightweight input, not a GeoPackage"}\n').hexdigest()
for record in expected["files"]:
    name = record["path"].encode()
    record.update(bytes=len(name), sha256=sha256(name).hexdigest())
with TemporaryDirectory(prefix="p13-05-l-fixtures-") as tmp:
    for workload in sorted(check_side.SHARD_WORKLOADS):
        base_rows = [deepcopy(s) for s in historical if s["workload"] == workload]
        exemplar = next(s for s in successful if s["workload"] == workload and s["status"] == "PASS")
        candidate_rows = []
        for old in base_rows:
            row = deepcopy(exemplar)
            row.update(tier="L", cache=old["cache"], phase=old["phase"], repeat=old["repeat"],
                       input_profile="p13-01", run_id="fixture-" + old["run_id"], plan_id="fixture-" + old["plan_id"],
                       correctness=expected["correctness"][workload])
            row["run_status"]["run_id"] = row["run_id"]
            row["telemetry"]["document"]["run_id"] = row["run_id"]
            candidate_rows.append(row)
        before = Path(tmp) / workload / "base/evidence"
        after = Path(tmp) / workload / "candidate/evidence"
        write_shard(before, base_rows, expected, base_commit, workload)
        write_shard(after, candidate_rows, expected, candidate_commit, workload)
        old = check_side.verify_shard(before, base_commit, workload, expected)
        new = check_side.verify_shard(after, candidate_commit, workload, expected)
        assert old["sample_counts"] == {"PASS": 0, "FAIL": 14, "NOT_RUN": 0}
        assert new["sample_counts"] == {"PASS": 14, "FAIL": 0, "NOT_RUN": 0}
        comparison = compare(before, after)
        assert comparison.returncode == 0, comparison.stderr
        paired = json.loads(comparison.stdout)
        assert paired["status"] == "MATCHED_EVIDENCE" and paired["candidate_all_measurements_pass"]
        assert all(g["before"]["wall_ns"]["FAIL"]["samples"] == 5 and g["after"]["wall_ns"]["PASS"]["samples"] == 5
                   and g["successful_sample_deltas"] == {} for g in paired["groups"])
        print(workload, "complete timeouts and successful downstream evidence matched; successful deltas empty")

        bad_timeout = deepcopy(base_rows[0])
        bad_timeout["telemetry"]["document"]["exit_code"] = 0
        bad_candidate = deepcopy(candidate_rows[0])
        bad_candidate["steps"][-1]["parameters"] = {"unexpected": True}
        for row, error in ((bad_timeout, "timeout evidence"), (bad_candidate, "executed tool or parameters differ")):
            try:
                check_side.verify_sample(row, workload, expected["correctness"][workload])
            except ValueError as problem:
                assert error in str(problem), problem
            else:
                raise AssertionError(f"{workload}: accepted malformed {error}")
        (after / "runtime-configuration.json").unlink()
        rejected = compare(before, after)
        assert rejected.returncode != 0 and "Runtime configuration evidence is required" in rejected.stderr
        print(workload, "bad timeout, changed downstream parameters and missing receipt rejected")
