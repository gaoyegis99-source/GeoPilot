"""Independently audit completed candidate rows and replay the strict comparisons."""

from collections import Counter
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
from statistics import median
import subprocess
import sys
from tempfile import TemporaryDirectory


def load(path):
    return json.loads(path.read_bytes())


def rows(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def distribution(values, partial=0):
    return {"samples": len(values), "partial": partial, "median": median(values), "p95_nearest_rank": max(values)}


def resource(values):
    sampled = {"sampled", "partial"}
    return distribution(
        [value["value"] for value in values if value["status"] in sampled],
        sum(value["status"] == "partial" for value in values),
    )


def compare(comparator, left, right):
    return subprocess.check_output((
        sys.executable, "-B", comparator, "--kind", "vector", "--require-runtime-configuration",
        "--before", left, "--after", right,
    ))


def verify(bundle, previous, cold):
    sys.path.insert(0, str(cold / "source"))
    sys.path.insert(0, str(cold))
    from verify_t14_cold import STEP_KEYS, expected_outputs

    workload = "t14-split_by_area"
    candidate = bundle / "candidate"
    current = candidate / "evidence"
    baseline = previous / workload / "base"
    base = baseline / (baseline / "COMPLETED").read_text().strip()
    old = previous / workload / "candidate"
    frozen = old / (old / "COMPLETED").read_text().strip()
    original = base / "evidence"
    comparator = previous / "proof/run_memory_profile.py"
    runner_seal = dict(line.split()[::-1] for line in (candidate / "frozen-runner.sha256").read_text().splitlines())
    assert sha256(comparator.read_bytes()).hexdigest() == runner_seal["run_memory_profile.py"]
    assert (candidate / "container-exit").read_text().strip() == "0"
    assert (candidate / "logging-exit").read_text().strip() == "0"
    comparison = bundle / "comparison/result.json"
    assert not (bundle / "comparison/stderr.log").read_bytes()
    assert compare(comparator, original, current) == comparison.read_bytes()
    assert compare(comparator, current, current) == (candidate / "self-comparison.json").read_bytes()
    assert compare(comparator, original, original) == (base / "self-comparison.json").read_bytes()
    receipt = load(comparison)
    assert (receipt["status"], receipt["before_source"], receipt["after_source"]) == (
        "MATCHED_EVIDENCE", "977ab412d9f6e7558d22a5c431fac0ada90b07be", "fff225f223568921ef2ac56f2b76ee9c4f8cbd29",
    )
    assert receipt["candidate_all_measurements_pass"] and not receipt["same_source"]
    shard = load(candidate / "shard-verification.json")
    assert (shard["source_commit"], shard["workload"], shard["status"]) == (receipt["after_source"], workload, "PASS")
    assert shard["sample_counts"] == {"PASS": 14, "FAIL": 0, "NOT_RUN": 0}
    assert shard["runtime_configuration_sha256"] == receipt["runtime_configuration"]["sha256"]
    all_groups = {group["group"][2]: group for group in receipt["groups"]}
    caches = ("process_cold", "warm")
    assert set(all_groups) == set(caches)
    new_rows = rows(current / "samples.jsonl")
    base_rows = rows(original / "samples.jsonl")
    frozen_rows = rows(frozen / "evidence/samples.jsonl")
    assert len(new_rows) == len(base_rows) == len(frozen_rows) == 14
    assert len({row["run_id"] for row in new_rows + base_rows + frozen_rows}) == 42
    schedule = [("warmup", 1), ("warmup", 2), *(("measurement", index) for index in range(1, 6))]
    assert [(row["cache"], row["phase"], row["repeat"]) for row in new_rows] == [
        (cache, phase, repeat) for cache, (phase, repeat) in product(caches, schedule)
    ]
    cold_prefix = b"".join((current / "samples.jsonl").read_bytes().splitlines(keepends=True)[:7])
    assert cold_prefix == (cold / "cold-samples.jsonl").read_bytes()
    input_name = "input-L/manifest.json"
    input_content = (current / input_name).read_bytes()
    for path in (original / input_name, frozen / "evidence" / input_name, cold / "input-manifest.json"):
        assert input_content == path.read_bytes()
    input_hash = sha256(input_content).hexdigest()
    assert shard["input_manifest_sha256"] == input_hash
    assert [row["service_reused"] for row in new_rows] == [False] * 8 + [True] * 6
    assert all(row["status"] == "FAIL" for row in base_rows + frozen_rows)
    with TemporaryDirectory(prefix="geopilot-t14-reference.") as temporary:
        expected, fingerprints = expected_outputs(json.loads(input_content)["reference"], Path(temporary))
    output = {
        "strict_replays": ["before-self", "after-self", "pair"],
        "sample_counts": dict(Counter(row["status"] for row in new_rows)),
        "input_sha256": input_hash, "correctness": expected, "text_fingerprints": fingerprints,
        "groups": {},
    }
    for cache in caches:
        group_rows = [row for row in new_rows if row["cache"] == cache]
        for row in group_rows:
            assert (row["tier"], row["workload"], row["status"]) == ("L", workload, "PASS")
            assert not row.get("error") and row["input_manifest_sha256"] == input_hash
            state = row["run_status"]
            assert (state["run_id"], state["execution_status"], state["check_status"]) == (row["run_id"], "SUCCEEDED", "PASSED")
            assert not state["error"] and row["correctness"] == expected
            assert row["checks"]["rules"] == {"output_exists": True}
            steps = row["steps"]
            assert tuple(step["key"] for step in steps) == STEP_KEYS
            assert all((step["status"], step["exit_code"]) == ("SUCCEEDED", 0) for step in steps)
            for role, expected_file in fingerprints.items():
                record = row["artifacts"][role]
                assert record["fingerprint"] == expected_file["fingerprint"], (cache, role)
                assert record["layer"] is None and record["step"] == "aggregate_by_zone"
            document = row["telemetry"]["document"]
            assert document["run_id"] == row["run_id"]
            assert tuple(step["step_key"] for step in document["steps"]) == STEP_KEYS
        measured = group_rows[2:]
        official = all_groups[cache]
        assert official["before"]["counts"] == {"PASS": 0, "FAIL": 5, "NOT_RUN": 0}
        assert official["after"]["counts"] == {"PASS": 5, "FAIL": 0, "NOT_RUN": 0}
        assert not official["successful_sample_deltas"]
        telemetry = [row["telemetry"]["document"] for row in measured]
        metrics = {
            "wall_ns": distribution([row["wall_ns"] for row in measured]),
            "peak_rss_bytes": resource([item["resources"]["peak_rss_bytes"] for item in telemetry]),
            "peak_temp_bytes": resource([row["peak_temp_bytes"] for row in measured]),
        }
        for name, metric in metrics.items():
            assert metric == official["after"][name]["PASS"], (cache, name, metric, official["after"][name])
        metrics["step_wall_ns"] = {
            key: distribution([item["steps"][index]["wall_ns"] for item in telemetry])
            for index, key in enumerate(STEP_KEYS)
        }
        metrics["step_peak_rss_bytes"] = {
            key: resource([item["steps"][index]["resources"]["peak_rss_bytes"] for item in telemetry])
            for index, key in enumerate(STEP_KEYS)
        }
        output["groups"][cache] = metrics
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    verify(*(Path(path).resolve() for path in sys.argv[1:]))
