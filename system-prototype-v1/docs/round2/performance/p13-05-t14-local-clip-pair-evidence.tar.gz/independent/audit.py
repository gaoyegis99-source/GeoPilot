"""Independent small-file audit of the T14 L local-clip finalized strict pair."""
from collections import Counter
from io import BytesIO
from hashlib import sha256
import json
import math
import re
from pathlib import Path
import re
import shlex
from statistics import median
import subprocess
import tarfile
import sys

REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
RECORDS = REPO / "docs/round2/performance"
PLAN = REPO / "artifacts/test-results/p13-05-vector-l-plan.a2d2e68.C905zE"
ROOT = Path("/mnt/datab/geopilot-p13-05-vector-l-t14.fff225f22356.SIbfWQ")
WORKLOAD = "t14-split_by_area"
SHARD = ROOT / WORKLOAD
COMMITS = {
    "base": "977ab412d9f6e7558d22a5c431fac0ada90b07be",
    "candidate": "fff225f223568921ef2ac56f2b76ee9c4f8cbd29",
}
OLD = "37cb329be04eaddfeb23ac62789926d0fcdb63aa"
TREE_HASHES = {
    "base": "19bf6a3df70aee71ea6bf87f690a7b13b28b2cfc08ad3e79aa01c3e72b6e4277",
    "candidate": "05258667966a75b5695ca10e9835daf9bb36d050fd8254fdfe95eabef18930e7",
}
FROZEN_RUNNER_HASH = "b0b83f6fa51bf097a28b8ae69e828e0ef401e35981e7262f469eca52c95c5af2"
IMAGE = "sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87"
FILESYSTEM = "/dev/sdb1 ext4"
RELATION = {"spatial_relation": "intersects"}
ALLOCATION = {"boundary_assignment": "split_by_area", "boundary_tie": "unassigned", "area_crs": "EPSG:6933"}
OPTIONS = {**RELATION, **ALLOCATION}
STEPS = (
    ("apply_spatial_relation", "python-select-spatial-relation", RELATION),
    ("clip_back_to_analysis_extent", "python-clip-vector-to-extent", {}),
    ("aggregate_by_zone", "python-polygon-zone-statistics", {**ALLOCATION, "area_unit": "square_meter"}),
)
CACHES = ("process_cold", "warm")
PHASES = (("warmup", 2), ("measurement", 5))
PLANNED = [(cache, phase, i) for cache in CACHES for phase, n in PHASES for i in range(1, n + 1)]
RESOURCES = ("cpu_ns", "peak_rss_bytes", "disk_read_bytes", "disk_write_bytes")
METRICS = ("wall_ns", "queue_wall_ns", "execute_steps_wall_ns", "finalize_wall_ns",
           *RESOURCES, "peak_temp_bytes", "input_bytes", "output_bytes")


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def snapshot_digest(snapshot):
    payload = {name: value for name, value in snapshot.items() if name != "sha256"}
    encoded = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return sha256(encoded.encode("ascii")).hexdigest()


def distribution(readings):
    values = sorted(item["value"] for item in readings if item.get("value") is not None)
    return {
        "samples": len(values),
        "coverage": dict(Counter(item["status"] for item in readings)),
        "median": median(values) if len(values) >= 3 else None,
        "p95": values[math.ceil(.95 * len(values)) - 1] if len(values) >= 3 else None,
    }


def reading(value):
    return {"status": "recorded" if value is not None else "unavailable", "value": value}


def measure_columns(row):
    sidecar = row["telemetry"]["document"]
    return {
        "wall_ns": reading(row["wall_ns"]),
        "queue_wall_ns": sidecar["queue_wall_ns"],
        "execute_steps_wall_ns": reading(sidecar["execute_steps_wall_ns"]),
        "finalize_wall_ns": reading(sidecar["finalize_wall_ns"]),
        **sidecar["resources"],
        "peak_temp_bytes": row["peak_temp_bytes"],
        "input_bytes": reading(row["input_bytes"]),
        "output_bytes": reading(row.get("output_bytes")),
    }


def one_run(row, expected):
    assert (row["tier"], row["workload"], row["input_profile"], row["input_manifest_sha256"]) == (
        "L", WORKLOAD, "p13-01", expected["input_manifest_sha256"],
    )
    package = next(file for file in expected["files"] if file["path"] == "t14.gpkg")
    assert row["input"] == package and row["input_bytes"] == package["bytes"]
    assert row["method"] == {"id": "polygon-zone-statistics", "version": 1}
    assert row["critical_options"] == OPTIONS and row["plan_version"] == 1
    assert isinstance(row["wall_ns"], int) and row["wall_ns"] > 0 and row["submission_attempted"]
    assert (row.get("input_preread_ns", 0) > 0) == (row["cache"] == "warm")
    assert row["checks_only_ns"] == {
        "status": "unavailable", "reason": "sidecar_finalization_includes_artifact_registration",
    }
    state = row["run_status"]
    doc = row["telemetry"]["document"]
    assert row["telemetry"]["status"] == "recorded"
    assert doc["schema_version"] == 1 and doc["wall_scope"] == "execution_through_finalization"
    assert state["run_id"] == doc["run_id"] == row["run_id"]
    assert (state["execution_status"], state["check_status"]) == (doc["execution_status"], doc["check_status"])
    assert not state["cancel_requested"]
    assert len(row["steps"]) == len(STEPS)
    events = {event["step_key"]: event for event in doc["steps"]}
    assert len(events) == len(doc["steps"])
    for step, (key, tool, parameters) in zip(row["steps"], STEPS, strict=True):
        assert step["key"] == key
        if step["status"] == "NOT_STARTED":
            assert key not in events and all(step[name] is None for name in ("tool", "parameters", "exit_code", "error"))
            continue
        event = events[key]
        assert step["tool"] == {"id": tool, "version": 1} and step["parameters"] == parameters
        assert event["tool"]["id"] == tool and event["tool"]["version"] == 1
        assert (step["status"], step["exit_code"]) == (event["status"], event["exit_code"])
        assert any(proc["phase"] == "execute" for proc in event["processes"])
    assert row["status"] == "PASS"
    assert (state["execution_status"], state["check_status"], doc["exit_code"]) == ("SUCCEEDED", "PASSED", 0)
    assert state["current_report_id"] and state["error"] is None and not row.get("status_read_errors")
    assert len(events) == 3 and row["checks"]["rules"] == {"output_exists": True}
    assert re.fullmatch(r"[0-9a-f]{64}", row["checks"]["report_sha256"])
    assert all(step["status"] == "SUCCEEDED" and step["exit_code"] == 0 for step in row["steps"])
    for event in events.values():
        process, = [p for p in event["processes"] if p["phase"] == "execute"]
        assert process["exit_code"] == 0 and not process["timed_out"] and not process["cancelled"]
    assert row["correctness"] == expected["correctness"][WORKLOAD]
    assert set(row["artifacts"]) == {"clipped_targets", "original_targets", "allocation_details", "zone_statistics"}
    for role, artifact in row["artifacts"].items():
        assert re.fullmatch(r"[0-9a-f]{64}", artifact["fingerprint"])
        step, output, file = {
            "allocation_details": ("aggregate_by_zone", "allocation_details", "allocation_details.csv"),
            "zone_statistics": ("aggregate_by_zone", "zone_statistics", "zone_statistics.json"),
            "clipped_targets": ("clip_back_to_analysis_extent", "targets", "targets.gpkg"),
            "original_targets": ("clip_back_to_analysis_extent", "original_targets", "original_targets.gpkg"),
        }[role]
        assert artifact["step"] == step and artifact["output"] == output
        assert artifact["uri"] == f"intermediate/{step}/{file}"
    messages = (
        "Selected 131072 of 131072 complete target(s) using intersects",
        "Clipped 114688 of 131072 selected target(s) with nonempty intersections",
        "Summarized 98304 unique target(s), 32768 unassigned",
    )
    assert all(message in row["step_logs"][f"steps/{step}/process.log"]["text"]
               for (step, _, _), message in zip(STEPS, messages, strict=True))
    return {
        "cache": row["cache"], "phase": row["phase"], "repeat": row["repeat"],
        "run_id": row["run_id"], "plan_id": row["plan_id"], "workdir": row["workdir"],
        "status": row["status"], "terminal": [state["execution_status"], state["check_status"]],
        "exit_code": doc["exit_code"], "error": state["error"], "wall_ns": row["wall_ns"],
        "steps": [{"key": step["key"], "status": step["status"], "exit_code": step["exit_code"],
                   "timed_out": any(p["timed_out"] for p in events.get(step["key"], {}).get("processes", []))}
                  for step in row["steps"]],
        "status_read_errors": row.get("status_read_errors", []), "correctness": row.get("correctness"),
        "resources": measure_columns(row),
        "artifacts": row.get("artifacts"), "checks": row.get("checks"),
    }


def timeout_prefix(row, failure_index):
    failure = row["run_status"]["error"]
    failed_key = STEPS[failure_index][0]
    assert (row["status"], row["run_status"]["execution_status"], row["run_status"]["check_status"]) == (
        "FAIL", "FAILED", "NOT_CHECKED",
    )
    assert row["error"] == "ValueError: Run state is FAILED/NOT_CHECKED"
    assert (failure["code"], failure["phase"], failure["step_key"], failure["message"]) == (
        "PROCESS_TIMEOUT", "execute", failed_key, "Process exceeded 60 seconds",
    )
    assert row["run_status"]["current_step"] == failed_key and row["run_status"]["current_report_id"] is None
    assert all(name not in row for name in ("correctness", "checks", "artifacts"))

    steps = row["steps"]
    for completed in steps[:failure_index]:
        assert completed["status"] == "SUCCEEDED" and completed["exit_code"] == 0 and completed["error"] is None
    failed = steps[failure_index]
    assert failed["status"] == "FAILED" and failed["exit_code"] == -15 and failed["error"] == failure
    for unstarted in steps[failure_index + 1:]:
        assert unstarted["status"] == "NOT_STARTED"
        assert all(unstarted[field] is None for field in ("exit_code", "error", "tool", "parameters"))
    sidecar = row["telemetry"]["document"]
    assert sidecar["exit_code"] == -15
    assert [event["step_key"] for event in sidecar["steps"]] == [step[0] for step in STEPS[:failure_index + 1]]
    for index, event in enumerate(sidecar["steps"]):
        process, = [proc for proc in event["processes"] if proc["phase"] == "execute"]
        assert process["cancelled"] is False
        if index == failure_index:
            assert event["exit_code"] == process["exit_code"] == -15 and event["status"] == "FAILED"
            assert process["timed_out"] is True and process["wall_ns"] >= 60_000_000_000
        else:
            assert event["exit_code"] == process["exit_code"] == 0 and event["status"] == "SUCCEEDED"
            assert process["timed_out"] is False
    if failure_index == 1:
        selected = row["step_logs"]["steps/apply_spatial_relation/process.log"]
        assert not selected["truncated"]
        assert "Selected 131072 of 131072 complete target(s) using intersects" in selected["text"]


def audit_runs(rows, expected, *, complete, failure_index):
    keys = [(row["cache"], row["phase"], row["repeat"]) for row in rows]
    assert keys == PLANNED[:len(rows)] and (not complete or keys == PLANNED)
    for field in ("run_id", "workdir"):
        assert len({row[field] for row in rows}) == len(rows)
    records = []
    for row in rows:
        record = one_run(row, expected)
        if failure_index is not None:
            timeout_prefix(row, failure_index)
        records.append(record)

    groups = {}
    for cache in CACHES:
        group = [r for r in rows if r["cache"] == cache]
        plans = {r["plan_id"] for r in group}
        assert len(plans) == (len(group) if cache == "process_cold" else bool(group))
        assert [r["service_reused"] for r in group] == [cache == "warm" and i > 0 for i in range(len(group))]
        measured = [r for r in group if r["phase"] == "measurement"]
        by_status = {}
        for outcome in ("PASS", "FAIL"):
            selected = [r for r in measured if r["status"] == outcome]
            columns = [measure_columns(r) for r in selected]
            by_status[outcome] = {field: distribution([m[field] for m in columns]) for field in METRICS}
            by_status[outcome]["steps"] = {}
            for step_key, _, _ in STEPS:
                events = [event for row in selected for event in row["telemetry"]["document"]["steps"]
                          if event["step_key"] == step_key]
                by_status[outcome]["steps"][step_key] = {
                    "wall_ns": distribution([reading(e["wall_ns"]) for e in events]),
                    **{name: distribution([e["resources"][name] for e in events]) for name in RESOURCES},
                }
        groups[cache] = {
            "counts": {phase: dict(Counter(r["status"] for r in group if r["phase"] == phase))
                       for phase, _ in PHASES},
            "measured_distributions": by_status,
        }
    plans = {cache: {r["plan_id"] for r in rows if r["cache"] == cache} for cache in CACHES}
    assert plans["process_cold"].isdisjoint(plans["warm"])
    return {"rows": records, "groups": groups}


def side_environment(attempt, side):
    command, filesystem = (attempt / "command.log").read_text().splitlines()
    args = shlex.split(command)
    assert IMAGE in args and filesystem == FILESYSTEM
    assert digest(attempt / "source-tree.sha256") == TREE_HASHES[side]
    assert digest(attempt / "frozen-runner.sha256") == FROZEN_RUNNER_HASH
    assert args[args.index("--source-commit") + 1] == COMMITS[side]
    assert args[args.index("--workload") + 1] == WORKLOAD
    assert args[args.index("--tier") + 1] == "L"
    assert [args[i+1] for i, arg in enumerate(args) if arg == "--cache-state"] == list(CACHES)
    environment_path = attempt / "evidence/environment.json"
    if not environment_path.is_file():
        return None
    env = read(environment_path)
    assert env["source_commit"] == COMMITS[side] and env["probe"] is False
    assert (env["planned_warmups"], env["planned_repeats"], env["run_wait_seconds"], env["budget_seconds"]) == (2, 5, 600, None)
    assert env["runner_sha256"] == {
        "run_vector.py": "52b254fcd93b08521ae7347c44e27f9dda3979bcda7fd8b97f1d72a5cd232063",
        "_vector_reference.py": "2aad7d57adba3a9a98cf93e68c40e60d717268b6fd5f229ad54e59bfd46d41f1",
        "_vector_road_profile.py": "31aefb282de59a63882e7b1bcca436fe1f10204bf60e6c07f0f8c6d0d5117232",
    }
    assert env["qgis_version"]["exit_code"] == 0
    return {name: env[name] for name in ("source_commit", "started_utc", "qgis_version", "runner_sha256", "storage_filesystem")}


def id_sets(audit):
    return {field: {row[field] for row in audit["rows"]} for field in ("run_id", "plan_id", "workdir")}


ATTEMPT = SHARD / "candidate/attempt.BdH0Dm"
DOC = "system-prototype-v1/docs/round2/performance"
MANIFEST = "ada61ccadb58accc19039b9f30c24db3d25ac0dc11d09987148105e10dac9c24"
ARTIFACT_SCOPE = "completed cold rows record independent feature/area verification and published artifact fingerprints; worker temporary workspaces removed"


def git(commit, name):
    return subprocess.check_output(["git", "-C", str(REPO), "show", f"{commit}:{DOC}/{name}"])


def archived_pair(commit, name):
    raw = git(commit, f"p13-05-vector-l-{name}-evidence.tar.gz")
    rows = {}
    with tarfile.open(fileobj=BytesIO(raw), mode="r:gz") as archive:
        checksums = dict((path, sha) for sha, path in
                         (line.split(maxsplit=1) for line in archive.extractfile("./SHA256SUMS").read().decode().splitlines()))
        for side in ("base", "candidate"):
            m, = [item for item in archive.getmembers()
                  if f"/{side}/" in item.name and item.name.endswith("/evidence/samples.jsonl")]
            payload = archive.extractfile(m).read()
            assert digest_bytes(payload) == checksums[m.name]
            rows[side] = [json.loads(line) for line in payload.splitlines()]
            assert len(rows[side]) == len({row["run_id"] for row in rows[side]}) == 14
    return rows, digest_bytes(raw)


def digest_bytes(raw):
    return sha256(raw).hexdigest()


def reference(commit):
    raw = git(commit, "p13-03-L-input-manifest.json")
    assert digest_bytes(raw) == MANIFEST
    fixture = json.loads(raw)
    ref = fixture["reference"]
    t14 = ref["t14"]
    tiles = ref["side_tiles"]**2
    split = t14["methods"]["split_by_area"]
    data = {
        "selected": t14["selected_rows"],
        "clipped": sum(t14["clipped_rows_per_id_per_tile"].values()) * tiles,
        "counts": split["counts"], "areas_m2": split["areas_m2"],
        "allocation_rows": len(split["details_per_tile"]) * tiles,
        "zones": ref["layer_counts"]["t14.gpkg"]["zones"],
    }
    assert (data["selected"], data["clipped"], data["allocation_rows"], data["zones"]) == (131072, 114688, 147456, 32768)
    assert data["areas_m2"]["total"] == data["areas_m2"]["assigned"] + data["areas_m2"]["unassigned"]
    return {"files": fixture["files"], "input_manifest_sha256": MANIFEST, "correctness": {WORKLOAD: data}}


BASE_ATTEMPT = Path("/mnt/datab/geopilot-p13-05-vector-l.a2d2e68.C905zE/t14-split_by_area/base/attempt.6p4fhK")
COLD_PROOF = Path("/tmp/geopilot-p13-05-t14-local-clip-cold-audit.ZtWuiS/independent.json")
COLD_PROOF_SHA = "4c2f0f9644505895f1f658fb9d7970e8e15f376184039e1aaf6991b817484a51"
CONFIG_SHA = "f290b7d264577770445efb0ad192777294df5e9f230050edff595c05ce2455b3"


def final_attempt(attempt, side, expected):
    evidence = attempt / "evidence"
    assert (attempt.parent / "COMPLETED").read_text().strip() == attempt.name
    assert (attempt / "container-exit").read_text().strip() == ("1" if side == "base" else "0")
    assert (attempt / "logging-exit").read_text().strip() == "0"
    env = read(evidence / "environment.json")
    assert env["source_commit"] == COMMITS[side] and not env["probe"]
    assert (env["planned_warmups"], env["planned_repeats"], env["run_wait_seconds"], env["budget_seconds"]) == (2, 5, 600, None)
    assert env["workspace_retention"] == "temporary_directory_removed_after_worker_exit"
    if side == "candidate":
        assert side_environment(attempt, side)
    report = read(evidence / "summary.json")
    assert not report["probe"] and report["finished_utc"]
    counts = {"PASS": 14 if side == "candidate" else 0, "FAIL": 0 if side == "candidate" else 14, "NOT_RUN": 0}
    assert report["sample_counts"] == counts and report["status"] == ("PASS" if side == "candidate" else "INCOMPLETE")
    receipts = read(evidence / "runtime-configuration.json")
    assert receipts["schema_version"] == 1
    assert receipts["report_files"] == {name: digest(evidence / name) for name in ("summary.json", "environment.json")}
    snapshot = receipts["before"]
    assert snapshot == receipts["after"] and snapshot["sha256"] == CONFIG_SHA
    payload = {key: value for key, value in snapshot.items() if key != "sha256"}
    canonical = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("ascii")
    assert digest_bytes(canonical) == CONFIG_SHA
    inputs = read(evidence / "inputs.json")
    assert set(inputs) == {"L"}
    record = inputs["L"]
    assert record["input_manifest_sha256"] == MANIFEST and record["files_before"] == record["files_after"] == expected["files"]
    assert digest(evidence / "input-L/manifest.json") == MANIFEST
    raw = (evidence / "samples.jsonl").read_bytes().splitlines(keepends=True)
    assert len(raw) == 14 and all(line.endswith(b"\n") for line in raw)
    rows = [json.loads(line) for line in raw]
    assert [(row["cache"], row["phase"], row["repeat"]) for row in rows] == PLANNED
    assert len({row["run_id"] for row in rows}) == 14 and all(row["input_manifest_sha256"] == MANIFEST for row in rows)
    return rows, report, {"attempt": str(attempt), "source": COMMITS[side], "finished_utc": report["finished_utc"],
                          "samples_sha256": digest_bytes(b"".join(raw)), "cold_prefix_sha256": digest_bytes(b"".join(raw[:7])),
                          "receipt_sha256": digest(evidence / "runtime-configuration.json")}


def measured_groups(rows, side):
    result = {}
    for cache in CACHES:
        subset = [row for row in rows if row["cache"] == cache]
        measured = [row for row in subset if row["phase"] == "measurement"]
        group = {"counts": {"warmup": dict(Counter(row["status"] for row in subset if row["phase"] == "warmup")),
                            "measurement": dict(Counter(row["status"] for row in measured))}}
        assert len(measured) == 5
        phase = {}
        for status in ("PASS", "FAIL"):
            samples = [row for row in measured if row["status"] == status]
            columns = [measure_columns(row) for row in samples]
            values = {field: distribution([item[field] for item in columns]) for field in METRICS}
            values["steps"] = {}
            for key, _, _ in STEPS:
                events = [item for row in samples for item in row["telemetry"]["document"]["steps"] if item["step_key"] == key]
                values["steps"][key] = {
                    "wall_ns": distribution([reading(event["wall_ns"]) for event in events]),
                    **{field: distribution([event["resources"][field] for event in events]) for field in RESOURCES},
                }
            phase[status] = values
        group["measured_distributions"] = phase
        result[cache] = group
    return result


def check_stat(record, field, expected):
    assert record[field + "_n"] == expected["samples"]
    assert record[field + "_partial_n"] == expected["coverage"].get("partial", 0)
    assert (record[field + "_median"], record[field + "_p95"]) == (expected["median"], expected["p95"])


def check_summary(summary, groups):
    assert len(summary["groups"]) == 2
    for group in summary["groups"]:
        cache = group["cache"]
        raw = groups[cache]
        for phase, label in (("warmup", "warmup"), ("measurement", "measured")):
            for status in ("PASS", "FAIL", "NOT_RUN"):
                assert group[label + "_" + status.lower()] == raw["counts"][phase].get(status, 0)
        success = raw["measured_distributions"]["PASS"]
        for key in METRICS:
            check_stat(group, key, success[key])
        recorded = [item for item in summary["step_groups"] if item["cache"] == cache]
        assert len(recorded) == (3 if raw["counts"]["measurement"].get("PASS") else 0)
        for step in recorded:
            for key in ("wall_ns", *RESOURCES):
                check_stat(step, key, success["steps"][step["step"]][key])


def check_comparison(file, left, right, groups_left, groups_right):
    result = read(file)
    assert (result["status"], result["before_source"], result["after_source"], result["same_source"]) == (
        "MATCHED_EVIDENCE", left["source"], right["source"], left["source"] == right["source"],
    )
    assert result["candidate_all_measurements_pass"] == (right["source"] == COMMITS["candidate"])
    assert result["runtime_configuration"] == {
        "level": "application_config_and_python_proj", "schema_version": 1, "sha256": CONFIG_SHA,
    }
    assert len(result["groups"]) == 2 and {g["group"][2] for g in result["groups"]} == set(CACHES)
    metrics = ("wall_ns", "peak_rss_bytes", "peak_temp_bytes")
    for group in result["groups"]:
        cache = group["group"][2]
        assert group["group"] == ["L", WORKLOAD, cache, "p13-01"]
        for label, raw in (("before", groups_left[cache]), ("after", groups_right[cache])):
            expected = raw["counts"]["measurement"]
            assert group[label]["counts"] == {status: expected.get(status, 0) for status in ("PASS", "FAIL", "NOT_RUN")}
            assert group[label]["failure_codes"] == ({"PROCESS_TIMEOUT": 5} if expected.get("FAIL") else {})
            for metric in metrics:
                for status in ("PASS", "FAIL"):
                    dist = raw["measured_distributions"][status][metric]
                    assert group[label][metric][status] == {
                        "samples": dist["samples"], "partial": dist["coverage"].get("partial", 0),
                        "median": dist["median"], "p95_nearest_rank": dist["p95"],
                    }
        deltas = {}
        for metric in metrics:
            a, b = (group[label][metric]["PASS"] for label in ("before", "after"))
            n = group["before"]["counts"]["PASS"]
            if n >= 3 and a["samples"] == b["samples"] == n == group["after"]["counts"]["PASS"] and not (a["partial"] or b["partial"]):
                deltas[metric] = {key: b[key] - a[key] for key in ("median", "p95_nearest_rank")}
        assert group["successful_sample_deltas"] == deltas
    return result


def main(commit, output):
    expected = reference(commit)
    baserows, basereport, base = final_attempt(BASE_ATTEMPT, "base", expected)
    candrows, candreport, candidate = final_attempt(ATTEMPT, "candidate", expected)
    frozen, archive_sha = archived_pair(commit, "area")
    assert baserows == frozen["base"]
    for row in baserows:
        timeout_prefix(row, 0)
    for row in frozen["candidate"]:
        timeout_prefix(row, 1)
    validated = audit_runs(candrows, expected, complete=True, failure_index=None)
    candidate["groups"], candidate["samples"] = validated["groups"], validated["rows"]
    base["groups"] = measured_groups(baserows, "base")
    base["run_ids"] = [row["run_id"] for row in baserows]
    candidate["run_ids"] = [row["run_id"] for row in candrows]
    assert len(set(base["run_ids"] + candidate["run_ids"])) == 28
    assert len({row["run_id"] for row in frozen["candidate"] + baserows + candrows}) == 42

    assert digest(COLD_PROOF) == COLD_PROOF_SHA
    cold = read(COLD_PROOF)
    assert candidate["cold_prefix_sha256"] == cold["cold_prefix_sha256"]
    assert candidate["samples"][:7] == cold["samples"] and candidate["groups"]["process_cold"] == cold["group"]
    check_summary(basereport, base["groups"])
    check_summary(candreport, candidate["groups"])
    for side, attempt in ((base, BASE_ATTEMPT), (candidate, ATTEMPT)):
        self_file = attempt / "self-comparison.json"
        check_comparison(self_file, side, side, side["groups"], side["groups"])
        side["self_comparison_sha256"] = digest(self_file)
    result_file, = SHARD.glob("comparison.*/result.json")
    assert result_file.with_name("stderr.log").read_bytes() == b""
    assert result_file.with_name("evidence-paths").read_text().splitlines() == [
        str(BASE_ATTEMPT / "evidence"), str(ATTEMPT / "evidence"),
    ]
    comparison = check_comparison(result_file, base, candidate, base["groups"], candidate["groups"])
    assert all(group["successful_sample_deltas"] == {} for group in comparison["groups"])
    archive_refs = []
    for name in ("point", "line"):
        pair, _ = archived_pair(commit, name)
        archive_refs.extend(row["run_id"] for side in ("base", "candidate") for row in pair[side])
    import gzip
    old = [json.loads(line)["run_id"] for suffix in ("formal", "remaining")
           for line in gzip.decompress(git(commit, f"p13-03-L-{suffix}-samples.jsonl.gz")).splitlines()]
    frozen_ids = archive_refs + old + [row["run_id"] for side in ("base", "candidate") for row in frozen[side]]
    assert len(frozen_ids) == len(set(frozen_ids)) == 224
    assert len(set(frozen_ids + candidate["run_ids"])) == 238

    payload = {
        "scope": "completed local clip L candidate and reused original baseline",
        "candidate": candidate, "baseline": base, "comparison": str(result_file),
        "comparison_sha256": digest(result_file), "comparison_result": comparison,
        "runtime_configuration_sha256": CONFIG_SHA, "input_manifest_sha256": MANIFEST,
        "reference": expected["correctness"][WORKLOAD], "frozen_archive_sha256": archive_sha,
        "artifact_scope": ARTIFACT_SCOPE, "cold_prefix_unchanged": True,
        "identity_counts": {"strict_pair_unique": 28, "historical_and_frozen": 224, "new_candidate": 14, "combined_unique": 238},
    }
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print("cold prefix unchanged; 14 candidate GIS and benchmark PASS; original 14 first-step timeouts")
    print("both receipts", CONFIG_SHA, "comparison", result_file, digest(result_file))
    for label, side, status in (("base", base, "FAIL"), ("candidate", candidate, "PASS")):
        for cache in CACHES:
            group = side["groups"][cache]
            d = group["measured_distributions"][status]
            print(label, cache, group["counts"], "E2E", d["wall_ns"], "RSS", d["peak_rss_bytes"], "temp", d["peak_temp_bytes"])
            for step, fields in d["steps"].items():
                print(step, "wall", fields["wall_ns"], "RSS", fields["peak_rss_bytes"])
    print("correctness", payload["reference"], "unique IDs", payload["identity_counts"])
    print("original success deltas empty; runner removed temporary geometry workspaces after recorded validation")


if __name__ == "__main__":
    main(sys.argv[1], Path(sys.argv[2]))
