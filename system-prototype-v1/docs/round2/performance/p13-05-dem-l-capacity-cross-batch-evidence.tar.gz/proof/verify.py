"""Compare the third completed worker with the two independently replayed predecessors."""
from hashlib import sha256
import json
from pathlib import Path
import sys


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


root, previous = (Path(value) for value in sys.argv[1:])
cross = root / "cross-batch"
proof = root / "proof"
plan = load(previous / "plan.json")
contract = load(previous / "proof/contract.json")
source = plan["sources"]["cross-batch"]
manifest = proof / "cross-batch.sha256"
assert digest(manifest) == source["source_manifest_sha256"]
assert len(manifest.read_bytes().splitlines()) == source["source_files"]
assert digest(proof / "cross-batch-area_stats.py") == source["area_module_sha256"]
assert (cross / "exit-code").read_text().strip() == "0"
receipt = load(cross / "receipt.json")
assert receipt["scope"] == "direct_area_capacity_probe"
assert receipt["container_exit_code"] == receipt["worker_exit_code"] == 0 and not receipt["timed_out"]
assert receipt["runtime_tree"] == contract["runtime_tree"]
assert receipt["worker_wall_budget_s"] == 1800
assert receipt["files_sha256"] == {
    name: digest(cross / name) for name in ("result.json", "environment.json", "production-report.json")
}
result = load(cross / "result.json")
assert result["status"] == "PASS" and result["commit"] == receipt["commit"] == source["commit"]
assert result["area_module_sha256"] == source["area_module_sha256"]
assert result["input_sha256_before"] == result["input_sha256_after"] == plan["input_sha256"]
assert result["report"] == load(cross / "production-report.json")
assert result["environment"] == load(cross / "environment.json")
assert 0 < result["core_cpu_ns"] <= receipt["wall_ns"] and result["core_wall_ns"] <= receipt["wall_ns"]
assert receipt["rss_samples"] > 0 and receipt["peak_rss_bytes"] >= receipt["sampled_rss_peak_bytes"] > 0
summary = load(root / "summary.json")
assert summary["scope"] == receipt["scope"] and summary["same_observed_environment"]
assert summary["frozen_cross_batch_report_exact"]
assert summary["variants"] == {
    label: {"state": "PASS", "container_exit_code": 0} for label in ("baseline", "frozen", "cross-batch")
}
out = {}
for label in ("baseline", "frozen"):
    worker = previous / label
    for name in ("environment.json", "production-report.json"):
        assert (worker / name).read_bytes() == (cross / name).read_bytes()
    comparison = load(worker / "result.json")
    assert comparison["input_sha256_before"] == result["input_sha256_before"]
    assert comparison["reference_checks"] == result["reference_checks"]
    memory = load(worker / "receipt.json")["peak_rss_bytes"]
    out[label] = {
        "core_wall_reduction_percent": (1 - result["core_wall_ns"] / comparison["core_wall_ns"]) * 100,
        "core_cpu_reduction_percent": (1 - result["core_cpu_ns"] / comparison["core_cpu_ns"]) * 100,
        "rss_change_bytes": receipt["peak_rss_bytes"] - memory,
        "rss_change_percent": (receipt["peak_rss_bytes"] / memory - 1) * 100,
    }
print(json.dumps({
    "scope": summary["scope"], "status": "PASS", "commit": result["commit"],
    "production_report_byte_equal_all_workers": True, "environment_byte_equal_all_workers": True,
    "core_wall_ns": result["core_wall_ns"], "core_cpu_ns": result["core_cpu_ns"],
    "peak_rss_bytes": receipt["peak_rss_bytes"], "peak_rss_mib": receipt["peak_rss_bytes"] / 2**20,
    "comparison": out,
}, indent=2))
