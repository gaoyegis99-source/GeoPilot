"""Exercise the raster poller against the actual local status route."""

import json
import logging
from datetime import UTC, datetime
from pathlib import Path
import sqlite3
import sys
import time

from fastapi.testclient import TestClient

from _raster_workloads import _terminal_state
from geopilot.api.app import create_app
from geopilot.persistence.run_repository import insert_run
from geopilot.persistence.schema import initialize_database, open_database
from geopilot.runs.models import Run


class RecordWarnings(logging.Handler):
    def __init__(self):
        super().__init__(logging.WARNING)
        self.events = []

    def emit(self, record):
        event = json.loads(record.getMessage())
        assert event["event"] == "run_status_read_failed"
        self.events.append(event)


class RecoveringClient:
    def __init__(self, first_get, current_get):
        self.getters = iter((first_get, current_get))

    def get(self, endpoint):
        return next(self.getters)(endpoint)


def main(root):
    database = root / "project.sqlite"
    missing = root / "missing.sqlite"
    initialize_database(database)
    now = datetime.now(UTC)
    with open_database(database) as connection, connection:
        connection.execute("INSERT INTO task VALUES ('task', '{}', NULL, ?)", (now.isoformat(),))
        connection.execute("INSERT INTO analysis_plan VALUES ('plan', 1, 'task', 'confirmed', '{}', ?)", (now.isoformat(),))
        insert_run(connection, Run(
            id="terminal", plan_id="plan", plan_version=1, workdir=str(root), created_at=now,
            execution_status="SUCCEEDED", check_status="PASSED",
        ))
    logger = logging.getLogger("geopilot.api.app")
    capture = RecordWarnings()
    logger.addHandler(capture)
    output = {"sqlite_version": sqlite3.sqlite_version, "cases": {}}
    try:
        with TestClient(create_app(database)) as current, TestClient(create_app(missing)) as unavailable:
            def blocked(endpoint):
                with open_database(database) as writer, writer:
                    writer.execute("BEGIN EXCLUSIVE")
                    return current.get(endpoint)

            for label, getter, code in (("exclusive_lock", blocked, 5), ("missing_database", unavailable.get, 14)):
                trial = {}
                state = _terminal_state(
                    RecoveringClient(getter, current.get), "/api/runs/terminal", trial, time.monotonic() + 15,
                )
                assert (state["run_id"], state["execution_status"], state["check_status"]) == ("terminal", "SUCCEEDED", "PASSED")
                error, = trial["status_poll_errors"]
                event, = capture.events
                capture.events.clear()
                assert error["http_status"] == 500 and error["body"]["detail"]["code"] == "STORAGE_FAILED"
                assert event["sqlite_extended_code"] == code
                assert error["elapsed_ns"] >= round(event["elapsed_ms"] * 1_000_000) - 1_000
                output["cases"][label] = {"error": error, "server_diagnostic": event, "terminal_state": state}
    finally:
        logger.removeHandler(capture)
    assert not missing.exists()
    assert output["cases"]["exclusive_lock"]["error"]["elapsed_ns"] >= 4_000_000_000
    assert output["cases"]["missing_database"]["error"]["elapsed_ns"] < 4_000_000_000
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve(strict=True))
