PYTHONPATH="$PWD/src" PYTHONDONTWRITEBYTECODE=1 nice -n 19 /home/mtd/liweigis/GeoPilot-round2/system-prototype-v1/.venv/bin/python -B "$scratch/local-stages.py"
