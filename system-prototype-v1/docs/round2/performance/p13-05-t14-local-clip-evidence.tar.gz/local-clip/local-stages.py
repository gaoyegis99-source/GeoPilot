"""Measure in-memory operations on at most 256 generated small tiles."""
import importlib.util
from pathlib import Path
from statistics import median
from time import monotonic_ns

import numpy as np
import shapely
from shapely.geometry import box

from geopilot.gis.tools import clip_vector_to_extent as candidate


def frozen_module(path):
    spec = importlib.util.spec_from_file_location("frozen_clip_vector_to_extent", path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def fixture(tile_count):
    areas = []
    targets = []
    for tile in range(tile_count):
        x = 1_000_000 + tile % 16 * 4_000
        y = 2_000_000 + tile // 16 * 4_000
        areas.extend((box(x, y, x + 120, y + 20),
                      box(x, y + 30, x + 120, y + 50),
                      box(x + 190, y + 60, x + 240, y + 100)))
        crossing = box(x + 60, y + 10, x + 160, y + 40)
        targets.extend((crossing, crossing, box(x + 80, y + 10, x + 120, y + 20),
                        box(x + 10, y + 32, x + 30, y + 42), box(x + 190, y + 70, x + 220, y + 80),
                        box(x + 220, y + 80, x + 230, y + 90), box(x + 120, y + 5, x + 130, y + 15),
                        box(x + 150, y + 40, x + 170, y + 45)))
    return np.asarray(areas), np.asarray(targets)


frozen = frozen_module(Path(__file__).with_name("frozen-clip.py"))
print("Shapely", shapely.__version__, "GEOS", shapely.geos_version_string, "process nice", __import__("os").getpriority(0, 0))
for tile_count in (16, 64, 256):
    areas, targets = fixture(tile_count)
    times = {"union_ns": [], "frozen_clip_ns": [], "local_clip_ns": []}
    for i in range(5):
        start = monotonic_ns()
        scope = shapely.union_all(areas)
        times["union_ns"].append(monotonic_ns() - start)
        work = [("frozen_clip_ns", lambda: frozen._component_intersections(targets, scope)),
                ("local_clip_ns", lambda: candidate._component_intersections(targets, scope, True))]
        outputs = {}
        for name, clip in (work if i % 2 == 0 else work[::-1]):
            start = monotonic_ns()
            outputs[name] = clip()
            times[name].append(monotonic_ns() - start)
        frozen_wkb = shapely.to_wkb(outputs["frozen_clip_ns"]).tolist()
        assert shapely.to_wkb(outputs["local_clip_ns"]).tolist() == frozen_wkb
        assert shapely.to_wkb(shapely.intersection(targets, scope)).tolist() == frozen_wkb
        assert (~shapely.is_empty(outputs["local_clip_ns"])).sum() == 7 * tile_count
    print("tiles", tile_count, "scope_parts", len(areas), "targets", len(targets),
          "raw_ns", times, "median_ns", {key: median(values) for key, values in times.items()})
