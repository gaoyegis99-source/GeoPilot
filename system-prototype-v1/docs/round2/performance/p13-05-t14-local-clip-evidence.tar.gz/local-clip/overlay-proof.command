nice -n 19 .venv/bin/python -B "$scratch/overlay-proof.py"
