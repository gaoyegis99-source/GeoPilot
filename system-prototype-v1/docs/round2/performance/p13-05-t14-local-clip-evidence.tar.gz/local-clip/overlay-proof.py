"""Small exact-WKB comparison of full and ordered local rectangular scope."""
from itertools import permutations, product
from random import Random
from time import monotonic_ns

import numpy as np
import shapely
from shapely.geometry import Polygon, box


def rectangle(x1, y1, x2, y2, orientation):
    coords = [(x1, y1), (x1, y2), (x2, y2), (x2, y1)]
    if orientation >= 4:
        coords.reverse()
    start = orientation % 4
    return Polygon(coords[start:] + coords[:start])


def wkb(geometry):
    return shapely.to_wkb(geometry)


def one_case(target, neighbors):
    scope = shapely.union_all(neighbors)
    parts = shapely.get_parts(scope)
    ids = sorted(shapely.STRtree(parts).query(target).tolist())
    assert len(ids) == 2
    local = shapely.multipolygons(parts[ids])
    assert wkb(shapely.intersection(target, scope)) == wkb(shapely.intersection(target, local)), (
        target, scope, local, shapely.intersection(target, scope), shapely.intersection(target, local),
    )


north = box(0, 30, 120, 50)
south = box(0, 0, 120, 20)
east = box(190, 60, 240, 100)
remote = box(4000, -20, 4090, 20)
n = 0
for bands in permutations([north, south, east, remote]):
    for left, bottom, right, top, orientation in product([0, 60], [0, 10], [110, 120, 160], [35, 50], range(8)):
        one_case(rectangle(left, bottom, right, top, orientation), bands)
        n += 1
print("T14-like order/boundary/ring cases", n)

rng = Random(391040)
for i in range(512):
    dx, dy = rng.randrange(-10_000_000, 10_000_000), rng.randrange(-10_000_000, 10_000_000)
    gap = rng.randrange(1, 10)
    orientation = rng.randrange(8)
    target = rectangle(dx - 1, dy + 2, dx + 5, dy + gap + 8, orientation)
    bands = [rectangle(dx - 4, dy, dx + 9, dy + 4, rng.randrange(8)),
             rectangle(dx - 3, dy + gap + 4, dx + 7, dy + gap + 10, rng.randrange(8)),
             box(dx + 100, dy - 100, dx + 110, dy - 90),
             box(dx - 200, dy + 40, dx - 190, dy + 50)]
    rng.shuffle(bands)
    one_case(target, bands)
print("translated rectangle cases", 512)

parts = []
targets = []
for i in range(16):
    x = i * 4000
    parts.extend([box(x, 0, x + 120, 20), box(x, 30, x + 120, 50), box(x + 190, 60, x + 240, 100)])
    targets.extend([box(x + 60, 10, x + 160, 40)] * 2)
    targets.extend([box(x + 150, 40, x + 170, 45), box(x + 120, 5, x + 130, 15)])
t0 = monotonic_ns()
scope = shapely.union_all(parts)
t1 = monotonic_ns()
exact = shapely.intersection(np.asarray(targets), scope)
t2 = monotonic_ns()
print("small segmented observation", len(parts), len(targets), "union_ns", t1 - t0, "whole_overlay_ns", t2 - t1,
      "nonempty", (~shapely.is_empty(exact)).sum())
