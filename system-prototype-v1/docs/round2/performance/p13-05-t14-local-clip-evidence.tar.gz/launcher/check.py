"""Check the derived launcher, without starting a real measurement or Docker."""
import fcntl
import json
import os
import shlex
import subprocess
import sys
import tempfile
from pathlib import Path

import launch


NEW = "fff225f223568921ef2ac56f2b76ee9c4f8cbd29"
ORIGINAL_CANDIDATE_COMMAND = (
    launch.BASELINE.parent.parent / "candidate/attempt.nEpTbD/command.log"
)


def command(log):
    rows = [line for line in log.read_text().splitlines() if line.startswith("docker ")]
    assert len(rows) == 1, rows
    return shlex.split(rows[0])


def normalize(command):
    cmd = list(command)
    name = cmd.index("--name") + 1
    commit = cmd.index("--source-commit") + 1
    assert cmd[name].startswith("geopilot-p1305-L-") and "-candidate-" in cmd[name]
    cmd[name] = "container-name"
    assert cmd[commit] in (launch.OLD, NEW)
    cmd[commit] = "candidate-commit"
    for i, part in enumerate(cmd):
        if part.startswith("type=bind,src=") and part.endswith(",dst=/project,readonly"):
            assert Path(part.removeprefix("type=bind,src=").removesuffix(",dst=/project,readonly")).name == "candidate"
            cmd[i] = "candidate-source"
        if part.startswith("type=bind,src=") and part.endswith(",dst=/scratch"):
            cmd[i] = "isolated-candidate-output"
    return cmd


def invoke(args, env):
    return subprocess.run([sys.executable, "-B", "launch.py", *args], capture_output=True, text=True, env=env)


def main():
    here = launch.HERE
    proof = here / "proof"
    snapshot = here / "snapshots" / NEW
    original = launch.ORIGINAL / "run-l.sh"
    shell = launch.derive(original.read_text())
    subprocess.run(["bash", "-n"], input=shell, check=True, text=True)
    print("Derived Bash syntax exit=0")
    for log, commit, source in (("old-dry-run.log", launch.OLD, launch.FROZEN),
                                ("new-dry-run.log", NEW, snapshot)):
        preview = command(proof / log)
        assert preview[-1] == commit
        assert f"type=bind,src={source}/candidate,dst=/project,readonly" in preview
        assert normalize(preview) == normalize(command(ORIGINAL_CANDIDATE_COMMAND))
        print(f"{log} matches actual frozen L candidate Docker args except source mount, commit, attempt mount and name")
    env = dict(os.environ, PATH=f"{proof / 'forbid-docker'}:{os.environ['PATH']}")
    bad = invoke(["--dry-run", "--candidate", NEW, "--output-root", str(launch.BASELINE.parent.parent.parent)], env)
    assert bad.returncode == 2 and "Output must be" in bad.stderr, bad
    print("Existing original output root rejected, exit=2")
    old = invoke(["--run", "--candidate", launch.OLD], env)
    assert old.returncode == 2 and "available for dry-run only" in old.stderr, old
    print("Dry-run-only original candidate rejected for live use, exit=2")
    output = Path(f"/mnt/datab/geopilot-p13-05-vector-l-t14.{NEW[:12]}.{here.name.rsplit('.', 1)[-1]}")
    with tempfile.TemporaryDirectory(prefix="t14-lease-fixture.", dir="/dev/shm") as temp:
        folder = Path(temp)
        with (folder / ".orchestrator.lock").open("w") as handle:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            busy = subprocess.run(
                ["bash", "-s", "--", "--run", "--workload", launch.WORKLOAD],
                input=launch.once(shell, "m_output=/mnt/datab/geopilot-p13-05-vector-m.8IVSI6", f"m_output={folder}"),
                env=dict(env, T14_PLAN=str(here), T14_SNAPSHOT=str(snapshot), T14_CANDIDATE=NEW,
                         T14_OUTPUT=str(output), T14_BASELINE=str(launch.BASELINE)),
                capture_output=True, text=True,
            )
    assert busy.returncode == 2 and "holds the shared measurement lease" in busy.stderr, busy
    assert not output.exists()
    assert not (proof / "forbid-docker/docker.calls").exists()
    print("Busy lock fixture rejected before creating output; Docker calls=0")
    raw_environment = json.loads((launch.BASELINE / "evidence/environment.json").read_bytes())
    assert (raw_environment["planned_warmups"], raw_environment["planned_repeats"]) == (2, 5)
    assert raw_environment["run_wait_seconds"] == 600 and raw_environment["budget_seconds"] is None
    protocol = "benchmarks/manifest.yaml"
    assert launch.sha(snapshot / "candidate" / protocol) == raw_environment["protocol_sha256"]
    config = json.loads((launch.BASELINE / "evidence/runtime-configuration.json").read_bytes())
    print("Frozen benchmark protocol and original evidence agree on 2+5 per cold/warm group, wait 600 s, no total budget")
    print(f"Baseline runtime configuration receipt sha256={config['before']['sha256']}")


if __name__ == "__main__":
    main()
