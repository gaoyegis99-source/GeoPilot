# P13-05 矢量 L T14 裁回修复单侧复测

按面积分配候选基于 `fff225f223568921ef2ac56f2b76ee9c4f8cbd29`。候选树由该提交的精确 Git 树导出，覆盖原正式 L 运行使用的五个文件。严格比较器沿用独立的原冻结 runner 副本。候选树清单 SHA-256 为 `05258667966a75b5695ca10e9835daf9bb36d050fd8254fdfe95eabef18930e7`，runner 清单 SHA-256 为 `b0b83f6fa51bf097a28b8ae69e828e0ef401e35981e7262f469eca52c95c5af2`。

正式测量由主控在现行栅格批次之后安排。以下命令从本计划目录执行。

```bash
python3 -B launch.py --dry-run --candidate a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc
python3 -B launch.py --dry-run --candidate fff225f223568921ef2ac56f2b76ee9c4f8cbd29
python3 -B launch.py --run --candidate fff225f223568921ef2ac56f2b76ee9c4f8cbd29
```

本计划的候选已准备。若为同一基线准备后续提交，先运行 `python3 -B launch.py --prepare --candidate FULL_COMMIT_SHA`，然后按上述方式预演。准备在新目录原子发布快照，要求提交是原候选的后继，配置、基准、生成器与参考文件不变。正式运行在获得共用租约后复查候选树完整内容。

正式默认根为 `/mnt/datab/geopilot-p13-05-vector-l-t14.fff225f22356.SIbfWQ`。两缓存组各 2 次预热、5 次正式测量，等待上限 600 秒，整组预算为空。实际候选侧命令与原候选相同的参数经逐 token 比对，变化限于候选源挂载、源版本、新结果挂载和对应容器名。流程复用原 `run-l.sh` 的命令构造、运行、候选侧校验、完成指针和比较。派生差异见 `proof/derived-launcher.diff`。

原版固定为 `/mnt/datab/geopilot-p13-05-vector-l.a2d2e68.C905zE/t14-split_by_area/base/attempt.6p4fhK`。当前预检只读验证小型元数据封存、14 个已实际执行的失败样本、原版摘要及严格自比较。原始输入 GPKG 的字节校验沿用当次正式分片结果。候选仍按原协议生成并验证自己的输入文件组及独立正确性。比较前确认两个分片的各 14 个 run ID 不重叠，并复查旧原版元数据封存。原版 0 通过、14 失败，严格比较会保留失败分布。

共用历史 M 锁必须存在且空闲。候选结果根有独立锁与计划身份，旧结果根会被拒绝。未完成尝试保留，新运行创建新的 attempt。完整候选可核验后继续用于配对。现行队列由主控排程。

预演和测试在 CPU31、nice 19、ionice idle 下执行。两个版本的预演和新候选准备均退出 0。假忙锁、旧输出路径、旧候选 live 请求均被拒绝，退出 2。Docker 替身记录为零，正式结果根不存在。证明和原始命令见 `proof/`。
