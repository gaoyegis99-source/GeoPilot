#!/usr/bin/env python3
"""Prepare or run one T14 L candidate using the frozen L recipe and existing baseline."""
import argparse
import difflib
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1")
ARTIFACTS = REPO / "artifacts/test-results"
ORIGINAL = ARTIFACTS / "p13-05-vector-l-plan.a2d2e68.C905zE"
FROZEN = ARTIFACTS / "p13-05-revised-pair-source.a2d2e68"
BASELINE = Path("/mnt/datab/geopilot-p13-05-vector-l.a2d2e68.C905zE/t14-split_by_area/base/attempt.6p4fhK")
OLD = "a2d2e6874fd7d5d2a239de9d95a927f8505e2ebc"
BASE = "977ab412d9f6e7558d22a5c431fac0ada90b07be"
WORKLOAD = "t14-split_by_area"
OLD_LAUNCHER = "0a9a3b3568923fad2ad588b7d7bb4b45798c7e1ea6eb5c5b51d5bc8559125de0"
FROZEN_RUNNER_MANIFEST = "b0b83f6fa51bf097a28b8ae69e828e0ef401e35981e7262f469eca52c95c5af2"
OLD_TREE_MANIFEST = "ff853a59c4dea94bd0cf1046c34d1980904a3661744ee3827e7911303b51fac7"
BASE_SAMPLES = "52f899e03926d5ecf24e4b1a12cc37777bd8dca8b1f6247685283a6693b7533a"
BASELINE_MANIFEST = "e29b842a49fc8345966643ba888a0a31b3144d4bd1f5103e0a7e7b0f8ac36355"
OVERLAYS = ("run_vector.py", "_vector_reference.py", "_vector_road_profile.py",
            "run_with_runtime_configuration.py", "_runtime_config.py")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.run(["git", "-C", REPO.parent, *args], check=True, capture_output=True, text=True).stdout.strip()


def check_files(root, manifest):
    subprocess.run(["sha256sum", "--quiet", "-c", manifest], cwd=root, check=True)


def check_frozen_runner():
    manifest = FROZEN / "proof/frozen-runner.sha256"
    require(sha(manifest) == FROZEN_RUNNER_MANIFEST, "Frozen runner manifest changed")
    check_files(FROZEN / "runner", manifest)


def check_plan():
    require(sha(HERE / "proof/baseline.sha256") == BASELINE_MANIFEST, "Baseline metadata seal changed")
    for name in ("check-side.py", "expected-inputs.json"):
        require(sha(HERE / "proof" / name) == sha(ORIGINAL / "proof" / name), f"Original verifier differs: {name}")


def verify_baseline():
    require(BASELINE.resolve(strict=True) == BASELINE, "Baseline path is not canonical")
    mount = subprocess.check_output(
        ["findmnt", "-n", "-o", "SOURCE,FSTYPE,UUID,MAJ:MIN", "--target", BASELINE], text=True,
    ).split()
    require(mount == ["/dev/sdb1", "ext4", "41500e8e-5be7-438f-b5ff-9caeebd11411", "8:17"],
            "Baseline is not on the original vector storage device")
    require((BASELINE.parent / "COMPLETED").read_text().strip() == BASELINE.name, "Baseline completion pointer differs")
    check_files(BASELINE, HERE / "proof/baseline.sha256")
    require(sha(BASELINE / "evidence/samples.jsonl") == BASE_SAMPLES, "Baseline samples differ from the independent audit")
    verification = json.loads((BASELINE / "shard-verification.json").read_bytes())
    require(verification["source_commit"] == BASE and verification["workload"] == WORKLOAD
            and verification["sample_counts"] == {"FAIL": 14, "PASS": 0, "NOT_RUN": 0},
            "Expected the original, complete 14-trial T14 baseline")
    env = BASELINE / "evidence"
    cmd = [sys.executable, "-B", FROZEN / "runner/run_memory_profile.py", "--kind", "vector",
           "--require-runtime-configuration", "--before", env, "--after", env]
    observed = subprocess.check_output(cmd)
    require(observed == (BASELINE / "self-comparison.json").read_bytes(), "Frozen baseline self-comparison differs")
    print(f"reuse readonly baseline={BASELINE} raw_sha256={BASE_SAMPLES} trials=14", flush=True)


def source_identity(commit, snapshot):
    marker = snapshot / "proof/candidate-commit"
    manifest = snapshot / "proof/candidate-tree.sha256"
    require(marker.read_text().strip() == commit, "Candidate revision differs from snapshot")
    actual = sha(manifest)
    if commit == OLD:
        require(actual == OLD_TREE_MANIFEST, "Original candidate manifest changed")
    else:
        record = json.loads((snapshot / "proof/preparation.json").read_bytes())
        require(record == {"commit": commit, "tree_manifest_sha256": actual, "runner_manifest_sha256": FROZEN_RUNNER_MANIFEST},
                "Prepared candidate identity changed")
    check_files(snapshot / "runner", FROZEN / "proof/frozen-runner.sha256")
    for name in OVERLAYS:
        require(sha(snapshot / "candidate/scripts/bench" / name) == sha(snapshot / "runner" / name),
                f"Candidate overlay differs: {name}")
    require((snapshot / "proof/frozen-runner.sha256").read_bytes()
            == (FROZEN / "proof/frozen-runner.sha256").read_bytes(), "Snapshot runner seal changed")
    return actual


def prepare(commit, snapshot):
    require(commit != OLD, "The original candidate is reserved for dry-run")
    git("merge-base", "--is-ancestor", OLD, commit)
    require(not snapshot.exists(), f"Candidate snapshot already exists: {snapshot}")
    # Only a production candidate may change. Benchmarks, generators, configuration and fixture references stay fixed.
    unchanged = ("config", "benchmarks", "scripts/bench", "tests/fixtures/vector",
                 "tests/gis/test_source_feature_identity.py", "tests/methods/test_full_geometry_before_clip.py")
    require(not git("diff", "--name-only", OLD, commit, "--", *[f"system-prototype-v1/{path}" for path in unchanged]),
            "Candidate differs in configuration, benchmark code or generator reference sources")
    snapshot.parent.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=f".{commit[:12]}-", dir=snapshot.parent) as temporary:
        stage = Path(temporary)
        for folder in ("candidate", "runner", "proof"):
            (stage / folder).mkdir()
        git_tree = f"{commit}:system-prototype-v1"
        subprocess.run(
            ["bash", "-c", 'set -euo pipefail; git -C "$1" archive "$2" | tar -x -C "$3"',
             "archive", REPO.parent, git_tree, stage / "candidate"], check=True,
        )
        for name in (*OVERLAYS, "run_memory_profile.py"):
            shutil.copyfile(FROZEN / "runner" / name, stage / "runner" / name)
            if name in OVERLAYS:
                shutil.copyfile(stage / "runner" / name, stage / "candidate/scripts/bench" / name)
        shutil.copyfile(FROZEN / "proof/frozen-runner.sha256", stage / "proof/frozen-runner.sha256")
        manifest = stage / "proof/candidate-tree.sha256"
        with manifest.open("wb") as stream:
            subprocess.run(
                ["bash", "-c", "set -euo pipefail; find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum"],
                cwd=stage / "candidate", stdout=stream, check=True,
            )
        (stage / "proof/candidate-commit").write_text(commit + "\n")
        record = {"commit": commit, "tree_manifest_sha256": sha(manifest), "runner_manifest_sha256": FROZEN_RUNNER_MANIFEST}
        (stage / "proof/preparation.json").write_text(json.dumps(record, indent=2) + "\n")
        source_identity(commit, stage)
        stage.rename(snapshot)
    print(json.dumps({"snapshot": str(snapshot), **record}, indent=2))


def once(text, old, new):
    require(text.count(old) == 1, f"Frozen launcher anchor changed: {old!r}")
    return text.replace(old, new, 1)


def derive(original):
    shell = once(original, 'plan="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"', 'plan="${T14_PLAN:?}"')
    shell = once(shell, 'snapshot="$repo/artifacts/test-results/p13-05-revised-pair-source.a2d2e68"', 'snapshot="${T14_SNAPSHOT:?}"')
    shell = once(shell, 'output_root="/mnt/datab/geopilot-p13-05-vector-l.a2d2e68.${plan##*.}"', 'output_root="${T14_OUTPUT:?}"')
    shell = once(shell, f"  [candidate]={OLD}", '  [candidate]="${T14_CANDIDATE:?}"')
    shell = once(shell, 'all=(t13-points-intersects t13-lines-intersects t14-split_by_area)', f'all=({WORKLOAD})')
    shell = once(shell, 't13-points-intersects|t13-lines-intersects|t14-split_by_area) ;;', f'{WORKLOAD}) ;;')
    start = shell.index('(\n  cd "$snapshot"\n  sha256sum --quiet -c "$plan/proof/revised-source-identity.sha256"')
    end = shell.index("printf 'mode=", start)
    shell = shell[:start] + '''session_identity="$(
  cd "$plan"
  sha256sum launch.py proof/{check-side.py,expected-inputs.json,baseline.sha256} |
    cat - "$snapshot/proof/candidate-tree.sha256" |
    sha256sum | cut -d ' ' -f 1
)"
''' + shell[end:]
    start = shell.index("side_order() {")
    end = shell.index('[[ -d "$runtime"', start)
    shell = shell[:start] + '''if [[ "$mode" == dry-run ]]; then
  build_command "${selected[0]}" candidate "$output_root/${selected[0]}/candidate/attempt.NEW" \\
    "geopilot-p1305-L-${commits[candidate]:0:12}-${plan##*.}-${selected[0]}-candidate-NEW"
  print_command
  exit 0
fi

[[ -f "$m_output/.orchestrator.lock" && ! -L "$m_output/.orchestrator.lock" ]] ||
  die 'The shared formal measurement lease is missing'
exec 8<"$m_output/.orchestrator.lock"
flock -n 8 || die 'Another formal batch holds the shared measurement lease'
check_source candidate
''' + shell[end:]
    shell = once(shell, 'name="geopilot-p1305-L-a2d2e68-${plan##*.}-$workload-$side-${attempt##*.}"',
                 'name="geopilot-p1305-L-${commits[candidate]:0:12}-${plan##*.}-$workload-$side-${attempt##*.}"')
    shell = once(shell, '''  side_order "$workload"
  for side in "${sides[@]}"; do
    measure_side "$workload" "$side"
  done''', '''  completed[base]="${T14_BASELINE:?}/evidence"
  measure_side "$workload" candidate
  python3 -B "$plan/launch.py" --check-disjoint "${completed[base]}" "${completed[candidate]}"
  (cd "${T14_BASELINE:?}" && sha256sum --quiet -c "$plan/proof/baseline.sha256")''')
    return shell


def disjoint(before, after):
    def ids(folder):
        path = Path(folder) / "samples.jsonl"
        return {json.loads(line)["run_id"] for line in path.read_text().splitlines()}
    a, b = ids(before), ids(after)
    require(len(a) == len(b) == 14 and not a & b, "Candidate and baseline run IDs overlap or are incomplete")


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--prepare", action="store_true")
    modes.add_argument("--dry-run", action="store_true")
    modes.add_argument("--run", action="store_true")
    modes.add_argument("--print-derivation", action="store_true")
    modes.add_argument("--check-disjoint", nargs=2, metavar=("BASE_EVIDENCE", "CANDIDATE_EVIDENCE"))
    parser.add_argument("--candidate")
    parser.add_argument("--output-root", type=Path)
    args = parser.parse_args()
    if args.check_disjoint:
        disjoint(*args.check_disjoint)
        return
    original_path = ORIGINAL / "run-l.sh"
    require(sha(original_path) == OLD_LAUNCHER, "Original L launcher bytes changed")
    original = original_path.read_text()
    if args.print_derivation:
        sys.stdout.writelines(difflib.unified_diff(
            original.splitlines(keepends=True), derive(original).splitlines(keepends=True),
            fromfile="frozen/run-l.sh", tofile="derived/run-l.sh",
        ))
        return
    commit = args.candidate
    require(commit is not None and re.fullmatch(r"[0-9a-f]{40}", commit)
            and git("rev-parse", "--verify", f"{commit}^{{commit}}") == commit,
            "Provide an exact existing 40-hex candidate commit")
    check_plan()
    check_frozen_runner()
    snapshot = FROZEN if commit == OLD else HERE / "snapshots" / commit
    if args.prepare:
        prepare(commit, snapshot)
        return
    require(not args.run or commit != OLD, "Original candidate is available for dry-run only")
    seal = source_identity(commit, snapshot)
    output = args.output_root or Path(f"/mnt/datab/geopilot-p13-05-vector-l-t14.{commit[:12]}.{HERE.name.rsplit('.', 1)[-1]}")
    require(output.is_absolute() and output.resolve() == output and "," not in str(output)
            and output.parent == Path("/mnt/datab")
            and output.name.startswith(f"geopilot-p13-05-vector-l-t14.{commit[:12]}."),
            "Output must be a fresh or owned T14 candidate directory named for this commit under /mnt/datab")
    verify_baseline()
    print(f"candidate={commit} snapshot={snapshot} tree_sha256={seal}", flush=True)
    env = dict(os.environ, T14_PLAN=str(HERE), T14_SNAPSHOT=str(snapshot), T14_CANDIDATE=commit,
               T14_OUTPUT=str(output), T14_BASELINE=str(BASELINE))
    code = subprocess.run(["bash", "-s", "--", "--run" if args.run else "--dry-run", "--workload", WORKLOAD],
                          input=derive(original), text=True, env=env, check=False).returncode
    raise SystemExit(code)


if __name__ == "__main__":
    try:
        main()
    except (KeyError, OSError, TypeError, ValueError, subprocess.CalledProcessError) as error:
        print(f"T14 candidate: {error}", file=sys.stderr)
        raise SystemExit(2) from error
