"""Run the S supplement only after the exact M supervisor terminates."""
import os
from pathlib import Path
import sys
import time

root = Path(sys.argv[1]).resolve()
project = Path(sys.argv[2]).resolve()
pid = int(sys.argv[3])
proc = Path(f"/proc/{pid}/stat")

def state():
    try:
        tail = proc.read_text().rsplit(") ", 1)[1].split()
        return tail[0], tail[19]
    except FileNotFoundError:
        return None

initial = state()
assert initial and initial[0] != "Z"
while True:
    now = state()
    if not now or now[0] == "Z" or now[1] != initial[1]:
        break
    time.sleep(15)
assert (root / "supervisor.exit-code").read_text().strip() == "0", "M supervisor terminated without completion receipt"
assert all((root / family / "exit-code").is_file() for family in ("raster", "remote-sensing"))
os.execv("/bin/bash", ["/bin/bash", str(root / "run-s.sh"), str(root), str(project)])
