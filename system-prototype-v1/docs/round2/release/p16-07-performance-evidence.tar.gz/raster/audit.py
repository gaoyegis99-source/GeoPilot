"""Independently calculate V2 targets from all retained complete-method trials."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import argparse
import json
import math
import statistics

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--tier", choices=("M", "S", "all"), default="all")
args = parser.parse_args()
root = Path(__file__).resolve().parent
commit = (root / "source-commit").read_text().strip()
records = []
all_ids = set()
for tier in (("M", "S") if args.tier == "all" else (args.tier,)):
    prefix = "" if tier == "M" else "s-"
    targets = json.loads((root / f"targets{'-s' if tier == 'S' else ''}.json").read_bytes())
    for family in ("raster", "remote-sensing"):
        folder = root / f"{prefix}{family}"
        evidence = folder / "evidence"
        target_key = ("dem" if family == "raster" else "remote_sensing") + f"_{tier.lower()}_p95_seconds_max"
        target = targets[target_key]
        output = {
            "family": family, "tier": tier, "target_p95_seconds": target,
            "target_policy_sha256": sha256((root / f"targets{'-s' if tier == 'S' else ''}.json").read_bytes()).hexdigest(),
        }
        records.append(output)
        if not (folder / "exit-code").is_file():
            output["status"] = "NOT_TERMINAL"
            continue
        output["exit_code"] = int((folder / "exit-code").read_text())
        if not (evidence / "report.json").is_file() or not (evidence / "trials.jsonl").is_file():
            output["status"] = "INCOMPLETE"
            continue
        report_bytes = (evidence / "report.json").read_bytes()
        report = json.loads(report_bytes)
        assert report["environment"]["commit"] == commit
        assert report["environment"]["affinity"] == [17, 18, 19, 20]
        assert report["family"] == family.replace("-", "_") and report["mode"] == "formal"
        output["report_status"] = report["status"]
        output["environment"] = report["environment"]
        output["recipe"] = report["command"]
        output["report_sha256"] = sha256(report_bytes).hexdigest()
        trials_raw = (evidence / "trials.jsonl").read_bytes()
        trials = [json.loads(line) for line in trials_raw.splitlines()]
        output["raw_trials_sha256"] = sha256(trials_raw).hexdigest()
        receipt_path = evidence / "runtime-configuration.json"
        if receipt_path.is_file():
            receipt = json.loads(receipt_path.read_bytes())
            assert receipt["before"] == receipt["after"]
            assert receipt["report_files"]["report.json"] == output["report_sha256"]
            output["runtime_configuration_matched"] = True
            output["runtime_configuration_sha256"] = sha256(receipt_path.read_bytes()).hexdigest()
        else:
            output["runtime_configuration_matched"] = False
        fixture = root / f"inputs-{prefix}{family}" / tier / "manifest.json"
        fixture_ref = json.loads(fixture.read_bytes())["reference"]
        manifest = sha256(fixture.read_bytes()).hexdigest()
        output["input_manifest_sha256"] = manifest
        output["input_fingerprints_matched"] = (folder / "input-fingerprint-check").read_text().strip() == "matched"
        assert all(row["workload"] == "method" and row["tier"] == tier for row in trials)
        expected_keys = [(cache, i) for cache in ("process_cold", "warm") for i in range(1, 8)]
        keys = [(row["cache"], row["index"]) for row in trials]
        assert len(keys) == len(set(keys)) and set(keys) <= set(expected_keys)
        if "inputs" in report and tier in report["inputs"]:
            assert report["inputs"][tier]["manifest_sha256"] == manifest
            output["input_fingerprints_matched"] &= (
                report["inputs"][tier]["first_fingerprints"] == report["inputs"][tier]["last_fingerprints"]
            )
        output["groups"] = {}
        for cache in ("process_cold", "warm"):
            group = [row for row in trials if row["cache"] == cache]
            output["groups"][cache] = group_report = {"raw_observed": len(group), "raw_failed": 0, "observations": []}
            valid = []
            for row in group:
                formal = row["index"] >= 3
                assert row["kind"] == ("measurement" if formal else "warmup")
                assert row.get("manifest_sha256", manifest) == manifest
                run_id = row.get("run_id")
                if run_id:
                    assert run_id not in all_ids
                    all_ids.add(run_id)
                state = row.get("run_state", {})
                correctness = row.get("correctness", {})
                observed_area = correctness.get("area_statistics", {}).get("observed", {})
                proof = {}
                if correctness:
                    assert (state["execution_status"], state["check_status"]) == ("SUCCEEDED", "PASSED")
                    assert len(row["executed_steps"]) == (7 if family == "raster" else 8)
                    assert all(step["exit_code"] == 0 and step["status"] == "SUCCEEDED" for step in row["executed_steps"])
                    expected = correctness["area_statistics"]["expected_area_by_class_m2"]
                    observed_classes = {str(item["class_id"]): item for item in observed_area["classes"]}
                    assert expected.keys() == observed_classes.keys() and observed_area["area_crs"] == "EPSG:6933"
                    if family == "raster":
                        counts = {"7": fixture_ref["valid_terrain_pixels"]}
                        nodata = fixture_ref["terrain_nodata_pixels"]
                    else:
                        counts = {str(i): fixture_ref["change_counts"][name]
                                  for i, name in [(1, "decrease"), (2, "stable"), (3, "increase")]}
                        nodata = fixture_ref["nodata_pixels"]
                    assert observed_area["nodata_pixel_count"] == nodata
                    assert observed_area["selected_pixel_count"] == sum(counts.values())
                    assert observed_area["valid_pixel_count"] == sum(counts.values())
                    assert observed_area["unselected_pixel_count"] == 0
                    assert {k: v["pixel_count"] for k, v in observed_classes.items()} == counts
                    for key, expected_value in expected.items():
                        assert math.isclose(observed_classes[key]["area_m2"], expected_value, rel_tol=2e-7, abs_tol=0.02)
                    assert math.isclose(observed_area["total_area_m2"], sum(expected.values()), rel_tol=2e-7, abs_tol=0.02)
                    proof = {
                        "counts_by_class": counts, "nodata_count": nodata,
                        "total_area_m2": observed_area["total_area_m2"], "reference_area_m2": sum(expected.values()),
                    }
                poll_errors = row.get("status_poll_errors", [])
                seconds = row.get("wall_ns", 0) / 1e9
                group_report["observations"].append({
                    "index": row["index"], "kind": row["kind"], "status": row["status"], "wall_seconds": seconds,
                    "run_id": run_id, "status_poll_errors": poll_errors,
                    "run_state": state, "correctness": proof, "error": row.get("error"),
                    "workspace_peak_bytes": row.get("workspace_size", {}).get("peak_workspace_bytes"),
                })
                if row["status"] == "PASS":
                    assert proof and not poll_errors and seconds > 0 and row["exit_code"] == 0
                    if formal:
                        valid.append(seconds)
                else:
                    group_report["raw_failed"] += 1
            group_report["qualified_measurements"] = len(valid)
            if len(group) == 7 and len(valid) == 5:
                p95 = sorted(valid)[math.ceil(.95 * len(valid)) - 1]
                group_report.update(p95_seconds=p95, median_seconds=statistics.median(valid),
                                    target_result="PASS" if p95 <= target else "FAIL")
                bench_group, = [item for item in report["groups"] if item["cache"] == cache]
                assert bench_group["operations"]["method"]["wall_ns"]["p95_nearest_rank"] == round(p95 * 1e9)
            else:
                group_report["target_result"] = "INSUFFICIENT"
        verdicts = {g["target_result"] for g in output["groups"].values()}
        output["status"] = ("INSUFFICIENT" if not output["runtime_configuration_matched"] or
                            not output["input_fingerprints_matched"] or "INSUFFICIENT" in verdicts
                            else "FAIL" if "FAIL" in verdicts else "PASS")
        output["execution_check_correctness_pass_count"] = sum("correctness" in row for row in trials)
        output["counts_by_benchmark_status"] = dict(Counter(row["status"] for row in trials))
print(json.dumps({"source_commit": commit, "workloads": records}, indent=2))
