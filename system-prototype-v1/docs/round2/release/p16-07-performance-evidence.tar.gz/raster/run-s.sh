#!/bin/bash
set -euo pipefail
root="$1"
workspace="$2"
source_commit=$(cat "$root/source-commit")
image=sha256:c618d0d9d91d0cf473d61e5fc284aa335e87caabd51381b73cd61b2d0f93cb87
for family in raster remote-sensing; do
  output="$root/s-$family"
  cmd=(/usr/bin/docker run --rm --pull=never --name "geopilot-v2-b-s-$family-${root##*.}" --network none --cpuset-cpus 17-20
       --user "$(id -u):$(id -g)" --entrypoint /runtime/venv/bin/python --workdir /project
       -e HOME=/tmp -e QT_QPA_PLATFORM=offscreen -e QGIS_CUSTOM_CONFIG_PATH=/tmp/geopilot-qgis -e PYTHONDONTWRITEBYTECODE=1
       -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -e GDAL_NUM_THREADS=1 -e MKL_NUM_THREADS=1 -e PROJ_NETWORK=OFF -e GDAL_CACHEMAX=64
       --mount "type=bind,src=$root/source/system-prototype-v1,dst=/project,readonly"
       --mount "type=bind,src=$workspace/.environments/p13-native,dst=/runtime,readonly"
       --mount "type=bind,src=$workspace/.environments/qgis-deb/usr/bin/qgis_process,dst=/usr/bin/qgis_process,readonly"
       --mount "type=bind,src=$workspace/.environments/qgis-deb/usr/bin/qgis_process.bin,dst=/usr/bin/qgis_process.bin,readonly"
       --mount "type=bind,src=$root/inputs-s-$family,dst=/inputs,readonly"
       --mount "type=bind,src=$output,dst=/scratch" "$image"
       -B scripts/bench/run_with_runtime_configuration.py --kind raster --config /project/config --output /scratch/evidence --
       --profile "benchmarks/datasets/$family.yaml" --tiers S --workload method --cache process_cold warm
       --input-root /inputs --timeout 1800 --source-commit "$source_commit")
  printf '%q ' "${cmd[@]}" > "$output/command.sh"
  printf '\n' >> "$output/command.sh"
  date -u +%FT%T.%NZ > "$output/started-utc"
  cat /proc/pressure/{cpu,io,memory} > "$output/host-pressure-before.log"
  printf 'start %s ' "$family"
  cat "$output/started-utc"
  set +e
  "${cmd[@]}" > "$output/benchmark.log" 2>&1
  code=$?
  set -e
  printf '%s\n' "$code" > "$output/exit-code"
  date -u +%FT%T.%NZ > "$output/finished-utc"
  cat /proc/pressure/{cpu,io,memory} > "$output/host-pressure-after.log"
  (cd "$root/inputs-s-$family/S" && sha256sum -- *) > "$output/input-sha256-after"
  if cmp "$output/input-sha256-before" "$output/input-sha256-after"; then
    printf 'matched\n' > "$output/input-fingerprint-check"
  else
    printf 'changed\n' > "$output/input-fingerprint-check"
  fi
  printf 'end %s exit %s ' "$family" "$code"
  cat "$output/finished-utc"
done
printf '0\n' > "$root/supervisor-s.exit-code"
