"""Record historical P13 comparators and whether the exact fixture was reused."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import tarfile

root, project = map(Path, sys.argv[1:])
archive = project / "docs/round2/performance"
recipes = (
    ("raster", "M", "p13-05-dem-m-candidate-evidence.tar.gz", "./dem-m/candidate/attempt.f0puyhqd/evidence/report.json"),
    ("remote-sensing", "M", "p13-04-remote-method-sm-report.json", None),
    ("raster", "S", "p13-05-raster-s-evidence.tar.gz", "./dem-s/candidate/attempt.7exbfjl6/evidence/report.json"),
    ("remote-sensing", "S", "p13-05-raster-s-evidence.tar.gz", "./remote-s/candidate/attempt.q97gl6sz/evidence/report.json"),
    ("remote-sensing", "S", "p13-05-remote-s-rerun-evidence.tar.gz", "./remote-s/candidate/attempt._d7itl7q/evidence/report.json"),
)
reports = []
for family, tier, filename, member in recipes:
    if member is None:
        data = (archive / filename).read_bytes()
    else:
        with tarfile.open(archive / filename) as tar:
            data = tar.extractfile(member).read()
    old = json.loads(data)
    env = old["environment"]
    folder = root / (f"inputs-s-{family}" if tier == "S" else f"inputs-{family}")
    fixture = sha256((folder / tier / "manifest.json").read_bytes()).hexdigest()
    assert fixture == old["inputs"][tier]["manifest_sha256"]
    groups = []
    for group in old["groups"]:
        if group["tier"] != tier or group["workload"] != "method":
            continue
        metrics = group["operations"]["method"]
        wall = metrics["wall_ns"]
        groups.append({
            "cache": group["cache"], "passed": metrics["passed"], "failed": metrics["failed"],
            "median_seconds": wall["median"] / 1e9,
            "p95_nearest_rank_seconds": wall["p95_nearest_rank"] / 1e9,
        })
    reports.append({
        "family": family, "tier": tier, "historical_report": filename, "member": member,
        "report_sha256": sha256(data).hexdigest(), "historical_commit": env["commit"],
        "fixture_manifest_sha256": fixture, "historical_filesystem": env["storage"]["mount_source_and_filesystem"],
        "historical_affinity": env["affinity"], "historical_versions": env["versions"], "groups": groups,
    })
print(json.dumps(reports, indent=2))
