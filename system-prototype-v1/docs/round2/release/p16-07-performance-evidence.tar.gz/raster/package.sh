#!/bin/bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
test "$(cat "$root/supervisor.exit-code")" = 0
test "$(cat "$root/supervisor-s.exit-code")" = 0
python3 -B "$root/audit.py" > "$root/result.json"
mkdir "$root/portable"
portable="$root/portable"
for file in source-commit source-tree source-commit-object targets.json targets-s.json targets-s.defined-utc host-before.log     run.sh run-s.sh queue-s.py compare-history.py historical.json benchmark-source.sha256 audit.py package.sh     result.json supervisor.exit-code supervisor-s.exit-code; do
  cp "$root/$file" "$portable/"
done
for label in raster remote-sensing s-raster s-remote-sensing; do
  tier=M
  if [[ "$label" = s-* ]]; then tier=S; fi
  out="$portable/$label"
  mkdir -p "$out/evidence"
  for file in command.sh started-utc finished-utc exit-code host-pressure-before.log host-pressure-after.log       input-sha256-before input-sha256-after input-fingerprint-check benchmark.log; do
    cp "$root/$label/$file" "$out/"
  done
  if test -f "$root/$label/container-live.log"; then cp "$root/$label/container-live.log" "$out/"; fi
  for file in report.json trials.jsonl runtime-configuration.json; do
    if test -f "$root/$label/evidence/$file"; then cp "$root/$label/evidence/$file" "$out/evidence/"; fi
  done
  mkdir -p "$portable/inputs-$label/$tier"
  cp "$root/inputs-$label/$tier/manifest.json" "$portable/inputs-$label/$tier/"
done
(
 cd "$portable"
 find . -type f -print0 | sort -z | xargs -0 sha256sum > "$root/evidence-files.sha256"
)
cp "$root/evidence-files.sha256" "$portable/SHA256SUMS"
(
 cd "$portable"
 sha256sum -c SHA256SUMS > "$root/archive-verification.log"
 python3 -B audit.py > "$root/portable-replay.json"
)
cmp "$root/result.json" "$root/portable-replay.json"
tar -C "$portable" -czf "$root/p16-v2-raster-target-evidence.tar.gz" .
sha256sum "$root/p16-v2-raster-target-evidence.tar.gz"
