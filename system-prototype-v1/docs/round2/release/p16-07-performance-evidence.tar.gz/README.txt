Exact source f85c3c8b6f214840efd188d08409087c17668834.
Evaluate all 80 measured trials with python3 -B evaluate-performance.py "$PWD".
The output must match performance-result.json byte for byte.
Road has one complete cold/warm S/M run set and independent repeats for S warm
and M cold. All raw warmups and measurements are in the JSONL files.
Run scripts from the supplied pinned checkout. The road Python adapter selects
road-buffer-statistics@3; the normal benchmark runner and correctness oracle
are unchanged. Inputs can be regenerated from the committed benchmark profiles.
Route and raster folders contain their independent records and replay commands.
