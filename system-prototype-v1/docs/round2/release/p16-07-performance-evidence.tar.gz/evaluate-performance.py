"""Recompute candidate performance against the frozen V2 reference goals."""

from collections import Counter
import json
from math import ceil
from pathlib import Path
from statistics import median
import sys


def jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def summarize(samples, threshold):
    ids = [item["run_id"] for item in samples if item["run_id"]]
    assert len(ids) == len(set(ids))
    counts = Counter(item["status"] for item in samples)
    verified = sorted(item["seconds"] for item in samples if item["status"] == "PASS")
    assert all(value > 0 for value in verified)
    p95 = verified[ceil(0.95 * len(verified)) - 1] if len(verified) >= 3 else None
    return {
        "planned_formal": 5,
        "observed_formal": len(samples),
        "passed": counts["PASS"],
        "failed_or_missing": 5 - counts["PASS"],
        "median_seconds": median(verified) if verified else None,
        "p95_seconds": p95,
        "met": len(samples) == counts["PASS"] == 5 and p95 <= threshold,
        "samples": samples,
    }


def geo_samples(path, method, version, tier, phase_key, state_key, cache):
    results = []
    for sample in jsonl(path):
        if sample["tier"] != tier or sample["cache"] != cache or sample[phase_key] != "measurement":
            continue
        status = sample["status"]
        if status == "PASS":
            assert sample["method"] == {"id": method, "version": version}
            state = sample[state_key]
            assert state["execution_status"] == "SUCCEEDED" and state["check_status"] == "PASSED"
            assert sample["correctness"]
        results.append({
            "run_id": sample.get("run_id"),
            "seconds": sample["wall_ns"] / 1e9 if sample.get("wall_ns") is not None else None,
            "status": status,
        })
    return results


def route_samples(path, group):
    report = json.loads(path.read_bytes())
    condition = {"process_cold": "cold_process", "warm": "warm_process"}[group]
    results = []
    for sample in report["measurements"][condition]["formal"]:
        if sample["status"] == "PASS":
            proof = sample["correctness"]
            assert proof["edge_count"] == 62 and proof["total_distance_m"] == 620
            assert proof["crs"] == "EPSG:32650" and proof["all_edges_matched_input_and_continuous"]
        results.append({
            "run_id": sample.get("run_id"),
            "seconds": sample.get("elapsed_s"),
            "status": sample["status"],
        })
    return results


def evaluate(root):
    specification = json.loads((root / "performance-targets.json").read_bytes())
    rows = []
    for goal in specification["groups"]:
        method, version = goal["method"].split("/")[0].split("@")
        scale = goal["scale"]
        limit = goal["p95_seconds"]
        groups = {}
        for cache in ("process_cold", "warm"):
            if method == "road-network-shortest-path":
                observed = route_samples(root / "route/summary.json", cache)
            elif method == "road-buffer-statistics":
                path = root / "road/evidence/samples.jsonl"
                observed = geo_samples(path, method, int(version), scale, "phase", "run_status", cache)
            else:
                family = "raster" if method == "dem-terrain-analysis" else "remote-sensing"
                folder = family if scale == "M" else f"s-{family}"
                path = root / "raster" / folder / "evidence/trials.jsonl"
                observed = geo_samples(path, method, int(version), scale, "kind", "run_state", cache)
            groups[cache] = summarize(observed, limit)
        row = {**goal, "groups": groups, "initial_target_met": all(group["met"] for group in groups.values())}
        if method == "road-buffer-statistics":
            policy = json.loads((root / "road/road-ceiling.json").read_bytes())
            ceiling = policy["reference_p95_ceiling_seconds"]
            assert limit == policy["initial_improvement_targets_seconds"][scale]
            repeat_cache, = (item["cache"] for item in policy["repeat_groups"] if item["scale"] == scale)
            path = root / f"road/repeat-{scale}-{repeat_cache}/samples.jsonl"
            repeated = geo_samples(path, method, int(version), scale, "phase", "run_status", repeat_cache)
            row["repeat"] = {"cache": repeat_cache, **summarize(repeated, ceiling)}
        else:
            ceiling = limit
        groups_for_ceiling = [*groups.values(), *([row["repeat"]] if "repeat" in row else [])]
        row["reference_p95_ceiling_seconds"] = ceiling
        row["reference_p95_met"] = all(
            group["passed"] == group["observed_formal"] == 5
            and group["p95_seconds"] is not None and group["p95_seconds"] <= ceiling
            for group in groups_for_ceiling
        )
        observed = [group["p95_seconds"] for group in groups_for_ceiling if group["p95_seconds"] is not None]
        row["highest_observed_p95_seconds"] = max(observed, default=None)
        rows.append(row)
    all_ids = [sample["run_id"] for row in rows
               for group in [*row["groups"].values(), *([row["repeat"]] if "repeat" in row else [])]
               for sample in group["samples"] if sample["run_id"]]
    assert len(all_ids) == len(set(all_ids))
    return {"source_commit": (root / "source-commit").read_text().strip(), "rows": rows}


print(json.dumps(evaluate(Path(sys.argv[1])), indent=2, ensure_ascii=False))
