#!/usr/bin/env bash
set -uo pipefail
cd -- "$(dirname -- "$0")"
. ./environment.sh
sha256sum -c protocol.sha256
taskset -c 5-8 "$PYTHON" -B route_benchmark.py > benchmark.log 2>&1
result=$?
printf '%s\n' "$result" > exit-code
exit "$result"
