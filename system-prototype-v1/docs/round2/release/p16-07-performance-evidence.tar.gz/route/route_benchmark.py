import hashlib
import json
import math
import os
import signal
import socket
import statistics
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener

import geopandas as gpd
import pyogrio
from shapely.geometry import LineString, Point

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "system-prototype-v1"
PROTOCOL = json.loads((ROOT / "protocol.json").read_text())
PYTHON = sys.executable
CRS = PROTOCOL["crs"]
METHOD = {"id": "road-network-shortest-path", "version": 1}
TOOL = {"id": "python-road-network-shortest-path", "version": 1}
STEP = "solve_shortest_route"
ROLES = ("network", "start", "end")
N = PROTOCOL["grid_nodes_per_axis"]
GAP = PROTOCOL["grid_spacing_m"]
X, Y = PROTOCOL["grid_origin"]
CLIENT = build_opener(ProxyHandler({}))
RUN_IDS = set()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def file_digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def node(i, j):
    return X + GAP * i, Y + GAP * j


def prepare_fixture():
    fixture = ROOT / "fixture"
    fixture.mkdir()
    lookup = {}
    for i in range(N):
        for j in range(N):
            if i + 1 < N:
                lookup[f"x{i:02d}-{j:02d}"] = (node(i, j), node(i + 1, j))
            if j + 1 < N:
                lookup[f"y{i:02d}-{j:02d}"] = (node(i, j), node(i, j + 1))
    count = 2 * N * (N - 1)
    assert len(lookup) == count == PROTOCOL["network_edges"]
    paths = {role: fixture / f"{role}.gpkg" for role in ROLES}
    edges = gpd.GeoDataFrame({"source_feature_id": list(lookup)},
                             geometry=[LineString(pair) for pair in lookup.values()], crs=CRS)
    pyogrio.write_dataframe(edges, paths["network"], layer="network")
    for role, position in (("start", node(0, 0)), ("end", node(N - 1, N - 1))):
        frame = gpd.GeoDataFrame({"sample": [role]}, geometry=[Point(position)], crs=CRS)
        pyogrio.write_dataframe(frame, paths[role], layer=role)
    write_json(fixture / "manifest.json", {
        "nodes": N**2, "edges": count, "crs": CRS, "start": node(0, 0), "end": node(N - 1, N - 1),
        "files": {role: {"name": path.name, "size": path.stat().st_size, "sha256": file_digest(path)}
                  for role, path in paths.items()},
        "independent_reference": "An axis-adjacent route needs at least 31 east and 31 north moves. A monotone 62-move route exists, so minimum 620 m.",
    })
    return paths, lookup


def api(url, path, payload=None, *, expected=200, raw=False):
    data = None if payload is None else json.dumps(payload).encode()
    headers = {} if data is None else {"content-type": "application/json"}
    request = Request(url + path, data=data, headers=headers)
    try:
        with CLIENT.open(request, timeout=15) as response:
            body = response.read()
            assert response.status == expected, (path, response.status, expected, body[:500])
            return (body, dict(response.headers)) if raw else json.loads(body)
    except HTTPError as error:
        raise RuntimeError(f"{request.method} {path} -> {error.code}: {error.read()[:1500]!r}") from error


@contextmanager
def server(directory):
    directory.mkdir()
    with socket.socket() as reservation:
        reservation.bind(("127.0.0.1", 0))
        port = reservation.getsockname()[1]
    url = f"http://127.0.0.1:{port}"
    args = [PYTHON, "-B", "-m", "geopilot.api.server", "--database", str(directory / "project.sqlite"),
            "--workspace", str(directory / "workspace"), "--config", str(SOURCE / "config"),
            "--qgis-process", str(ROOT / "not-configured"), "--port", str(port)]
    env = dict(os.environ, PYTHONPATH=str(SOURCE / "src"))
    log = directory / "server.log"
    with log.open("wb") as stream:
        process = subprocess.Popen(args, env=env, cwd=SOURCE, stdout=stream, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        record = {"argv": args, "pid": process.pid, "cpu_affinity": sorted(os.sched_getaffinity(process.pid))}
        write_json(directory / "launch.json", record)
        try:
            deadline = time.monotonic() + 45
            while True:
                try:
                    api(url, "/openapi.json")
                    break
                except (URLError, ConnectionError, TimeoutError):
                    if time.monotonic() >= deadline or process.poll() is not None:
                        raise
                    time.sleep(0.1)
            assert record["cpu_affinity"] == PROTOCOL["cpu_affinity"]
            yield url, record
        finally:
            if process.poll() is None:
                process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
                record["forced_stop"] = True
            record["server_shutdown_return_code"] = process.returncode
            write_json(directory / "launch.json", record)


def confirmed_plan(url, paths, directory):
    methods = api(url, "/api/methods")["methods"]
    entry, = (item for item in methods if item["definition"]["id"] == METHOD["id"])
    assert entry["available"] and entry["definition"]["version"] == METHOD["version"], entry
    registered = {role: api(url, "/api/assets", {"path": str(path), "layer": role}) for role, path in paths.items()}
    for role, entry in registered.items():
        assert entry["source"]["path"] == str(paths[role]) and entry["source"]["layer"] == role
        assert entry["metadata"]["crs"] == CRS
    assert registered["network"]["metadata"]["feature_count"] == PROTOCOL["network_edges"]
    assert [registered[role]["metadata"]["feature_count"] for role in ("start", "end")] == [1, 1]
    inputs = {role: {name: item[name] for name in ("asset_id", "asset_version")} for role, item in registered.items()}
    goal = {"summary": "Find the shortest route across a 32-by-32 grid"}
    request = {"method": METHOD, "inputs": inputs,
               "critical_options": {"target_crs": CRS, "snap_tolerance_m": 0}}
    preview = api(url, "/api/tasks/context-preview", {**request, "goal": goal})
    assert set(preview["roles"]) == set(ROLES) and all(value["status"] == "READY" for value in preview["roles"].values())
    task_id = api(url, "/api/tasks", {"goal": goal}, expected=201)["task_id"]
    draft = api(url, f"/api/tasks/{task_id}/plans", request)
    assert draft["status"] == "draft" and draft["issues"] == [] and draft["inputs"] == inputs
    assert [(step["key"], step["tool"]) for step in draft["steps"]] == [(STEP, TOOL)]
    payload = {"plan_version": draft["version"]}
    endpoint = f"/api/plans/{draft['id']}"
    plan = api(url, endpoint + "/confirm", payload)
    assert plan["status"] == "confirmed" and plan["inputs"] == inputs and plan["method"] == METHOD
    write_json(directory / "plan-and-assets.json", {"registered": registered, "preview": preview, "plan": plan})
    return endpoint, payload, plan


def verify_route(edges_path, summary, lookup):
    frame = pyogrio.read_dataframe(edges_path).sort_values("sequence")
    n = 2 * (N - 1)
    start = node(0, 0)
    end = node(N - 1, N - 1)
    assert n == PROTOCOL["expected_route_edges"] and n * GAP == PROTOCOL["expected_distance_m"]
    assert len(frame) == n and list(frame.sequence) == list(range(1, n + 1))
    assert frame.crs.to_string() == CRS and summary["crs"] == CRS
    assert summary["schema_version"] == 1 and summary["distance_unit"] == "meter"
    assert summary["snap_tolerance_m"] == PROTOCOL["snap_tolerance_m"]
    assert summary["start"] == {"node_xy": list(start), "offset_m": 0}
    assert summary["end"] == {"node_xy": list(end), "offset_m": 0}
    identifiers = list(frame.source_feature_id)
    assert len(set(identifiers)) == n and identifiers == summary["edge_ids"]
    cursor = start
    distances = []
    for row in frame.itertuples(index=False):
        assert row.geometry.geom_type == "LineString" and row.geometry.is_valid
        pair = tuple(row.geometry.coords)
        assert len(pair) == 2 and pair[0] == cursor
        assert pair in (lookup[row.source_feature_id], tuple(reversed(lookup[row.source_feature_id])))
        assert (pair[1][0] - cursor[0], pair[1][1] - cursor[1]) in {(GAP, 0), (0, GAP)}
        assert row.distance_m == row.geometry.length == GAP
        distances.append(row.distance_m)
        cursor = pair[1]
    assert cursor == end
    assert math.fsum(distances) == summary["total_distance_m"] == PROTOCOL["expected_distance_m"]
    return {"edge_count": len(frame), "total_distance_m": summary["total_distance_m"],
            "crs": CRS, "start": start, "end": end, "all_edges_matched_input_and_continuous": True}


def run_trial(url, plan_data, directory, server_directory, record, lookup):
    endpoint, payload, plan = plan_data
    timer = time.monotonic()
    run_id = api(url, endpoint + "/runs", payload, expected=202)["run_id"]
    record["run_id"] = run_id
    assert run_id not in RUN_IDS, f"Reused run ID: {run_id}"
    RUN_IDS.add(run_id)
    run_endpoint = f"/api/runs/{run_id}"
    trace = []
    try:
        while True:
            status = api(url, run_endpoint)
            elapsed = time.monotonic() - timer
            trace.append({"elapsed_s": elapsed, "execution_status": status["execution_status"],
                          "check_status": status["check_status"], "report_id": status["current_report_id"]})
            if status["execution_status"] == "SUCCEEDED" and status["check_status"] == "PASSED":
                assert status["current_report_id"]
                record["elapsed_s"] = elapsed
                break
            if status["execution_status"] in {"FAILED", "CANCELLED"} or (
                status["execution_status"] == "SUCCEEDED" and
                status["check_status"] in {"FAILED", "WARNING", "NOT_CHECKED"} and status["current_report_id"]
            ):
                raise AssertionError(f"Run did not pass: {status}")
            assert elapsed < 90, f"90s observation deadline: {status}"
            time.sleep(0.1)
    finally:
        write_json(directory / "poll-trace.json", trace)
    checks = api(url, run_endpoint + "/checks")
    report = checks["current_report"]
    assert checks["check_status"] == "PASSED" and report["id"] == status["current_report_id"] and report["status"] == "PASSED"
    findings = report["report"]["phase_findings"]
    assert any(item["rule"] == "projected_crs_suitable_for_extent" and item["passed"] is True for item in findings["input"])
    assert any(item["rule"] == "output_crs_expected" and item["passed"] is True for item in findings["artifact"])
    origin = api(url, run_endpoint + "/origin")
    assert origin == {"run_id": run_id, "task_id": plan["task_id"], "plan_id": plan["id"], "plan_version": plan["version"]}
    artifacts = api(url, run_endpoint + "/artifacts")
    by_role = {item["role"]: item for item in artifacts["artifacts"]}
    assert artifacts["check_status"] == "PASSED" and artifacts["run_id"] == run_id
    assert len(artifacts["artifacts"]) == 2 and set(by_role) == {"route_edges", "route_summary"}
    assert by_role["route_edges"]["metadata"]["crs"] == CRS
    workdir = server_directory / "workspace" / "tasks" / plan["task_id"] / "runs" / run_id
    for role, suffix in (("route_edges", ".gpkg"), ("route_summary", ".json")):
        item = by_role[role]
        assert item["run_id"] == run_id and item["readable"] is True
        assert item["source"] == {"plan_id": plan["id"], "plan_version": plan["version"], "step_key": STEP,
                                  "output_name": role, "tool": TOOL, "inputs": plan["inputs"]}
        body, headers = api(url, f"/api/artifacts/{item['id']}/file", raw=True)
        downloaded = directory / f"{role}{suffix}"
        downloaded.write_bytes(body)
        assert run_id in headers["content-disposition"]
        assert (workdir / item["uri"]).read_bytes() == body
        record[f"{role}_sha256"] = file_digest(downloaded)
    record["correctness"] = verify_route(directory / "route_edges.gpkg",
                                         json.loads((directory / "route_summary.json").read_bytes()), lookup)
    steps = api(url, run_endpoint + "/steps")["steps"]
    assert len(steps) == 1 and steps[0]["step_key"] == STEP and steps[0]["status"] == "SUCCEEDED"
    assert steps[0]["log_available"]
    logs, _ = api(url, run_endpoint + f"/steps/{STEP}/log", raw=True)
    (directory / "worker.log").write_bytes(logs)
    write_json(directory / "validation.json", {"status": status, "origin": origin, "checks": checks,
                                               "artifacts": artifacts, "steps": steps})
    record["status"] = "PASS"


def observe(condition, index, trial_directory, paths, lookup, shared=None):
    trial_directory.mkdir()
    record = {"condition": condition, "index": index, "formal": index >= 3}
    try:
        if shared:
            url, launch, plan_data, server_directory = shared
            record["server_pid"] = launch["pid"]
            run_trial(url, plan_data, trial_directory, server_directory, record, lookup)
        else:
            server_directory = trial_directory / "server"
            with server(server_directory) as (url, launch):
                record["server_pid"] = launch["pid"]
                plan_data = confirmed_plan(url, paths, trial_directory)
                run_trial(url, plan_data, trial_directory, server_directory, record, lookup)
    except Exception as error:
        record.update(status="FAIL", error_type=type(error).__name__, error=str(error))
    write_json(trial_directory / "trial.json", record)
    print(json.dumps(record, separators=(",", ":")), flush=True)
    return record


def main():
    assert sorted(os.sched_getaffinity(0)) == PROTOCOL["cpu_affinity"]
    paths, lookup = prepare_fixture()
    results = ROOT / "trials"
    results.mkdir()
    records = [observe("cold_process", index, results / f"cold-{index}", paths, lookup) for index in range(1, 8)]
    warm_server = results / "warm-server"
    with server(warm_server) as (url, launch):
        plan_data = confirmed_plan(url, paths, warm_server)
        for index in range(1, 8):
            records.append(observe("warm_process", index, results / f"warm-{index}", paths, lookup,
                                   shared=(url, launch, plan_data, warm_server)))
    summary = {}
    for condition in ("cold_process", "warm_process"):
        formal = [row for row in records if row["condition"] == condition and row["formal"]]
        passed = [row["elapsed_s"] for row in formal if row["status"] == "PASS"]
        complete = len(passed) == len(formal) == 5
        p95 = sorted(passed)[math.ceil(0.95 * len(passed)) - 1] if complete else None
        summary[condition] = {"formal": formal, "passed": len(passed), "p95_s": p95,
                              "median_s": statistics.median(passed) if complete else None,
                              "threshold_met": p95 is not None and p95 <= PROTOCOL["predeclared_threshold_seconds"]}
    outcome = all(value["threshold_met"] for value in summary.values()) and all(
        row["status"] == "PASS" for row in records if not row["formal"]
    )
    write_json(ROOT / "summary.json", {"protocol": PROTOCOL, "measurements": summary, "all_passed": outcome})
    print(json.dumps({"measurements": {key: {k: v for k, v in value.items() if k != "formal"}
                                      for key, value in summary.items()}, "all_passed": outcome}), flush=True)
    return 0 if outcome else 1


if __name__ == "__main__":
    raise SystemExit(main())
