#!/bin/bash
set -uo pipefail
trial="$1"
project="$2"
source="$3"
commit="$4"
export PATH="$trial/bin:$PATH"
export PYTHONPATH="$source/scripts/bench"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen PROJ_NETWORK=OFF
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1
cd "$source" || exit
overall=0
for spec in S:warm M:process_cold
do
  tier=${spec%:*}
  cache=${spec#*:}
  status=0
  taskset -c 13-16 "$project/.venv/bin/python" -B "$trial/road_v3.py" \
    --tier "$tier" --workload road --cache-state "$cache" \
    --qgis-process "$project/.environments/qgis-deb/qgis_process" --source-commit "$commit" \
    --output "$trial/repeat-$tier-$cache" || status=$?
  printf '%s\n' "$status" > "$trial/repeat-$tier-$cache.exit-code"
  if (( status != 0 )); then overall=1; fi
done
exit "$overall"
