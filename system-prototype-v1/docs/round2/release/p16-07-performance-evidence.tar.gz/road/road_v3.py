from dataclasses import replace

import run_vector

original_workloads = run_vector.workloads


def workloads():
    definitions = original_workloads()
    definitions["road"] = replace(definitions["road"], version=3)
    return definitions


if __name__ == "__main__":
    run_vector.workloads = workloads
    raise SystemExit(run_vector.main())
