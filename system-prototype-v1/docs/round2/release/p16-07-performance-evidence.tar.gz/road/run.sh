#!/bin/bash
set -uo pipefail
trial="$1"
project="$2"
source="$3"
commit="$4"
export PATH="$trial/bin:$PATH"
export PYTHONPATH="$source/scripts/bench"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen PROJ_NETWORK=OFF
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1
cd "$source" || exit
taskset -c 13-16 "$project/.venv/bin/python" -B "$trial/road_v3.py" --tier S --tier M --workload road \
  --qgis-process "$project/.environments/qgis-deb/qgis_process" --source-commit "$commit" --output "$trial/evidence"
status=$?
printf '%s\n' "$status" > "$trial/exit-code"
exit "$status"
