#!/bin/bash
set -euo pipefail
proof="$1"
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONDONTWRITEBYTECODE=1
set +e
.venv/bin/python -B scripts/quality/validate_release_readiness.py > "$proof/preflight.json" 2> "$proof/preflight.stderr"
status=$?
set -e
printf '%s\n' "$status" > "$proof/preflight.exit-code"
test "$status" = 1 && test ! -s "$proof/preflight.stderr"
.venv/bin/python -B -m pytest -q -p no:cacheprovider \
    tests/quality/test_validate_release_readiness.py tests/quality/test_round2_status.py \
    tests/quality/test_round2_release_manifest.py \
    --basetemp="$proof/pytest" --junitxml="$proof/junit.xml" 2>&1 | tee "$proof/pytest.log"
printf '0\n' > "$proof/pytest.exit-code"
.venv/bin/python -B scripts/quality/validate_round2_status.py --require-released > "$proof/p12.json"
printf '0\n' > "$proof/p12.exit-code"
git diff --exit-code 44b17fc "$(cat "$proof/source-commit")" -- src config frontend pyproject.toml requirements.txt requirements-test.txt artifacts/schemas > "$proof/runtime-diff.log"
printf '0\n' > "$proof/runtime-diff.exit-code"
