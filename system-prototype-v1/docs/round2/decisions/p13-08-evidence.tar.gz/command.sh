#!/bin/bash
set -euo pipefail
evidence="$1"
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONDONTWRITEBYTECODE=1
.venv/bin/python -B scripts/bench/summarize_scheduler.py > "$evidence/scheduler.json"
.venv/bin/python -B -m pytest -q -p no:cacheprovider tests/benchmarks/test_summarize_scheduler.py \
  --basetemp="$evidence/pytest" --junitxml="$evidence/junit.xml" 2>&1 | tee "$evidence/pytest.log"
