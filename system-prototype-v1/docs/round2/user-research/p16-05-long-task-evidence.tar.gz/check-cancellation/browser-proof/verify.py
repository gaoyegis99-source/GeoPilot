"""Verify saved SQLite/file snapshots and the actual downloaded artifact."""
import csv
from hashlib import sha256
import json
from pathlib import Path
import sys

output = Path(sys.argv[1]).resolve(strict=True)
source = output.parent / "system-prototype-v1"
def document(name):
    return json.loads((output / name).read_bytes())

run = document("before-cancel.json")
cancelled = document("after-cancel.json")
checking = document("during-recheck.json")
passed = document("after-recheck.json")
paths = ["plan_runs", "steps", "artifacts", "execution_and_artifact_files"]
for field in paths:
    assert all(candidate[field] == run[field] for candidate in (cancelled, checking, passed)), field
id = run["run"]["id"]
assert run["plan_runs"] == [id]
assert len(run["steps"]) == 7 and all(step["status"] == "SUCCEEDED" for step in run["steps"])
assert [item["run"]["execution_status"] for item in (run, cancelled, checking, passed)] == ["SUCCEEDED"] * 4
assert [item["run"]["check_status"] for item in (run, cancelled, checking, passed)] == ["CHECKING", "NOT_CHECKED", "CHECKING", "PASSED"]
old_id, new_id = cancelled["run"]["current_report_id"], passed["run"]["current_report_id"]
assert new_id != old_id
old_report, = [record for record in cancelled["checks"] if record["id"] == old_id]
new_report, = [record for record in passed["checks"] if record["id"] == new_id]
assert old_report in checking["checks"] and old_report in passed["checks"]
assert len(passed["checks"]) == 2 and old_report["status"] == "NOT_CHECKED" and new_report["status"] == "PASSED"
assert json.loads(old_report["report_json"])["interruption"]["code"] == "CHECK_CANCELLED"
assert json.loads(new_report["report_json"])["interruption"] is None
returned = [document(f"barrier/returned-{index}.json") for index in (1, 2)]
assert all(record["rule"] == "measurement_policy_satisfied" and record["passed"] is True for record in returned)
summary = document("browser.log")
assert summary["status"] == "PASS" and (summary["initial_check_report"], summary["recheck_report"]) == (old_id, new_id)
download = output / "recheck-result.csv"
with download.open(encoding="utf-8", newline="") as stream:
    counts = {row["zone_id"] or "unassigned": int(row["count"]) for row in csv.DictReader(stream)}
expected = json.loads((source / "tests/fixtures/vector/expected.json").read_bytes())["relations"]["intersects"]["counts"]
assert {**counts, "total": sum(counts.values())} == expected
download_digest = sha256(download.read_bytes()).hexdigest()
csv_role, = [record for record in run["artifacts"] if record["role"] == "zone_statistics"]
csv_identity = run["execution_and_artifact_files"]["intermediate/aggregate_by_zone/statistics.csv"]
assert download_digest == csv_identity["sha256"]
manifest = json.loads((source / "artifacts/reports/final/round2-delivery-manifest.json").read_bytes())
assert manifest["source_commit"].startswith("6ecdbca")
print(json.dumps({
    "scope": "technical browser rehearsal with a disclosed test-only wait before the original rule on both attempts",
    "source_commit": manifest["source_commit"], "run_id": id,
    "report_ids": {"cancelled": old_id, "rechecked": new_id},
    "check_states": [item["run"]["check_status"] for item in (run, cancelled, checking, passed)],
    "execution_states": [item["run"]["execution_status"] for item in (run, cancelled, checking, passed)],
    "execution_count": len(run["plan_runs"]), "unchanged_step_records": len(run["steps"]),
    "unchanged_artifacts": [{"role": record["role"], "id": record["id"]} for record in run["artifacts"]],
    "unchanged_file_identities": len(run["execution_and_artifact_files"]),
    "original_report_unchanged": True, "original_rule_returned": returned,
    "download": {"id": csv_role["id"], "sha256": download_digest, "matches_gis_output_bytes": True, "counts": counts},
    "status": "PASS"
}, indent=2))
