"""Snapshot persisted GIS results and report state in a read-only transaction."""
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
import sys

output, run_id = Path(sys.argv[1]).resolve(), sys.argv[2]


def digest(path):
    info = path.stat()
    return {
        "sha256": sha256(path.read_bytes()).hexdigest(), "size": info.st_size,
        "mtime_ns": info.st_mtime_ns, "inode": info.st_ino,
    }


with sqlite3.connect((output / "data/project.sqlite").as_uri() + "?mode=ro", uri=True) as db:
    db.row_factory = sqlite3.Row
    db.execute("BEGIN")
    run = dict(db.execute("SELECT * FROM run WHERE id = ?", (run_id,)).fetchone())
    workdir = Path(run["workdir"]).resolve(strict=True)
    assert workdir.is_relative_to(output / "data/workspace")
    tasks_runs = [row[0] for row in db.execute("SELECT id FROM run WHERE plan_id = ? ORDER BY created_at", (run["plan_id"],))]
    steps = [dict(row) for row in db.execute("SELECT * FROM run_step WHERE run_id = ? ORDER BY position", (run_id,))]
    artifacts = [dict(row) for row in db.execute("SELECT * FROM artifact WHERE run_id = ? ORDER BY role", (run_id,))]
    reports = [dict(row) for row in db.execute("SELECT * FROM check_report WHERE run_id = ? ORDER BY created_at, id", (run_id,))]
    results = {}
    for directory in ("steps", "intermediate", "outputs"):
        for path in sorted((workdir / directory).rglob("*")):
            if path.is_file() and not path.name.endswith(("-shm", "-wal", "-journal")):
                results[path.relative_to(workdir).as_posix()] = digest(path)
print(json.dumps({"run": run, "plan_runs": tasks_runs, "steps": steps, "artifacts": artifacts,
                  "checks": reports, "execution_and_artifact_files": results}, indent=2, sort_keys=True))
