"""Call the unmodified candidate entry point with a test-only wait around one real check."""
from functools import wraps
import json
import os
from pathlib import Path
import time

from geopilot.api import server

directory = Path(os.environ["GEOPILOT_TEST_CHECK_BARRIER"]).resolve(strict=True)
name = "measurement_policy_satisfied"
original = server.RUN_CHECKS[name]
arrival = 0


@wraps(original)
def wait_for_browser(context):
    global arrival
    arrival += 1
    position = arrival
    marker = directory / f"entered-{position}.json"
    temporary = marker.with_suffix(".tmp")
    temporary.write_text(json.dumps({
        "rule": name, "invocation": position, "workdir": str(context.workdir),
        "entered_monotonic_ns": time.monotonic_ns(),
    }) + "\n", encoding="utf-8")
    temporary.replace(marker)
    deadline = time.monotonic() + 45
    while not (directory / f"release-{position}").is_file():
        if time.monotonic() > deadline:
            print(f"CHECK_BARRIER_TIMED_OUT {position}; continuing original rule", flush=True)
            break
        time.sleep(0.03)
    result = original(context)
    (directory / f"returned-{position}.json").write_text(json.dumps({
        "rule": name, "invocation": position, "passed": result.passed,
        "returned_monotonic_ns": time.monotonic_ns(),
    }) + "\n", encoding="utf-8")
    return result


server.RUN_CHECKS[name] = wait_for_browser
server.main()
