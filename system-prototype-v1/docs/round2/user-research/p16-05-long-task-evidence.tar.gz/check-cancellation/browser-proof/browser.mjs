import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { access, appendFile, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'

const directory = process.argv[2] ?? process.cwd()
const session = JSON.parse(await readFile(join(directory, 'session.json'), 'utf8'))
const site = new URL(session.url)
assert.equal(site.protocol, 'http:')
assert.equal(site.hostname, '127.0.0.1')
const { chromium } = await import(session.browser_module)
const env = { ...process.env, PATH: '/usr/bin:/bin' }
delete env.PYTHONPATH
delete env.GEOPILOT_QGIS_PROCESS
const browser = await chromium.launch({
  headless: true,
  env,
  args: ['--enable-webgl', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
})
const elapsed = performance.now()
let stage = 'startup'
const errors = []
const events = []
async function note(action, observed = {}) {
  const item = { action, automation_ms: Math.round(performance.now() - elapsed), ...observed }
  events.push(item)
  await appendFile(join(directory, 'check-trace.jsonl'), JSON.stringify(item) + '\n')
}

try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true })
  const page = await context.newPage()
  page.setDefaultTimeout(30000)
  page.on('pageerror', error => errors.push(error.message))
  const runRegion = page.getByRole('region', { name: '运行', exact: true })
  const planRegion = page.getByRole('region', { name: '方案', exact: true })
  const checkRegion = page.getByRole('region', { name: '规则检查', exact: true })
  const runState = () => runRegion.locator('span.workbench__status').innerText()
  const snapshot = async () => {
    const currentStep = runRegion.getByText('当前步骤', { exact: false }).first()
    return {
      label: await runState(),
      current_step_text: await currentStep.isVisible() ? await currentStep.innerText() : null,
      visible_run_text: await runRegion.innerText(),
      location_search: new URL(page.url()).search,
    }
  }

  async function observePost(path, action) {
    const [response] = await Promise.all([
      page.waitForResponse(item => item.request().method() === 'POST' && path.test(new URL(item.url()).pathname)),
      action(),
    ])
    return { status: response.status(), data: await response.json() }
  }

  const ok = await page.goto(site.href)
  assert.ok(ok?.ok())
  await page.getByText('暂无数据', { exact: true }).waitFor()
  await note('open clean workbench', { chromium: browser.version(), location: page.url() })

  const dataRegion = page.getByRole('region', { name: '数据', exact: true })
  const importButton = dataRegion.getByRole('button', { name: '导入数据', exact: true })
  const pathInput = dataRegion.getByLabel('本机文件路径')
  const loadLayers = dataRegion.getByRole('button', { name: '读取图层', exact: true })
  const layerInput = dataRegion.getByLabel('GeoPackage 图层')
  stage = 'register sample layers'
  const registered = {}
  for (const role of ['analysis_extent', 'roads', 'targets', 'zones']) {
    await importButton.click()
    await pathInput.fill(session.fixture)
    await loadLayers.click()
    await dataRegion.locator('select').filter({ has: page.locator('option', { hasText: /^analysis_extent$/ }) }).first().waitFor()
    await layerInput.selectOption(role)
    const asset = await observePost(/^\/api\/assets$/, () => dataRegion.getByRole('button', { name: '登记资产', exact: true }).click())
    assert.equal(asset.status, 200)
    assert.equal(asset.data.source.layer, role)
    registered[role] = { asset_id: asset.data.asset_id, asset_version: asset.data.asset_version }
    await note('register layer via browser', { layer: role, crs: asset.data.metadata.crs })
  }

  stage = 'configure confirmed road-buffer plan'
  const method = page.getByRole('region', { name: '方法目录' }).locator('details')
    .filter({ hasText: '道路缓冲统计' }).filter({ has: page.locator('summary', { hasText: /版本 3\b/ }) })
  await method.locator('summary').click()
  await method.getByRole('button', { name: '选择方法', exact: true }).click()
  const form = page.getByRole('form', { name: '方法表单' })
  await form.getByLabel('任务目标').fill('核对取消检查和重新检查后道路 500 米影响范围内的分区计数')
  for (const [role, label] of Object.entries({
    analysis_extent: '分析范围', roads: '道路', targets: '目标对象', zones: '统计分区',
  })) {
    await form.getByLabel(label, { exact: true }).selectOption({ label: `road-buffer.gpkg · ${role} · v1` })
  }
  await form.getByLabel('缓冲距离').fill('500')
  for (const [label, value] of [
    ['距离计算方式', 'local_projected'], ['空间关系', 'intersects'], ['跨界归属', 'centroid'],
    ['边界并列处理', 'unassigned'], ['统计量', 'count'], ['输出范围', 'clipped_to_analysis_extent'],
  ]) {
    await form.getByLabel(label, { exact: true }).selectOption(value)
  }
  const crs = form.getByLabel('距离坐标参考系', { exact: true })
  const createDraft = form.getByRole('button', { name: '生成草稿' })
  const confirm = planRegion.getByRole('button', { name: '确认方案', exact: true })
  await crs.fill('EPSG:32650')
  const corrected = await observePost(/^\/api\/tasks\/[^/]+\/plans$/, () => createDraft.click())
  assert.equal(corrected.status, 200)
  assert.deepEqual(corrected.data.issues, [])
  assert.deepEqual(corrected.data.inputs, registered)
  const confirmed = await observePost(/^\/api\/plans\/[^/]+\/confirm$/, () => confirm.click())
  assert.equal(confirmed.status, 200)
  assert.equal(confirmed.data.status, 'confirmed')
  await note('generate and confirm plan', {
    corrected_plan_version: corrected.data.version,
    issues: corrected.data.issues,
    preserved_four_asset_bindings: true,
    corrected_crs: corrected.data.critical_options.distance_crs_ref,
  })

  const checkState = () => checkRegion.locator('span.workbench__status').innerText()
  const files = join(directory, 'barrier')
  async function entered(position) {
    const file = join(files, `entered-${position}.json`)
    const deadline = performance.now() + 90000
    while (performance.now() < deadline) {
      try {
        await access(file)
        return JSON.parse(await readFile(file, 'utf8'))
      } catch (error) {
        if (error.code !== 'ENOENT') throw error
        await new Promise(resolve => setTimeout(resolve, 80))
      }
    }
    throw new Error(`Rule barrier ${position} was never reached`)
  }
  const release = position => writeFile(join(files, `release-${position}`), 'release original rule\n')
  function readSnapshot(label, runId) {
    const data = execFileSync(session.python, [session.snapshot_script, directory, runId], { encoding: 'utf8' })
    return writeFile(join(directory, `${label}.json`), data).then(() => JSON.parse(data))
  }
  function ensureNoExecutionOrArtifactChanges(before, after) {
    for (const field of ['plan_runs', 'steps', 'artifacts', 'execution_and_artifact_files']) {
      assert.deepEqual(after[field], before[field], `Unexpected change in ${field}`)
    }
    assert.equal(after.run.execution_status, 'SUCCEEDED')
    assert.equal(after.run.id, before.run.id)
    assert.equal(after.run.plan_id, before.run.plan_id)
    assert.equal(after.run.plan_version, before.run.plan_version)
    assert.equal(after.plan_runs.length, 1)
  }

  stage = 'start actual seven-step GIS run'
  const start = runRegion.getByRole('button', { name: '开始运行', exact: true })
  const started = await observePost(/^\/api\/plans\/[^/]+\/runs$/, () => start.click())
  assert.equal(started.status, 202)
  const runId = started.data.run_id
  await page.waitForURL(url => url.searchParams.get('run') === runId)

  stage = 'wait for initial live check'
  const firstBarrier = await entered(1)
  const cancel = runRegion.getByRole('button', { name: '取消检查', exact: true })
  await cancel.waitFor()
  await checkRegion.getByText('规则检查中', { exact: true }).waitFor()
  assert.equal(await runState(), '运行成功')
  assert.equal(await runRegion.getByRole('button', { name: '取消运行', exact: true }).count(), 0)
  assert.ok(await runRegion.getByText('正在检查成果…', { exact: true }).isVisible())
  const before = await readSnapshot('before-cancel', runId)
  assert.equal(before.run.execution_status, 'SUCCEEDED')
  assert.equal(before.run.check_status, 'CHECKING')
  assert.equal(before.steps.length, 7)
  assert.ok(before.steps.every(step => step.status === 'SUCCEEDED'))
  assert.ok(before.artifacts.length > 0)
  await note('initial check held at original measurement rule', {
    barrier: firstBarrier, run_id: runId, check_label: await checkState(), ...await snapshot(),
    step_count: before.steps.length, artifact_ids: before.artifacts.map(item => item.id),
  })
  const originalUrl = page.url()
  await page.reload({ waitUntil: 'domcontentloaded' })
  await cancel.waitFor()
  await checkRegion.getByText('规则检查中', { exact: true }).waitFor()
  assert.equal(page.url(), originalUrl)
  assert.equal(await runState(), '运行成功')
  await note('refresh restored same run and check state', { run_id: runId, check_label: await checkState(), ...await snapshot() })
  await runRegion.screenshot({ path: join(directory, 'checking.png') })

  stage = 'click cancel check and let real rule return'
  const cancelReceipt = await observePost(/^\/api\/runs\/[^/]+\/cancel$/, () => cancel.click())
  assert.equal(cancelReceipt.status, 202)
  assert.equal(cancelReceipt.data.execution_status, 'SUCCEEDED')
  assert.equal(cancelReceipt.data.check_status, 'CHECKING')
  assert.equal(cancelReceipt.data.cancel_requested, true)
  const pending = runRegion.getByRole('button', { name: '已请求取消检查', exact: true })
  await pending.waitFor()
  assert.ok(await pending.isDisabled())
  await note('cancel check accepted while execution stays successful', {
    http_status: cancelReceipt.status, response: cancelReceipt.data, check_label: await checkState(), ...await snapshot(),
  })
  await runRegion.screenshot({ path: join(directory, 'cancel-requested.png') })
  await release(1)

  stage = 'inspect interrupted check and recovery controls'
  await checkRegion.getByText('规则检查未完成', { exact: true }).waitFor()
  const cancelled = await readSnapshot('after-cancel', runId)
  ensureNoExecutionOrArtifactChanges(before, cancelled)
  assert.equal(cancelled.run.check_status, 'NOT_CHECKED')
  const firstReport = cancelled.checks.find(report => report.id === cancelled.run.current_report_id)
  assert.equal(firstReport.status, 'NOT_CHECKED')
  assert.equal(JSON.parse(firstReport.report_json).interruption.code, 'CHECK_CANCELLED')
  assert.equal(JSON.parse(cancelled.run.error_json).code, 'CHECK_CANCELLED')
  assert.equal(await runState(), '运行成功')
  const disclosure = checkRegion.locator('summary').first()
  const expanded = await disclosure.evaluate(summary => summary.parentElement.open)
  if (!expanded) await disclosure.click()
  const recheck = checkRegion.getByRole('button', { name: '重新检查', exact: true })
  await recheck.waitFor()
  const panel = checkRegion.getByRole('article', { name: '检查报告明细' })
  await panel.waitFor()
  await note('check cancelled, current report incomplete and existing run remains successful', {
    run_id: runId, report_id: firstReport.id, check_label: await checkState(), ...await snapshot(),
    report_header: await panel.locator('header').innerText(),
    report_alerts: await panel.getByRole('alert').allTextContents(),
    run_controls: await runRegion.getByRole('button').allTextContents(),
    check_controls: await checkRegion.getByRole('button').allTextContents(),
  })
  await checkRegion.screenshot({ path: join(directory, 'check-cancelled.png') })

  stage = 'click recheck without running GIS again'
  const recheckReceipt = await observePost(/^\/api\/runs\/[^/]+\/checks$/, () => recheck.click())
  assert.equal(recheckReceipt.status, 202)
  const secondReportId = recheckReceipt.data.report_id
  assert.ok(secondReportId)
  assert.notEqual(firstReport.id, secondReportId)
  const secondBarrier = await entered(2)
  await checkRegion.getByText('规则检查中', { exact: true }).waitFor()
  await cancel.waitFor()
  assert.equal(await runState(), '运行成功')
  assert.equal(page.url(), originalUrl)
  const during = await readSnapshot('during-recheck', runId)
  ensureNoExecutionOrArtifactChanges(before, during)
  assert.equal(during.run.check_status, 'CHECKING')
  assert.deepEqual(during.checks.find(report => report.id === firstReport.id), firstReport)
  assert.equal(during.checks.find(report => report.id === secondReportId).status, 'CHECKING')
  await note('recheck entered same real rule under new report', {
    barrier: secondBarrier, response: recheckReceipt.data, http_status: recheckReceipt.status,
    run_id: runId, check_label: await checkState(), ...await snapshot(),
  })
  await release(2)

  stage = 'verify final passed report and unchanged GIS output'
  await checkRegion.getByText('规则检查通过', { exact: true }).waitFor()
  const passed = await readSnapshot('after-recheck', runId)
  ensureNoExecutionOrArtifactChanges(before, passed)
  assert.equal(passed.run.check_status, 'PASSED')
  assert.equal(passed.run.current_report_id, secondReportId)
  assert.equal(passed.run.error_json, null)
  assert.deepEqual(passed.checks.find(report => report.id === firstReport.id), firstReport)
  const finalReport = passed.checks.find(report => report.id === secondReportId)
  assert.equal(finalReport.status, 'PASSED')
  assert.equal(JSON.parse(finalReport.report_json).interruption, null)
  assert.equal(passed.checks.length, 2)
  await panel.getByText('当前报告', { exact: true }).waitFor()
  const reportNumber = panel.locator('summary').filter({ hasText: '报告编号' })
  await reportNumber.click()
  await panel.getByText(secondReportId, { exact: true }).waitFor()
  const history = checkRegion.locator('.checks-panel__history select')
  await history.selectOption(firstReport.id)
  await panel.getByText('历史报告', { exact: true }).waitFor()
  assert.equal(await panel.getByLabel('报告状态').innerText(), '未完成')
  await history.selectOption('')
  await panel.getByText('当前报告', { exact: true }).waitFor()
  assert.equal(await panel.getByLabel('报告状态').innerText(), '通过')
  const csvLink = page.getByRole('list', { name: '正式成果' }).getByRole('listitem')
    .filter({ has: page.getByText('分区统计', { exact: true }) }).getByRole('link', { name: '下载原文件' })
  const [download] = await Promise.all([page.waitForEvent('download'), csvLink.click()])
  assert.equal(await download.failure(), null)
  await download.saveAs(join(directory, 'recheck-result.csv'))
  await checkRegion.screenshot({ path: join(directory, 'check-passed.png') })
  assert.deepEqual(errors, [])
  const summary = {
    status: 'PASS', chromium: browser.version(), candidate: '6ecdbca', run_id: runId,
    execution_status: passed.run.execution_status, initial_check_report: firstReport.id,
    initial_check_terminal: firstReport.status, interruption: JSON.parse(firstReport.report_json).interruption,
    recheck_report: finalReport.id, recheck_terminal: finalReport.status,
    execution_step_records_unchanged: true, unchanged_artifact_ids: passed.artifacts.map(item => item.id),
    unchanged_file_count: Object.keys(passed.execution_and_artifact_files).length,
    original_report_retained: true, same_run_url: originalUrl === page.url(), errors,
  }
  await note('verification complete', summary)
  console.log(JSON.stringify(summary, null, 2))
} catch (error) {
  await note('automation stopped', { stage, message: String(error), page_errors: errors })
  throw error
} finally {
  await browser.close()
}
