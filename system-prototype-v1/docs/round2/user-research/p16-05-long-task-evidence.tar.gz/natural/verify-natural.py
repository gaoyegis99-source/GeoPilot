"""Compare browser evidence, durable run state and the independent P13 DEM reference."""
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
import sys

import numpy as np
import rasterio

trial = Path(sys.argv[1])
inputs = Path(sys.argv[2])
evidence = trial / "browser-run"
browser = json.loads((evidence / "browser.log").read_bytes())
trace = [json.loads(line) for line in (evidence / "trace.jsonl").read_text().splitlines()]
reference = json.loads((inputs / "workloads.json").read_bytes())["dem_m"]
assert browser["status"] == "PASS" and not browser["errors"]
for file in reference["files"]:
    actual = (inputs / "DEM-M" / file["path"]).read_bytes()
    assert len(actual) == file["bytes"] and sha256(actual).hexdigest() == file["sha256"]
assert browser["before"]["seconds"] >= 5 and browser["before"]["url"] == browser["after"]["url"]

def duration(step):
    return (datetime.fromisoformat(step["finished_at"]) - datetime.fromisoformat(step["started_at"])).total_seconds()

with sqlite3.connect((evidence / "data/project.sqlite").as_uri() + "?mode=ro", uri=True) as db:
    db.row_factory = sqlite3.Row
    runs = {row["id"]: dict(row) for row in db.execute("SELECT * FROM run")}
    assert set(runs) == {browser["completed"], browser["cancelled"]}
    passed, cancelled = runs[browser["completed"]], runs[browser["cancelled"]]
    assert (passed["execution_status"], passed["check_status"]) == ("SUCCEEDED", "PASSED")
    assert (cancelled["execution_status"], cancelled["check_status"]) == ("CANCELLED", "NOT_CHECKED")
    assert (passed["plan_id"], passed["plan_version"]) == (cancelled["plan_id"], cancelled["plan_version"])
    plan = db.execute("SELECT plan_json FROM analysis_plan WHERE id=? AND version=?",
                      (passed["plan_id"], passed["plan_version"])).fetchone()
    assert json.loads(plan[0])["critical_options"] == reference["confirmed_parameters"]
    steps = lambda run_id: [dict(row) for row in db.execute(
        "SELECT * FROM run_step WHERE run_id=? ORDER BY position", (run_id,))]
    successful_steps, cancelled_steps = steps(passed["id"]), steps(cancelled["id"])
    assert [row["status"] for row in successful_steps] == ["SUCCEEDED"] * 7
    assert [row["status"] for row in cancelled_steps] == ["SUCCEEDED"] * 6 + ["CANCELLED"]
    assert cancelled_steps[-1]["step_key"] == "calculate_area_with_equal_area_projection"
    error = json.loads(cancelled_steps[-1]["result_json"])["error"]
    assert error["code"] == "PROCESS_CANCELLED"
    assert db.execute("SELECT count(*) FROM artifact WHERE run_id=?", (cancelled["id"],)).fetchone()[0] == 0
    artifacts = {row["role"]: row["uri"] for row in db.execute(
        "SELECT role,uri FROM artifact WHERE run_id=?", (passed["id"],))}
    path = Path(passed["workdir"])
    data = (evidence / "area-statistics.json").read_bytes()
    assert data == (path / artifacts["area_statistics"]).read_bytes()
    report = json.loads(data)
    expected = reference["archive_reference"]["area_statistics"]
    assert report["area_crs"] == "EPSG:6933"
    assert report["selected_pixel_count"] == 4_183_812
    assert report["nodata_pixel_count"] == 2_304
    row, = report["classes"]
    assert (row["class_id"], row["pixel_count"]) == (7, 4_183_812)
    delta = abs(report["total_area_m2"] - expected["expected_area_by_class_m2"]["7"])
    assert delta <= expected["absolute_tolerance_m2"]
    with rasterio.open(path / artifacts["threshold_regions"]) as raster:
        assert [raster.height, raster.width] == reference["shape"]
        band = raster.read(1)
        assert int(np.count_nonzero(band == 7)) == 4_183_812
        assert int(np.count_nonzero(band == raster.nodata)) == 2_304

transitions = {}
for event in trace:
    if event["event"] != "observed_run_api":
        continue
    record = event["record"]
    history = transitions.setdefault(record["run_id"], [])
    state = [record["execution_status"], record["check_status"]]
    if not history or history[-1] != state:
        history.append(state)

print(json.dumps({
    "status": "PASS", "completed_run": passed["id"], "cancelled_run": cancelled["id"],
    "completed_step_wall_seconds": [round(duration(row), 3) for row in successful_steps],
    "cancelled_area_step_wall_seconds": round(duration(cancelled_steps[-1]), 3),
    "cancelled_artifact_count": 0, "registered_area_report_sha256": sha256(data).hexdigest(),
    "selected_pixels": report["selected_pixel_count"], "nodata_pixels": report["nodata_pixel_count"],
    "observed_area_m2": report["total_area_m2"], "absolute_area_difference_m2": delta,
    "browser_status_transitions": transitions,
}, indent=2))
