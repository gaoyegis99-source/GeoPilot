#!/bin/bash
set -euo pipefail
output="$1"
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_NUM_THREADS=1 PROJ_NETWORK=OFF
.venv/bin/python -B scripts/bench/generate_raster.py --tier M --output "$output/DEM-M"
