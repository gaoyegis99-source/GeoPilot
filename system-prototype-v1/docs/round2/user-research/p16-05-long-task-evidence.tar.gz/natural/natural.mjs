import assert from 'node:assert/strict'
import { appendFile, readFile } from 'node:fs/promises'
import { join } from 'node:path'

const directory = process.argv[2]
const session = JSON.parse(await readFile(join(directory, 'session.json'), 'utf8'))
const fixture = JSON.parse(await readFile(session.input_manifest, 'utf8'))
const site = new URL(session.url)
assert.equal(site.hostname, '127.0.0.1')
const { chromium } = await import(session.browser_module)
const browser = await chromium.launch({
  headless: true,
  args: ['--enable-webgl', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
})
const timer = performance.now()
const errors = []
const trace = (event, fields = {}) => appendFile(join(directory, 'trace.jsonl'),
  JSON.stringify({ event, browser_automation_ms: Math.round(performance.now() - timer), ...fields }) + '\n')
const area = 'calculate_area_with_equal_area_projection'
let stage = 'load'
try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true })
  await context.route('**/*', route => new URL(route.request().url()).origin === site.origin ? route.continue() : route.abort())
  const page = await context.newPage()
  page.setDefaultTimeout(30000)
  page.on('pageerror', error => errors.push(error.message))
  page.on('response', async response => {
    const path = new URL(response.url()).pathname
    if (response.request().method() !== 'GET' || !/^\/api\/runs\/[^/]+$/.test(path)) return
    const record = await response.json().catch(() => null)
    if (record) await trace('observed_run_api', { status: response.status(), record })
  })
  const runRegion = page.getByRole('region', { name: '运行', exact: true })
  const checkRegion = page.getByRole('region', { name: '规则检查', exact: true })
  const runBadge = runRegion.locator('span.workbench__status')
  const checkBadge = checkRegion.locator('span.workbench__status')
  const activeArea = runRegion.locator('p').filter({ hasText: new RegExp(`当前步骤\\s+${area}\\b`) })
  const secs = text => Number(/·\s+(\d+) 秒/.exec(text)?.[1] ?? -1)
  const waitArea = async minimum => {
    const target = runRegion.locator('p').filter({
      hasText: new RegExp(`当前步骤\\s+${area}\\s*·\\s*(?:[1-9][0-9]+|[${minimum}-9]) 秒`),
    })
    await target.waitFor({ timeout: 100000 })
    const text = await activeArea.innerText()
    const seconds = secs(text)
    assert.ok(seconds >= minimum)
    return { text, seconds, label: await runBadge.innerText(), check: await checkBadge.innerText(), url: page.url() }
  }

  async function post(path, action, status) {
    const [response] = await Promise.all([
      page.waitForResponse(item => item.request().method() === 'POST' && path.test(new URL(item.url()).pathname)),
      action(),
    ])
    assert.equal(response.status(), status, await response.text())
    return response.json()
  }

  assert.ok((await page.goto(site.href))?.ok())
  await page.getByText('暂无数据', { exact: true }).waitFor()
  stage = 'register'
  const data = page.getByRole('region', { name: '数据', exact: true })
  const assetRefs = {}
  for (const [role, entry] of Object.entries(fixture.assets)) {
    await data.getByRole('button', { name: '导入数据', exact: true }).click()
    await data.getByLabel('本机文件路径').fill(entry.path)
    if (entry.layer) {
      await data.getByRole('button', { name: '读取图层', exact: true }).click()
      await data.getByRole('combobox', { name: 'GeoPackage 图层' }).selectOption(entry.layer)
    }
    const saved = await post(/^\/api\/assets$/, () => data.getByRole('button', { name: '登记资产', exact: true }).click(), 200)
    assert.equal(saved.source.layer, entry.layer)
    assetRefs[role] = { asset_id: saved.asset_id, asset_version: saved.asset_version }
    await trace('registered', { role, layer: entry.layer, crs: saved.metadata.crs })
  }

  stage = 'confirm method'
  const method = page.getByRole('region', { name: '方法目录' }).locator('details')
    .filter({ has: page.locator('summary').filter({ has: page.getByText('dem-terrain-analysis', { exact: true }) }) })
  await method.locator('summary').click()
  await method.getByRole('button', { name: '选择方法', exact: true }).click()
  const form = page.getByRole('form', { name: '方法表单' })
  await form.getByLabel('任务目标').fill('验证中档 DEM 坡度统计的运行进度和取消')
  for (const [role, label] of Object.entries({ analysis_extent: '分析范围', dem: '高程栅格（DEM）' })) {
    const ref = assetRefs[role]
    await form.getByLabel(label, { exact: true }).selectOption(`${ref.asset_id}@${ref.asset_version}`)
  }
  await form.getByLabel('地形指标', { exact: true }).selectOption(fixture.options.terrain_output)
  await form.getByLabel('坡度单位', { exact: true }).selectOption(fixture.options.slope_unit)
  await form.getByLabel('面积坐标参考系', { exact: true }).fill(fixture.options.area_crs)
  await form.getByLabel('分类阈值', { exact: true }).fill(JSON.stringify(fixture.options.threshold))
  const draft = await post(/^\/api\/tasks\/[^/]+\/plans$/, () => form.getByRole('button', { name: '生成草稿' }).click(), 200)
  assert.equal(draft.method.id, 'dem-terrain-analysis')
  assert.equal(draft.steps.length, 7)
  assert.deepEqual(draft.issues, [])
  const confirmed = await post(/^\/api\/plans\/[^/]+\/confirm$/,
    () => page.getByRole('button', { name: '确认方案', exact: true }).click(), 200)
  assert.equal(confirmed.status, 'confirmed')
  await trace('confirmed', { plan_id: confirmed.id, version: confirmed.version, options: confirmed.critical_options })

  stage = 'natural run, refresh during calculation'
  const start = runRegion.getByRole('button', { name: '开始运行', exact: true })
  const first = await post(/^\/api\/plans\/[^/]+\/runs$/, () => start.click(), 202)
  await page.waitForURL(url => url.searchParams.get('run') === first.run_id)
  const before = await waitArea(5)
  assert.equal(before.label, '运行中')
  await trace('before_refresh', { run_id: first.run_id, ...before })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await activeArea.waitFor({ timeout: 15000 })
  const after = { url: page.url(), text: await activeArea.innerText(), label: await runBadge.innerText() }
  assert.equal(after.url, before.url)
  assert.equal(after.label, '运行中')
  assert.ok(secs(after.text) >= before.seconds)
  await trace('after_refresh', { run_id: first.run_id, ...after, seconds: secs(after.text) })
  await runRegion.screenshot({ path: join(directory, 'refreshed-progress.png') })

  stage = 'natural completion and original report'
  await runRegion.getByText('运行成功', { exact: true }).waitFor({ timeout: 120000 })
  await checkRegion.getByText('规则检查通过', { exact: true }).waitFor({ timeout: 120000 })
  const finalStep = runRegion.getByText(/最后完成的计算步骤/).filter({ hasText: area })
  await finalStep.waitFor()
  assert.equal(await activeArea.count(), 0)
  const result = page.getByRole('list', { name: '正式成果' }).getByRole('listitem')
    .filter({ has: page.getByText('面积统计', { exact: true }) })
  const [download] = await Promise.all([
    page.waitForEvent('download'), result.getByRole('link', { name: '下载原文件' }).click(),
  ])
  assert.equal(await download.failure(), null)
  assert.ok(download.suggestedFilename().includes(first.run_id))
  await download.saveAs(join(directory, 'area-statistics.json'))
  await trace('natural_success', { run_id: first.run_id, step: await finalStep.innerText(), suggested_name: download.suggestedFilename() })

  stage = 'cancel another long execution'
  const second = await post(/^\/api\/plans\/[^/]+\/runs$/, () => start.click(), 202)
  assert.notEqual(second.run_id, first.run_id)
  await page.waitForURL(url => url.searchParams.get('run') === second.run_id)
  const during = await waitArea(5)
  const cancelled = await post(/^\/api\/runs\/[^/]+\/cancel$/,
    () => runRegion.getByRole('button', { name: '取消运行', exact: true }).click(), 202)
  assert.ok(cancelled.cancel_requested)
  await runRegion.getByRole('status').filter({ hasText: /^已取消$/ }).waitFor()
  await runRegion.getByRole('button', { name: '按原方案重新运行', exact: true }).waitFor()
  assert.equal(await page.getByRole('list', { name: '正式成果' }).count(), 0)
  await trace('natural_cancelled', { run_id: second.run_id, during, final: await runRegion.innerText() })
  assert.deepEqual(errors, [])
  console.log(JSON.stringify({ status: 'PASS', chromium: browser.version(), completed: first.run_id,
    cancelled: second.run_id, before, after, errors }, null, 2))
} catch (error) {
  await trace('failure', { stage, error: String(error), errors })
  throw error
} finally {
  await browser.close()
}
