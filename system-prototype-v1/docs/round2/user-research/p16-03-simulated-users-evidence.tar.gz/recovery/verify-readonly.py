import csv
from hashlib import sha256
import json
from pathlib import Path
import sqlite3

root = Path(__file__).resolve().parent
summary = json.loads((root / "recovery.stdout.log").read_text())
candidate = json.loads((root / "session.json").read_text())
fixture_reference = json.loads(Path(candidate["fixture"]).with_name("expected.json").read_text())
expected = fixture_reference["relations"]["intersects"]["counts"]
download = root / "recovery-result.csv"
with download.open(encoding="utf-8", newline="") as stream:
    counts = {row["zone_id"] or "unassigned": int(row["count"]) for row in csv.DictReader(stream)}
assert {**counts, "total": sum(counts.values())} == expected
db = sqlite3.connect((root / "project.sqlite").as_uri() + "?mode=ro", uri=True)
db.row_factory = sqlite3.Row
run = db.execute("select id, plan_id, plan_version, execution_status, check_status, cancel_requested, current_step from run where id in (?, ?) order by created_at",
                 (summary["originalRun"], summary["runId"])).fetchall()
assert len(run) == 2
assert run[0]["execution_status"] == "CANCELLED" and run[0]["check_status"] == "NOT_CHECKED"
assert run[1]["execution_status"] == "SUCCEEDED" and run[1]["check_status"] == "PASSED"
assert (run[0]["plan_id"], run[0]["plan_version"]) == (run[1]["plan_id"], run[1]["plan_version"])
steps = {}
for item in run:
    steps[item["id"]] = [dict(row) for row in db.execute(
        "select step_key, status, started_at, finished_at from run_step where run_id = ? order by position", (item["id"],)
    )]
assert steps[run[0]["id"]][0]["status"] == "CANCELLED"
assert all(step["status"] == "NOT_STARTED" for step in steps[run[0]["id"]][1:])
assert all(step["status"] == "SUCCEEDED" for step in steps[run[1]["id"]])
artifact_counts = {item["id"]: db.execute("select count(*) from artifact where run_id = ?", (item["id"],)).fetchone()[0] for item in run}
assert artifact_counts[run[0]["id"]] == 0
artifacts = list((root / "workspace").glob(f"tasks/*/runs/{run[1]['id']}/intermediate/aggregate_by_zone/statistics.csv"))
assert len(artifacts) == 1 and artifacts[0].read_bytes() == download.read_bytes()
print(json.dumps({"mode": "read-only postcheck, separate from simulated browser actions",
                  "runs": [dict(row) for row in run], "steps": steps, "artifact_counts": artifact_counts,
                  "download": {"same_bytes_as_backend": True, "counts": counts, "matches_fixture": True,
                               "sha256": sha256(download.read_bytes()).hexdigest()}}, ensure_ascii=False, indent=2))
