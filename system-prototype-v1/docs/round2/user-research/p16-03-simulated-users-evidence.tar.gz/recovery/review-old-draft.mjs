import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { join } from 'node:path'
const directory = process.argv[2] ?? process.cwd()
const session = JSON.parse(await readFile(join(directory, 'session.json'), 'utf8'))
const events = (await readFile(join(directory, 'recovery-trace.jsonl'), 'utf8')).trim().split('\n').map(JSON.parse)
const run = events.find(event => event.action === 'before reloading active run')
const oldDraft = new URL(run.location_search, session.url)
assert.equal(oldDraft.hostname, '127.0.0.1')
oldDraft.searchParams.set('version', '1')
oldDraft.searchParams.delete('run')
const { chromium } = await import(session.browser_module)
const browser = await chromium.launch({ headless: true })
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
  await page.goto(oldDraft.href)
  const problems = page.getByRole('region', { name: '待补项', exact: true })
  await problems.waitFor({ timeout: 10000 })
  const link = problems.getByRole('button', { name: '定位 inputs.roads', exact: true })
  await link.click()
  const form = page.getByRole('form', { name: '方法表单' })
  const road = form.getByLabel('道路', { exact: true })
  const crs = form.getByLabel('距离坐标参考系', { exact: true })
  const focused = node => node === document.activeElement
  const evidence = {
    evidence_kind: 'simulated technical follow-up',
    old_draft_url: oldDraft.href,
    visible_issue: await problems.innerText(),
    actual_focus: await page.evaluate(() => ({ tag: document.activeElement?.tagName, name: document.activeElement?.getAttribute('name') })),
    road_control_focused: await road.evaluate(focused),
    distance_crs_focused: await crs.evaluate(focused),
    restored_wrong_crs_value: await crs.inputValue(),
  }
  assert.equal(evidence.restored_wrong_crs_value, 'EPSG:3857')
  await page.screenshot({ path: join(directory, 'draft-issue-focus.png') })
  console.log(JSON.stringify(evidence, null, 2))
} finally {
  await browser.close()
}
