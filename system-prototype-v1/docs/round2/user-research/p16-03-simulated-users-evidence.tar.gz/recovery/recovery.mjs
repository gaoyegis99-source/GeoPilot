import assert from 'node:assert/strict'
import { appendFile, readFile } from 'node:fs/promises'
import { join } from 'node:path'

const directory = process.argv[2] ?? process.cwd()
const session = JSON.parse(await readFile(join(directory, 'session.json'), 'utf8'))
const site = new URL(session.url)
assert.equal(site.protocol, 'http:')
assert.equal(site.hostname, '127.0.0.1')
const { chromium } = await import(session.browser_module)
const env = { ...process.env, PATH: '/usr/bin:/bin' }
delete env.PYTHONPATH
delete env.GEOPILOT_QGIS_PROCESS
const browser = await chromium.launch({
  headless: true,
  env,
  args: ['--enable-webgl', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
})
const elapsed = performance.now()
let stage = 'startup'
const errors = []
const events = []
async function note(action, observed = {}) {
  const item = { action, automation_ms: Math.round(performance.now() - elapsed), ...observed }
  events.push(item)
  await appendFile(join(directory, 'recovery-trace.jsonl'), JSON.stringify(item) + '\n')
}

try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true })
  const page = await context.newPage()
  page.setDefaultTimeout(30000)
  page.on('pageerror', error => errors.push(error.message))
  const runRegion = page.getByRole('region', { name: '运行', exact: true })
  const planRegion = page.getByRole('region', { name: '方案', exact: true })
  const checkRegion = page.getByRole('region', { name: '规则检查', exact: true })
  const runState = () => runRegion.locator('span.workbench__status').innerText()
  const snapshot = async () => {
    const currentStep = runRegion.getByText('当前步骤', { exact: false }).first()
    return {
      label: await runState(),
      current_step_text: await currentStep.isVisible() ? await currentStep.innerText() : null,
      visible_run_text: await runRegion.innerText(),
      location_search: new URL(page.url()).search,
    }
  }

  async function observePost(path, action) {
    const [response] = await Promise.all([
      page.waitForResponse(item => item.request().method() === 'POST' && path.test(new URL(item.url()).pathname)),
      action(),
    ])
    return { status: response.status(), data: await response.json() }
  }

  const ok = await page.goto(site.href)
  assert.ok(ok?.ok())
  await page.getByText('暂无数据', { exact: true }).waitFor()
  await note('open clean workbench', { chromium: browser.version(), location: page.url() })

  stage = 'missing asset path then correction'
  const dataRegion = page.getByRole('region', { name: '数据', exact: true })
  const importButton = dataRegion.getByRole('button', { name: '导入数据', exact: true })
  const pathInput = dataRegion.getByLabel('本机文件路径')
  const loadLayers = dataRegion.getByRole('button', { name: '读取图层', exact: true })
  const layerInput = dataRegion.getByLabel('GeoPackage 图层')
  await importButton.click()
  const wrongPath = join(directory, 'not-present.gpkg')
  await pathInput.fill(wrongPath)
  await loadLayers.click()
  const alert = dataRegion.getByRole('alert')
  await alert.waitFor()
  await note('read layers from missing file', {
    alert: await alert.innerText(),
    entered_path_preserved: await pathInput.inputValue() === wrongPath,
    read_layers_still_enabled: await loadLayers.isEnabled(),
    visible_recovery_actions: await dataRegion.getByRole('button').allTextContents(),
  })
  await pathInput.screenshot({ path: join(directory, 'missing-path-field.png') })
  await dataRegion.screenshot({ path: join(directory, 'missing-path.png') })

  stage = 'register corrected sample layers'
  const registered = {}
  for (const [index, role] of ['analysis_extent', 'roads', 'targets', 'zones'].entries()) {
    if (index !== 0) await importButton.click()
    await pathInput.fill(session.fixture)
    await loadLayers.click()
    await dataRegion.locator('select').filter({ has: page.locator('option', { hasText: /^analysis_extent$/ }) }).first().waitFor()
    await layerInput.selectOption(role)
    const asset = await observePost(/^\/api\/assets$/, () => dataRegion.getByRole('button', { name: '登记资产', exact: true }).click())
    assert.equal(asset.status, 200)
    assert.equal(asset.data.source.layer, role)
    registered[role] = { asset_id: asset.data.asset_id, asset_version: asset.data.asset_version }
    await note('register layer via browser', { layer: role, corrected_existing_form: index === 0, crs: asset.data.metadata.crs })
  }

  stage = 'invalid draft then correction'
  const method = page.getByRole('region', { name: '方法目录' }).locator('details')
    .filter({ hasText: '道路缓冲统计' }).filter({ has: page.locator('summary', { hasText: /版本 3\b/ }) })
  await method.locator('summary').click()
  await method.getByRole('button', { name: '选择方法', exact: true }).click()
  const form = page.getByRole('form', { name: '方法表单' })
  await form.getByLabel('任务目标').fill('核对错误输入与取消恢复后道路 500 米影响范围内的分区计数')
  for (const [role, label] of Object.entries({
    analysis_extent: '分析范围', roads: '道路', targets: '目标对象', zones: '统计分区',
  })) {
    await form.getByLabel(label, { exact: true }).selectOption({ label: `road-buffer.gpkg · ${role} · v1` })
  }
  await form.getByLabel('缓冲距离').fill('500')
  for (const [label, value] of [
    ['距离计算方式', 'local_projected'], ['空间关系', 'intersects'], ['跨界归属', 'centroid'],
    ['边界并列处理', 'unassigned'], ['统计量', 'count'], ['输出范围', 'clipped_to_analysis_extent'],
  ]) {
    await form.getByLabel(label, { exact: true }).selectOption(value)
  }
  const crs = form.getByLabel('距离坐标参考系', { exact: true })
  const createDraft = form.getByRole('button', { name: '生成草稿' })
  const confirm = planRegion.getByRole('button', { name: '确认方案', exact: true })
  await crs.fill('EPSG:3857')
  const draft = await observePost(/^\/api\/tasks\/[^/]+\/plans$/, () => createDraft.click())
  assert.equal(draft.status, 200)
  assert.ok(draft.data.issues.length > 0)
  const problems = planRegion.getByRole('region', { name: '待补项', exact: true })
  await problems.waitFor()
  await note('generate draft with Web Mercator', {
    visible_issues: await problems.innerText(),
    confirm_disabled: await confirm.isDisabled(),
    draft_version: draft.data.version,
    ui_issue_codes: draft.data.issues.map(issue => issue.code),
  })
  assert.ok(await confirm.isDisabled())
  await problems.screenshot({ path: join(directory, 'draft-issues.png') })
  const location = problems.getByRole('button', { name: /定位.*distance_crs_ref/ }).first()
  if (await location.isVisible()) {
    await location.click()
    await note('use issue link to locate CRS', { focus_is_crs: await crs.evaluate(node => node === document.activeElement) })
  }
  await crs.fill('EPSG:32650')
  const dirty = planRegion.getByText('表单已修改，请先生成草稿。', { exact: true })
  await dirty.waitFor()
  await note('correct only CRS value', { visible_guidance: await dirty.innerText(), confirm_still_disabled: await confirm.isDisabled() })
  const corrected = await observePost(/^\/api\/tasks\/[^/]+\/plans$/, () => createDraft.click())
  assert.equal(corrected.status, 200)
  assert.deepEqual(corrected.data.issues, [])
  assert.deepEqual(corrected.data.inputs, registered)
  const confirmed = await observePost(/^\/api\/plans\/[^/]+\/confirm$/, () => confirm.click())
  assert.equal(confirmed.status, 200)
  assert.equal(confirmed.data.status, 'confirmed')
  await note('regenerate and confirm without reentering other fields', {
    corrected_plan_version: corrected.data.version,
    issues: corrected.data.issues,
    preserved_four_asset_bindings: true,
    corrected_crs: corrected.data.critical_options.distance_crs_ref,
  })

  stage = 'start run and refresh'
  const start = runRegion.getByRole('button', { name: '开始运行', exact: true })
  const started = await observePost(/^\/api\/plans\/[^/]+\/runs$/, () => start.click())
  assert.equal(started.status, 202)
  const originalRun = started.data.run_id
  await page.waitForURL(url => url.searchParams.get('run') === originalRun)
  await page.waitForFunction(() => document.querySelector('section[aria-labelledby] .run-panel button') !== null)
  const activeOrDone = runRegion.getByRole('button', { name: '取消运行', exact: true })
    .or(runRegion.getByText('运行成功', { exact: true }))
    .or(runRegion.getByText('运行失败', { exact: true }))
  await activeOrDone.first().waitFor()
  const before = await snapshot()
  await note('before reloading active run', { run_id: originalRun, ...before })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await activeOrDone.first().waitFor()
  const after = await snapshot()
  await note('after reloading same run', { run_id: originalRun, ...after, same_url: before.location_search === after.location_search })

  stage = 'cancel if still active and retry'
  let runId = originalRun
  let cancelled = false
  const cancel = runRegion.getByRole('button', { name: '取消运行', exact: true })
  if (await cancel.isVisible() && await cancel.isEnabled()) {
    const response = await observePost(/^\/api\/runs\/[^/]+\/cancel$/, () => cancel.click())
    await note('submit cancellation from visible UI', { response_status: response.status, cancel_requested: response.data.cancel_requested, ...await snapshot() })
    const finished = runRegion.getByText('已取消', { exact: true })
      .or(runRegion.getByText('运行成功', { exact: true }))
      .or(runRegion.getByText('运行失败', { exact: true }))
    await finished.first().waitFor({ timeout: 90000 })
    cancelled = await runState() === '已取消'
    await note('first run terminal after cancel attempt', { cancelled, ...await snapshot() })
    if (cancelled) {
      const retry = runRegion.getByRole('button', { name: '重新运行', exact: true })
      const explicitRetry = await retry.isVisible()
      await note('observe recovery controls', {
        explicit_retry_visible: explicitRetry,
        start_available: await start.isEnabled(),
        visible_button_labels: (await runRegion.getByRole('button').all()).length
          ? await runRegion.getByRole('button').allTextContents() : [],
      })
      await runRegion.screenshot({ path: join(directory, 'cancelled-run.png') })
      const restarted = await observePost(/^\/api\/plans\/[^/]+\/runs$/, () => (explicitRetry ? retry : start).click())
      assert.equal(restarted.status, 202)
      assert.notEqual(restarted.data.run_id, originalRun)
      runId = restarted.data.run_id
      await page.waitForURL(url => url.searchParams.get('run') === runId)
      await note('rerun from existing confirmed plan', {
        original_run_id: originalRun, run_id: runId,
        control: explicitRetry ? '重新运行' : '开始运行', data_or_plan_reentry: false,
        same_confirmed_plan: true,
      })
    }
  } else {
    await note('cancel not attempted because active button no longer available', await snapshot())
  }

  stage = 'wait for results and download'
  await runRegion.getByText('运行成功', { exact: true }).waitFor({ timeout: 90000 })
  await checkRegion.getByText('规则检查通过', { exact: true }).waitFor({ timeout: 90000 })
  await note('successful terminal run', { run_id: runId, ...await snapshot(), visible_check: await checkRegion.innerText() })
  const result = page.getByRole('list', { name: '正式成果' }).getByRole('listitem')
    .filter({ has: page.getByText('分区统计', { exact: true }) })
  const [download] = await Promise.all([
    page.waitForEvent('download'), result.getByRole('link', { name: '下载原文件' }).click(),
  ])
  assert.equal(await download.failure(), null)
  const csv = join(directory, 'recovery-result.csv')
  await download.saveAs(csv)
  const raw = await readFile(csv, 'utf8')
  const lines = raw.trimEnd().split(/\r?\n/)
  assert.equal(lines.length, 4)
  const counts = Object.fromEntries(lines.slice(1).map(line => {
    const [zone, , count] = line.split(',', 3)
    return [zone || 'unassigned', Number(count)]
  }))
  await note('download CSV after recovery', { file: csv, counts, suggested_filename: download.suggestedFilename() })
  await runRegion.screenshot({ path: join(directory, 'completed-run.png') })
  await note('complete', { outcome: 'SIMULATION_PASS', cancelled, original_run_id: originalRun, successful_run_id: runId, page_errors: errors })
  console.log(JSON.stringify({ outcome: 'SIMULATION_PASS', cancelled, originalRun, runId, counts, events: events.length, errors }, null, 2))
} catch (error) {
  await note('automation stopped', { stage, message: String(error), page_errors: errors })
  throw error
} finally {
  await browser.close()
}
