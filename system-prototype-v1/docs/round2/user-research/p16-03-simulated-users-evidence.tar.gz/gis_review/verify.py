"""Read-only audit of two UI downloads and their run receipts."""

import csv
from hashlib import sha256
import json
from pathlib import Path
from urllib.parse import urljoin
from urllib.request import build_opener, ProxyHandler

root = Path(__file__).resolve().parent
read = lambda name: json.loads((root / name).read_bytes())
cfg = read("session.json")
review = read("review.json")
expected = json.loads(Path(cfg["fixture"]).with_name("expected.json").read_bytes())["relations"]["intersects"]
opener = build_opener(ProxyHandler({}))
audits = []

for suffix, filename in [("", "road-buffer.csv"), ("_second", "road-buffer-second.csv")]:
    run_id = review["run_id" + suffix]
    href = review["csv_href_second" if suffix else "csv_href_first"]
    artifact_id = href.split("/")[-2]
    path = root / filename
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, strict=True)
        assert reader.fieldnames == ["zone_id", "assignment_status", "count", "source_feature_ids"]
        rows = list(reader)
    zones = {row["zone_id"]: json.loads(row["source_feature_ids"]) for row in rows if row["assignment_status"] == "assigned"}
    unassigned, = [row for row in rows if row["assignment_status"] == "unassigned"]
    assert len(rows) == 3 and unassigned["zone_id"] == ""
    counts = {row["zone_id"] or "unassigned": int(row["count"]) for row in rows}
    counts["total"] = sum(counts.values())
    assert counts == expected["counts"]
    assert zones == expected["zone_target_ids"]
    assert json.loads(unassigned["source_feature_ids"]) == expected["unassigned_target_ids"]
    run, = (root / "workspace").glob(f"tasks/*/runs/{run_id}")
    report = json.loads((run / "checks/report.json").read_bytes())
    assert report["run_id"] == run_id and report["status"] == "PASSED"
    manifest = json.loads((run / "outputs/manifest.json").read_bytes())
    exported = run / manifest["artifacts"]["zone_statistics"]["path"]
    assert exported.read_bytes() == path.read_bytes()
    with opener.open(urljoin(cfg["url"], f"/api/runs/{run_id}/artifacts"), timeout=5) as response:
        listing = json.load(response)
    row, = [item for item in listing["artifacts"] if item["role"] == "zone_statistics"]
    assert row["id"] == artifact_id and row["run_id"] == run_id
    audits.append({
        "run_id": run_id, "report_id": report["report_id"], "artifact_id": artifact_id,
        "counts": counts, "source_ids_match_fixture": True, "bytes_match_run_workspace": True,
        "csv_sha256": sha256(path.read_bytes()).hexdigest(),
    })

assert audits[0]["run_id"] != audits[1]["run_id"]
assert audits[0]["report_id"] != audits[1]["report_id"]
assert audits[0]["artifact_id"] != audits[1]["artifact_id"]
assert audits[0]["csv_sha256"] == audits[1]["csv_sha256"]
print(json.dumps(audits, indent=2))
