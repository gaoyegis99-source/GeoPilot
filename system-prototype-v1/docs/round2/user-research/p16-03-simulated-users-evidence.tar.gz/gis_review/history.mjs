import assert from 'node:assert/strict'
import {readFile, writeFile} from 'node:fs/promises'
import {dirname, join} from 'node:path'

const base = dirname(new URL(import.meta.url).pathname)
const cfg = JSON.parse(await readFile(join(base, 'session.json')))
const review = JSON.parse(await readFile(join(base, 'review.json')))
const {chromium} = await import(cfg.browser_module)
const browser = await chromium.launch({headless:true,args:['--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']})
const observed = []
try {
  const context = await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true})
  await context.route('**/*', route => new URL(route.request().url()).origin === new URL(cfg.url).origin ? route.continue() : route.abort())
  const page = await context.newPage()
  for (const [label,url,href,run] of [
    ['second', review.url_second, review.csv_href_second, review.run_id_second],
    ['first', review.url_first, review.csv_href_first, review.run_id],
  ]) {
    assert.ok((await page.goto(url))?.ok())
    await page.getByText('规则检查通过',{exact:true}).first().waitFor()
    const item = page.getByRole('list',{name:'正式成果'}).getByRole('listitem').filter({has:page.getByText('分区统计',{exact:true})})
    const link = item.getByRole('link',{name:'下载原文件'})
    assert.equal(await link.getAttribute('href'),href)
    await item.getByText('来源详情',{exact:true}).click()
    const provenance = (await item.innerText()).trim()
    const ruleRegion = page.getByRole('region',{name:'规则检查',exact:true})
    await ruleRegion.locator('details').first().locator(':scope > summary').click()
    const checkReport = page.getByRole('article',{name:'检查报告明细'})
    const timestampStatus = (await checkReport.innerText()).split('\n').slice(0,2)
    const reportSummary = checkReport.getByText('报告编号',{exact:true})
    await reportSummary.click()
    const reportId = (await reportSummary.locator('..').innerText()).split('\n').at(-1).trim()
    await item.screenshot({path:join(base,`provenance-${label}.png`)})
    observed.push({label, url:page.url(), run, href, provenance, reportId, timestampStatus, visible_run_id: provenance.includes(run)})
  }
  assert.notEqual(observed[0].href,observed[1].href)
  assert.notEqual(observed[0].reportId,observed[1].reportId)
  const browserBack = await page.goBack()
  assert.ok(browserBack?.ok())
  const artifact = page.getByRole('list',{name:'正式成果'}).getByRole('listitem').filter({has:page.getByText('分区统计',{exact:true})})
  assert.equal(await artifact.getByRole('link',{name:'下载原文件'}).getAttribute('href'),review.csv_href_second)
  await writeFile(join(base,'history.json'),JSON.stringify({observed, browser_back_between_explicit_visits:page.url()},null,2)+'\n')
} catch(error) {
  await writeFile(join(base,'history.json'),JSON.stringify({observed,error:error.stack},null,2)+'\n')
  process.exitCode=1
} finally {
  await browser.close()
}
