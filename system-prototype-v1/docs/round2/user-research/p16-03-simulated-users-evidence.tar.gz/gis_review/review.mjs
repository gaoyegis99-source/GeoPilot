import assert from 'node:assert/strict'
import {readFile, writeFile, appendFile} from 'node:fs/promises'
import {join, dirname} from 'node:path'

const base = dirname(new URL(import.meta.url).pathname)
const session = JSON.parse(await readFile(join(base, 'session.json'), 'utf8'))
const site = new URL(session.url)
assert.equal(site.protocol, 'http:')
assert.equal(site.hostname, '127.0.0.1')
const {chromium} = await import(session.browser_module)
const browser = await chromium.launch({ headless: true, args: ['--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] })
const errors = []
const evidence = {}
let phase = 'startup'
const log = async (label, details={}) => appendFile(join(base, 'trace.jsonl'), JSON.stringify({label,...details})+'\n')
const save = async () => writeFile(join(base, 'review.json'), JSON.stringify({profile: 'gis_review', simulated: true, chromium: browser.version(), phase, ...evidence, page_errors: errors}, null, 2)+'\n')
try {
  const context = await browser.newContext({viewport:{width:1440,height:1000}, acceptDownloads:true})
  await context.route('**/*', route => new URL(route.request().url()).origin === site.origin ? route.continue() : route.abort())
  const page = await context.newPage()
  page.setDefaultTimeout(30000)
  page.on('pageerror', error => errors.push(error.message))
  const region = name => page.getByRole('region', {name, exact:true})
  const clean = text => text.split(/\s*\n\s*/).filter(Boolean).join(' | ')
  const text = async locator => clean(await locator.innerText())
  const screenshot = async name => page.screenshot({path:join(base,name), fullPage:true, timeout:10000})
  async function post(regex, action, status) {
    const [response] = await Promise.all([
      page.waitForResponse(item => item.request().method() === 'POST' && regex.test(new URL(item.url()).pathname)),
      action(),
    ])
    assert.equal(response.status(), status, await response.text())
    return response.json()
  }
  async function ensureDetails(details) {
    if (await details.getAttribute('open') === null) await details.locator(':scope > summary').click()
  }
  assert.ok((await page.goto(site.href))?.ok())
  await page.getByText('暂无数据', {exact:true}).waitFor()
  phase = 'register assets'
  evidence.assets = {}
  for (const role of ['analysis_extent','roads','targets','zones']) {
    await page.getByRole('button',{name:'导入数据',exact:true}).click()
    await page.getByLabel('本机文件路径').fill(session.fixture)
    await page.getByRole('button',{name:'读取图层',exact:true}).click()
    await page.getByLabel('GeoPackage 图层').selectOption(role)
    const item = await post(/^\/api\/assets$/,() => page.getByRole('button',{name:'登记资产',exact:true}).click(),200)
    evidence.assets[role] = {asset_id:item.asset_id, version:item.asset_version, crs:item.metadata.crs, layer:item.source.layer}
    await log('register via visible form',{role, ...evidence.assets[role]})
  }
  phase = 'configure and confirm'
  const method = region('方法目录').locator('details').filter({hasText:'道路缓冲统计'})
    .filter({has:page.locator('summary',{hasText:/版本 3\b/})})
  await ensureDetails(method)
  evidence.catalog_text = await text(method)
  await method.getByRole('button',{name:'选择方法',exact:true}).click()
  const form = page.getByRole('form',{name:'方法表单'})
  await form.getByLabel('任务目标').fill('GIS 复核：按分区统计道路 500 米缓冲内的目标点')
  const options = {}
  for (const [role,label] of Object.entries({analysis_extent:'分析范围', roads:'道路', targets:'目标对象', zones:'统计分区'})) {
    const control = form.getByLabel(label,{exact:true})
    await control.selectOption({label:`road-buffer.gpkg · ${role} · v1`})
    options[role] = await control.locator('option:checked').innerText()
  }
  await form.getByLabel('缓冲距离').fill('500')
  for (const [label,value] of [['距离计算方式','local_projected'],['空间关系','intersects'],['跨界归属','centroid'],['边界并列处理','unassigned'],['统计量','count'],['输出范围','clipped_to_analysis_extent']]) {
    const control = form.getByLabel(label,{exact:true})
    await control.selectOption(value)
    options[label] = await control.locator('option:checked').innerText()
  }
  await form.getByLabel('距离坐标参考系',{exact:true}).fill('EPSG:32650')
  evidence.visible_inputs = options
  evidence.buffer_field_text = await text(form.getByLabel('缓冲距离').locator('..'))
  const draft = await post(/^\/api\/tasks\/[^/]+\/plans$/, () => form.getByRole('button',{name:'生成草稿'}).click(), 200)
  assert.deepEqual(draft.method,{id:'road-buffer-statistics',version:3})
  assert.equal(draft.critical_options.distance_m,500)
  assert.equal(draft.critical_options.distance_crs_ref,'EPSG:32650')
  evidence.plan_response = {method:draft.method, inputs:draft.inputs, parameters:draft.critical_options, steps:draft.steps.length}
  evidence.plan_visible_before_confirm = await text(region('方案'))
  await log('draft through visible form',{...evidence.plan_response, visible:evidence.plan_visible_before_confirm})
  const confirmed = await post(/^\/api\/plans\/[^/]+\/confirm$/, () => page.getByRole('button',{name:'确认方案',exact:true}).click(), 200)
  assert.equal(confirmed.status,'confirmed')
  phase = 'start and review first run'
  const first = await post(/^\/api\/plans\/[^/]+\/runs$/, () => page.getByRole('button',{name:'开始运行',exact:true}).click(), 202)
  evidence.run_id = first.run_id
  await log('start from confirmed plan',{run_id:first.run_id})
  await region('运行').getByText('运行成功',{exact:true}).first().waitFor({timeout:120000})
  await page.getByText('规则检查通过',{exact:true}).first().waitFor({timeout:120000})
  evidence.run_visible_first = await text(region('运行'))
  const checks = region('规则检查')
  await ensureDetails(checks.locator('details').first())
  const report = page.getByRole('article',{name:'检查报告明细'})
  const rule = report.locator('details').filter({has:page.locator('summary',{hasText:'measurement_policy_satisfied'})})
  await ensureDetails(rule)
  await rule.getByText('期望值',{exact:true}).waitFor()
  evidence.rule_visible = await text(rule)
  evidence.check_visible_first = (await text(report)).slice(0,5500)
  const artifacts = page.getByRole('list',{name:'正式成果'})
  const csvItem = artifacts.getByRole('listitem').filter({has:page.getByText('分区统计',{exact:true})})
  const firstLink = csvItem.getByRole('link',{name:'下载原文件'})
  evidence.csv_visible_first = await text(csvItem)
  evidence.csv_href_first = await firstLink.getAttribute('href')
  const [download] = await Promise.all([page.waitForEvent('download'),firstLink.click()])
  assert.equal(await download.failure(),null)
  await download.saveAs(join(base,'road-buffer.csv'))
  evidence.csv_suggested_name_first = download.suggestedFilename()
  evidence.url_first = page.url()
  await log('download first original via UI',{run_id:first.run_id, suggested_name:download.suggestedFilename(), link:evidence.csv_href_first, visible:evidence.csv_visible_first})
  await screenshot('first-result.png')
  await save()
  phase = 'probe history'
  const secondButton = page.getByRole('button',{name:'开始运行',exact:true})
  evidence.buttons_after_first = await page.getByRole('button').allTextContents()
  if (await secondButton.count() === 1 && await secondButton.isEnabled()) {
    const second = await post(/^\/api\/plans\/[^/]+\/runs$/, () => secondButton.click(),202)
    evidence.run_id_second = second.run_id
    await log('start same confirmed plan a second time through UI',{first:first.run_id,second:second.run_id})
    assert.notEqual(second.run_id, first.run_id)
    await region('运行').getByText('运行成功',{exact:true}).first().waitFor({timeout:120000})
    await page.getByText('规则检查通过',{exact:true}).first().waitFor({timeout:120000})
    evidence.run_visible_second = await text(region('运行'))
    evidence.csv_href_second = await firstLink.getAttribute('href')
    evidence.csv_visible_second = await text(csvItem)
    const [repeatDownload] = await Promise.all([page.waitForEvent('download'),firstLink.click()])
    assert.equal(await repeatDownload.failure(),null)
    await repeatDownload.saveAs(join(base,'road-buffer-second.csv'))
    evidence.csv_suggested_name_second = repeatDownload.suggestedFilename()
    evidence.url_second = page.url()
    evidence.controls_after_second = await page.getByRole('combobox').evaluateAll(items => items.filter(el => el.checkVisibility()).map(el=>({label:el.labels?.[0]?.innerText, value:el.value, options:[...el.options].map(option=>option.text)})))
    evidence.buttons_after_second = await page.getByRole('button').allTextContents()
    evidence.links_after_second = await page.getByRole('link').evaluateAll(items => items.filter(el => el.checkVisibility()).map(el=>({text:el.innerText,href:el.getAttribute('href')})))
    evidence.check_visible_second = (await text(report)).slice(0,1600)
    await screenshot('second-result.png')
    await log('record history affordances and second link',{first:evidence.csv_href_first,second:evidence.csv_href_second,visible:evidence.csv_visible_second})
  }
  phase = 'done'
} catch (error) {
  evidence.error = error.stack
  process.exitCode = 1
} finally {
  await save()
  await browser.close()
}
