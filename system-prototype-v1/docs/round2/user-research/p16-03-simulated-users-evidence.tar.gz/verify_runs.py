from collections import Counter
import csv
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
import sys

root = Path(sys.argv[1]).resolve()
expected = json.loads((root / "system-prototype-v1/tests/fixtures/vector/expected.json").read_bytes())["relations"]["intersects"]["counts"]
results = {}
for name in ("first_use", "gis_review", "recovery"):
    profile = root / name
    output = []
    with sqlite3.connect((profile / "project.sqlite").as_uri() + "?mode=ro", uri=True) as connection:
        connection.row_factory = sqlite3.Row
        for row in connection.execute("SELECT * FROM run ORDER BY created_at, id"):
            run = dict(row)
            workdir = Path(run.pop("workdir"))
            assert workdir.is_relative_to(profile / "workspace")
            counts = Counter(entry[0] for entry in connection.execute(
                "SELECT status FROM run_step WHERE run_id = ?", (run["id"],)))
            linked_report = connection.execute(
                "SELECT status FROM check_report WHERE id = ? AND run_id = ?",
                (run["current_report_id"], run["id"])).fetchone()
            artifacts = [dict(artifact) for artifact in connection.execute(
                "SELECT id, role, uri, fingerprint FROM artifact WHERE run_id = ? ORDER BY role", (run["id"],))]
            product = next((item for item in artifacts if item["role"] == "zone_statistics"), None)
            if product is not None:
                path = (workdir / product["uri"]).resolve()
                assert path.is_relative_to(workdir)
                with path.open(newline="", encoding="utf-8") as stream:
                    csv_rows = list(csv.DictReader(stream, strict=True))
                actual = {row["zone_id"] or "unassigned": int(row["count"]) for row in csv_rows}
                actual["total"] = sum(actual.values())
                assert actual == expected and len(csv_rows) == 3
                data = path.read_bytes()
                product["fixture_counts"] = actual
                product["sha256"] = sha256(data).hexdigest()
                product["browser_download_matches"] = [
                    candidate.relative_to(profile).as_posix()
                    for candidate in sorted(profile.rglob("*.csv"))
                    if not candidate.is_relative_to(profile / "workspace") and candidate.read_bytes() == data
                ]
            output.append({"id": run["id"], "plan_id": run["plan_id"], "plan_version": run["plan_version"],
                           "execution_status": run["execution_status"], "check_status": run["check_status"],
                           "cancel_requested": bool(run["cancel_requested"]),
                           "steps": counts, "linked_check_status": linked_report[0] if linked_report else None,
                           "artifacts": artifacts})
    results[name] = output
print(json.dumps(results, ensure_ascii=False, indent=2))
