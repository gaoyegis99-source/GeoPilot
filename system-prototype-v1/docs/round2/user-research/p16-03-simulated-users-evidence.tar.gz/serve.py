from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import sys
from threading import Event

scratch, project = (Path(value).resolve() for value in sys.argv[1:])
source = scratch / "system-prototype-v1"
frontend = source / "frontend"
qgis = project / ".environments/qgis-deb/qgis_process"
spec = importlib.util.spec_from_file_location("matrix", source / "scripts/install-check/run_matrix.py")
matrix = importlib.util.module_from_spec(spec)
spec.loader.exec_module(matrix)
profiles = ("first_use", "gis_review", "recovery")
with ExitStack() as reservations:
    sockets = [reservations.enter_context(socket.socket()) for _ in range(6)]
    for entry in sockets:
        entry.bind(("127.0.0.1", 0))
    ports = [entry.getsockname()[1] for entry in sockets]
stop = Event()
signal.signal(signal.SIGTERM, lambda *_: stop.set())
signal.signal(signal.SIGINT, lambda *_: stop.set())
reports = []
try:
    with ExitStack() as servers:
        for profile, bp, fp in zip(profiles, ports[::2], ports[1::2]):
            output = scratch / profile
            backend_url = f"http://127.0.0.1:{bp}"
            frontend_url = f"http://127.0.0.1:{fp}"
            env = {**os.environ, "PYTHONPATH": str(source / "src"), "PYTHONDONTWRITEBYTECODE": "1",
                   "GEOPILOT_API_URL": backend_url, "QT_QPA_PLATFORM": "offscreen", "PROJ_NETWORK": "OFF",
                   "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "GDAL_NUM_THREADS": "1",
                   "GEOPILOT_SIM_FRONT_PORT": str(fp), "GEOPILOT_SIM_CACHE": str(output / "vite-cache")}
            report = {"profile": profile, "steps": []}
            reports.append(report)
            backend = [project / ".venv/bin/python", "-m", "geopilot.api.server", "--database",
                       output / "project.sqlite", "--workspace", output / "workspace", "--config",
                       source / "config", "--qgis-process", qgis, "--port", str(bp)]
            ui = ["node", "--input-type=module", "-e",
                  "import {createServer} from 'vite'; const s = await createServer({cacheDir:process.env.GEOPILOT_SIM_CACHE,server:{host:'127.0.0.1',port:Number(process.env.GEOPILOT_SIM_FRONT_PORT),strictPort:true}}); await s.listen(); s.printUrls();"]
            service = servers.enter_context(matrix.server(report, output, "backend", backend, source, env))
            matrix.wait_http(service, backend_url + "/api/methods")
            site = servers.enter_context(matrix.server(report, output, "frontend", ui, frontend, env))
            matrix.wait_http(site, frontend_url + "/api/methods")
            (output / "session.json").write_text(json.dumps({
                "profile": profile, "url": frontend_url, "fixture": str(source / "tests/fixtures/vector/road-buffer.gpkg"),
                "browser_module": "/home/mtd/.npm/_npx/d537ee5ee2a13f03/node_modules/playwright/index.mjs",
                "task_sheet": str(source / "docs/round2/user-research/participant-task.md"),
            }, indent=2) + "\n")
        (scratch / "service-pid").write_text(str(os.getpid()) + "\n")
        print("All three browser workbenches ready", flush=True)
        while not stop.wait(2):
            continue
finally:
    (scratch / "server-receipt.json").write_text(json.dumps(reports, indent=2) + "\n")
