import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
const meta = JSON.parse(fs.readFileSync('session.json', 'utf8'));
const {chromium} = await import(meta.browser_module);
const browser = await chromium.launch({headless:true});
const context = await browser.newContext({viewport:{width:1366,height:900},acceptDownloads:true});
const page = await context.newPage();
const fixture = meta.fixture;
const errors = [];
page.on('pageerror', e => errors.push(String(e)));
const log = (line) => fs.appendFileSync('browser-actions.log', line+'\n');
const out = (value) => {const v=typeof value==='string'?value:JSON.stringify(value,null,2); console.log(v); log(v??'');};
const shot = async name => { await page.screenshot({path:name+'.png',fullPage:false}); return name+'.png'; };
const snap = async () => await page.locator('body').ariaSnapshot({timeout:3000});
await page.goto(meta.url, {waitUntil:'domcontentloaded'});
out('Opened '+meta.url+' with Chromium '+browser.version());
for await (const line of readline.createInterface({input:process.stdin,terminal:false})) {
  if (line==='exit') break;
  if (!line.trim()) continue;
  log('> '+line);
  try {const result=await eval('(async()=>{'+line+'})()'); if(result!==undefined)out(result);}
  catch(e){out('Automation error: '+e.message);}
}
out({pageErrors:errors});
await browser.close();
