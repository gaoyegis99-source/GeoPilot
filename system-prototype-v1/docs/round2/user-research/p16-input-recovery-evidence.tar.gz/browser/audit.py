"""Independently match pinned GIS inputs and preserved downloads against browser evidence."""

from hashlib import sha256
import json
from pathlib import Path
import sqlite3
import sys

root = Path(sys.argv[1]).resolve(strict=True)


def get(path):
    return json.loads(path.read_text())


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def source_snapshot(run):
    step = next(row for row in run["steps"] if row["step_key"] == "select_roads_from_expanded_extent")
    selection = json.loads(step["request_json"])["inputs"]["source"]
    assert selection["layer"] == "roads"
    copied = root / "pinned-roads" / (run["run"]["id"] + ".gpkg")
    return copied if copied.exists() else Path(run["run"]["workdir"]) / selection["path"]


def inspect_roads(path):
    with sqlite3.connect(path.as_uri() + "?mode=ro", uri=True) as db:
        rows = db.execute("SELECT fid, source_feature_id, hex(geom) FROM roads ORDER BY fid").fetchall()
        assert db.execute("PRAGMA integrity_check").fetchone() == ("ok",)
        return [list(row) for row in rows]


legacy = root / "baseline/browser-run"
corrected = root / "corrected-final/browser-run"
assert (legacy / "launcher.exit-code").read_text().strip() == "0"
assert (corrected / "launcher.exit-code").read_text().strip() == "0"
assert get(legacy / "verification.json")["verdict"] == "LEGACY_GAP_REPRODUCED"
verification = get(corrected / "verification.json")
assert verification["verdict"] == "PASS"
assert verification["source_commit"] == (corrected.parent / "source-commit").read_text().strip()
before = get(corrected / "before-input-change.json")
rejected = get(corrected / "after-rejected-start.json")
after = get(corrected / "after-new-run.json")
assert before == rejected
old = before["runs"][verification["old_run"]]
assert old == after["runs"][verification["old_run"]]
new = after["runs"][verification["new_run"]]
mutation = get(corrected / "source-edit.json")
old_snapshot = source_snapshot(old)
new_snapshot = source_snapshot(new)
assert sha(old_snapshot) == mutation["before"]["sha256"]
assert sha(new_snapshot) == mutation["after"]["sha256"]
assert inspect_roads(old_snapshot) == mutation["rows_before"]
assert inspect_roads(new_snapshot) == mutation["rows_after"]
assert len(set(sha(corrected / name) for name in (
    "old-statistics.csv", "new-statistics.csv", "old-statistics-after-revision.csv",
))) == 1
result = {
    "verdict": "PASS",
    "source_commit": verification["source_commit"],
    "old_run": old["run"]["id"], "new_run": new["run"]["id"],
    "pinned_roads_v1_sha256": sha(old_snapshot), "pinned_roads_v2_sha256": sha(new_snapshot),
    "old_value": mutation["rows_before"][0][1], "new_value": mutation["rows_after"][0][1],
    "unchanged_old_execution_files": len(old["files"]),
    "old_and_new_statistics_sha256": sha(corrected / "old-statistics.csv"),
}
print(json.dumps(result, ensure_ascii=False, indent=2))
