"""Make the external input edit and capture persisted evidence from the isolated trial."""

from hashlib import sha256
import json
from pathlib import Path
import sqlite3
import sys

output, action = Path(sys.argv[1]).resolve(strict=True), sys.argv[2]
session = json.loads((output / "session.json").read_text())
mutable = Path(session["mutable"]).resolve(strict=True)
assert mutable.is_relative_to(output / "data/mutable")


def digest(path):
    info = path.stat()
    return {
        "sha256": sha256(path.read_bytes()).hexdigest(),
        "size": info.st_size,
        "mtime_ns": info.st_mtime_ns,
        "inode": info.st_ino,
    }


def mutate():
    def unexpected_spatial_trigger(*args):
        raise RuntimeError("The attribute-only edit must not touch spatial triggers")

    def rows(db):
        return db.execute("SELECT fid, source_feature_id, hex(geom) FROM roads ORDER BY fid").fetchall()

    before_file = digest(mutable)
    with sqlite3.connect(mutable) as db:
        for name in ("ST_IsEmpty", "ST_MinX", "ST_MaxX", "ST_MinY", "ST_MaxY"):
            db.create_function(name, 1, unexpected_spatial_trigger)
        before = rows(db)
        assert before[0][:2] == (1, "road-main")
        changed = db.execute("UPDATE roads SET source_feature_id = ? WHERE fid = ?", ("road-main-revised", 1))
        assert changed.rowcount == 1
        after = rows(db)
        assert after == [(1, "road-main-revised", before[0][2]), *before[1:]]
        assert db.execute("PRAGMA integrity_check").fetchone() == ("ok",)
    after_file = digest(mutable)
    assert before_file["sha256"] != after_file["sha256"]
    return {
        "path": str(mutable), "before": before_file, "after": after_file,
        "rows_before": before, "rows_after": after, "one_attribute_changed": True,
    }


def snapshot(task_id):
    def select(db, sql, *params):
        return [dict(row) for row in db.execute(sql, params)]

    with sqlite3.connect((output / "data/project.sqlite").as_uri() + "?mode=ro", uri=True) as db:
        db.row_factory = sqlite3.Row
        db.execute("BEGIN")
        plans = select(db, "SELECT * FROM analysis_plan WHERE task_id = ? ORDER BY version", task_id)
        runs = select(db, """
            SELECT r.* FROM run r JOIN analysis_plan p ON r.plan_id=p.id AND r.plan_version=p.version
            WHERE p.task_id=? ORDER BY r.created_at, r.id
        """, task_id)
        assets = select(db, "SELECT * FROM data_asset ORDER BY id, version")
        details = {}
        for run in runs:
            run_id = run["id"]
            workdir = Path(run["workdir"]).resolve(strict=True)
            assert workdir.is_relative_to(output / "data/workspace")
            files = {}
            for name in ("steps", "intermediate", "outputs"):
                for path in sorted((workdir / name).rglob("*")):
                    if path.is_file() and not path.name.endswith(("-shm", "-wal", "-journal")):
                        files[path.relative_to(workdir).as_posix()] = digest(path)
            details[run_id] = {
                "run": run,
                "steps": select(db, "SELECT * FROM run_step WHERE run_id = ? ORDER BY position", run_id),
                "artifacts": select(db, "SELECT * FROM artifact WHERE run_id = ? ORDER BY role", run_id),
                "checks": select(db, "SELECT * FROM check_report WHERE run_id = ? ORDER BY created_at, id", run_id),
                "files": files,
            }
        return {"plans": plans, "runs": details, "assets": assets}


result = mutate() if action == "mutate" else snapshot(sys.argv[3])
print(json.dumps(result, indent=2, sort_keys=True))
