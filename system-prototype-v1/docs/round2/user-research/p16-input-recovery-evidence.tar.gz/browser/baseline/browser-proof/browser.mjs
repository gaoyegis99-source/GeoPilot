import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { appendFile, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'

const directory = process.argv[2]
const session = JSON.parse(await readFile(join(directory, 'session.json'), 'utf8'))
const site = new URL(session.url)
assert.equal(site.protocol, 'http:')
assert.equal(site.hostname, '127.0.0.1')
const { chromium } = await import(session.browser_module)
const env = { ...process.env, PATH: '/usr/bin:/bin' }
delete env.PYTHONPATH
delete env.GEOPILOT_QGIS_PROCESS
const browser = await chromium.launch({
  headless: true,
  env,
  args: ['--enable-webgl', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
})
const startedAt = performance.now()
const errors = []
let stage = 'startup'

async function save(name, value) {
  await writeFile(join(directory, name + '.json'), JSON.stringify(value, null, 2) + '\n')
}

async function note(action, detail = {}) {
  const entry = { action, automation_ms: Math.round(performance.now() - startedAt), ...detail }
  await appendFile(join(directory, 'registration-trace.jsonl'), JSON.stringify(entry) + '\n')
}

async function proof(action, label, taskId) {
  const args = ['-B', session.proof, directory, action]
  if (taskId) args.push(taskId)
  const output = JSON.parse(execFileSync(session.python, args, { encoding: 'utf8' }))
  await save(label, output)
  return output
}

try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true })
  const page = await context.newPage()
  page.setDefaultTimeout(30000)
  page.on('pageerror', error => errors.push(error.message))
  const dataRegion = page.getByRole('region', { name: '数据', exact: true })
  const runRegion = page.getByRole('region', { name: '运行', exact: true })
  const planRegion = page.getByRole('region', { name: '方案', exact: true })
  const checkRegion = page.getByRole('region', { name: '规则检查', exact: true })
  const form = page.getByRole('form', { name: '方法表单' })
  const start = runRegion.getByRole('button', { name: '开始运行', exact: true })
  const confirm = planRegion.getByRole('button', { name: '确认方案', exact: true })
  const draft = form.getByRole('button', { name: '生成草稿' })
  const roadSelection = form.getByLabel('道路', { exact: true })

  async function observePost(path, action) {
    const [response] = await Promise.all([
      page.waitForResponse(item => item.request().method() === 'POST' && path.test(new URL(item.url()).pathname)),
      action(),
    ])
    return { status: response.status(), request: response.request().postDataJSON(), data: await response.json() }
  }

  async function register(layer, path) {
    await dataRegion.getByRole('button', { name: '导入数据', exact: true }).click()
    await dataRegion.getByLabel('本机文件路径').fill(path)
    await dataRegion.getByRole('button', { name: '读取图层', exact: true }).click()
    const picker = dataRegion.getByLabel('GeoPackage 图层')
    await picker.locator('option[value="roads"]').waitFor({ state: 'attached' })
    await picker.selectOption(layer)
    const response = await observePost(/^\/api\/assets$/, () => dataRegion.getByRole('button', { name: '登记资产', exact: true }).click())
    assert.equal(response.status, 200)
    assert.equal(response.data.source.layer, layer)
    assert.equal(response.data.source.path, path)
    return response.data
  }

  function assetRef(asset) {
    return { asset_id: asset.asset_id, asset_version: asset.asset_version }
  }

  const roles = { analysis_extent: '分析范围', roads: '道路', targets: '目标对象', zones: '统计分区' }
  async function formValues() {
    return {
      goal: await form.getByLabel('任务目标').inputValue(),
      assets: Object.fromEntries(await Promise.all(Object.entries(roles).map(async ([role, label]) => [
        role, await form.getByLabel(label, { exact: true }).inputValue(),
      ]))),
      fields: Object.fromEntries(await Promise.all([
        '缓冲距离', '距离坐标参考系', '距离计算方式', '空间关系', '跨界归属', '边界并列处理', '统计量', '输出范围',
      ].map(async label => [label, await form.getByLabel(label, { exact: true }).inputValue()]))),
    }
  }

  async function successfulDownload(id, filename) {
    await page.waitForURL(url => url.searchParams.get('run') === id)
    await runRegion.getByText('运行成功', { exact: true }).waitFor({ timeout: 90000 })
    await checkRegion.getByText('规则检查通过', { exact: true }).waitFor({ timeout: 90000 })
    const result = page.getByRole('list', { name: '正式成果' }).getByRole('listitem')
      .filter({ has: page.getByText('分区统计', { exact: true }) })
    const [download] = await Promise.all([
      page.waitForEvent('download'), result.getByRole('link', { name: '下载原文件' }).click(),
    ])
    assert.equal(await download.failure(), null)
    assert.equal(download.suggestedFilename(), `statistics-${id}.csv`)
    const file = join(directory, filename)
    await download.saveAs(file)
    const csv = await readFile(file, 'utf8')
    const counts = Object.fromEntries(csv.trimEnd().split(/\r?\n/).slice(1).map(line => {
      const [zone, , count] = line.split(',', 3)
      return [zone || 'unassigned', Number(count)]
    }))
    assert.deepEqual(counts, { 'zone-east': 2, 'zone-west': 3, unassigned: 1 })
    return { csv, counts }
  }

  const ok = await page.goto(site.href)
  assert.ok(ok?.ok())
  await page.getByText('暂无数据', { exact: true }).waitFor()
  await note('open isolated workbench', { chromium: browser.version(), source_commit: session.source_commit, mode: session.mode })

  stage = 'register fixture layers and confirm original plan'
  const initialAssets = {}
  for (const role of Object.keys(roles)) {
    const asset = await register(role, role === 'roads' ? session.mutable : session.fixture)
    assert.equal(asset.asset_version, 1)
    initialAssets[role] = assetRef(asset)
  }
  const method = page.getByRole('region', { name: '方法目录' }).locator('details')
    .filter({ hasText: '道路缓冲统计' }).filter({ has: page.locator('summary', { hasText: /版本 3\b/ }) })
  await method.locator('summary').click()
  await method.getByRole('button', { name: '选择方法', exact: true }).click()
  await form.getByLabel('任务目标').fill('重登记变更的道路输入后复核原方案及成果历史')
  for (const [role, label] of Object.entries(roles)) {
    await form.getByLabel(label, { exact: true }).selectOption({ label: `road-buffer.gpkg · ${role} · v1` })
  }
  await form.getByLabel('缓冲距离').fill('500')
  for (const [label, value] of [
    ['距离计算方式', 'local_projected'], ['空间关系', 'intersects'], ['跨界归属', 'centroid'],
    ['边界并列处理', 'unassigned'], ['统计量', 'count'], ['输出范围', 'clipped_to_analysis_extent'],
  ]) {
    await form.getByLabel(label, { exact: true }).selectOption(value)
  }
  await form.getByLabel('距离坐标参考系', { exact: true }).fill('EPSG:32650')
  const originalValues = await formValues()
  const originalDraft = await observePost(/^\/api\/tasks\/[^/]+\/plans$/, () => draft.click())
  assert.equal(originalDraft.status, 200)
  assert.deepEqual(originalDraft.data.issues, [])
  assert.deepEqual(originalDraft.data.inputs, initialAssets)
  const originalPlan = await observePost(/^\/api\/plans\/[^/]+\/confirm$/, () => confirm.click())
  assert.equal(originalPlan.status, 200)
  assert.equal(originalPlan.data.status, 'confirmed')
  const taskId = originalPlan.data.task_id
  await save('old-confirmed-plan', originalPlan)

  stage = 'complete original GIS run and save output'
  const original = await observePost(/^\/api\/plans\/[^/]+\/runs$/, () => start.click())
  assert.equal(original.status, 202)
  const oldRun = original.data.run_id
  const oldResult = await successfulDownload(oldRun, 'old-statistics.csv')
  const before = await proof('snapshot', 'before-input-change', taskId)
  const oldRecord = before.runs[oldRun]
  assert.equal(oldRecord.run.execution_status, 'SUCCEEDED')
  assert.equal(oldRecord.run.check_status, 'PASSED')
  assert.equal(oldRecord.artifacts.length, 3)
  assert.equal(oldRecord.steps.length, 7)
  assert.ok(Object.keys(oldRecord.files).length > 0)
  await note('original GIS run succeeded and downloaded', {
    task_id: taskId, confirmed_plan_id: originalPlan.data.id, plan_version: originalPlan.data.version,
    run_id: oldRun, counts: oldResult.counts, artifacts: oldRecord.artifacts.map(item => item.id),
  })

  stage = 'modify one source attribute outside workbench then attempt old plan'
  const mutation = await proof('mutate', 'source-edit')
  assert.ok(mutation.one_attribute_changed)
  const rejected = await observePost(/^\/api\/plans\/[^/]+\/runs$/, () => start.click())
  await save('rejected-start', rejected)
  assert.equal(rejected.status, 409)
  assert.equal(rejected.data.detail.code, 'INPUT_CHANGED')
  const denied = await proof('snapshot', 'after-rejected-start', taskId)
  assert.deepEqual(denied, before)
  assert.equal(new URL(page.url()).searchParams.get('run'), oldRun)
  const diagnosis = runRegion.locator('.workbench-problem').filter({ has: page.locator('code', { hasText: /^INPUT_CHANGED$/ }) })
  await diagnosis.getByRole('alert').waitFor()
  const alert = await diagnosis.getByRole('alert').innerText()
  const visibleActions = await runRegion.getByRole('button').allTextContents()
  await note('old plan start rejected without a run or history change', {
    code: rejected.data.detail.code, field: rejected.data.detail.field, status: rejected.status, alert, visible_actions: visibleActions,
  })
  await diagnosis.screenshot({ path: join(directory, 'input-changed.png') })
  await runRegion.screenshot({ path: join(directory, 'old-run-with-diagnosis.png') })
  if (session.mode === 'legacy') {
    assert.equal(await diagnosis.getByRole('button').count(), 0)
    assert.match(alert, /fingerprint|source/i)
    await diagnosis.getByText('技术详情', { exact: true }).click()
    await diagnosis.getByText('INPUT_CHANGED', { exact: true }).waitFor()
    assert.deepEqual(errors, [])
    await save('verification', { verdict: 'LEGACY_GAP_REPRODUCED', task_id: taskId, old_run: oldRun, diagnosis: alert, page_errors: errors })
  } else {
    stage = 'follow explicit registration recovery through revised GIS run'
    await revisedRun({ page, dataRegion, runRegion, form, roadSelection, start, confirm, draft, diagnosis, rejected,
      before, oldRun, oldResult, oldRecord, originalPlan, originalValues, initialAssets, taskId,
      assetRef, successfulDownload, observePost, formValues, proof, note, save, errors })
  }
} catch (error) {
  await save('failure', { stage, error: String(error), page_errors: errors })
  throw error
} finally {
  await browser.close()
}

async function revisedRun({
  page, dataRegion, runRegion, form, roadSelection, start, confirm, draft, diagnosis, rejected,
  before, oldRun, oldResult, oldRecord, originalPlan, originalValues, initialAssets, taskId,
  assetRef, successfulDownload, observePost, formValues, proof, note, save, errors,
}) {
  const alert = diagnosis.getByRole('alert')
  await alert.getByText('输入数据', { exact: true }).waitFor()
  await alert.getByText('本机输入文件与方案中的登记版本不一致。', { exact: true }).waitFor()
  await alert.getByText(/重新登记.*选择新版本.*生成并确认草稿/).waitFor()
  const action = diagnosis.getByRole('button', { name: '打开资产登记', exact: true })
  assert.equal(await action.count(), 1)
  assert.equal(await diagnosis.getByRole('button').count(), 1)
  assert.equal(await diagnosis.getByRole('link', { name: '查看完整日志' }).count(), 0)
  const technical = diagnosis.locator('details')
  assert.equal(await technical.evaluate(node => node.open), false)
  await diagnosis.getByText('技术详情', { exact: true }).click()
  await technical.getByText('INPUT_CHANGED', { exact: true }).waitFor()
  await technical.getByText(rejected.data.detail.message, { exact: true }).waitFor()
  if (rejected.data.detail.field) await technical.getByText(rejected.data.detail.field, { exact: true }).waitFor()
  await diagnosis.screenshot({ path: join(directory, 'input-changed-technical-details.png') })

  stage = 'open existing run log while the input diagnosis is present'
  const stepLog = runRegion.getByRole('list', { name: '运行步骤' }).getByRole('button', { name: '查看日志', exact: true }).first()
  const [logResponse] = await Promise.all([
    page.waitForResponse(response => response.request().method() === 'GET'
      && new URL(response.url()).pathname.startsWith('/api/runs/' + oldRun + '/steps/')
      && new URL(response.url()).pathname.endsWith('/log') && new URL(response.url()).searchParams.get('tail') === '60'),
    stepLog.click(),
  ])
  assert.equal(logResponse.status(), 200)
  const logText = await logResponse.text()
  assert.ok(logText.trim())
  const visibleLog = runRegion.locator('.run-panel__log pre')
  await visibleLog.waitFor()
  assert.equal(await visibleLog.textContent(), logText)
  const fullLog = runRegion.locator('.run-panel__log').getByRole('link', { name: '查看完整日志', exact: true })
  assert.equal(await fullLog.getAttribute('href'), new URL(logResponse.url()).pathname)
  const [fullResponse, logPage] = await Promise.all([
    page.context().waitForEvent('response', response => response.request().method() === 'GET'
      && new URL(response.url()).pathname === new URL(logResponse.url()).pathname && new URL(response.url()).search === ''),
    page.waitForEvent('popup'),
    fullLog.click(),
  ])
  assert.equal(fullResponse.status(), 200)
  const fullText = await fullResponse.text()
  assert.ok(fullText.includes(logText.trim()))
  await logPage.close()
  await writeFile(join(directory, 'old-step.log'), fullText)
  await runRegion.screenshot({ path: join(directory, 'old-run-log.png') })
  await note('open existing run tail and full log through browser', {
    run_id: oldRun, tail_status: logResponse.status(), full_status: fullResponse.status(),
    log_url: new URL(fullResponse.url()).pathname, tail_bytes: Buffer.byteLength(logText), full_bytes: Buffer.byteLength(fullText),
    tail_visible_in_workbench: true,
  })

  stage = 'open explicit registration and register only the changed layer'
  const source = dataRegion.getByLabel('本机文件路径', { exact: true })
  assert.equal(await source.count(), 0)
  await action.click()
  await source.waitFor()
  assert.ok(await source.evaluate(node => node === document.activeElement))
  assert.equal(await source.inputValue(), '')
  assert.deepEqual(await proof('snapshot', 'after-opening-registration', taskId), before)
  await dataRegion.screenshot({ path: join(directory, 'focused-registration.png') })
  await source.fill(session.mutable)
  await dataRegion.getByRole('button', { name: '读取图层', exact: true }).click()
  const picker = dataRegion.getByLabel('GeoPackage 图层')
  await picker.locator('option[value="roads"]').waitFor({ state: 'attached' })
  await picker.selectOption('roads')
  const registered = await observePost(/^\/api\/assets$/, () => dataRegion.getByRole('button', { name: '登记资产', exact: true }).click())
  await save('asset-v2', registered)
  assert.equal(registered.status, 200)
  assert.deepEqual(registered.request, { path: session.mutable, layer: 'roads' })
  assert.equal(registered.data.source.path, session.mutable)
  assert.equal(registered.data.source.layer, 'roads')
  const v2 = assetRef(registered.data)
  assert.equal(v2.asset_id, initialAssets.roads.asset_id)
  assert.equal(v2.asset_version, 2)
  await dataRegion.getByRole('checkbox', { name: '显示 roads v2', exact: true }).waitFor()
  assert.deepEqual(await formValues(), originalValues)
  const registeredState = await proof('snapshot', 'after-registration', taskId)
  assert.deepEqual(registeredState.plans, before.plans)
  assert.deepEqual(registeredState.runs, before.runs)
  assert.equal(registeredState.assets.length, before.assets.length + 1)
  const roads = registeredState.assets.filter(asset => asset.id === v2.asset_id)
  assert.deepEqual(roads.map(asset => asset.version), [1, 2])
  assert.notEqual(roads[0].fingerprint, roads[1].fingerprint)
  await note('register changed layer from explicit recovery control', {
    focus_is_source: true, no_automatic_registration: true, asset_id: v2.asset_id, new_version: v2.asset_version,
    only_new_asset_version: true, selection_still_old: true,
  })

  stage = 'choose v2 and explicitly generate and confirm revised plan'
  await roadSelection.selectOption({ label: 'road-buffer.gpkg · roads · v2' })
  const changedValues = await formValues()
  assert.notEqual(changedValues.assets.roads, originalValues.assets.roads)
  assert.deepEqual({ ...changedValues, assets: { ...changedValues.assets, roads: originalValues.assets.roads } }, originalValues)
  await page.getByText('表单已修改，请先生成草稿。', { exact: true }).waitFor()
  assert.ok(await start.isDisabled())
  const revised = await observePost(/^\/api\/tasks\/[^/]+\/plans$/, () => draft.click())
  await save('revised-draft', revised)
  assert.equal(revised.status, 200)
  assert.equal(revised.data.id, originalPlan.data.id)
  assert.equal(revised.data.task_id, taskId)
  assert.equal(revised.data.version, originalPlan.data.version + 1)
  assert.equal(revised.data.status, 'draft')
  assert.deepEqual(revised.data.issues, [])
  assert.deepEqual(revised.data.inputs, { ...initialAssets, roads: v2 })
  assert.deepEqual(revised.data.goal, originalPlan.data.goal)
  assert.deepEqual(revised.data.critical_options, originalPlan.data.critical_options)
  assert.equal(revised.request.base_plan_id, originalPlan.data.id)
  assert.equal(revised.request.base_plan_version, originalPlan.data.version)
  const confirmed = await observePost(/^\/api\/plans\/[^/]+\/confirm$/, () => confirm.click())
  await save('revised-confirmed-plan', confirmed)
  assert.equal(confirmed.status, 200)
  assert.equal(confirmed.data.version, revised.data.version)
  assert.equal(confirmed.data.status, 'confirmed')
  assert.deepEqual(confirmed.data.inputs, revised.data.inputs)
  assert.equal(new URL(page.url()).searchParams.get('run'), oldRun)
  await note('reselect only roads v2 and explicitly generate and confirm revision', {
    plan_id: revised.data.id, old_plan_version: originalPlan.data.version, new_plan_version: revised.data.version,
    old_run_still_selected: true, inputs: revised.data.inputs,
  })

  stage = 'complete new GIS run and return to old run in browser history'
  const newStart = await observePost(/^\/api\/plans\/[^/]+\/runs$/, () => start.click())
  assert.equal(newStart.status, 202)
  assert.equal(newStart.request.plan_version, revised.data.version)
  const newRun = newStart.data.run_id
  assert.notEqual(newRun, oldRun)
  const newResult = await successfulDownload(newRun, 'new-statistics.csv')
  assert.equal(newResult.csv, oldResult.csv)
  const after = await proof('snapshot', 'after-new-run', taskId)
  assert.deepEqual(Object.keys(after.runs), [oldRun, newRun])
  assert.deepEqual(after.plans.find(plan => plan.version === originalPlan.data.version), before.plans[0])
  assert.deepEqual(after.runs[oldRun], oldRecord)
  assert.equal(after.runs[newRun].run.plan_id, revised.data.id)
  assert.equal(after.runs[newRun].run.plan_version, revised.data.version)
  assert.equal(after.runs[newRun].run.execution_status, 'SUCCEEDED')
  assert.equal(after.runs[newRun].run.check_status, 'PASSED')
  assert.equal(after.runs[newRun].artifacts.length, 3)
  assert.equal(after.runs[newRun].steps.length, 7)
  assert.ok(after.runs[newRun].artifacts.every(artifact => !oldRecord.artifacts.some(old => old.id === artifact.id)))
  await runRegion.getByText('运行历史（2 次）', { exact: true }).click()
  const history = runRegion.getByRole('list', { name: '运行历史' })
  await history.screenshot({ path: join(directory, 'both-runs-in-history.png') })
  await history.locator('a[title="' + oldRun + '"]').click()
  const redownload = await successfulDownload(oldRun, 'old-statistics-after-revision.csv')
  assert.equal(redownload.csv, oldResult.csv)
  assert.deepEqual(await proof('snapshot', 'after-opening-old-history', taskId), after)
  assert.deepEqual(errors, [])
  await note('new run passed and previous run and results remained accessible', {
    new_run_id: newRun, old_run_id: oldRun, old_run_record_unchanged: true,
    old_file_count_unchanged: Object.keys(oldRecord.files).length, old_download_bytes_unchanged: true,
  })
  await save('verification', {
    verdict: 'PASS', source_commit: session.source_commit, task_id: taskId, plan_id: revised.data.id,
    old_plan_version: originalPlan.data.version, new_plan_version: revised.data.version,
    old_run: oldRun, new_run: newRun, changed_asset: v2,
    old_artifacts: oldRecord.artifacts.map(item => item.id),
    new_artifacts: after.runs[newRun].artifacts.map(item => item.id),
    old_files_verified_unchanged: Object.keys(oldRecord.files).length,
    check_statuses: [oldRecord.run.check_status, after.runs[newRun].run.check_status],
    counts: newResult.counts, page_errors: errors,
  })
}
