#!/usr/bin/env bash
set -euo pipefail
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
project=/home/mtd/liweigis/GeoPilot-round2/system-prototype-v1
repo="$(git -C "$project" rev-parse --show-toplevel)"
prefix="$(git -C "$project" rev-parse --show-prefix)"
revision="$(git -C "$repo" rev-parse --verify --end-of-options "$1^{commit}")"
expectation="$2"
[[ "$expectation" == legacy || "$expectation" == corrected ]]
label="$3"
[[ "$label" =~ ^[a-zA-Z0-9_-]+$ ]]
trial="$root/$label"
mkdir "$trial" "$trial/tmp"
export TMPDIR="$trial/tmp"
printf '%s\n' "$revision" > "$trial/source-commit"
cp -a "$root/browser-proof" "$trial/"
git -C "$repo" archive "$revision" "${prefix%/}" | tar -xf - -C "$trial"
source="$trial/${prefix%/}"
( cd "$source" && sha256sum tests/fixtures/vector/{road-buffer.gpkg,expected.json} frontend/package-lock.json ) > "$trial/source-input.sha256"
( cd "$source/frontend" && npm ci --offline --cache "$root/npm-cache" --include=dev --no-audit --no-fund ) > "$trial/npm-install.log" 2>&1
set +e
"$project/.venv/bin/python" -B "$trial/browser-proof/launch.py" "$trial" "$project" /home/mtd/.npm/_npx/d537ee5ee2a13f03/node_modules/playwright/index.mjs "$project/.environments/qgis-deb/qgis_process" browser-run "$expectation"
status=$?
set -e
printf '%s\n' "$status" > "$trial/browser-run/launcher.exit-code"
if (( status != 0 )); then exit "$status"; fi
set +e
"$project/.venv/bin/python" -B "$trial/browser-proof/verify.py" "$trial/browser-run" > "$trial/browser-run/verification.json"
status=$?
set -e
printf '%s\n' "$status" > "$trial/browser-run/verification.exit-code"
exit "$status"
