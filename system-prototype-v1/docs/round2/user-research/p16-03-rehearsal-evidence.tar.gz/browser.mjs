import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { readFile, realpath } from 'node:fs/promises'

const site = new URL(process.argv[2])
assert.equal(site.protocol, 'http:')
assert.equal(site.hostname, '127.0.0.1')
const fixture = await realpath(process.argv[3])
const expected = JSON.parse(await readFile(process.argv[4], 'utf8'))
const { chromium } = await import(process.env.GEOPILOT_PLAYWRIGHT_MODULE)
const env = { ...process.env, PATH: '/usr/bin:/bin' }
delete env.GEOPILOT_QGIS_PROCESS
delete env.PYTHONPATH
assert.equal(spawnSync('/bin/sh', ['-c', 'if command -v qgis_process; then exit 1; fi'], { env }).status, 0)
const browser = await chromium.launch({
  headless: true,
  env,
  args: ['--enable-webgl', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
})
try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true })
  const page = await context.newPage()
  page.setDefaultTimeout(45000)
  const errors = []
  page.on('pageerror', error => errors.push(error.message))
  let stage = 'startup'

  async function post(path, action, status) {
    const [response] = await Promise.all([
      page.waitForResponse(item => item.request().method() === 'POST' && path.test(new URL(item.url()).pathname)),
      action(),
    ])
    assert.equal(response.status(), status, await response.text())
    return response.json()
  }

  try {
    assert.ok((await page.goto(site.href))?.ok())
    await page.getByText('暂无数据', { exact: true }).waitFor()
    stage = 'register assets'
    const registered = {}
    for (const role of ['analysis_extent', 'roads', 'targets', 'zones']) {
      await page.getByRole('button', { name: '导入数据', exact: true }).click()
      await page.getByLabel('本机文件路径').fill(fixture)
      await page.getByRole('button', { name: '读取图层', exact: true }).click()
      await page.locator('select').filter({ has: page.locator('option', { hasText: /^analysis_extent$/ }) })
        .first().waitFor()
      await page.getByLabel('GeoPackage 图层').selectOption(role)
      const asset = await post(/^\/api\/assets$/, () => page.getByRole('button', { name: '登记资产', exact: true }).click(), 200)
      assert.equal(asset.asset_version, 1)
      assert.equal(asset.source.layer, role)
      assert.equal(asset.metadata.crs, 'EPSG:32650')
      registered[role] = { asset_id: asset.asset_id, asset_version: asset.asset_version }
    }
    stage = 'select method and create draft'
    const method = page.getByRole('region', { name: '方法目录' }).locator('details')
      .filter({ hasText: '道路缓冲统计' }).filter({ has: page.locator('summary', { hasText: /版本 3\b/ }) })
    await method.locator('summary').click()
    await method.getByRole('button', { name: '选择方法', exact: true }).click()
    const form = page.getByRole('form', { name: '方法表单' })
    await form.getByLabel('任务目标').fill('统计道路 500 米缓冲范围内各区的目标点')
    for (const [role, label] of Object.entries({
      analysis_extent: '分析范围', roads: '道路', targets: '目标对象', zones: '统计分区',
    })) {
      await form.getByLabel(label, { exact: true }).selectOption({ label: `road-buffer.gpkg · ${role} · v1` })
    }
    await form.getByLabel('缓冲距离').fill('500')
    for (const [label, value] of [
      ['距离计算方式', 'local_projected'], ['空间关系', 'intersects'], ['跨界归属', 'centroid'],
      ['边界并列处理', 'unassigned'], ['统计量', 'count'], ['输出范围', 'clipped_to_analysis_extent'],
    ]) {
      await form.getByLabel(label, { exact: true }).selectOption(value)
    }
    await form.getByLabel('距离坐标参考系', { exact: true }).fill('EPSG:32650')
    const draft = await post(/^\/api\/tasks\/[^/]+\/plans$/, () => form.getByRole('button', { name: '生成草稿' }).click(), 200)
    assert.equal(draft.status, 'draft')
    assert.deepEqual(draft.method, { id: 'road-buffer-statistics', version: 3 })
    assert.deepEqual(draft.inputs, registered)
    assert.deepEqual(draft.issues, [])
    assert.equal(draft.steps.length, 7)
    assert.equal(draft.critical_options.distance_m, 500)
    assert.equal(draft.critical_options.distance_crs_ref, 'EPSG:32650')
    stage = 'confirm plan'
    const confirmed = await post(/^\/api\/plans\/[^/]+\/confirm$/,
      () => page.getByRole('button', { name: '确认方案', exact: true }).click(), 200)
    assert.equal(confirmed.status, 'confirmed')
    stage = 'run'
    const run = await post(/^\/api\/plans\/[^/]+\/runs$/,
      () => page.getByRole('button', { name: '开始运行', exact: true }).click(), 202)
    await page.getByRole('region', { name: '运行' }).getByText('运行成功', { exact: true }).first().waitFor()
    stage = 'inspect checks'
    await page.getByText('规则检查通过', { exact: true }).first().waitFor()
    await page.getByRole('region', { name: '规则检查' }).locator('summary').first().click()
    const report = page.getByRole('article', { name: '检查报告明细' })
    const rule = report.locator('details').filter({ has: page.locator('summary', { hasText: 'measurement_policy_satisfied' }) })
    await rule.locator('summary').click()
    await rule.getByText('期望值', { exact: true }).waitFor()
    stage = 'download result'
    const result = page.getByRole('list', { name: '正式成果' }).getByRole('listitem')
      .filter({ has: page.getByText('分区统计', { exact: true }) })
    const [download] = await Promise.all([
      page.waitForEvent('download'), result.getByRole('link', { name: '下载原文件' }).click(),
    ])
    assert.equal(await download.failure(), null)
    await download.saveAs(process.argv[5])
    const body = await readFile(process.argv[5], 'utf8')
    const [header, ...rows] = body.trimEnd().split(/\r?\n/)
    assert.equal(header, 'zone_id,assignment_status,count,source_feature_ids')
    const counts = Object.fromEntries(rows.map(line => {
      const [zone, , count] = line.split(',', 3)
      return [zone || 'unassigned', Number(count)]
    }))
    assert.equal(rows.length, 3)
    assert.deepEqual({ ...counts, total: Object.values(counts).reduce((a, b) => a + b, 0) },
      expected.relations.intersects.counts)
    assert.deepEqual(errors, [])
    console.log(JSON.stringify({
      status: 'TECHNICAL_REHEARSAL_PASS', browser: browser.version(), method: confirmed.method,
      run_id: run.run_id, execution_status: 'SUCCEEDED', check_status: 'PASSED', counts, page_errors: errors,
    }, null, 2))
  } catch (error) {
    console.error(`Rehearsal stage: ${stage}`)
    throw error
  }
} finally {
  await browser.close()
}
