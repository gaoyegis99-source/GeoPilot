"""Run the packaged workbench on loopback and perform the technical browser rehearsal."""

from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

trial, project, browser_module, qgis = (Path(value).resolve() for value in sys.argv[1:5])
source = trial / "system-prototype-v1"
output = trial / sys.argv[5]
output.mkdir()
spec = importlib.util.spec_from_file_location("matrix", source / "scripts/install-check/run_matrix.py")
matrix = importlib.util.module_from_spec(spec)
spec.loader.exec_module(matrix)
with socket.socket() as backend_socket, socket.socket() as frontend_socket:
    for reserved in (backend_socket, frontend_socket):
        reserved.bind(("127.0.0.1", 0))
    backend_port = backend_socket.getsockname()[1]
    frontend_port = frontend_socket.getsockname()[1]
backend_url = f"http://127.0.0.1:{backend_port}"
frontend_url = f"http://127.0.0.1:{frontend_port}"
report = {"status": "TECHNICAL_REHEARSAL", "steps": []}
env = {**os.environ, "PYTHONPATH": str(source / "src"), "PYTHONDONTWRITEBYTECODE": "1",
       "GEOPILOT_API_URL": backend_url, "GEOPILOT_PLAYWRIGHT_MODULE": str(browser_module),
       "QT_QPA_PLATFORM": "offscreen", "PROJ_NETWORK": "OFF", "OPENBLAS_NUM_THREADS": "1",
       "OMP_NUM_THREADS": "1", "GDAL_NUM_THREADS": "1"}
data = output / "data"
data.mkdir()
backend = [project / ".venv/bin/python", "-m", "geopilot.api.server", "--database", data / "project.sqlite",
           "--workspace", data / "workspace", "--config", source / "config", "--qgis-process", qgis,
           "--port", str(backend_port)]
frontend = ["npm", "run", "dev", "--", "--host", "127.0.0.1", "--port", str(frontend_port), "--strictPort"]
fixtures = source / "tests/fixtures/vector"
(output / "session.json").write_text(json.dumps({
    "url": frontend_url, "fixture": str(fixtures / "road-buffer.gpkg"), "browser_module": str(browser_module),
}, indent=2) + "\n")
browser = ["node", trial / "browser-proof/browser.mjs", output]
try:
    with ExitStack() as servers:
        service = servers.enter_context(matrix.server(report, output, "backend", backend, source, env))
        matrix.wait_http(service, backend_url + "/api/methods")
        site = servers.enter_context(matrix.server(report, output, "frontend", frontend, source / "frontend", env))
        matrix.wait_http(site, frontend_url + "/api/methods")
        with (output / "browser.log").open("wb") as log, (output / "browser.stderr.log").open("wb") as error:
            finished = subprocess.run(browser, cwd=source, env=env, stdout=log, stderr=error, timeout=180)
        report["steps"].append({"name": "browser", "argv": list(map(str, browser)), "exit_code": finished.returncode})
    report["status"] = "PASS" if finished.returncode == 0 else "FAIL"
finally:
    (output / "launch.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
sys.exit(finished.returncode)
