"""Reconcile browser downloads with the independently expected counts and registered originals."""
from collections import Counter
import csv
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
import sys

root = Path(sys.argv[1]).resolve()
evidence = root / "browser-run"
browser = json.loads((evidence / "browser.log").read_bytes())
assert browser["outcome"] == "PASS" and not browser["errors"]
expected = json.loads(
    (root / "system-prototype-v1/tests/fixtures/vector/expected.json").read_bytes()
)["relations"]["intersects"]["counts"]

with sqlite3.connect((evidence / "data/project.sqlite").as_uri() + "?mode=ro", uri=True) as db:
    db.row_factory = sqlite3.Row
    runs = {row["id"]: dict(row) for row in db.execute("SELECT * FROM run")}
    assert len(runs) == 3
    assert len({(row["plan_id"], row["plan_version"]) for row in runs.values()}) == 1
    original = runs[browser["originalRun"]]
    assert (original["execution_status"], original["check_status"]) == ("CANCELLED", "NOT_CHECKED")
    assert db.execute("SELECT count(*) FROM artifact WHERE run_id = ?", (original["id"],)).fetchone()[0] == 0
    checked = []
    for label, name in (("runId", "recovery-result.csv"), ("newerId", "second-result.csv")):
        run = runs[browser[label]]
        assert (run["execution_status"], run["check_status"]) == ("SUCCEEDED", "PASSED")
        step_statuses = Counter(row["status"] for row in db.execute("SELECT status FROM run_step WHERE run_id = ?", (run["id"],)))
        assert step_statuses == {"SUCCEEDED": 7}
        artifact = db.execute(
            "SELECT id, uri FROM artifact WHERE run_id = ? AND role = 'zone_statistics'", (run["id"],)
        ).fetchone()
        registered = Path(run["workdir"]) / artifact["uri"]
        downloaded = evidence / name
        data = downloaded.read_bytes()
        assert registered.read_bytes() == data
        with downloaded.open(newline="", encoding="utf-8") as stream:
            rows = list(csv.DictReader(stream, strict=True))
        counts = {row["zone_id"] or "unassigned": int(row["count"]) for row in rows}
        counts["total"] = sum(counts.values())
        assert len(rows) == 3 and counts == expected
        checked.append({"run_id": run["id"], "artifact_id": artifact["id"], "sha256": sha256(data).hexdigest(),
                        "counts": counts, "seven_steps_passed": True})
    assert len({item["artifact_id"] for item in checked}) == 2

print(json.dumps({"status": "PASS", "cancelled_run": original["id"], "confirmed_plan": original["plan_id"],
                  "plan_version": original["plan_version"], "verified_downloads": checked}, indent=2))
